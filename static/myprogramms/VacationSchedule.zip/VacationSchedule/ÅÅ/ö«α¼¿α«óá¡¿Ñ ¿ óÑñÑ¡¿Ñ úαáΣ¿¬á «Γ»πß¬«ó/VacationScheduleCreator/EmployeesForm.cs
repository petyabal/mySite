﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace VacationScheduleCreator
{
    public partial class EmployeesForm : Form
    {
        public EmployeesForm()
        {
            InitializeComponent();
        }

        //процедура вывода сведений из таблиц базы данных
        private void EmployeesForm_Load(object sender, EventArgs e)
        {
            DB_Connection.ShowEmployees();
            dataGridViewEmployees.DataSource = DB_Connection.dtEmployees;
            dataGridViewEmployees.Columns["Табельный номер"].Visible = false;
            dataGridViewEmployees.Columns["Surname_NF"].Visible = false;
            DB_Connection.ShowAlternateList();
            dataGridViewAlternateList.DataSource = DB_Connection.dtAlternateList;
            dataGridViewAlternateList.Columns["Position_id"].Visible = false;
            DB_Connection.ShowEmployeesSickLists();
            dataGridViewEmployeesSickLists.DataSource = DB_Connection.dtEmployeesSickLists;
            dataGridViewEmployeesSickLists.Columns["Sick_list_id"].Visible = false;
        }

        //процедура обновления данных в таблицах
        void RefreshData()
        {
            DB_Connection.ShowEmployees();
            DB_Connection.ShowAlternateList();
            DB_Connection.ShowEmployeesSickLists();
        }

        //процедура показа формы с таблицей "Сотрудники"
        private void btnEmployeesDetail_Click(object sender, EventArgs e)
        {
            EmployeesDetailForm EmployeesDetail = new EmployeesDetailForm();
            EmployeesDetail.ShowEmployeesTab();
            EmployeesDetail.WindowState = FormWindowState.Maximized;
            EmployeesDetail.ShowDialog();
            RefreshData();
        }

        //процедура показа формы с таблицей "Список замещающих лиц"
        private void btnAlternateListDetail_Click(object sender, EventArgs e)
        {
            EmployeesDetailForm EmployeesDetail = new EmployeesDetailForm();
            EmployeesDetail.ShowAlternateListTab();
            EmployeesDetail.WindowState = FormWindowState.Maximized;
            EmployeesDetail.ShowDialog();
            RefreshData();
        }

        //процедура показа формы с таблицей "Больничные листы сотрудников"
        private void btnEmployeesSickListsDatail_Click(object sender, EventArgs e)
        {
            EmployeesDetailForm EmployeesDetail = new EmployeesDetailForm();
            EmployeesDetail.ShowEmployeesSickListsTab();
            EmployeesDetail.WindowState = FormWindowState.Maximized;
            EmployeesDetail.ShowDialog();
            RefreshData();
        }
    }
}
