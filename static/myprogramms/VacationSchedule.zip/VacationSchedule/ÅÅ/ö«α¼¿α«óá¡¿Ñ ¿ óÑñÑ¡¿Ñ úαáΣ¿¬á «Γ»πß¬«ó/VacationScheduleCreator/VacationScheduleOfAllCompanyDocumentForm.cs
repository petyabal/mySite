﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace VacationScheduleCreator
{
    public partial class VacationScheduleOfAllCompanyDocumentForm : Form
    {
        public VacationScheduleOfAllCompanyDocumentForm()
        {
            InitializeComponent();
        }

        //процедура загрузки данных в экранную таблицу из БД
        private void VacationScheduleOfAllCompanyDocumentForm_Load(object sender, EventArgs e)
        {
            DB_Connection.AllCompanyVacationScheduleDocument();
            dataGridViewVacationSchedule.DataSource = 
                DB_Connection.dtAllCompanyVacationScheduleDocument;
            dataGridViewVacationSchedule.Columns["Вид отпуска"].Visible = false;
        }

        //процедура формирования документа "График отпусков" (всего предприятия)
        private void btnVacationScheduleCompanyCreate_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;
            Excel.OpenExcel(Application.StartupPath + @"\CompanyVacationScheduleTemplate.xlsx");
            string Path_to_file = Application.StartupPath + @"\Excel documents\График отпусков предприятия_" +
                DateTime.Now.ToString("yyyy-MM-dd_hh-mm-ss") + ".xlsx";
            int k = -1;
            string tab = dataGridViewVacationSchedule.Rows[0].Cells[0].Value.ToString();
            for (Int32 i = 0; i < dataGridViewVacationSchedule.RowCount; i++)
            {
                if (tab == dataGridViewVacationSchedule.Rows[i].Cells[0].Value.ToString())
                    k++;
                else
                {
                    Excel.workSheet.Range[Excel.workSheet.Cells[i - k + 13, 2], Excel.workSheet.Cells[i + 13, 2]].Merge();
                    Excel.workSheet.Range[Excel.workSheet.Cells[i - k + 13, 3], Excel.workSheet.Cells[i + 13, 3]].Merge();
                    Excel.workSheet.Range[Excel.workSheet.Cells[i - k + 13, 3], Excel.workSheet.Cells[i + 13, 3]].HorizontalAlignment = Excel.excelAlign;
                    //Excel.workSheet.Range[Excel.workSheet.Cells[i - k + 13, 4], Excel.workSheet.Cells[i - k + 13, 4]].AutoFit();
                    Excel.workSheet.Range[Excel.workSheet.Cells[i - k + 13, 4], Excel.workSheet.Cells[i + 13, 4]].Merge();
                    k = 0;
                    tab = dataGridViewVacationSchedule.Rows[i].Cells[0].Value.ToString();
                }
                for (Int32 j = 1; j < dataGridViewVacationSchedule.ColumnCount - 1; j++)///
                {
                    Excel.workSheet.Cells[i + 14, j + 1].Value =
                        dataGridViewVacationSchedule.Rows[i].Cells[j].Value;
                }
            }
            for (Int32 i = 0; i < dataGridViewVacationSchedule.RowCount; i++)
                Excel.workSheet.Cells[i + 14, 1].Value = (i + 1).ToString();
            Excel.workBook.SaveAs(Path_to_file);
            MessageBox.Show("Данные успешно сохранены в файл!");
            this.Cursor = Cursors.Default;
        }

        private void VacationScheduleOfAllCompanyDocumentForm_Activated(object sender, EventArgs e)
        {
           /* for (int i = 0; i < dataGridViewVacationSchedule.RowCount; i++)
            {
                string person = dataGridViewVacationSchedule.Rows[i].Cells["Табельный номер"].
                    Value.ToString();
                string type = DB_Connection.GetVacationTypeId(
                    dataGridViewVacationSchedule.Rows[i].Cells["Вид отпуска"].Value.ToString());
                dataGridViewVacationSchedule.Rows[i].Cells["Продолжительность отпуска"].
                    Value = DB_Connection.GetSumDays(person, type);
            }*/
        }

        private void VacationScheduleOfAllCompanyDocumentForm_Shown(object sender, EventArgs e)
        {
            for (int i = 0; i < dataGridViewVacationSchedule.RowCount; i++)
            {
                string person = dataGridViewVacationSchedule.Rows[i].Cells["Табельный номер"].
                    Value.ToString();
                string type = DB_Connection.GetVacationTypeId(
                    dataGridViewVacationSchedule.Rows[i].Cells["Вид отпуска"].Value.ToString());
                dataGridViewVacationSchedule.Rows[i].Cells["Продолжительность отпуска"].
                    Value = DB_Connection.GetSumDays(person, type);
            }
        }
    }
}
