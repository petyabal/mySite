﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace VacationScheduleCreator
{
    //класс формы для формирования отчета "Список сотрудников, неизрасходовавших дни отпуска"
    public partial class DaysRemainReportForm : Form
    {
        public DaysRemainReportForm()
        {
            InitializeComponent();
        }

        //процедура загрузки информации из таблиц БД
        private void DaysRemainReportForm_Load(object sender, EventArgs e)
        {
                DB_Connection.ShowDaysRemainReport();
                dataGridViewDaysRemainReport.DataSource = DB_Connection.dtDaysRemainReport;
        }

        //процедура экспорта данных для отчета в Эксель файл
        private void btnDaysRemainReportCreate_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;
            Excel.OpenExcel(Application.StartupPath + @"\DaysRemainReportTemplate.xlsx");
            string Path_to_file = Application.StartupPath + @"\Excel documents\" +
            "Неизрасходованные дни отпусков " + DateTime.Now.ToString("yyyy-MM-dd_hh-mm-ss") + ".xlsx";            
            Excel.workSheet.Cells[1, 6].Value = DateTime.Now.ToString("dd.MM.yyyy");
            for (Int32 i = 0; i < dataGridViewDaysRemainReport.RowCount; i++)
            {             
                for (Int32 j = 0; j < dataGridViewDaysRemainReport.ColumnCount; j++)
                {
                    Excel.workSheet.Cells[i + 5, j + 2].Value = 
                        dataGridViewDaysRemainReport.Rows[i].Cells[j].Value;
                }                
            }
            for (Int32 i = 0; i < dataGridViewDaysRemainReport.RowCount; i++)
                Excel.workSheet.Cells[i + 5, 1].Value = (i + 1).ToString();
            Excel.workBook.SaveAs(Path_to_file);
            MessageBox.Show("Данные успешно сохранены в файл!");
            this.Cursor = Cursors.Default;
        }
    }
}
