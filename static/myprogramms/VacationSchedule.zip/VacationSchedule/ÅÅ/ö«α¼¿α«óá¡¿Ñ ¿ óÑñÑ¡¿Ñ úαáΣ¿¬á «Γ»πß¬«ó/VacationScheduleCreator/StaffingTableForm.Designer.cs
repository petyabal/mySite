﻿namespace VacationScheduleCreator
{
    partial class StaffingTableForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(StaffingTableForm));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tableLayoutPanel_AllForm = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel_Company = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBoxCompany = new System.Windows.Forms.PictureBox();
            this.lblCompany = new System.Windows.Forms.Label();
            this.tableLayoutPanel_StaffingTable = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel_Working_field = new System.Windows.Forms.TableLayoutPanel();
            this.groupBoxStaffingTableStatus = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanelStaffingTableStatus = new System.Windows.Forms.TableLayoutPanel();
            this.dataGridViewStaffingTableStatus = new System.Windows.Forms.DataGridView();
            this.btnStaffingTableStatusDatail = new System.Windows.Forms.Button();
            this.groupBoxStaffingTable = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanelStaffingTable = new System.Windows.Forms.TableLayoutPanel();
            this.dataGridViewStaffingTable = new System.Windows.Forms.DataGridView();
            this.btnStaffingTableDetail = new System.Windows.Forms.Button();
            this.groupBoxStructuralUnits = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanelStructuralUnits = new System.Windows.Forms.TableLayoutPanel();
            this.dataGridViewStructuralUnits = new System.Windows.Forms.DataGridView();
            this.btnStructuralUnitsDetail = new System.Windows.Forms.Button();
            this.tableLayoutPanel_WindowHeader = new System.Windows.Forms.TableLayoutPanel();
            this.lblStaffingTable = new System.Windows.Forms.Label();
            this.tableLayoutPanel_Programm = new System.Windows.Forms.TableLayoutPanel();
            this.lblProgramm = new System.Windows.Forms.Label();
            this.tableLayoutPanel_AllForm.SuspendLayout();
            this.tableLayoutPanel_Company.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCompany)).BeginInit();
            this.tableLayoutPanel_StaffingTable.SuspendLayout();
            this.tableLayoutPanel_Working_field.SuspendLayout();
            this.groupBoxStaffingTableStatus.SuspendLayout();
            this.tableLayoutPanelStaffingTableStatus.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewStaffingTableStatus)).BeginInit();
            this.groupBoxStaffingTable.SuspendLayout();
            this.tableLayoutPanelStaffingTable.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewStaffingTable)).BeginInit();
            this.groupBoxStructuralUnits.SuspendLayout();
            this.tableLayoutPanelStructuralUnits.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewStructuralUnits)).BeginInit();
            this.tableLayoutPanel_WindowHeader.SuspendLayout();
            this.tableLayoutPanel_Programm.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel_AllForm
            // 
            this.tableLayoutPanel_AllForm.ColumnCount = 1;
            this.tableLayoutPanel_AllForm.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_AllForm.Controls.Add(this.tableLayoutPanel_Company, 0, 1);
            this.tableLayoutPanel_AllForm.Controls.Add(this.tableLayoutPanel_StaffingTable, 0, 2);
            this.tableLayoutPanel_AllForm.Controls.Add(this.tableLayoutPanel_Programm, 0, 0);
            this.tableLayoutPanel_AllForm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_AllForm.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel_AllForm.Name = "tableLayoutPanel_AllForm";
            this.tableLayoutPanel_AllForm.RowCount = 3;
            this.tableLayoutPanel_AllForm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel_AllForm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tableLayoutPanel_AllForm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 75F));
            this.tableLayoutPanel_AllForm.Size = new System.Drawing.Size(784, 497);
            this.tableLayoutPanel_AllForm.TabIndex = 9;
            // 
            // tableLayoutPanel_Company
            // 
            this.tableLayoutPanel_Company.BackColor = System.Drawing.SystemColors.HotTrack;
            this.tableLayoutPanel_Company.ColumnCount = 2;
            this.tableLayoutPanel_Company.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel_Company.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.tableLayoutPanel_Company.Controls.Add(this.pictureBoxCompany, 0, 1);
            this.tableLayoutPanel_Company.Controls.Add(this.lblCompany, 1, 1);
            this.tableLayoutPanel_Company.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Company.Location = new System.Drawing.Point(3, 52);
            this.tableLayoutPanel_Company.Name = "tableLayoutPanel_Company";
            this.tableLayoutPanel_Company.RowCount = 3;
            this.tableLayoutPanel_Company.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel_Company.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tableLayoutPanel_Company.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel_Company.Size = new System.Drawing.Size(778, 68);
            this.tableLayoutPanel_Company.TabIndex = 7;
            // 
            // pictureBoxCompany
            // 
            this.pictureBoxCompany.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxCompany.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxCompany.Image")));
            this.pictureBoxCompany.Location = new System.Drawing.Point(3, 6);
            this.pictureBoxCompany.Name = "pictureBoxCompany";
            this.pictureBoxCompany.Size = new System.Drawing.Size(227, 55);
            this.pictureBoxCompany.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxCompany.TabIndex = 3;
            this.pictureBoxCompany.TabStop = false;
            // 
            // lblCompany
            // 
            this.lblCompany.AutoSize = true;
            this.lblCompany.BackColor = System.Drawing.SystemColors.HotTrack;
            this.lblCompany.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCompany.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblCompany.ForeColor = System.Drawing.Color.White;
            this.lblCompany.Location = new System.Drawing.Point(236, 3);
            this.lblCompany.Name = "lblCompany";
            this.lblCompany.Size = new System.Drawing.Size(539, 61);
            this.lblCompany.TabIndex = 2;
            this.lblCompany.Text = "МЕЖРЕГИОНАЛЬНАЯ РАСПРЕДЕЛИТЕЛЬНАЯ СЕТЕВАЯ КОМПАНИЯ СЕВЕРО-ЗАПАДА";
            this.lblCompany.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel_StaffingTable
            // 
            this.tableLayoutPanel_StaffingTable.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPanel_StaffingTable.ColumnCount = 1;
            this.tableLayoutPanel_StaffingTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_StaffingTable.Controls.Add(this.tableLayoutPanel_Working_field, 0, 1);
            this.tableLayoutPanel_StaffingTable.Controls.Add(this.tableLayoutPanel_WindowHeader, 0, 0);
            this.tableLayoutPanel_StaffingTable.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_StaffingTable.Location = new System.Drawing.Point(3, 126);
            this.tableLayoutPanel_StaffingTable.Name = "tableLayoutPanel_StaffingTable";
            this.tableLayoutPanel_StaffingTable.RowCount = 2;
            this.tableLayoutPanel_StaffingTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12F));
            this.tableLayoutPanel_StaffingTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 88F));
            this.tableLayoutPanel_StaffingTable.Size = new System.Drawing.Size(778, 368);
            this.tableLayoutPanel_StaffingTable.TabIndex = 6;
            // 
            // tableLayoutPanel_Working_field
            // 
            this.tableLayoutPanel_Working_field.ColumnCount = 2;
            this.tableLayoutPanel_Working_field.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel_Working_field.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel_Working_field.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel_Working_field.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel_Working_field.Controls.Add(this.groupBoxStaffingTableStatus, 0, 1);
            this.tableLayoutPanel_Working_field.Controls.Add(this.groupBoxStaffingTable, 0, 0);
            this.tableLayoutPanel_Working_field.Controls.Add(this.groupBoxStructuralUnits, 1, 1);
            this.tableLayoutPanel_Working_field.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Working_field.Location = new System.Drawing.Point(3, 44);
            this.tableLayoutPanel_Working_field.Margin = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.tableLayoutPanel_Working_field.Name = "tableLayoutPanel_Working_field";
            this.tableLayoutPanel_Working_field.RowCount = 2;
            this.tableLayoutPanel_Working_field.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Working_field.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Working_field.Size = new System.Drawing.Size(772, 321);
            this.tableLayoutPanel_Working_field.TabIndex = 7;
            // 
            // groupBoxStaffingTableStatus
            // 
            this.groupBoxStaffingTableStatus.Controls.Add(this.tableLayoutPanelStaffingTableStatus);
            this.groupBoxStaffingTableStatus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxStaffingTableStatus.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBoxStaffingTableStatus.ForeColor = System.Drawing.Color.White;
            this.groupBoxStaffingTableStatus.Location = new System.Drawing.Point(3, 163);
            this.groupBoxStaffingTableStatus.Name = "groupBoxStaffingTableStatus";
            this.groupBoxStaffingTableStatus.Size = new System.Drawing.Size(302, 155);
            this.groupBoxStaffingTableStatus.TabIndex = 0;
            this.groupBoxStaffingTableStatus.TabStop = false;
            this.groupBoxStaffingTableStatus.Text = "Свойства штатного расписания:";
            // 
            // tableLayoutPanelStaffingTableStatus
            // 
            this.tableLayoutPanelStaffingTableStatus.ColumnCount = 1;
            this.tableLayoutPanelStaffingTableStatus.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelStaffingTableStatus.Controls.Add(this.dataGridViewStaffingTableStatus, 0, 0);
            this.tableLayoutPanelStaffingTableStatus.Controls.Add(this.btnStaffingTableStatusDatail, 0, 1);
            this.tableLayoutPanelStaffingTableStatus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelStaffingTableStatus.Location = new System.Drawing.Point(3, 25);
            this.tableLayoutPanelStaffingTableStatus.Name = "tableLayoutPanelStaffingTableStatus";
            this.tableLayoutPanelStaffingTableStatus.RowCount = 2;
            this.tableLayoutPanelStaffingTableStatus.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 75F));
            this.tableLayoutPanelStaffingTableStatus.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanelStaffingTableStatus.Size = new System.Drawing.Size(296, 127);
            this.tableLayoutPanelStaffingTableStatus.TabIndex = 0;
            // 
            // dataGridViewStaffingTableStatus
            // 
            this.dataGridViewStaffingTableStatus.AllowUserToAddRows = false;
            this.dataGridViewStaffingTableStatus.AllowUserToDeleteRows = false;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.AntiqueWhite;
            this.dataGridViewStaffingTableStatus.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle7;
            this.dataGridViewStaffingTableStatus.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewStaffingTableStatus.DefaultCellStyle = dataGridViewCellStyle8;
            this.dataGridViewStaffingTableStatus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewStaffingTableStatus.Location = new System.Drawing.Point(3, 3);
            this.dataGridViewStaffingTableStatus.MultiSelect = false;
            this.dataGridViewStaffingTableStatus.Name = "dataGridViewStaffingTableStatus";
            this.dataGridViewStaffingTableStatus.ReadOnly = true;
            this.dataGridViewStaffingTableStatus.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewStaffingTableStatus.Size = new System.Drawing.Size(290, 89);
            this.dataGridViewStaffingTableStatus.TabIndex = 0;
            // 
            // btnStaffingTableStatusDatail
            // 
            this.btnStaffingTableStatusDatail.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnStaffingTableStatusDatail.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnStaffingTableStatusDatail.Location = new System.Drawing.Point(3, 98);
            this.btnStaffingTableStatusDatail.Name = "btnStaffingTableStatusDatail";
            this.btnStaffingTableStatusDatail.Size = new System.Drawing.Size(290, 26);
            this.btnStaffingTableStatusDatail.TabIndex = 1;
            this.btnStaffingTableStatusDatail.Text = "Перейти к свойствам штатного расписания";
            this.btnStaffingTableStatusDatail.UseVisualStyleBackColor = false;
            this.btnStaffingTableStatusDatail.Click += new System.EventHandler(this.btnStaffingTableStatusDetail_Click);
            // 
            // groupBoxStaffingTable
            // 
            this.tableLayoutPanel_Working_field.SetColumnSpan(this.groupBoxStaffingTable, 2);
            this.groupBoxStaffingTable.Controls.Add(this.tableLayoutPanelStaffingTable);
            this.groupBoxStaffingTable.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxStaffingTable.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBoxStaffingTable.ForeColor = System.Drawing.Color.White;
            this.groupBoxStaffingTable.Location = new System.Drawing.Point(3, 3);
            this.groupBoxStaffingTable.Name = "groupBoxStaffingTable";
            this.groupBoxStaffingTable.Size = new System.Drawing.Size(766, 154);
            this.groupBoxStaffingTable.TabIndex = 3;
            this.groupBoxStaffingTable.TabStop = false;
            this.groupBoxStaffingTable.Text = "Штатное расписание:";
            // 
            // tableLayoutPanelStaffingTable
            // 
            this.tableLayoutPanelStaffingTable.ColumnCount = 1;
            this.tableLayoutPanelStaffingTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelStaffingTable.Controls.Add(this.dataGridViewStaffingTable, 0, 0);
            this.tableLayoutPanelStaffingTable.Controls.Add(this.btnStaffingTableDetail, 0, 1);
            this.tableLayoutPanelStaffingTable.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelStaffingTable.Location = new System.Drawing.Point(3, 25);
            this.tableLayoutPanelStaffingTable.Name = "tableLayoutPanelStaffingTable";
            this.tableLayoutPanelStaffingTable.RowCount = 2;
            this.tableLayoutPanelStaffingTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 75F));
            this.tableLayoutPanelStaffingTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanelStaffingTable.Size = new System.Drawing.Size(760, 126);
            this.tableLayoutPanelStaffingTable.TabIndex = 0;
            // 
            // dataGridViewStaffingTable
            // 
            this.dataGridViewStaffingTable.AllowUserToAddRows = false;
            this.dataGridViewStaffingTable.AllowUserToDeleteRows = false;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.AntiqueWhite;
            this.dataGridViewStaffingTable.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle9;
            this.dataGridViewStaffingTable.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewStaffingTable.DefaultCellStyle = dataGridViewCellStyle10;
            this.dataGridViewStaffingTable.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewStaffingTable.Location = new System.Drawing.Point(3, 3);
            this.dataGridViewStaffingTable.MultiSelect = false;
            this.dataGridViewStaffingTable.Name = "dataGridViewStaffingTable";
            this.dataGridViewStaffingTable.ReadOnly = true;
            this.dataGridViewStaffingTable.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewStaffingTable.Size = new System.Drawing.Size(754, 88);
            this.dataGridViewStaffingTable.TabIndex = 0;
            // 
            // btnStaffingTableDetail
            // 
            this.btnStaffingTableDetail.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnStaffingTableDetail.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnStaffingTableDetail.Location = new System.Drawing.Point(3, 97);
            this.btnStaffingTableDetail.Name = "btnStaffingTableDetail";
            this.btnStaffingTableDetail.Size = new System.Drawing.Size(754, 26);
            this.btnStaffingTableDetail.TabIndex = 1;
            this.btnStaffingTableDetail.Text = "Перейти к штатному расписанию";
            this.btnStaffingTableDetail.UseVisualStyleBackColor = false;
            this.btnStaffingTableDetail.Click += new System.EventHandler(this.btnStaffingTableDetail_Click);
            // 
            // groupBoxStructuralUnits
            // 
            this.groupBoxStructuralUnits.Controls.Add(this.tableLayoutPanelStructuralUnits);
            this.groupBoxStructuralUnits.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxStructuralUnits.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBoxStructuralUnits.ForeColor = System.Drawing.Color.White;
            this.groupBoxStructuralUnits.Location = new System.Drawing.Point(311, 163);
            this.groupBoxStructuralUnits.Name = "groupBoxStructuralUnits";
            this.groupBoxStructuralUnits.Size = new System.Drawing.Size(458, 155);
            this.groupBoxStructuralUnits.TabIndex = 4;
            this.groupBoxStructuralUnits.TabStop = false;
            this.groupBoxStructuralUnits.Text = "Структурные подразделения:";
            // 
            // tableLayoutPanelStructuralUnits
            // 
            this.tableLayoutPanelStructuralUnits.ColumnCount = 1;
            this.tableLayoutPanelStructuralUnits.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelStructuralUnits.Controls.Add(this.dataGridViewStructuralUnits, 0, 0);
            this.tableLayoutPanelStructuralUnits.Controls.Add(this.btnStructuralUnitsDetail, 0, 1);
            this.tableLayoutPanelStructuralUnits.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelStructuralUnits.Location = new System.Drawing.Point(3, 25);
            this.tableLayoutPanelStructuralUnits.Name = "tableLayoutPanelStructuralUnits";
            this.tableLayoutPanelStructuralUnits.RowCount = 2;
            this.tableLayoutPanelStructuralUnits.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 75F));
            this.tableLayoutPanelStructuralUnits.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanelStructuralUnits.Size = new System.Drawing.Size(452, 127);
            this.tableLayoutPanelStructuralUnits.TabIndex = 0;
            // 
            // dataGridViewStructuralUnits
            // 
            this.dataGridViewStructuralUnits.AllowUserToAddRows = false;
            this.dataGridViewStructuralUnits.AllowUserToDeleteRows = false;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.AntiqueWhite;
            this.dataGridViewStructuralUnits.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle11;
            this.dataGridViewStructuralUnits.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewStructuralUnits.DefaultCellStyle = dataGridViewCellStyle12;
            this.dataGridViewStructuralUnits.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewStructuralUnits.Location = new System.Drawing.Point(3, 3);
            this.dataGridViewStructuralUnits.MultiSelect = false;
            this.dataGridViewStructuralUnits.Name = "dataGridViewStructuralUnits";
            this.dataGridViewStructuralUnits.ReadOnly = true;
            this.dataGridViewStructuralUnits.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewStructuralUnits.Size = new System.Drawing.Size(446, 89);
            this.dataGridViewStructuralUnits.TabIndex = 0;
            // 
            // btnStructuralUnitsDetail
            // 
            this.btnStructuralUnitsDetail.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnStructuralUnitsDetail.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnStructuralUnitsDetail.Location = new System.Drawing.Point(3, 98);
            this.btnStructuralUnitsDetail.Name = "btnStructuralUnitsDetail";
            this.btnStructuralUnitsDetail.Size = new System.Drawing.Size(446, 26);
            this.btnStructuralUnitsDetail.TabIndex = 1;
            this.btnStructuralUnitsDetail.Text = "Перейти к структурным подразделениям";
            this.btnStructuralUnitsDetail.UseVisualStyleBackColor = false;
            this.btnStructuralUnitsDetail.Click += new System.EventHandler(this.btnStructuralUnitsDetail_Click);
            // 
            // tableLayoutPanel_WindowHeader
            // 
            this.tableLayoutPanel_WindowHeader.ColumnCount = 4;
            this.tableLayoutPanel_WindowHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_WindowHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_WindowHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_WindowHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_WindowHeader.Controls.Add(this.lblStaffingTable, 0, 0);
            this.tableLayoutPanel_WindowHeader.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_WindowHeader.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel_WindowHeader.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.tableLayoutPanel_WindowHeader.Name = "tableLayoutPanel_WindowHeader";
            this.tableLayoutPanel_WindowHeader.RowCount = 1;
            this.tableLayoutPanel_WindowHeader.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_WindowHeader.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 41F));
            this.tableLayoutPanel_WindowHeader.Size = new System.Drawing.Size(772, 41);
            this.tableLayoutPanel_WindowHeader.TabIndex = 6;
            // 
            // lblStaffingTable
            // 
            this.lblStaffingTable.AutoSize = true;
            this.tableLayoutPanel_WindowHeader.SetColumnSpan(this.lblStaffingTable, 4);
            this.lblStaffingTable.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblStaffingTable.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblStaffingTable.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblStaffingTable.Location = new System.Drawing.Point(3, 0);
            this.lblStaffingTable.Name = "lblStaffingTable";
            this.lblStaffingTable.Size = new System.Drawing.Size(766, 41);
            this.lblStaffingTable.TabIndex = 19;
            this.lblStaffingTable.Text = "ШТАТНОЕ РАСПИСАНИЕ";
            this.lblStaffingTable.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel_Programm
            // 
            this.tableLayoutPanel_Programm.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPanel_Programm.ColumnCount = 1;
            this.tableLayoutPanel_Programm.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Programm.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Programm.Controls.Add(this.lblProgramm, 0, 0);
            this.tableLayoutPanel_Programm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Programm.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel_Programm.Name = "tableLayoutPanel_Programm";
            this.tableLayoutPanel_Programm.RowCount = 1;
            this.tableLayoutPanel_Programm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Programm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Programm.Size = new System.Drawing.Size(778, 43);
            this.tableLayoutPanel_Programm.TabIndex = 8;
            // 
            // lblProgramm
            // 
            this.lblProgramm.AutoSize = true;
            this.lblProgramm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblProgramm.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblProgramm.ForeColor = System.Drawing.Color.White;
            this.lblProgramm.Location = new System.Drawing.Point(3, 0);
            this.lblProgramm.Name = "lblProgramm";
            this.lblProgramm.Size = new System.Drawing.Size(772, 43);
            this.lblProgramm.TabIndex = 0;
            this.lblProgramm.Text = "ФОРМИРОВАНИЕ И ВЕДЕНИЕ ГРАФИКА ОТПУСКОВ СОТРУДНИКОВ";
            this.lblProgramm.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // StaffingTableForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 497);
            this.Controls.Add(this.tableLayoutPanel_AllForm);
            this.Name = "StaffingTableForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ОРГАНИЗАЦИОННАЯ СТРУКТУРА";
            this.Load += new System.EventHandler(this.StaffingTableForm_Load);
            this.tableLayoutPanel_AllForm.ResumeLayout(false);
            this.tableLayoutPanel_Company.ResumeLayout(false);
            this.tableLayoutPanel_Company.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCompany)).EndInit();
            this.tableLayoutPanel_StaffingTable.ResumeLayout(false);
            this.tableLayoutPanel_Working_field.ResumeLayout(false);
            this.groupBoxStaffingTableStatus.ResumeLayout(false);
            this.tableLayoutPanelStaffingTableStatus.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewStaffingTableStatus)).EndInit();
            this.groupBoxStaffingTable.ResumeLayout(false);
            this.tableLayoutPanelStaffingTable.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewStaffingTable)).EndInit();
            this.groupBoxStructuralUnits.ResumeLayout(false);
            this.tableLayoutPanelStructuralUnits.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewStructuralUnits)).EndInit();
            this.tableLayoutPanel_WindowHeader.ResumeLayout(false);
            this.tableLayoutPanel_WindowHeader.PerformLayout();
            this.tableLayoutPanel_Programm.ResumeLayout(false);
            this.tableLayoutPanel_Programm.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_AllForm;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Company;
        private System.Windows.Forms.PictureBox pictureBoxCompany;
        private System.Windows.Forms.Label lblCompany;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_StaffingTable;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Working_field;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_WindowHeader;
        private System.Windows.Forms.Label lblStaffingTable;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Programm;
        private System.Windows.Forms.Label lblProgramm;
        private System.Windows.Forms.GroupBox groupBoxStaffingTableStatus;
        private System.Windows.Forms.GroupBox groupBoxStaffingTable;
        private System.Windows.Forms.GroupBox groupBoxStructuralUnits;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelStaffingTableStatus;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelStaffingTable;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelStructuralUnits;
        private System.Windows.Forms.DataGridView dataGridViewStaffingTableStatus;
        private System.Windows.Forms.Button btnStaffingTableStatusDatail;
        private System.Windows.Forms.DataGridView dataGridViewStaffingTable;
        private System.Windows.Forms.Button btnStaffingTableDetail;
        private System.Windows.Forms.DataGridView dataGridViewStructuralUnits;
        private System.Windows.Forms.Button btnStructuralUnitsDetail;
    }
}