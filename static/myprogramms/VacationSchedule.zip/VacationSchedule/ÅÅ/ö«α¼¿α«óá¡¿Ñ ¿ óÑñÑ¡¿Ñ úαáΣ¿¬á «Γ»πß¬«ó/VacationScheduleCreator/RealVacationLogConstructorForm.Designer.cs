﻿namespace VacationScheduleCreator
{
    partial class RealVacationLogConstructorForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RealVacationLogConstructorForm));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tableLayoutPanel_AllForm = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel_Company = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBoxCompany = new System.Windows.Forms.PictureBox();
            this.lblCompany = new System.Windows.Forms.Label();
            this.tableLayoutPanel_Employees = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel_Working_field = new System.Windows.Forms.TableLayoutPanel();
            this.btnDeleteVacation = new System.Windows.Forms.Button();
            this.groupBoxVacationStatus = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanelVacationStatus = new System.Windows.Forms.TableLayoutPanel();
            this.dataGridViewVacationStatus = new System.Windows.Forms.DataGridView();
            this.btnAddVacation = new System.Windows.Forms.Button();
            this.btnChangeVacation = new System.Windows.Forms.Button();
            this.groupBoxSpendingOfVacation = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanelSpendingOfVacation = new System.Windows.Forms.TableLayoutPanel();
            this.dataGridViewRealVacationSpending = new System.Windows.Forms.DataGridView();
            this.groupBoxEmployees = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanelEmployees = new System.Windows.Forms.TableLayoutPanel();
            this.comboBoxEmployee = new System.Windows.Forms.ComboBox();
            this.groupBoxStructuralUnits = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanelStructuralUnits = new System.Windows.Forms.TableLayoutPanel();
            this.comboBoxStructuralUnit = new System.Windows.Forms.ComboBox();
            this.groupBoxVacationSchedule = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanelDaysRemainReport = new System.Windows.Forms.TableLayoutPanel();
            this.dataGridViewVacationSchedule = new System.Windows.Forms.DataGridView();
            this.tableLayoutPanel_WindowHeader = new System.Windows.Forms.TableLayoutPanel();
            this.llblRealVacationLogConstructorForm = new System.Windows.Forms.Label();
            this.tableLayoutPanel_Programm = new System.Windows.Forms.TableLayoutPanel();
            this.lblProgramm = new System.Windows.Forms.Label();
            this.tableLayoutPanel_AllForm.SuspendLayout();
            this.tableLayoutPanel_Company.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCompany)).BeginInit();
            this.tableLayoutPanel_Employees.SuspendLayout();
            this.tableLayoutPanel_Working_field.SuspendLayout();
            this.groupBoxVacationStatus.SuspendLayout();
            this.tableLayoutPanelVacationStatus.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVacationStatus)).BeginInit();
            this.groupBoxSpendingOfVacation.SuspendLayout();
            this.tableLayoutPanelSpendingOfVacation.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewRealVacationSpending)).BeginInit();
            this.groupBoxEmployees.SuspendLayout();
            this.tableLayoutPanelEmployees.SuspendLayout();
            this.groupBoxStructuralUnits.SuspendLayout();
            this.tableLayoutPanelStructuralUnits.SuspendLayout();
            this.groupBoxVacationSchedule.SuspendLayout();
            this.tableLayoutPanelDaysRemainReport.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVacationSchedule)).BeginInit();
            this.tableLayoutPanel_WindowHeader.SuspendLayout();
            this.tableLayoutPanel_Programm.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel_AllForm
            // 
            this.tableLayoutPanel_AllForm.ColumnCount = 1;
            this.tableLayoutPanel_AllForm.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_AllForm.Controls.Add(this.tableLayoutPanel_Company, 0, 1);
            this.tableLayoutPanel_AllForm.Controls.Add(this.tableLayoutPanel_Employees, 0, 2);
            this.tableLayoutPanel_AllForm.Controls.Add(this.tableLayoutPanel_Programm, 0, 0);
            this.tableLayoutPanel_AllForm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_AllForm.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel_AllForm.Name = "tableLayoutPanel_AllForm";
            this.tableLayoutPanel_AllForm.RowCount = 3;
            this.tableLayoutPanel_AllForm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel_AllForm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tableLayoutPanel_AllForm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 75F));
            this.tableLayoutPanel_AllForm.Size = new System.Drawing.Size(784, 497);
            this.tableLayoutPanel_AllForm.TabIndex = 11;
            // 
            // tableLayoutPanel_Company
            // 
            this.tableLayoutPanel_Company.BackColor = System.Drawing.SystemColors.HotTrack;
            this.tableLayoutPanel_Company.ColumnCount = 2;
            this.tableLayoutPanel_Company.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel_Company.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.tableLayoutPanel_Company.Controls.Add(this.pictureBoxCompany, 0, 1);
            this.tableLayoutPanel_Company.Controls.Add(this.lblCompany, 1, 1);
            this.tableLayoutPanel_Company.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Company.Location = new System.Drawing.Point(3, 52);
            this.tableLayoutPanel_Company.Name = "tableLayoutPanel_Company";
            this.tableLayoutPanel_Company.RowCount = 3;
            this.tableLayoutPanel_Company.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel_Company.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tableLayoutPanel_Company.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel_Company.Size = new System.Drawing.Size(778, 68);
            this.tableLayoutPanel_Company.TabIndex = 7;
            // 
            // pictureBoxCompany
            // 
            this.pictureBoxCompany.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxCompany.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxCompany.Image")));
            this.pictureBoxCompany.Location = new System.Drawing.Point(3, 6);
            this.pictureBoxCompany.Name = "pictureBoxCompany";
            this.pictureBoxCompany.Size = new System.Drawing.Size(227, 55);
            this.pictureBoxCompany.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxCompany.TabIndex = 3;
            this.pictureBoxCompany.TabStop = false;
            // 
            // lblCompany
            // 
            this.lblCompany.AutoSize = true;
            this.lblCompany.BackColor = System.Drawing.SystemColors.HotTrack;
            this.lblCompany.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCompany.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblCompany.ForeColor = System.Drawing.Color.White;
            this.lblCompany.Location = new System.Drawing.Point(236, 3);
            this.lblCompany.Name = "lblCompany";
            this.lblCompany.Size = new System.Drawing.Size(539, 61);
            this.lblCompany.TabIndex = 2;
            this.lblCompany.Text = "МЕЖРЕГИОНАЛЬНАЯ РАСПРЕДЕЛИТЕЛЬНАЯ СЕТЕВАЯ КОМПАНИЯ СЕВЕРО-ЗАПАДА";
            this.lblCompany.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel_Employees
            // 
            this.tableLayoutPanel_Employees.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPanel_Employees.ColumnCount = 1;
            this.tableLayoutPanel_Employees.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_Employees.Controls.Add(this.tableLayoutPanel_Working_field, 0, 1);
            this.tableLayoutPanel_Employees.Controls.Add(this.tableLayoutPanel_WindowHeader, 0, 0);
            this.tableLayoutPanel_Employees.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Employees.Location = new System.Drawing.Point(3, 126);
            this.tableLayoutPanel_Employees.Name = "tableLayoutPanel_Employees";
            this.tableLayoutPanel_Employees.RowCount = 2;
            this.tableLayoutPanel_Employees.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12F));
            this.tableLayoutPanel_Employees.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 88F));
            this.tableLayoutPanel_Employees.Size = new System.Drawing.Size(778, 368);
            this.tableLayoutPanel_Employees.TabIndex = 6;
            // 
            // tableLayoutPanel_Working_field
            // 
            this.tableLayoutPanel_Working_field.ColumnCount = 3;
            this.tableLayoutPanel_Working_field.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel_Working_field.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel_Working_field.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel_Working_field.Controls.Add(this.btnDeleteVacation, 2, 3);
            this.tableLayoutPanel_Working_field.Controls.Add(this.groupBoxVacationStatus, 1, 0);
            this.tableLayoutPanel_Working_field.Controls.Add(this.btnAddVacation, 0, 3);
            this.tableLayoutPanel_Working_field.Controls.Add(this.btnChangeVacation, 0, 3);
            this.tableLayoutPanel_Working_field.Controls.Add(this.groupBoxSpendingOfVacation, 0, 2);
            this.tableLayoutPanel_Working_field.Controls.Add(this.groupBoxEmployees, 0, 1);
            this.tableLayoutPanel_Working_field.Controls.Add(this.groupBoxStructuralUnits, 0, 0);
            this.tableLayoutPanel_Working_field.Controls.Add(this.groupBoxVacationSchedule, 1, 2);
            this.tableLayoutPanel_Working_field.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Working_field.Location = new System.Drawing.Point(3, 44);
            this.tableLayoutPanel_Working_field.Margin = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.tableLayoutPanel_Working_field.Name = "tableLayoutPanel_Working_field";
            this.tableLayoutPanel_Working_field.RowCount = 4;
            this.tableLayoutPanel_Working_field.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tableLayoutPanel_Working_field.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tableLayoutPanel_Working_field.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_Working_field.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel_Working_field.Size = new System.Drawing.Size(772, 321);
            this.tableLayoutPanel_Working_field.TabIndex = 7;
            // 
            // btnDeleteVacation
            // 
            this.btnDeleteVacation.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnDeleteVacation.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnDeleteVacation.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnDeleteVacation.ForeColor = System.Drawing.Color.White;
            this.btnDeleteVacation.Location = new System.Drawing.Point(517, 289);
            this.btnDeleteVacation.Name = "btnDeleteVacation";
            this.btnDeleteVacation.Size = new System.Drawing.Size(252, 29);
            this.btnDeleteVacation.TabIndex = 9;
            this.btnDeleteVacation.Text = "Удалить отпуск";
            this.btnDeleteVacation.UseVisualStyleBackColor = false;
            this.btnDeleteVacation.Click += new System.EventHandler(this.btnDeleteVacation_Click);
            // 
            // groupBoxVacationStatus
            // 
            this.tableLayoutPanel_Working_field.SetColumnSpan(this.groupBoxVacationStatus, 2);
            this.groupBoxVacationStatus.Controls.Add(this.tableLayoutPanelVacationStatus);
            this.groupBoxVacationStatus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxVacationStatus.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBoxVacationStatus.ForeColor = System.Drawing.Color.White;
            this.groupBoxVacationStatus.Location = new System.Drawing.Point(260, 3);
            this.groupBoxVacationStatus.Name = "groupBoxVacationStatus";
            this.tableLayoutPanel_Working_field.SetRowSpan(this.groupBoxVacationStatus, 2);
            this.groupBoxVacationStatus.Size = new System.Drawing.Size(509, 114);
            this.groupBoxVacationStatus.TabIndex = 8;
            this.groupBoxVacationStatus.TabStop = false;
            this.groupBoxVacationStatus.Text = "Сведения о графике отпусков:";
            // 
            // tableLayoutPanelVacationStatus
            // 
            this.tableLayoutPanelVacationStatus.ColumnCount = 1;
            this.tableLayoutPanelVacationStatus.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelVacationStatus.Controls.Add(this.dataGridViewVacationStatus, 0, 0);
            this.tableLayoutPanelVacationStatus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelVacationStatus.Location = new System.Drawing.Point(3, 22);
            this.tableLayoutPanelVacationStatus.Name = "tableLayoutPanelVacationStatus";
            this.tableLayoutPanelVacationStatus.RowCount = 1;
            this.tableLayoutPanelVacationStatus.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelVacationStatus.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 93F));
            this.tableLayoutPanelVacationStatus.Size = new System.Drawing.Size(503, 89);
            this.tableLayoutPanelVacationStatus.TabIndex = 0;
            // 
            // dataGridViewVacationStatus
            // 
            this.dataGridViewVacationStatus.AllowUserToAddRows = false;
            this.dataGridViewVacationStatus.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.AntiqueWhite;
            this.dataGridViewVacationStatus.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewVacationStatus.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewVacationStatus.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewVacationStatus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewVacationStatus.Location = new System.Drawing.Point(3, 3);
            this.dataGridViewVacationStatus.MultiSelect = false;
            this.dataGridViewVacationStatus.Name = "dataGridViewVacationStatus";
            this.dataGridViewVacationStatus.ReadOnly = true;
            this.dataGridViewVacationStatus.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewVacationStatus.Size = new System.Drawing.Size(497, 83);
            this.dataGridViewVacationStatus.TabIndex = 0;
            // 
            // btnAddVacation
            // 
            this.btnAddVacation.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnAddVacation.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnAddVacation.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnAddVacation.ForeColor = System.Drawing.Color.White;
            this.btnAddVacation.Location = new System.Drawing.Point(3, 289);
            this.btnAddVacation.Name = "btnAddVacation";
            this.btnAddVacation.Size = new System.Drawing.Size(251, 29);
            this.btnAddVacation.TabIndex = 7;
            this.btnAddVacation.Text = "Добавить отпуск";
            this.btnAddVacation.UseVisualStyleBackColor = false;
            this.btnAddVacation.Click += new System.EventHandler(this.btnAddVacation_Click);
            // 
            // btnChangeVacation
            // 
            this.btnChangeVacation.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnChangeVacation.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnChangeVacation.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnChangeVacation.ForeColor = System.Drawing.Color.White;
            this.btnChangeVacation.Location = new System.Drawing.Point(260, 289);
            this.btnChangeVacation.Name = "btnChangeVacation";
            this.btnChangeVacation.Size = new System.Drawing.Size(251, 29);
            this.btnChangeVacation.TabIndex = 6;
            this.btnChangeVacation.Text = "Редактировать отпуск";
            this.btnChangeVacation.UseVisualStyleBackColor = false;
            this.btnChangeVacation.Click += new System.EventHandler(this.btnChangeVacation_Click);
            // 
            // groupBoxSpendingOfVacation
            // 
            this.groupBoxSpendingOfVacation.Controls.Add(this.tableLayoutPanelSpendingOfVacation);
            this.groupBoxSpendingOfVacation.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxSpendingOfVacation.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBoxSpendingOfVacation.ForeColor = System.Drawing.Color.White;
            this.groupBoxSpendingOfVacation.Location = new System.Drawing.Point(3, 123);
            this.groupBoxSpendingOfVacation.Name = "groupBoxSpendingOfVacation";
            this.groupBoxSpendingOfVacation.Size = new System.Drawing.Size(251, 160);
            this.groupBoxSpendingOfVacation.TabIndex = 5;
            this.groupBoxSpendingOfVacation.TabStop = false;
            this.groupBoxSpendingOfVacation.Text = "Выберите назначенный опуск:";
            // 
            // tableLayoutPanelSpendingOfVacation
            // 
            this.tableLayoutPanelSpendingOfVacation.ColumnCount = 1;
            this.tableLayoutPanelSpendingOfVacation.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelSpendingOfVacation.Controls.Add(this.dataGridViewRealVacationSpending, 0, 0);
            this.tableLayoutPanelSpendingOfVacation.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelSpendingOfVacation.Location = new System.Drawing.Point(3, 22);
            this.tableLayoutPanelSpendingOfVacation.Name = "tableLayoutPanelSpendingOfVacation";
            this.tableLayoutPanelSpendingOfVacation.RowCount = 1;
            this.tableLayoutPanelSpendingOfVacation.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelSpendingOfVacation.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 139F));
            this.tableLayoutPanelSpendingOfVacation.Size = new System.Drawing.Size(245, 135);
            this.tableLayoutPanelSpendingOfVacation.TabIndex = 0;
            // 
            // dataGridViewRealVacationSpending
            // 
            this.dataGridViewRealVacationSpending.AllowUserToAddRows = false;
            this.dataGridViewRealVacationSpending.AllowUserToDeleteRows = false;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.AntiqueWhite;
            this.dataGridViewRealVacationSpending.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridViewRealVacationSpending.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewRealVacationSpending.DefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridViewRealVacationSpending.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewRealVacationSpending.Location = new System.Drawing.Point(3, 3);
            this.dataGridViewRealVacationSpending.MultiSelect = false;
            this.dataGridViewRealVacationSpending.Name = "dataGridViewRealVacationSpending";
            this.dataGridViewRealVacationSpending.ReadOnly = true;
            this.dataGridViewRealVacationSpending.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewRealVacationSpending.Size = new System.Drawing.Size(239, 129);
            this.dataGridViewRealVacationSpending.TabIndex = 0;
            // 
            // groupBoxEmployees
            // 
            this.groupBoxEmployees.Controls.Add(this.tableLayoutPanelEmployees);
            this.groupBoxEmployees.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxEmployees.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBoxEmployees.ForeColor = System.Drawing.Color.White;
            this.groupBoxEmployees.Location = new System.Drawing.Point(3, 63);
            this.groupBoxEmployees.Name = "groupBoxEmployees";
            this.groupBoxEmployees.Size = new System.Drawing.Size(251, 54);
            this.groupBoxEmployees.TabIndex = 4;
            this.groupBoxEmployees.TabStop = false;
            this.groupBoxEmployees.Text = "Выберите сотрудника:";
            // 
            // tableLayoutPanelEmployees
            // 
            this.tableLayoutPanelEmployees.ColumnCount = 1;
            this.tableLayoutPanelEmployees.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelEmployees.Controls.Add(this.comboBoxEmployee, 0, 0);
            this.tableLayoutPanelEmployees.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelEmployees.Location = new System.Drawing.Point(3, 22);
            this.tableLayoutPanelEmployees.Name = "tableLayoutPanelEmployees";
            this.tableLayoutPanelEmployees.RowCount = 1;
            this.tableLayoutPanelEmployees.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelEmployees.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 33F));
            this.tableLayoutPanelEmployees.Size = new System.Drawing.Size(245, 29);
            this.tableLayoutPanelEmployees.TabIndex = 0;
            // 
            // comboBoxEmployee
            // 
            this.comboBoxEmployee.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBoxEmployee.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxEmployee.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBoxEmployee.FormattingEnabled = true;
            this.comboBoxEmployee.Location = new System.Drawing.Point(3, 3);
            this.comboBoxEmployee.Name = "comboBoxEmployee";
            this.comboBoxEmployee.Size = new System.Drawing.Size(239, 28);
            this.comboBoxEmployee.TabIndex = 1;
            this.comboBoxEmployee.SelectedValueChanged += new System.EventHandler(this.comboBoxEmployee_SelectedValueChanged);
            // 
            // groupBoxStructuralUnits
            // 
            this.groupBoxStructuralUnits.Controls.Add(this.tableLayoutPanelStructuralUnits);
            this.groupBoxStructuralUnits.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxStructuralUnits.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBoxStructuralUnits.ForeColor = System.Drawing.Color.White;
            this.groupBoxStructuralUnits.Location = new System.Drawing.Point(3, 3);
            this.groupBoxStructuralUnits.Name = "groupBoxStructuralUnits";
            this.groupBoxStructuralUnits.Size = new System.Drawing.Size(251, 54);
            this.groupBoxStructuralUnits.TabIndex = 3;
            this.groupBoxStructuralUnits.TabStop = false;
            this.groupBoxStructuralUnits.Text = "Выберите отдел:";
            // 
            // tableLayoutPanelStructuralUnits
            // 
            this.tableLayoutPanelStructuralUnits.ColumnCount = 1;
            this.tableLayoutPanelStructuralUnits.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelStructuralUnits.Controls.Add(this.comboBoxStructuralUnit, 0, 0);
            this.tableLayoutPanelStructuralUnits.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelStructuralUnits.Location = new System.Drawing.Point(3, 22);
            this.tableLayoutPanelStructuralUnits.Name = "tableLayoutPanelStructuralUnits";
            this.tableLayoutPanelStructuralUnits.RowCount = 1;
            this.tableLayoutPanelStructuralUnits.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelStructuralUnits.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 33F));
            this.tableLayoutPanelStructuralUnits.Size = new System.Drawing.Size(245, 29);
            this.tableLayoutPanelStructuralUnits.TabIndex = 0;
            // 
            // comboBoxStructuralUnit
            // 
            this.comboBoxStructuralUnit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBoxStructuralUnit.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxStructuralUnit.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBoxStructuralUnit.FormattingEnabled = true;
            this.comboBoxStructuralUnit.Location = new System.Drawing.Point(3, 3);
            this.comboBoxStructuralUnit.Name = "comboBoxStructuralUnit";
            this.comboBoxStructuralUnit.Size = new System.Drawing.Size(239, 28);
            this.comboBoxStructuralUnit.TabIndex = 0;
            this.comboBoxStructuralUnit.SelectedValueChanged += new System.EventHandler(this.comboBoxStructuralUnit_SelectedValueChanged);
            // 
            // groupBoxVacationSchedule
            // 
            this.tableLayoutPanel_Working_field.SetColumnSpan(this.groupBoxVacationSchedule, 2);
            this.groupBoxVacationSchedule.Controls.Add(this.tableLayoutPanelDaysRemainReport);
            this.groupBoxVacationSchedule.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxVacationSchedule.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBoxVacationSchedule.ForeColor = System.Drawing.Color.White;
            this.groupBoxVacationSchedule.Location = new System.Drawing.Point(260, 123);
            this.groupBoxVacationSchedule.Name = "groupBoxVacationSchedule";
            this.groupBoxVacationSchedule.Size = new System.Drawing.Size(509, 160);
            this.groupBoxVacationSchedule.TabIndex = 2;
            this.groupBoxVacationSchedule.TabStop = false;
            this.groupBoxVacationSchedule.Text = "Фактические отпуска сотрудников:";
            // 
            // tableLayoutPanelDaysRemainReport
            // 
            this.tableLayoutPanelDaysRemainReport.ColumnCount = 1;
            this.tableLayoutPanelDaysRemainReport.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelDaysRemainReport.Controls.Add(this.dataGridViewVacationSchedule, 0, 0);
            this.tableLayoutPanelDaysRemainReport.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelDaysRemainReport.Location = new System.Drawing.Point(3, 22);
            this.tableLayoutPanelDaysRemainReport.Name = "tableLayoutPanelDaysRemainReport";
            this.tableLayoutPanelDaysRemainReport.RowCount = 1;
            this.tableLayoutPanelDaysRemainReport.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelDaysRemainReport.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 139F));
            this.tableLayoutPanelDaysRemainReport.Size = new System.Drawing.Size(503, 135);
            this.tableLayoutPanelDaysRemainReport.TabIndex = 0;
            // 
            // dataGridViewVacationSchedule
            // 
            this.dataGridViewVacationSchedule.AllowUserToAddRows = false;
            this.dataGridViewVacationSchedule.AllowUserToDeleteRows = false;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.AntiqueWhite;
            this.dataGridViewVacationSchedule.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridViewVacationSchedule.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewVacationSchedule.DefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridViewVacationSchedule.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewVacationSchedule.Location = new System.Drawing.Point(3, 3);
            this.dataGridViewVacationSchedule.MultiSelect = false;
            this.dataGridViewVacationSchedule.Name = "dataGridViewVacationSchedule";
            this.dataGridViewVacationSchedule.ReadOnly = true;
            this.dataGridViewVacationSchedule.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewVacationSchedule.Size = new System.Drawing.Size(497, 129);
            this.dataGridViewVacationSchedule.TabIndex = 0;
            // 
            // tableLayoutPanel_WindowHeader
            // 
            this.tableLayoutPanel_WindowHeader.ColumnCount = 4;
            this.tableLayoutPanel_WindowHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_WindowHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_WindowHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_WindowHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_WindowHeader.Controls.Add(this.llblRealVacationLogConstructorForm, 0, 0);
            this.tableLayoutPanel_WindowHeader.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_WindowHeader.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel_WindowHeader.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.tableLayoutPanel_WindowHeader.Name = "tableLayoutPanel_WindowHeader";
            this.tableLayoutPanel_WindowHeader.RowCount = 1;
            this.tableLayoutPanel_WindowHeader.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_WindowHeader.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 41F));
            this.tableLayoutPanel_WindowHeader.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 41F));
            this.tableLayoutPanel_WindowHeader.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 41F));
            this.tableLayoutPanel_WindowHeader.Size = new System.Drawing.Size(772, 41);
            this.tableLayoutPanel_WindowHeader.TabIndex = 6;
            // 
            // llblRealVacationLogConstructorForm
            // 
            this.llblRealVacationLogConstructorForm.AutoSize = true;
            this.tableLayoutPanel_WindowHeader.SetColumnSpan(this.llblRealVacationLogConstructorForm, 4);
            this.llblRealVacationLogConstructorForm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.llblRealVacationLogConstructorForm.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.llblRealVacationLogConstructorForm.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.llblRealVacationLogConstructorForm.Location = new System.Drawing.Point(3, 0);
            this.llblRealVacationLogConstructorForm.Name = "llblRealVacationLogConstructorForm";
            this.llblRealVacationLogConstructorForm.Size = new System.Drawing.Size(766, 41);
            this.llblRealVacationLogConstructorForm.TabIndex = 19;
            this.llblRealVacationLogConstructorForm.Text = "ФОРМИРОВАНИЕ ЖУРНАЛА ВЕДЕНИЯ ОТПУСКОВ";
            this.llblRealVacationLogConstructorForm.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel_Programm
            // 
            this.tableLayoutPanel_Programm.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPanel_Programm.ColumnCount = 1;
            this.tableLayoutPanel_Programm.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Programm.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Programm.Controls.Add(this.lblProgramm, 0, 0);
            this.tableLayoutPanel_Programm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Programm.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel_Programm.Name = "tableLayoutPanel_Programm";
            this.tableLayoutPanel_Programm.RowCount = 1;
            this.tableLayoutPanel_Programm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Programm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Programm.Size = new System.Drawing.Size(778, 43);
            this.tableLayoutPanel_Programm.TabIndex = 8;
            // 
            // lblProgramm
            // 
            this.lblProgramm.AutoSize = true;
            this.lblProgramm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblProgramm.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblProgramm.ForeColor = System.Drawing.Color.White;
            this.lblProgramm.Location = new System.Drawing.Point(3, 0);
            this.lblProgramm.Name = "lblProgramm";
            this.lblProgramm.Size = new System.Drawing.Size(772, 43);
            this.lblProgramm.TabIndex = 0;
            this.lblProgramm.Text = "ФОРМИРОВАНИЕ И ВЕДЕНИЕ ГРАФИКА ОТПУСКОВ СОТРУДНИКОВ";
            this.lblProgramm.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // RealVacationLogConstructorForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 497);
            this.Controls.Add(this.tableLayoutPanel_AllForm);
            this.Name = "RealVacationLogConstructorForm";
            this.Text = "КОНСТРУКТОР ЖУРНАЛА ВЕДЕНИЯ ОТПУСКОВ";
            this.Load += new System.EventHandler(this.RealVacationLogConstructorForm_Load);
            this.tableLayoutPanel_AllForm.ResumeLayout(false);
            this.tableLayoutPanel_Company.ResumeLayout(false);
            this.tableLayoutPanel_Company.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCompany)).EndInit();
            this.tableLayoutPanel_Employees.ResumeLayout(false);
            this.tableLayoutPanel_Working_field.ResumeLayout(false);
            this.groupBoxVacationStatus.ResumeLayout(false);
            this.tableLayoutPanelVacationStatus.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVacationStatus)).EndInit();
            this.groupBoxSpendingOfVacation.ResumeLayout(false);
            this.tableLayoutPanelSpendingOfVacation.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewRealVacationSpending)).EndInit();
            this.groupBoxEmployees.ResumeLayout(false);
            this.tableLayoutPanelEmployees.ResumeLayout(false);
            this.groupBoxStructuralUnits.ResumeLayout(false);
            this.tableLayoutPanelStructuralUnits.ResumeLayout(false);
            this.groupBoxVacationSchedule.ResumeLayout(false);
            this.tableLayoutPanelDaysRemainReport.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVacationSchedule)).EndInit();
            this.tableLayoutPanel_WindowHeader.ResumeLayout(false);
            this.tableLayoutPanel_WindowHeader.PerformLayout();
            this.tableLayoutPanel_Programm.ResumeLayout(false);
            this.tableLayoutPanel_Programm.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_AllForm;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Company;
        private System.Windows.Forms.PictureBox pictureBoxCompany;
        private System.Windows.Forms.Label lblCompany;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Employees;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Working_field;
        private System.Windows.Forms.Button btnDeleteVacation;
        private System.Windows.Forms.GroupBox groupBoxVacationStatus;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelVacationStatus;
        private System.Windows.Forms.DataGridView dataGridViewVacationStatus;
        private System.Windows.Forms.Button btnAddVacation;
        private System.Windows.Forms.Button btnChangeVacation;
        private System.Windows.Forms.GroupBox groupBoxSpendingOfVacation;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelSpendingOfVacation;
        private System.Windows.Forms.DataGridView dataGridViewRealVacationSpending;
        private System.Windows.Forms.GroupBox groupBoxEmployees;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelEmployees;
        private System.Windows.Forms.ComboBox comboBoxEmployee;
        private System.Windows.Forms.GroupBox groupBoxStructuralUnits;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelStructuralUnits;
        private System.Windows.Forms.ComboBox comboBoxStructuralUnit;
        private System.Windows.Forms.GroupBox groupBoxVacationSchedule;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelDaysRemainReport;
        private System.Windows.Forms.DataGridView dataGridViewVacationSchedule;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_WindowHeader;
        private System.Windows.Forms.Label llblRealVacationLogConstructorForm;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Programm;
        private System.Windows.Forms.Label lblProgramm;

    }
}