﻿namespace VacationScheduleCreator
{
    partial class StaffingTableDetailForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(StaffingTableDetailForm));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tableLayoutPanel_AllForm = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel_Company = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBoxCompany = new System.Windows.Forms.PictureBox();
            this.lblCompany = new System.Windows.Forms.Label();
            this.tableLayoutPanel_Employees = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel_Working_field = new System.Windows.Forms.TableLayoutPanel();
            this.tabControlStaffingTable = new System.Windows.Forms.TabControl();
            this.tabPageStaffingTable = new System.Windows.Forms.TabPage();
            this.tableLayoutPanelStaffingTable = new System.Windows.Forms.TableLayoutPanel();
            this.btnDeleteFromStaffingTable = new System.Windows.Forms.Button();
            this.btnAddToStaffingTable = new System.Windows.Forms.Button();
            this.dataGridViewStaffingTable = new System.Windows.Forms.DataGridView();
            this.btnChangeInStaffingTable = new System.Windows.Forms.Button();
            this.tabPageStaffingTableStatus = new System.Windows.Forms.TabPage();
            this.tableLayoutPanelStaffingTableStatus = new System.Windows.Forms.TableLayoutPanel();
            this.btnChangeStaffingTableStatus = new System.Windows.Forms.Button();
            this.dataGridViewStaffingTableStatus = new System.Windows.Forms.DataGridView();
            this.tabPageStructuralUnits = new System.Windows.Forms.TabPage();
            this.tableLayoutPanelStructuralUnits = new System.Windows.Forms.TableLayoutPanel();
            this.btnAddStructuralUnit = new System.Windows.Forms.Button();
            this.btnDeleteStructralUnit = new System.Windows.Forms.Button();
            this.btnChangeStructuralUnit = new System.Windows.Forms.Button();
            this.dataGridViewStructuralUnits = new System.Windows.Forms.DataGridView();
            this.tableLayoutPanel_WindowHeader = new System.Windows.Forms.TableLayoutPanel();
            this.lblEmployeesInformation = new System.Windows.Forms.Label();
            this.tableLayoutPanel_Programm = new System.Windows.Forms.TableLayoutPanel();
            this.lblProgramm = new System.Windows.Forms.Label();
            this.tableLayoutPanel_AllForm.SuspendLayout();
            this.tableLayoutPanel_Company.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCompany)).BeginInit();
            this.tableLayoutPanel_Employees.SuspendLayout();
            this.tableLayoutPanel_Working_field.SuspendLayout();
            this.tabControlStaffingTable.SuspendLayout();
            this.tabPageStaffingTable.SuspendLayout();
            this.tableLayoutPanelStaffingTable.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewStaffingTable)).BeginInit();
            this.tabPageStaffingTableStatus.SuspendLayout();
            this.tableLayoutPanelStaffingTableStatus.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewStaffingTableStatus)).BeginInit();
            this.tabPageStructuralUnits.SuspendLayout();
            this.tableLayoutPanelStructuralUnits.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewStructuralUnits)).BeginInit();
            this.tableLayoutPanel_WindowHeader.SuspendLayout();
            this.tableLayoutPanel_Programm.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel_AllForm
            // 
            this.tableLayoutPanel_AllForm.ColumnCount = 1;
            this.tableLayoutPanel_AllForm.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_AllForm.Controls.Add(this.tableLayoutPanel_Company, 0, 1);
            this.tableLayoutPanel_AllForm.Controls.Add(this.tableLayoutPanel_Employees, 0, 2);
            this.tableLayoutPanel_AllForm.Controls.Add(this.tableLayoutPanel_Programm, 0, 0);
            this.tableLayoutPanel_AllForm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_AllForm.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel_AllForm.Name = "tableLayoutPanel_AllForm";
            this.tableLayoutPanel_AllForm.RowCount = 3;
            this.tableLayoutPanel_AllForm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel_AllForm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tableLayoutPanel_AllForm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 75F));
            this.tableLayoutPanel_AllForm.Size = new System.Drawing.Size(784, 497);
            this.tableLayoutPanel_AllForm.TabIndex = 8;
            // 
            // tableLayoutPanel_Company
            // 
            this.tableLayoutPanel_Company.BackColor = System.Drawing.SystemColors.HotTrack;
            this.tableLayoutPanel_Company.ColumnCount = 2;
            this.tableLayoutPanel_Company.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel_Company.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.tableLayoutPanel_Company.Controls.Add(this.pictureBoxCompany, 0, 1);
            this.tableLayoutPanel_Company.Controls.Add(this.lblCompany, 1, 1);
            this.tableLayoutPanel_Company.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Company.Location = new System.Drawing.Point(3, 52);
            this.tableLayoutPanel_Company.Name = "tableLayoutPanel_Company";
            this.tableLayoutPanel_Company.RowCount = 3;
            this.tableLayoutPanel_Company.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel_Company.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tableLayoutPanel_Company.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel_Company.Size = new System.Drawing.Size(778, 68);
            this.tableLayoutPanel_Company.TabIndex = 7;
            // 
            // pictureBoxCompany
            // 
            this.pictureBoxCompany.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxCompany.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxCompany.Image")));
            this.pictureBoxCompany.Location = new System.Drawing.Point(3, 6);
            this.pictureBoxCompany.Name = "pictureBoxCompany";
            this.pictureBoxCompany.Size = new System.Drawing.Size(227, 55);
            this.pictureBoxCompany.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxCompany.TabIndex = 3;
            this.pictureBoxCompany.TabStop = false;
            // 
            // lblCompany
            // 
            this.lblCompany.AutoSize = true;
            this.lblCompany.BackColor = System.Drawing.SystemColors.HotTrack;
            this.lblCompany.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCompany.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblCompany.ForeColor = System.Drawing.Color.White;
            this.lblCompany.Location = new System.Drawing.Point(236, 3);
            this.lblCompany.Name = "lblCompany";
            this.lblCompany.Size = new System.Drawing.Size(539, 61);
            this.lblCompany.TabIndex = 2;
            this.lblCompany.Text = "МЕЖРЕГИОНАЛЬНАЯ РАСПРЕДЕЛИТЕЛЬНАЯ СЕТЕВАЯ КОМПАНИЯ СЕВЕРО-ЗАПАДА";
            this.lblCompany.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel_Employees
            // 
            this.tableLayoutPanel_Employees.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPanel_Employees.ColumnCount = 1;
            this.tableLayoutPanel_Employees.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_Employees.Controls.Add(this.tableLayoutPanel_Working_field, 0, 1);
            this.tableLayoutPanel_Employees.Controls.Add(this.tableLayoutPanel_WindowHeader, 0, 0);
            this.tableLayoutPanel_Employees.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Employees.Location = new System.Drawing.Point(3, 126);
            this.tableLayoutPanel_Employees.Name = "tableLayoutPanel_Employees";
            this.tableLayoutPanel_Employees.RowCount = 2;
            this.tableLayoutPanel_Employees.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12F));
            this.tableLayoutPanel_Employees.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 88F));
            this.tableLayoutPanel_Employees.Size = new System.Drawing.Size(778, 368);
            this.tableLayoutPanel_Employees.TabIndex = 6;
            // 
            // tableLayoutPanel_Working_field
            // 
            this.tableLayoutPanel_Working_field.ColumnCount = 1;
            this.tableLayoutPanel_Working_field.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_Working_field.Controls.Add(this.tabControlStaffingTable, 0, 0);
            this.tableLayoutPanel_Working_field.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Working_field.Location = new System.Drawing.Point(3, 44);
            this.tableLayoutPanel_Working_field.Margin = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.tableLayoutPanel_Working_field.Name = "tableLayoutPanel_Working_field";
            this.tableLayoutPanel_Working_field.RowCount = 1;
            this.tableLayoutPanel_Working_field.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_Working_field.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 321F));
            this.tableLayoutPanel_Working_field.Size = new System.Drawing.Size(772, 321);
            this.tableLayoutPanel_Working_field.TabIndex = 7;
            // 
            // tabControlStaffingTable
            // 
            this.tabControlStaffingTable.Controls.Add(this.tabPageStaffingTable);
            this.tabControlStaffingTable.Controls.Add(this.tabPageStaffingTableStatus);
            this.tabControlStaffingTable.Controls.Add(this.tabPageStructuralUnits);
            this.tabControlStaffingTable.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlStaffingTable.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tabControlStaffingTable.Location = new System.Drawing.Point(3, 3);
            this.tabControlStaffingTable.Name = "tabControlStaffingTable";
            this.tabControlStaffingTable.SelectedIndex = 0;
            this.tabControlStaffingTable.Size = new System.Drawing.Size(766, 315);
            this.tabControlStaffingTable.TabIndex = 2;
            // 
            // tabPageStaffingTable
            // 
            this.tabPageStaffingTable.Controls.Add(this.tableLayoutPanelStaffingTable);
            this.tabPageStaffingTable.Location = new System.Drawing.Point(4, 32);
            this.tabPageStaffingTable.Name = "tabPageStaffingTable";
            this.tabPageStaffingTable.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageStaffingTable.Size = new System.Drawing.Size(758, 279);
            this.tabPageStaffingTable.TabIndex = 0;
            this.tabPageStaffingTable.Text = "Штатное расписание";
            this.tabPageStaffingTable.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanelStaffingTable
            // 
            this.tableLayoutPanelStaffingTable.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPanelStaffingTable.ColumnCount = 3;
            this.tableLayoutPanelStaffingTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanelStaffingTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanelStaffingTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanelStaffingTable.Controls.Add(this.btnDeleteFromStaffingTable, 2, 1);
            this.tableLayoutPanelStaffingTable.Controls.Add(this.btnAddToStaffingTable, 0, 1);
            this.tableLayoutPanelStaffingTable.Controls.Add(this.dataGridViewStaffingTable, 0, 0);
            this.tableLayoutPanelStaffingTable.Controls.Add(this.btnChangeInStaffingTable, 1, 1);
            this.tableLayoutPanelStaffingTable.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelStaffingTable.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanelStaffingTable.Name = "tableLayoutPanelStaffingTable";
            this.tableLayoutPanelStaffingTable.RowCount = 2;
            this.tableLayoutPanelStaffingTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 88F));
            this.tableLayoutPanelStaffingTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12F));
            this.tableLayoutPanelStaffingTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanelStaffingTable.Size = new System.Drawing.Size(752, 273);
            this.tableLayoutPanelStaffingTable.TabIndex = 0;
            // 
            // btnDeleteFromStaffingTable
            // 
            this.btnDeleteFromStaffingTable.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnDeleteFromStaffingTable.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnDeleteFromStaffingTable.ForeColor = System.Drawing.Color.White;
            this.btnDeleteFromStaffingTable.Location = new System.Drawing.Point(503, 243);
            this.btnDeleteFromStaffingTable.Name = "btnDeleteFromStaffingTable";
            this.btnDeleteFromStaffingTable.Size = new System.Drawing.Size(246, 27);
            this.btnDeleteFromStaffingTable.TabIndex = 8;
            this.btnDeleteFromStaffingTable.Text = "Удалить запись из штатного расписания";
            this.btnDeleteFromStaffingTable.UseVisualStyleBackColor = false;
            this.btnDeleteFromStaffingTable.Click += new System.EventHandler(this.btnDeleteFromStaffingTable_Click);
            // 
            // btnAddToStaffingTable
            // 
            this.btnAddToStaffingTable.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnAddToStaffingTable.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnAddToStaffingTable.ForeColor = System.Drawing.Color.White;
            this.btnAddToStaffingTable.Location = new System.Drawing.Point(3, 243);
            this.btnAddToStaffingTable.Name = "btnAddToStaffingTable";
            this.btnAddToStaffingTable.Size = new System.Drawing.Size(244, 27);
            this.btnAddToStaffingTable.TabIndex = 6;
            this.btnAddToStaffingTable.Text = "Добавить запись в штатное расписание";
            this.btnAddToStaffingTable.UseVisualStyleBackColor = false;
            this.btnAddToStaffingTable.Click += new System.EventHandler(this.btnAddToStaffingTable_Click);
            // 
            // dataGridViewStaffingTable
            // 
            this.dataGridViewStaffingTable.AllowUserToAddRows = false;
            this.dataGridViewStaffingTable.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.AntiqueWhite;
            this.dataGridViewStaffingTable.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewStaffingTable.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tableLayoutPanelStaffingTable.SetColumnSpan(this.dataGridViewStaffingTable, 3);
            this.dataGridViewStaffingTable.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewStaffingTable.Location = new System.Drawing.Point(3, 3);
            this.dataGridViewStaffingTable.MultiSelect = false;
            this.dataGridViewStaffingTable.Name = "dataGridViewStaffingTable";
            this.dataGridViewStaffingTable.ReadOnly = true;
            this.dataGridViewStaffingTable.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewStaffingTable.Size = new System.Drawing.Size(746, 234);
            this.dataGridViewStaffingTable.TabIndex = 4;
            // 
            // btnChangeInStaffingTable
            // 
            this.btnChangeInStaffingTable.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnChangeInStaffingTable.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnChangeInStaffingTable.ForeColor = System.Drawing.Color.White;
            this.btnChangeInStaffingTable.Location = new System.Drawing.Point(253, 243);
            this.btnChangeInStaffingTable.Name = "btnChangeInStaffingTable";
            this.btnChangeInStaffingTable.Size = new System.Drawing.Size(244, 27);
            this.btnChangeInStaffingTable.TabIndex = 5;
            this.btnChangeInStaffingTable.Text = "Редактировать запись";
            this.btnChangeInStaffingTable.UseVisualStyleBackColor = false;
            this.btnChangeInStaffingTable.Click += new System.EventHandler(this.btnChangeInStaffingTable_Click);
            // 
            // tabPageStaffingTableStatus
            // 
            this.tabPageStaffingTableStatus.Controls.Add(this.tableLayoutPanelStaffingTableStatus);
            this.tabPageStaffingTableStatus.Location = new System.Drawing.Point(4, 32);
            this.tabPageStaffingTableStatus.Name = "tabPageStaffingTableStatus";
            this.tabPageStaffingTableStatus.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageStaffingTableStatus.Size = new System.Drawing.Size(758, 279);
            this.tabPageStaffingTableStatus.TabIndex = 1;
            this.tabPageStaffingTableStatus.Text = "Свойства штатного расписания";
            this.tabPageStaffingTableStatus.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanelStaffingTableStatus
            // 
            this.tableLayoutPanelStaffingTableStatus.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPanelStaffingTableStatus.ColumnCount = 1;
            this.tableLayoutPanelStaffingTableStatus.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelStaffingTableStatus.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanelStaffingTableStatus.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanelStaffingTableStatus.Controls.Add(this.btnChangeStaffingTableStatus, 0, 1);
            this.tableLayoutPanelStaffingTableStatus.Controls.Add(this.dataGridViewStaffingTableStatus, 0, 0);
            this.tableLayoutPanelStaffingTableStatus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelStaffingTableStatus.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanelStaffingTableStatus.Name = "tableLayoutPanelStaffingTableStatus";
            this.tableLayoutPanelStaffingTableStatus.RowCount = 2;
            this.tableLayoutPanelStaffingTableStatus.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 88F));
            this.tableLayoutPanelStaffingTableStatus.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12F));
            this.tableLayoutPanelStaffingTableStatus.Size = new System.Drawing.Size(752, 273);
            this.tableLayoutPanelStaffingTableStatus.TabIndex = 0;
            // 
            // btnChangeStaffingTableStatus
            // 
            this.btnChangeStaffingTableStatus.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnChangeStaffingTableStatus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnChangeStaffingTableStatus.ForeColor = System.Drawing.Color.White;
            this.btnChangeStaffingTableStatus.Location = new System.Drawing.Point(3, 243);
            this.btnChangeStaffingTableStatus.Name = "btnChangeStaffingTableStatus";
            this.btnChangeStaffingTableStatus.Size = new System.Drawing.Size(746, 27);
            this.btnChangeStaffingTableStatus.TabIndex = 7;
            this.btnChangeStaffingTableStatus.Text = "Редактировать штатное расписание";
            this.btnChangeStaffingTableStatus.UseVisualStyleBackColor = false;
            this.btnChangeStaffingTableStatus.Click += new System.EventHandler(this.btnChangeStaffingTableStatus_Click);
            // 
            // dataGridViewStaffingTableStatus
            // 
            this.dataGridViewStaffingTableStatus.AllowUserToAddRows = false;
            this.dataGridViewStaffingTableStatus.AllowUserToDeleteRows = false;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.AntiqueWhite;
            this.dataGridViewStaffingTableStatus.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewStaffingTableStatus.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewStaffingTableStatus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewStaffingTableStatus.Location = new System.Drawing.Point(3, 3);
            this.dataGridViewStaffingTableStatus.MultiSelect = false;
            this.dataGridViewStaffingTableStatus.Name = "dataGridViewStaffingTableStatus";
            this.dataGridViewStaffingTableStatus.ReadOnly = true;
            this.dataGridViewStaffingTableStatus.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewStaffingTableStatus.Size = new System.Drawing.Size(746, 234);
            this.dataGridViewStaffingTableStatus.TabIndex = 5;
            // 
            // tabPageStructuralUnits
            // 
            this.tabPageStructuralUnits.Controls.Add(this.tableLayoutPanelStructuralUnits);
            this.tabPageStructuralUnits.Location = new System.Drawing.Point(4, 32);
            this.tabPageStructuralUnits.Name = "tabPageStructuralUnits";
            this.tabPageStructuralUnits.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageStructuralUnits.Size = new System.Drawing.Size(758, 279);
            this.tabPageStructuralUnits.TabIndex = 2;
            this.tabPageStructuralUnits.Text = "Список структурных подразделений";
            this.tabPageStructuralUnits.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanelStructuralUnits
            // 
            this.tableLayoutPanelStructuralUnits.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPanelStructuralUnits.ColumnCount = 3;
            this.tableLayoutPanelStructuralUnits.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanelStructuralUnits.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanelStructuralUnits.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanelStructuralUnits.Controls.Add(this.btnAddStructuralUnit, 0, 1);
            this.tableLayoutPanelStructuralUnits.Controls.Add(this.btnDeleteStructralUnit, 0, 1);
            this.tableLayoutPanelStructuralUnits.Controls.Add(this.btnChangeStructuralUnit, 0, 1);
            this.tableLayoutPanelStructuralUnits.Controls.Add(this.dataGridViewStructuralUnits, 0, 0);
            this.tableLayoutPanelStructuralUnits.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelStructuralUnits.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanelStructuralUnits.Name = "tableLayoutPanelStructuralUnits";
            this.tableLayoutPanelStructuralUnits.RowCount = 2;
            this.tableLayoutPanelStructuralUnits.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 88F));
            this.tableLayoutPanelStructuralUnits.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12F));
            this.tableLayoutPanelStructuralUnits.Size = new System.Drawing.Size(752, 273);
            this.tableLayoutPanelStructuralUnits.TabIndex = 0;
            // 
            // btnAddStructuralUnit
            // 
            this.btnAddStructuralUnit.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnAddStructuralUnit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnAddStructuralUnit.ForeColor = System.Drawing.Color.White;
            this.btnAddStructuralUnit.Location = new System.Drawing.Point(3, 243);
            this.btnAddStructuralUnit.Name = "btnAddStructuralUnit";
            this.btnAddStructuralUnit.Size = new System.Drawing.Size(244, 27);
            this.btnAddStructuralUnit.TabIndex = 12;
            this.btnAddStructuralUnit.Text = "Добавить структурное подразделение";
            this.btnAddStructuralUnit.UseVisualStyleBackColor = false;
            this.btnAddStructuralUnit.Click += new System.EventHandler(this.btnAddStructuralUnit_Click);
            // 
            // btnDeleteStructralUnit
            // 
            this.btnDeleteStructralUnit.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnDeleteStructralUnit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnDeleteStructralUnit.ForeColor = System.Drawing.Color.White;
            this.btnDeleteStructralUnit.Location = new System.Drawing.Point(503, 243);
            this.btnDeleteStructralUnit.Name = "btnDeleteStructralUnit";
            this.btnDeleteStructralUnit.Size = new System.Drawing.Size(246, 27);
            this.btnDeleteStructralUnit.TabIndex = 11;
            this.btnDeleteStructralUnit.Text = "Удалить структурное подразделение";
            this.btnDeleteStructralUnit.UseVisualStyleBackColor = false;
            this.btnDeleteStructralUnit.Click += new System.EventHandler(this.btnDeleteStructralUnit_Click);
            // 
            // btnChangeStructuralUnit
            // 
            this.btnChangeStructuralUnit.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnChangeStructuralUnit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnChangeStructuralUnit.ForeColor = System.Drawing.Color.White;
            this.btnChangeStructuralUnit.Location = new System.Drawing.Point(253, 243);
            this.btnChangeStructuralUnit.Name = "btnChangeStructuralUnit";
            this.btnChangeStructuralUnit.Size = new System.Drawing.Size(244, 27);
            this.btnChangeStructuralUnit.TabIndex = 10;
            this.btnChangeStructuralUnit.Text = "Редактировать  подразделение";
            this.btnChangeStructuralUnit.UseVisualStyleBackColor = false;
            this.btnChangeStructuralUnit.Click += new System.EventHandler(this.btnChangeStructuralUnit_Click);
            // 
            // dataGridViewStructuralUnits
            // 
            this.dataGridViewStructuralUnits.AllowUserToAddRows = false;
            this.dataGridViewStructuralUnits.AllowUserToDeleteRows = false;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.AntiqueWhite;
            this.dataGridViewStructuralUnits.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridViewStructuralUnits.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tableLayoutPanelStructuralUnits.SetColumnSpan(this.dataGridViewStructuralUnits, 3);
            this.dataGridViewStructuralUnits.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewStructuralUnits.Location = new System.Drawing.Point(3, 3);
            this.dataGridViewStructuralUnits.MultiSelect = false;
            this.dataGridViewStructuralUnits.Name = "dataGridViewStructuralUnits";
            this.dataGridViewStructuralUnits.ReadOnly = true;
            this.dataGridViewStructuralUnits.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewStructuralUnits.Size = new System.Drawing.Size(746, 234);
            this.dataGridViewStructuralUnits.TabIndex = 6;
            // 
            // tableLayoutPanel_WindowHeader
            // 
            this.tableLayoutPanel_WindowHeader.ColumnCount = 4;
            this.tableLayoutPanel_WindowHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_WindowHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_WindowHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_WindowHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_WindowHeader.Controls.Add(this.lblEmployeesInformation, 0, 0);
            this.tableLayoutPanel_WindowHeader.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_WindowHeader.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel_WindowHeader.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.tableLayoutPanel_WindowHeader.Name = "tableLayoutPanel_WindowHeader";
            this.tableLayoutPanel_WindowHeader.RowCount = 1;
            this.tableLayoutPanel_WindowHeader.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_WindowHeader.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 41F));
            this.tableLayoutPanel_WindowHeader.Size = new System.Drawing.Size(772, 41);
            this.tableLayoutPanel_WindowHeader.TabIndex = 6;
            // 
            // lblEmployeesInformation
            // 
            this.lblEmployeesInformation.AutoSize = true;
            this.tableLayoutPanel_WindowHeader.SetColumnSpan(this.lblEmployeesInformation, 4);
            this.lblEmployeesInformation.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblEmployeesInformation.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblEmployeesInformation.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblEmployeesInformation.Location = new System.Drawing.Point(3, 0);
            this.lblEmployeesInformation.Name = "lblEmployeesInformation";
            this.lblEmployeesInformation.Size = new System.Drawing.Size(766, 41);
            this.lblEmployeesInformation.TabIndex = 19;
            this.lblEmployeesInformation.Text = "ШТАТНОЕ РАСПИСАНИЕ";
            this.lblEmployeesInformation.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel_Programm
            // 
            this.tableLayoutPanel_Programm.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPanel_Programm.ColumnCount = 1;
            this.tableLayoutPanel_Programm.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Programm.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Programm.Controls.Add(this.lblProgramm, 0, 0);
            this.tableLayoutPanel_Programm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Programm.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel_Programm.Name = "tableLayoutPanel_Programm";
            this.tableLayoutPanel_Programm.RowCount = 1;
            this.tableLayoutPanel_Programm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Programm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Programm.Size = new System.Drawing.Size(778, 43);
            this.tableLayoutPanel_Programm.TabIndex = 8;
            // 
            // lblProgramm
            // 
            this.lblProgramm.AutoSize = true;
            this.lblProgramm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblProgramm.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblProgramm.ForeColor = System.Drawing.Color.White;
            this.lblProgramm.Location = new System.Drawing.Point(3, 0);
            this.lblProgramm.Name = "lblProgramm";
            this.lblProgramm.Size = new System.Drawing.Size(772, 43);
            this.lblProgramm.TabIndex = 0;
            this.lblProgramm.Text = "ФОРМИРОВАНИЕ И ВЕДЕНИЕ ГРАФИКА ОТПУСКОВ СОТРУДНИКОВ";
            this.lblProgramm.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // StaffingTableDetailForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 497);
            this.Controls.Add(this.tableLayoutPanel_AllForm);
            this.Name = "StaffingTableDetailForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ФОРМИРОВАНИЕ ОРГАНИЗЦИОННОЙ СТРУКТУРЫ";
            this.Load += new System.EventHandler(this.StaffingTableDetailForm_Load);
            this.tableLayoutPanel_AllForm.ResumeLayout(false);
            this.tableLayoutPanel_Company.ResumeLayout(false);
            this.tableLayoutPanel_Company.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCompany)).EndInit();
            this.tableLayoutPanel_Employees.ResumeLayout(false);
            this.tableLayoutPanel_Working_field.ResumeLayout(false);
            this.tabControlStaffingTable.ResumeLayout(false);
            this.tabPageStaffingTable.ResumeLayout(false);
            this.tableLayoutPanelStaffingTable.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewStaffingTable)).EndInit();
            this.tabPageStaffingTableStatus.ResumeLayout(false);
            this.tableLayoutPanelStaffingTableStatus.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewStaffingTableStatus)).EndInit();
            this.tabPageStructuralUnits.ResumeLayout(false);
            this.tableLayoutPanelStructuralUnits.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewStructuralUnits)).EndInit();
            this.tableLayoutPanel_WindowHeader.ResumeLayout(false);
            this.tableLayoutPanel_WindowHeader.PerformLayout();
            this.tableLayoutPanel_Programm.ResumeLayout(false);
            this.tableLayoutPanel_Programm.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_AllForm;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Company;
        private System.Windows.Forms.PictureBox pictureBoxCompany;
        private System.Windows.Forms.Label lblCompany;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Employees;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Working_field;
        private System.Windows.Forms.TabControl tabControlStaffingTable;
        private System.Windows.Forms.TabPage tabPageStaffingTable;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelStaffingTable;
        private System.Windows.Forms.Button btnAddToStaffingTable;
        private System.Windows.Forms.DataGridView dataGridViewStaffingTable;
        private System.Windows.Forms.Button btnChangeInStaffingTable;
        private System.Windows.Forms.TabPage tabPageStaffingTableStatus;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelStaffingTableStatus;
        private System.Windows.Forms.Button btnChangeStaffingTableStatus;
        private System.Windows.Forms.DataGridView dataGridViewStaffingTableStatus;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_WindowHeader;
        private System.Windows.Forms.Label lblEmployeesInformation;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Programm;
        private System.Windows.Forms.Label lblProgramm;
        private System.Windows.Forms.TabPage tabPageStructuralUnits;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelStructuralUnits;
        private System.Windows.Forms.DataGridView dataGridViewStructuralUnits;
        private System.Windows.Forms.Button btnDeleteFromStaffingTable;
        private System.Windows.Forms.Button btnAddStructuralUnit;
        private System.Windows.Forms.Button btnDeleteStructralUnit;
        private System.Windows.Forms.Button btnChangeStructuralUnit;
    }
}