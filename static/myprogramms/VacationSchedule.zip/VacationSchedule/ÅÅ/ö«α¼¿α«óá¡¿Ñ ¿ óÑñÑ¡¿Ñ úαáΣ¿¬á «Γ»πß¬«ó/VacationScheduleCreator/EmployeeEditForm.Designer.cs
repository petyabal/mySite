﻿namespace VacationScheduleCreator
{
    partial class EmployeeEditForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EmployeeEditForm));
            this.tableLayoutPanel_AllForm = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel_EditField = new System.Windows.Forms.TableLayoutPanel();
            this.tabControlEmployeesInformationEdit = new System.Windows.Forms.TabControl();
            this.tabPageEmployee = new System.Windows.Forms.TabPage();
            this.tableLayoutPannelEmployees = new System.Windows.Forms.TableLayoutPanel();
            this.tlpEmployeesFunctionalButtons = new System.Windows.Forms.TableLayoutPanel();
            this.btnEmployeeCancel = new System.Windows.Forms.Button();
            this.btnEmployeePost = new System.Windows.Forms.Button();
            this.tlpEmployeesInput = new System.Windows.Forms.TableLayoutPanel();
            this.lBlSurname = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.lblFathersName = new System.Windows.Forms.Label();
            this.lblBirthday = new System.Windows.Forms.Label();
            this.lblPasspordNumber = new System.Windows.Forms.Label();
            this.lblPassportSeries = new System.Windows.Forms.Label();
            this.labelRegistrationPlace = new System.Windows.Forms.Label();
            this.lblGender = new System.Windows.Forms.Label();
            this.lblSnils = new System.Windows.Forms.Label();
            this.lblInn = new System.Windows.Forms.Label();
            this.lblEmploymentDate = new System.Windows.Forms.Label();
            this.dateTimePickerEmploymentDate = new System.Windows.Forms.DateTimePicker();
            this.textBoxRegistrationPlace = new System.Windows.Forms.TextBox();
            this.textBoxInn = new System.Windows.Forms.TextBox();
            this.textBoxPassportNumber = new System.Windows.Forms.TextBox();
            this.textBoxPassportSeries = new System.Windows.Forms.TextBox();
            this.comboBoxGender = new System.Windows.Forms.ComboBox();
            this.dateTimePickerBirthday = new System.Windows.Forms.DateTimePicker();
            this.textBoxFathersName = new System.Windows.Forms.TextBox();
            this.textBoxName = new System.Windows.Forms.TextBox();
            this.textBoxSurname = new System.Windows.Forms.TextBox();
            this.maskedTextBoxSnils = new System.Windows.Forms.MaskedTextBox();
            this.tabPageEmployeesAccount = new System.Windows.Forms.TabPage();
            this.tlpEmployeesAccounts = new System.Windows.Forms.TableLayoutPanel();
            this.tlpEmployeeAccountInput = new System.Windows.Forms.TableLayoutPanel();
            this.labelEmployee = new System.Windows.Forms.Label();
            this.comboBoxEmployee = new System.Windows.Forms.ComboBox();
            this.labelLogin = new System.Windows.Forms.Label();
            this.textBoxLogin = new System.Windows.Forms.TextBox();
            this.labelPassword = new System.Windows.Forms.Label();
            this.textBoxPassword = new System.Windows.Forms.TextBox();
            this.labelRole = new System.Windows.Forms.Label();
            this.comboBoxRole = new System.Windows.Forms.ComboBox();
            this.labelStatus = new System.Windows.Forms.Label();
            this.comboBoxStatus = new System.Windows.Forms.ComboBox();
            this.tlpEmployeesAccountsFunctionalButtons = new System.Windows.Forms.TableLayoutPanel();
            this.btnEmployeesAccountPost = new System.Windows.Forms.Button();
            this.btnEmployeesAccountCancel = new System.Windows.Forms.Button();
            this.tabPageAlternateList = new System.Windows.Forms.TabPage();
            this.tlpAlternateList = new System.Windows.Forms.TableLayoutPanel();
            this.tlpAlternateListInput = new System.Windows.Forms.TableLayoutPanel();
            this.lblVacationist = new System.Windows.Forms.Label();
            this.lblAlternate = new System.Windows.Forms.Label();
            this.comboBoxVacationist = new System.Windows.Forms.ComboBox();
            this.comboBoxAlternate = new System.Windows.Forms.ComboBox();
            this.tlpAltenateListFunctionalButtons = new System.Windows.Forms.TableLayoutPanel();
            this.btnAlternateListPost = new System.Windows.Forms.Button();
            this.btnAlternateListCancel = new System.Windows.Forms.Button();
            this.tabPageEmployeesSickList = new System.Windows.Forms.TabPage();
            this.tlpEmployeesSickList = new System.Windows.Forms.TableLayoutPanel();
            this.tlpEmployeesSickListFunctionalButtons = new System.Windows.Forms.TableLayoutPanel();
            this.btnEmployeesSickListPost = new System.Windows.Forms.Button();
            this.btnEmployeesSickListCancel = new System.Windows.Forms.Button();
            this.tlpEmployeesSickListInput = new System.Windows.Forms.TableLayoutPanel();
            this.lblIllEmployee = new System.Windows.Forms.Label();
            this.comboBoxIllEmployee = new System.Windows.Forms.ComboBox();
            this.lblBeginningOfPeriod = new System.Windows.Forms.Label();
            this.dtpBeginningOfPeriod = new System.Windows.Forms.DateTimePicker();
            this.lblEndOfPeriod = new System.Windows.Forms.Label();
            this.dtpEndOfPeriod = new System.Windows.Forms.DateTimePicker();
            this.tableLayoutPanel_Company = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBoxCompany = new System.Windows.Forms.PictureBox();
            this.lblCompany = new System.Windows.Forms.Label();
            this.tableLayoutPanel_AllForm.SuspendLayout();
            this.tableLayoutPanel_EditField.SuspendLayout();
            this.tabControlEmployeesInformationEdit.SuspendLayout();
            this.tabPageEmployee.SuspendLayout();
            this.tableLayoutPannelEmployees.SuspendLayout();
            this.tlpEmployeesFunctionalButtons.SuspendLayout();
            this.tlpEmployeesInput.SuspendLayout();
            this.tabPageEmployeesAccount.SuspendLayout();
            this.tlpEmployeesAccounts.SuspendLayout();
            this.tlpEmployeeAccountInput.SuspendLayout();
            this.tlpEmployeesAccountsFunctionalButtons.SuspendLayout();
            this.tabPageAlternateList.SuspendLayout();
            this.tlpAlternateList.SuspendLayout();
            this.tlpAlternateListInput.SuspendLayout();
            this.tlpAltenateListFunctionalButtons.SuspendLayout();
            this.tabPageEmployeesSickList.SuspendLayout();
            this.tlpEmployeesSickList.SuspendLayout();
            this.tlpEmployeesSickListFunctionalButtons.SuspendLayout();
            this.tlpEmployeesSickListInput.SuspendLayout();
            this.tableLayoutPanel_Company.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCompany)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel_AllForm
            // 
            this.tableLayoutPanel_AllForm.ColumnCount = 1;
            this.tableLayoutPanel_AllForm.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_AllForm.Controls.Add(this.tableLayoutPanel_EditField, 0, 1);
            this.tableLayoutPanel_AllForm.Controls.Add(this.tableLayoutPanel_Company, 0, 0);
            this.tableLayoutPanel_AllForm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_AllForm.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel_AllForm.Name = "tableLayoutPanel_AllForm";
            this.tableLayoutPanel_AllForm.RowCount = 2;
            this.tableLayoutPanel_AllForm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel_AllForm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tableLayoutPanel_AllForm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel_AllForm.Size = new System.Drawing.Size(384, 561);
            this.tableLayoutPanel_AllForm.TabIndex = 2;
            // 
            // tableLayoutPanel_EditField
            // 
            this.tableLayoutPanel_EditField.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPanel_EditField.ColumnCount = 1;
            this.tableLayoutPanel_EditField.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_EditField.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel_EditField.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel_EditField.Controls.Add(this.tabControlEmployeesInformationEdit, 0, 0);
            this.tableLayoutPanel_EditField.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_EditField.Location = new System.Drawing.Point(3, 59);
            this.tableLayoutPanel_EditField.Name = "tableLayoutPanel_EditField";
            this.tableLayoutPanel_EditField.RowCount = 1;
            this.tableLayoutPanel_EditField.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tableLayoutPanel_EditField.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel_EditField.Size = new System.Drawing.Size(378, 499);
            this.tableLayoutPanel_EditField.TabIndex = 9;
            // 
            // tabControlEmployeesInformationEdit
            // 
            this.tabControlEmployeesInformationEdit.Controls.Add(this.tabPageEmployee);
            this.tabControlEmployeesInformationEdit.Controls.Add(this.tabPageEmployeesAccount);
            this.tabControlEmployeesInformationEdit.Controls.Add(this.tabPageAlternateList);
            this.tabControlEmployeesInformationEdit.Controls.Add(this.tabPageEmployeesSickList);
            this.tabControlEmployeesInformationEdit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlEmployeesInformationEdit.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tabControlEmployeesInformationEdit.Location = new System.Drawing.Point(3, 3);
            this.tabControlEmployeesInformationEdit.Name = "tabControlEmployeesInformationEdit";
            this.tabControlEmployeesInformationEdit.SelectedIndex = 0;
            this.tabControlEmployeesInformationEdit.Size = new System.Drawing.Size(372, 493);
            this.tabControlEmployeesInformationEdit.TabIndex = 0;
            // 
            // tabPageEmployee
            // 
            this.tabPageEmployee.Controls.Add(this.tableLayoutPannelEmployees);
            this.tabPageEmployee.Location = new System.Drawing.Point(4, 29);
            this.tabPageEmployee.Name = "tabPageEmployee";
            this.tabPageEmployee.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageEmployee.Size = new System.Drawing.Size(364, 460);
            this.tabPageEmployee.TabIndex = 0;
            this.tabPageEmployee.Text = "Сотрудники";
            this.tabPageEmployee.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPannelEmployees
            // 
            this.tableLayoutPannelEmployees.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPannelEmployees.ColumnCount = 1;
            this.tableLayoutPannelEmployees.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPannelEmployees.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPannelEmployees.Controls.Add(this.tlpEmployeesFunctionalButtons, 0, 1);
            this.tableLayoutPannelEmployees.Controls.Add(this.tlpEmployeesInput, 0, 0);
            this.tableLayoutPannelEmployees.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPannelEmployees.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPannelEmployees.Name = "tableLayoutPannelEmployees";
            this.tableLayoutPannelEmployees.RowCount = 2;
            this.tableLayoutPannelEmployees.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tableLayoutPannelEmployees.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPannelEmployees.Size = new System.Drawing.Size(358, 454);
            this.tableLayoutPannelEmployees.TabIndex = 2;
            // 
            // tlpEmployeesFunctionalButtons
            // 
            this.tlpEmployeesFunctionalButtons.ColumnCount = 2;
            this.tlpEmployeesFunctionalButtons.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpEmployeesFunctionalButtons.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpEmployeesFunctionalButtons.Controls.Add(this.btnEmployeeCancel, 0, 0);
            this.tlpEmployeesFunctionalButtons.Controls.Add(this.btnEmployeePost, 1, 0);
            this.tlpEmployeesFunctionalButtons.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpEmployeesFunctionalButtons.Location = new System.Drawing.Point(3, 411);
            this.tlpEmployeesFunctionalButtons.Name = "tlpEmployeesFunctionalButtons";
            this.tlpEmployeesFunctionalButtons.RowCount = 1;
            this.tlpEmployeesFunctionalButtons.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpEmployeesFunctionalButtons.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tlpEmployeesFunctionalButtons.Size = new System.Drawing.Size(352, 40);
            this.tlpEmployeesFunctionalButtons.TabIndex = 17;
            // 
            // btnEmployeeCancel
            // 
            this.btnEmployeeCancel.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnEmployeeCancel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnEmployeeCancel.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnEmployeeCancel.ForeColor = System.Drawing.Color.White;
            this.btnEmployeeCancel.Location = new System.Drawing.Point(3, 3);
            this.btnEmployeeCancel.Name = "btnEmployeeCancel";
            this.btnEmployeeCancel.Size = new System.Drawing.Size(170, 34);
            this.btnEmployeeCancel.TabIndex = 13;
            this.btnEmployeeCancel.Text = "Отмена";
            this.btnEmployeeCancel.UseVisualStyleBackColor = false;
            this.btnEmployeeCancel.Click += new System.EventHandler(this.btnEmployeeCancel_Click);
            // 
            // btnEmployeePost
            // 
            this.btnEmployeePost.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnEmployeePost.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnEmployeePost.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnEmployeePost.ForeColor = System.Drawing.Color.White;
            this.btnEmployeePost.Location = new System.Drawing.Point(179, 3);
            this.btnEmployeePost.Name = "btnEmployeePost";
            this.btnEmployeePost.Size = new System.Drawing.Size(170, 34);
            this.btnEmployeePost.TabIndex = 15;
            this.btnEmployeePost.Text = "Сохранить данные";
            this.btnEmployeePost.UseVisualStyleBackColor = false;
            this.btnEmployeePost.Click += new System.EventHandler(this.btnEmployeePost_Click);
            // 
            // tlpEmployeesInput
            // 
            this.tlpEmployeesInput.BackColor = System.Drawing.Color.Tan;
            this.tlpEmployeesInput.ColumnCount = 3;
            this.tlpEmployeesInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36F));
            this.tlpEmployeesInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 58F));
            this.tlpEmployeesInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6F));
            this.tlpEmployeesInput.Controls.Add(this.lBlSurname, 0, 1);
            this.tlpEmployeesInput.Controls.Add(this.lblName, 0, 2);
            this.tlpEmployeesInput.Controls.Add(this.lblFathersName, 0, 3);
            this.tlpEmployeesInput.Controls.Add(this.lblBirthday, 0, 4);
            this.tlpEmployeesInput.Controls.Add(this.lblPasspordNumber, 0, 7);
            this.tlpEmployeesInput.Controls.Add(this.lblPassportSeries, 0, 6);
            this.tlpEmployeesInput.Controls.Add(this.labelRegistrationPlace, 0, 10);
            this.tlpEmployeesInput.Controls.Add(this.lblGender, 0, 5);
            this.tlpEmployeesInput.Controls.Add(this.lblSnils, 0, 8);
            this.tlpEmployeesInput.Controls.Add(this.lblInn, 0, 9);
            this.tlpEmployeesInput.Controls.Add(this.lblEmploymentDate, 0, 11);
            this.tlpEmployeesInput.Controls.Add(this.dateTimePickerEmploymentDate, 1, 11);
            this.tlpEmployeesInput.Controls.Add(this.textBoxRegistrationPlace, 1, 10);
            this.tlpEmployeesInput.Controls.Add(this.textBoxInn, 1, 9);
            this.tlpEmployeesInput.Controls.Add(this.textBoxPassportNumber, 1, 7);
            this.tlpEmployeesInput.Controls.Add(this.textBoxPassportSeries, 1, 6);
            this.tlpEmployeesInput.Controls.Add(this.comboBoxGender, 1, 5);
            this.tlpEmployeesInput.Controls.Add(this.dateTimePickerBirthday, 1, 4);
            this.tlpEmployeesInput.Controls.Add(this.textBoxFathersName, 1, 3);
            this.tlpEmployeesInput.Controls.Add(this.textBoxName, 1, 2);
            this.tlpEmployeesInput.Controls.Add(this.textBoxSurname, 1, 1);
            this.tlpEmployeesInput.Controls.Add(this.maskedTextBoxSnils, 1, 8);
            this.tlpEmployeesInput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpEmployeesInput.Location = new System.Drawing.Point(3, 3);
            this.tlpEmployeesInput.Name = "tlpEmployeesInput";
            this.tlpEmployeesInput.RowCount = 13;
            this.tlpEmployeesInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.999866F));
            this.tlpEmployeesInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.500031F));
            this.tlpEmployeesInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.500031F));
            this.tlpEmployeesInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.500031F));
            this.tlpEmployeesInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.500031F));
            this.tlpEmployeesInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.500031F));
            this.tlpEmployeesInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.500031F));
            this.tlpEmployeesInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.500031F));
            this.tlpEmployeesInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.500031F));
            this.tlpEmployeesInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.500031F));
            this.tlpEmployeesInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.500031F));
            this.tlpEmployeesInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.499917F));
            this.tlpEmployeesInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.499917F));
            this.tlpEmployeesInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tlpEmployeesInput.Size = new System.Drawing.Size(352, 402);
            this.tlpEmployeesInput.TabIndex = 2;
            // 
            // lBlSurname
            // 
            this.lBlSurname.AutoSize = true;
            this.lBlSurname.BackColor = System.Drawing.Color.Transparent;
            this.lBlSurname.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lBlSurname.ForeColor = System.Drawing.Color.Black;
            this.lBlSurname.Location = new System.Drawing.Point(3, 40);
            this.lBlSurname.Name = "lBlSurname";
            this.lBlSurname.Size = new System.Drawing.Size(120, 30);
            this.lBlSurname.TabIndex = 0;
            this.lBlSurname.Text = "Фамилия:";
            this.lBlSurname.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblName.ForeColor = System.Drawing.Color.Black;
            this.lblName.Location = new System.Drawing.Point(3, 70);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(120, 30);
            this.lblName.TabIndex = 1;
            this.lblName.Text = "Имя:";
            this.lblName.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblFathersName
            // 
            this.lblFathersName.AutoSize = true;
            this.lblFathersName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblFathersName.ForeColor = System.Drawing.Color.Black;
            this.lblFathersName.Location = new System.Drawing.Point(3, 100);
            this.lblFathersName.Name = "lblFathersName";
            this.lblFathersName.Size = new System.Drawing.Size(120, 30);
            this.lblFathersName.TabIndex = 3;
            this.lblFathersName.Text = "Отчество:";
            this.lblFathersName.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblBirthday
            // 
            this.lblBirthday.AutoSize = true;
            this.lblBirthday.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblBirthday.ForeColor = System.Drawing.Color.Black;
            this.lblBirthday.Location = new System.Drawing.Point(3, 130);
            this.lblBirthday.Name = "lblBirthday";
            this.lblBirthday.Size = new System.Drawing.Size(120, 30);
            this.lblBirthday.TabIndex = 4;
            this.lblBirthday.Text = "Дата рождения:";
            this.lblBirthday.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblPasspordNumber
            // 
            this.lblPasspordNumber.AutoSize = true;
            this.lblPasspordNumber.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblPasspordNumber.ForeColor = System.Drawing.Color.Black;
            this.lblPasspordNumber.Location = new System.Drawing.Point(3, 220);
            this.lblPasspordNumber.Name = "lblPasspordNumber";
            this.lblPasspordNumber.Size = new System.Drawing.Size(120, 30);
            this.lblPasspordNumber.TabIndex = 6;
            this.lblPasspordNumber.Text = "Номер паспорта:";
            this.lblPasspordNumber.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblPassportSeries
            // 
            this.lblPassportSeries.AutoSize = true;
            this.lblPassportSeries.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblPassportSeries.ForeColor = System.Drawing.Color.Black;
            this.lblPassportSeries.Location = new System.Drawing.Point(3, 190);
            this.lblPassportSeries.Name = "lblPassportSeries";
            this.lblPassportSeries.Size = new System.Drawing.Size(120, 30);
            this.lblPassportSeries.TabIndex = 5;
            this.lblPassportSeries.Text = "Серия паспорта:";
            this.lblPassportSeries.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // labelRegistrationPlace
            // 
            this.labelRegistrationPlace.AutoSize = true;
            this.labelRegistrationPlace.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelRegistrationPlace.ForeColor = System.Drawing.Color.Black;
            this.labelRegistrationPlace.Location = new System.Drawing.Point(3, 310);
            this.labelRegistrationPlace.Name = "labelRegistrationPlace";
            this.labelRegistrationPlace.Size = new System.Drawing.Size(120, 30);
            this.labelRegistrationPlace.TabIndex = 12;
            this.labelRegistrationPlace.Text = "Регистрация:";
            this.labelRegistrationPlace.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblGender
            // 
            this.lblGender.AutoSize = true;
            this.lblGender.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblGender.ForeColor = System.Drawing.Color.Black;
            this.lblGender.Location = new System.Drawing.Point(3, 160);
            this.lblGender.Name = "lblGender";
            this.lblGender.Size = new System.Drawing.Size(120, 30);
            this.lblGender.TabIndex = 14;
            this.lblGender.Text = "Пол:";
            this.lblGender.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblSnils
            // 
            this.lblSnils.AutoSize = true;
            this.lblSnils.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblSnils.ForeColor = System.Drawing.Color.Black;
            this.lblSnils.Location = new System.Drawing.Point(3, 250);
            this.lblSnils.Name = "lblSnils";
            this.lblSnils.Size = new System.Drawing.Size(120, 30);
            this.lblSnils.TabIndex = 7;
            this.lblSnils.Text = "СНИЛС:";
            this.lblSnils.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblInn
            // 
            this.lblInn.AutoSize = true;
            this.lblInn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblInn.ForeColor = System.Drawing.Color.Black;
            this.lblInn.Location = new System.Drawing.Point(3, 280);
            this.lblInn.Name = "lblInn";
            this.lblInn.Size = new System.Drawing.Size(120, 30);
            this.lblInn.TabIndex = 8;
            this.lblInn.Text = "ИНН:";
            this.lblInn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblEmploymentDate
            // 
            this.lblEmploymentDate.AutoSize = true;
            this.lblEmploymentDate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblEmploymentDate.ForeColor = System.Drawing.Color.Black;
            this.lblEmploymentDate.Location = new System.Drawing.Point(3, 340);
            this.lblEmploymentDate.Name = "lblEmploymentDate";
            this.lblEmploymentDate.Size = new System.Drawing.Size(120, 30);
            this.lblEmploymentDate.TabIndex = 10;
            this.lblEmploymentDate.Text = "Принят в штат с:";
            this.lblEmploymentDate.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // dateTimePickerEmploymentDate
            // 
            this.dateTimePickerEmploymentDate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.dateTimePickerEmploymentDate.Location = new System.Drawing.Point(129, 343);
            this.dateTimePickerEmploymentDate.Name = "dateTimePickerEmploymentDate";
            this.dateTimePickerEmploymentDate.Size = new System.Drawing.Size(198, 25);
            this.dateTimePickerEmploymentDate.TabIndex = 21;
            // 
            // textBoxRegistrationPlace
            // 
            this.textBoxRegistrationPlace.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxRegistrationPlace.Location = new System.Drawing.Point(129, 313);
            this.textBoxRegistrationPlace.MaxLength = 100;
            this.textBoxRegistrationPlace.Name = "textBoxRegistrationPlace";
            this.textBoxRegistrationPlace.Size = new System.Drawing.Size(198, 25);
            this.textBoxRegistrationPlace.TabIndex = 28;
            // 
            // textBoxInn
            // 
            this.textBoxInn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxInn.Location = new System.Drawing.Point(129, 283);
            this.textBoxInn.MaxLength = 12;
            this.textBoxInn.Name = "textBoxInn";
            this.textBoxInn.Size = new System.Drawing.Size(198, 25);
            this.textBoxInn.TabIndex = 27;
            this.textBoxInn.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxInn_KeyPress);
            // 
            // textBoxPassportNumber
            // 
            this.textBoxPassportNumber.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxPassportNumber.Location = new System.Drawing.Point(129, 223);
            this.textBoxPassportNumber.MaxLength = 6;
            this.textBoxPassportNumber.Name = "textBoxPassportNumber";
            this.textBoxPassportNumber.Size = new System.Drawing.Size(198, 25);
            this.textBoxPassportNumber.TabIndex = 23;
            this.textBoxPassportNumber.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxPassportNumber_KeyPress);
            // 
            // textBoxPassportSeries
            // 
            this.textBoxPassportSeries.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxPassportSeries.Location = new System.Drawing.Point(129, 193);
            this.textBoxPassportSeries.MaxLength = 4;
            this.textBoxPassportSeries.Name = "textBoxPassportSeries";
            this.textBoxPassportSeries.Size = new System.Drawing.Size(198, 25);
            this.textBoxPassportSeries.TabIndex = 25;
            this.textBoxPassportSeries.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxPassportSeries_KeyPress);
            // 
            // comboBoxGender
            // 
            this.comboBoxGender.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBoxGender.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxGender.FormattingEnabled = true;
            this.comboBoxGender.Items.AddRange(new object[] {
            "Мужской",
            "Женский"});
            this.comboBoxGender.Location = new System.Drawing.Point(129, 164);
            this.comboBoxGender.Name = "comboBoxGender";
            this.comboBoxGender.Size = new System.Drawing.Size(198, 28);
            this.comboBoxGender.TabIndex = 19;
            // 
            // dateTimePickerBirthday
            // 
            this.dateTimePickerBirthday.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.dateTimePickerBirthday.Location = new System.Drawing.Point(129, 133);
            this.dateTimePickerBirthday.Name = "dateTimePickerBirthday";
            this.dateTimePickerBirthday.Size = new System.Drawing.Size(198, 25);
            this.dateTimePickerBirthday.TabIndex = 20;
            // 
            // textBoxFathersName
            // 
            this.textBoxFathersName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxFathersName.Location = new System.Drawing.Point(129, 103);
            this.textBoxFathersName.MaxLength = 45;
            this.textBoxFathersName.Name = "textBoxFathersName";
            this.textBoxFathersName.Size = new System.Drawing.Size(198, 25);
            this.textBoxFathersName.TabIndex = 18;
            this.textBoxFathersName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxFathersName_KeyPress);
            // 
            // textBoxName
            // 
            this.textBoxName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxName.Location = new System.Drawing.Point(129, 73);
            this.textBoxName.MaxLength = 45;
            this.textBoxName.Name = "textBoxName";
            this.textBoxName.Size = new System.Drawing.Size(198, 25);
            this.textBoxName.TabIndex = 17;
            this.textBoxName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxName_KeyPress);
            // 
            // textBoxSurname
            // 
            this.textBoxSurname.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxSurname.Location = new System.Drawing.Point(129, 43);
            this.textBoxSurname.MaxLength = 45;
            this.textBoxSurname.Name = "textBoxSurname";
            this.textBoxSurname.Size = new System.Drawing.Size(198, 25);
            this.textBoxSurname.TabIndex = 16;
            this.textBoxSurname.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxSurname_KeyPress);
            // 
            // maskedTextBoxSnils
            // 
            this.maskedTextBoxSnils.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.maskedTextBoxSnils.Location = new System.Drawing.Point(129, 253);
            this.maskedTextBoxSnils.Mask = "999-999-999 99";
            this.maskedTextBoxSnils.Name = "maskedTextBoxSnils";
            this.maskedTextBoxSnils.Size = new System.Drawing.Size(198, 25);
            this.maskedTextBoxSnils.TabIndex = 29;
            // 
            // tabPageEmployeesAccount
            // 
            this.tabPageEmployeesAccount.Controls.Add(this.tlpEmployeesAccounts);
            this.tabPageEmployeesAccount.Location = new System.Drawing.Point(4, 29);
            this.tabPageEmployeesAccount.Name = "tabPageEmployeesAccount";
            this.tabPageEmployeesAccount.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageEmployeesAccount.Size = new System.Drawing.Size(364, 460);
            this.tabPageEmployeesAccount.TabIndex = 1;
            this.tabPageEmployeesAccount.Text = "Учетные записи сотрудников";
            this.tabPageEmployeesAccount.UseVisualStyleBackColor = true;
            // 
            // tlpEmployeesAccounts
            // 
            this.tlpEmployeesAccounts.BackColor = System.Drawing.Color.Tan;
            this.tlpEmployeesAccounts.ColumnCount = 1;
            this.tlpEmployeesAccounts.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpEmployeesAccounts.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tlpEmployeesAccounts.Controls.Add(this.tlpEmployeeAccountInput, 0, 0);
            this.tlpEmployeesAccounts.Controls.Add(this.tlpEmployeesAccountsFunctionalButtons, 0, 1);
            this.tlpEmployeesAccounts.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpEmployeesAccounts.Location = new System.Drawing.Point(3, 3);
            this.tlpEmployeesAccounts.Name = "tlpEmployeesAccounts";
            this.tlpEmployeesAccounts.RowCount = 2;
            this.tlpEmployeesAccounts.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tlpEmployeesAccounts.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tlpEmployeesAccounts.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tlpEmployeesAccounts.Size = new System.Drawing.Size(358, 454);
            this.tlpEmployeesAccounts.TabIndex = 0;
            // 
            // tlpEmployeeAccountInput
            // 
            this.tlpEmployeeAccountInput.ColumnCount = 3;
            this.tlpEmployeeAccountInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tlpEmployeeAccountInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tlpEmployeeAccountInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tlpEmployeeAccountInput.Controls.Add(this.labelEmployee, 1, 0);
            this.tlpEmployeeAccountInput.Controls.Add(this.comboBoxEmployee, 1, 1);
            this.tlpEmployeeAccountInput.Controls.Add(this.labelLogin, 1, 2);
            this.tlpEmployeeAccountInput.Controls.Add(this.textBoxLogin, 1, 3);
            this.tlpEmployeeAccountInput.Controls.Add(this.labelPassword, 1, 4);
            this.tlpEmployeeAccountInput.Controls.Add(this.textBoxPassword, 1, 5);
            this.tlpEmployeeAccountInput.Controls.Add(this.labelRole, 1, 6);
            this.tlpEmployeeAccountInput.Controls.Add(this.comboBoxRole, 1, 7);
            this.tlpEmployeeAccountInput.Controls.Add(this.labelStatus, 1, 8);
            this.tlpEmployeeAccountInput.Controls.Add(this.comboBoxStatus, 1, 9);
            this.tlpEmployeeAccountInput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpEmployeeAccountInput.Location = new System.Drawing.Point(3, 3);
            this.tlpEmployeeAccountInput.Name = "tlpEmployeeAccountInput";
            this.tlpEmployeeAccountInput.RowCount = 11;
            this.tlpEmployeeAccountInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 17.5F));
            this.tlpEmployeeAccountInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpEmployeeAccountInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpEmployeeAccountInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpEmployeeAccountInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpEmployeeAccountInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpEmployeeAccountInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpEmployeeAccountInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpEmployeeAccountInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpEmployeeAccountInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpEmployeeAccountInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tlpEmployeeAccountInput.Size = new System.Drawing.Size(352, 402);
            this.tlpEmployeeAccountInput.TabIndex = 10;
            // 
            // labelEmployee
            // 
            this.labelEmployee.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.labelEmployee.AutoSize = true;
            this.labelEmployee.Location = new System.Drawing.Point(73, 50);
            this.labelEmployee.Name = "labelEmployee";
            this.labelEmployee.Size = new System.Drawing.Size(80, 20);
            this.labelEmployee.TabIndex = 1;
            this.labelEmployee.Text = "Сотрудник:";
            // 
            // comboBoxEmployee
            // 
            this.comboBoxEmployee.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBoxEmployee.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxEmployee.FormattingEnabled = true;
            this.comboBoxEmployee.Location = new System.Drawing.Point(73, 74);
            this.comboBoxEmployee.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.comboBoxEmployee.Name = "comboBoxEmployee";
            this.comboBoxEmployee.Size = new System.Drawing.Size(205, 28);
            this.comboBoxEmployee.TabIndex = 3;
            // 
            // labelLogin
            // 
            this.labelLogin.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.labelLogin.AutoSize = true;
            this.labelLogin.Location = new System.Drawing.Point(73, 110);
            this.labelLogin.Name = "labelLogin";
            this.labelLogin.Size = new System.Drawing.Size(50, 20);
            this.labelLogin.TabIndex = 5;
            this.labelLogin.Text = "Логин:";
            // 
            // textBoxLogin
            // 
            this.textBoxLogin.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxLogin.Location = new System.Drawing.Point(73, 133);
            this.textBoxLogin.MaxLength = 15;
            this.textBoxLogin.Name = "textBoxLogin";
            this.textBoxLogin.Size = new System.Drawing.Size(205, 25);
            this.textBoxLogin.TabIndex = 7;
            // 
            // labelPassword
            // 
            this.labelPassword.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.labelPassword.AutoSize = true;
            this.labelPassword.Location = new System.Drawing.Point(73, 170);
            this.labelPassword.Name = "labelPassword";
            this.labelPassword.Size = new System.Drawing.Size(61, 20);
            this.labelPassword.TabIndex = 6;
            this.labelPassword.Text = "Пароль:";
            // 
            // textBoxPassword
            // 
            this.textBoxPassword.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxPassword.Location = new System.Drawing.Point(73, 193);
            this.textBoxPassword.MaxLength = 20;
            this.textBoxPassword.Name = "textBoxPassword";
            this.textBoxPassword.Size = new System.Drawing.Size(205, 25);
            this.textBoxPassword.TabIndex = 8;
            // 
            // labelRole
            // 
            this.labelRole.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.labelRole.AutoSize = true;
            this.labelRole.Location = new System.Drawing.Point(73, 230);
            this.labelRole.Name = "labelRole";
            this.labelRole.Size = new System.Drawing.Size(45, 20);
            this.labelRole.TabIndex = 2;
            this.labelRole.Text = "Роль:";
            // 
            // comboBoxRole
            // 
            this.comboBoxRole.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBoxRole.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxRole.FormattingEnabled = true;
            this.comboBoxRole.Items.AddRange(new object[] {
            "Кадровик",
            "Руководитель",
            "Администратор"});
            this.comboBoxRole.Location = new System.Drawing.Point(73, 254);
            this.comboBoxRole.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.comboBoxRole.Name = "comboBoxRole";
            this.comboBoxRole.Size = new System.Drawing.Size(205, 28);
            this.comboBoxRole.TabIndex = 4;
            // 
            // labelStatus
            // 
            this.labelStatus.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.labelStatus.AutoSize = true;
            this.labelStatus.Location = new System.Drawing.Point(73, 290);
            this.labelStatus.Name = "labelStatus";
            this.labelStatus.Size = new System.Drawing.Size(55, 20);
            this.labelStatus.TabIndex = 9;
            this.labelStatus.Text = "Статус:";
            // 
            // comboBoxStatus
            // 
            this.comboBoxStatus.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBoxStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxStatus.FormattingEnabled = true;
            this.comboBoxStatus.Items.AddRange(new object[] {
            "Не заблокирован",
            "Заблокирован"});
            this.comboBoxStatus.Location = new System.Drawing.Point(73, 314);
            this.comboBoxStatus.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.comboBoxStatus.Name = "comboBoxStatus";
            this.comboBoxStatus.Size = new System.Drawing.Size(205, 28);
            this.comboBoxStatus.TabIndex = 10;
            // 
            // tlpEmployeesAccountsFunctionalButtons
            // 
            this.tlpEmployeesAccountsFunctionalButtons.ColumnCount = 2;
            this.tlpEmployeesAccountsFunctionalButtons.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpEmployeesAccountsFunctionalButtons.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpEmployeesAccountsFunctionalButtons.Controls.Add(this.btnEmployeesAccountPost, 1, 0);
            this.tlpEmployeesAccountsFunctionalButtons.Controls.Add(this.btnEmployeesAccountCancel, 0, 0);
            this.tlpEmployeesAccountsFunctionalButtons.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpEmployeesAccountsFunctionalButtons.Location = new System.Drawing.Point(3, 411);
            this.tlpEmployeesAccountsFunctionalButtons.Name = "tlpEmployeesAccountsFunctionalButtons";
            this.tlpEmployeesAccountsFunctionalButtons.RowCount = 1;
            this.tlpEmployeesAccountsFunctionalButtons.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpEmployeesAccountsFunctionalButtons.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tlpEmployeesAccountsFunctionalButtons.Size = new System.Drawing.Size(352, 40);
            this.tlpEmployeesAccountsFunctionalButtons.TabIndex = 1;
            // 
            // btnEmployeesAccountPost
            // 
            this.btnEmployeesAccountPost.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnEmployeesAccountPost.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnEmployeesAccountPost.ForeColor = System.Drawing.Color.White;
            this.btnEmployeesAccountPost.Location = new System.Drawing.Point(179, 3);
            this.btnEmployeesAccountPost.Name = "btnEmployeesAccountPost";
            this.btnEmployeesAccountPost.Size = new System.Drawing.Size(170, 34);
            this.btnEmployeesAccountPost.TabIndex = 0;
            this.btnEmployeesAccountPost.Text = "Сохранить данные";
            this.btnEmployeesAccountPost.UseVisualStyleBackColor = false;
            this.btnEmployeesAccountPost.Click += new System.EventHandler(this.btnEmployeesAccountPost_Click);
            // 
            // btnEmployeesAccountCancel
            // 
            this.btnEmployeesAccountCancel.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnEmployeesAccountCancel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnEmployeesAccountCancel.ForeColor = System.Drawing.Color.White;
            this.btnEmployeesAccountCancel.Location = new System.Drawing.Point(3, 3);
            this.btnEmployeesAccountCancel.Name = "btnEmployeesAccountCancel";
            this.btnEmployeesAccountCancel.Size = new System.Drawing.Size(170, 34);
            this.btnEmployeesAccountCancel.TabIndex = 1;
            this.btnEmployeesAccountCancel.Text = "Отмена";
            this.btnEmployeesAccountCancel.UseVisualStyleBackColor = false;
            this.btnEmployeesAccountCancel.Click += new System.EventHandler(this.btnEmployeesAccountCancel_Click);
            // 
            // tabPageAlternateList
            // 
            this.tabPageAlternateList.Controls.Add(this.tlpAlternateList);
            this.tabPageAlternateList.Location = new System.Drawing.Point(4, 29);
            this.tabPageAlternateList.Name = "tabPageAlternateList";
            this.tabPageAlternateList.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageAlternateList.Size = new System.Drawing.Size(364, 460);
            this.tabPageAlternateList.TabIndex = 2;
            this.tabPageAlternateList.Text = "Список замещающих лиц";
            this.tabPageAlternateList.UseVisualStyleBackColor = true;
            // 
            // tlpAlternateList
            // 
            this.tlpAlternateList.BackColor = System.Drawing.Color.Tan;
            this.tlpAlternateList.ColumnCount = 1;
            this.tlpAlternateList.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpAlternateList.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tlpAlternateList.Controls.Add(this.tlpAlternateListInput, 0, 0);
            this.tlpAlternateList.Controls.Add(this.tlpAltenateListFunctionalButtons, 0, 1);
            this.tlpAlternateList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpAlternateList.Location = new System.Drawing.Point(3, 3);
            this.tlpAlternateList.Name = "tlpAlternateList";
            this.tlpAlternateList.RowCount = 2;
            this.tlpAlternateList.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tlpAlternateList.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tlpAlternateList.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tlpAlternateList.Size = new System.Drawing.Size(358, 454);
            this.tlpAlternateList.TabIndex = 0;
            // 
            // tlpAlternateListInput
            // 
            this.tlpAlternateListInput.ColumnCount = 3;
            this.tlpAlternateListInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tlpAlternateListInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tlpAlternateListInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tlpAlternateListInput.Controls.Add(this.lblVacationist, 1, 0);
            this.tlpAlternateListInput.Controls.Add(this.lblAlternate, 1, 2);
            this.tlpAlternateListInput.Controls.Add(this.comboBoxVacationist, 1, 1);
            this.tlpAlternateListInput.Controls.Add(this.comboBoxAlternate, 1, 3);
            this.tlpAlternateListInput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpAlternateListInput.Location = new System.Drawing.Point(3, 3);
            this.tlpAlternateListInput.Name = "tlpAlternateListInput";
            this.tlpAlternateListInput.RowCount = 5;
            this.tlpAlternateListInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tlpAlternateListInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpAlternateListInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpAlternateListInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpAlternateListInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 37.5F));
            this.tlpAlternateListInput.Size = new System.Drawing.Size(352, 402);
            this.tlpAlternateListInput.TabIndex = 9;
            // 
            // lblVacationist
            // 
            this.lblVacationist.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblVacationist.AutoSize = true;
            this.lblVacationist.Location = new System.Drawing.Point(73, 140);
            this.lblVacationist.Name = "lblVacationist";
            this.lblVacationist.Size = new System.Drawing.Size(127, 20);
            this.lblVacationist.TabIndex = 1;
            this.lblVacationist.Text = "Замещаемое лицо:";
            // 
            // lblAlternate
            // 
            this.lblAlternate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblAlternate.AutoSize = true;
            this.lblAlternate.Location = new System.Drawing.Point(73, 200);
            this.lblAlternate.Name = "lblAlternate";
            this.lblAlternate.Size = new System.Drawing.Size(131, 20);
            this.lblAlternate.TabIndex = 2;
            this.lblAlternate.Text = "Замещающее лицо:";
            // 
            // comboBoxVacationist
            // 
            this.comboBoxVacationist.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBoxVacationist.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxVacationist.FormattingEnabled = true;
            this.comboBoxVacationist.Location = new System.Drawing.Point(73, 164);
            this.comboBoxVacationist.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.comboBoxVacationist.Name = "comboBoxVacationist";
            this.comboBoxVacationist.Size = new System.Drawing.Size(205, 28);
            this.comboBoxVacationist.TabIndex = 3;
            // 
            // comboBoxAlternate
            // 
            this.comboBoxAlternate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBoxAlternate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxAlternate.FormattingEnabled = true;
            this.comboBoxAlternate.Location = new System.Drawing.Point(73, 224);
            this.comboBoxAlternate.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.comboBoxAlternate.Name = "comboBoxAlternate";
            this.comboBoxAlternate.Size = new System.Drawing.Size(205, 28);
            this.comboBoxAlternate.TabIndex = 4;
            // 
            // tlpAltenateListFunctionalButtons
            // 
            this.tlpAltenateListFunctionalButtons.ColumnCount = 2;
            this.tlpAltenateListFunctionalButtons.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpAltenateListFunctionalButtons.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpAltenateListFunctionalButtons.Controls.Add(this.btnAlternateListPost, 1, 0);
            this.tlpAltenateListFunctionalButtons.Controls.Add(this.btnAlternateListCancel, 0, 0);
            this.tlpAltenateListFunctionalButtons.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpAltenateListFunctionalButtons.Location = new System.Drawing.Point(3, 411);
            this.tlpAltenateListFunctionalButtons.Name = "tlpAltenateListFunctionalButtons";
            this.tlpAltenateListFunctionalButtons.RowCount = 1;
            this.tlpAltenateListFunctionalButtons.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpAltenateListFunctionalButtons.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tlpAltenateListFunctionalButtons.Size = new System.Drawing.Size(352, 40);
            this.tlpAltenateListFunctionalButtons.TabIndex = 1;
            // 
            // btnAlternateListPost
            // 
            this.btnAlternateListPost.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnAlternateListPost.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnAlternateListPost.ForeColor = System.Drawing.Color.White;
            this.btnAlternateListPost.Location = new System.Drawing.Point(179, 3);
            this.btnAlternateListPost.Name = "btnAlternateListPost";
            this.btnAlternateListPost.Size = new System.Drawing.Size(170, 34);
            this.btnAlternateListPost.TabIndex = 0;
            this.btnAlternateListPost.Text = "Сохранить данные";
            this.btnAlternateListPost.UseVisualStyleBackColor = false;
            this.btnAlternateListPost.Click += new System.EventHandler(this.btnAlternateListPost_Click);
            // 
            // btnAlternateListCancel
            // 
            this.btnAlternateListCancel.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnAlternateListCancel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnAlternateListCancel.ForeColor = System.Drawing.Color.White;
            this.btnAlternateListCancel.Location = new System.Drawing.Point(3, 3);
            this.btnAlternateListCancel.Name = "btnAlternateListCancel";
            this.btnAlternateListCancel.Size = new System.Drawing.Size(170, 34);
            this.btnAlternateListCancel.TabIndex = 1;
            this.btnAlternateListCancel.Text = "Отмена";
            this.btnAlternateListCancel.UseVisualStyleBackColor = false;
            this.btnAlternateListCancel.Click += new System.EventHandler(this.btnAlternateListCancel_Click);
            // 
            // tabPageEmployeesSickList
            // 
            this.tabPageEmployeesSickList.Controls.Add(this.tlpEmployeesSickList);
            this.tabPageEmployeesSickList.Location = new System.Drawing.Point(4, 25);
            this.tabPageEmployeesSickList.Name = "tabPageEmployeesSickList";
            this.tabPageEmployeesSickList.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageEmployeesSickList.Size = new System.Drawing.Size(324, 407);
            this.tabPageEmployeesSickList.TabIndex = 3;
            this.tabPageEmployeesSickList.Text = "Больничные листы сотрудников";
            this.tabPageEmployeesSickList.UseVisualStyleBackColor = true;
            // 
            // tlpEmployeesSickList
            // 
            this.tlpEmployeesSickList.BackColor = System.Drawing.Color.Tan;
            this.tlpEmployeesSickList.ColumnCount = 1;
            this.tlpEmployeesSickList.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpEmployeesSickList.Controls.Add(this.tlpEmployeesSickListFunctionalButtons, 0, 1);
            this.tlpEmployeesSickList.Controls.Add(this.tlpEmployeesSickListInput, 0, 0);
            this.tlpEmployeesSickList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpEmployeesSickList.Location = new System.Drawing.Point(3, 3);
            this.tlpEmployeesSickList.Name = "tlpEmployeesSickList";
            this.tlpEmployeesSickList.RowCount = 2;
            this.tlpEmployeesSickList.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tlpEmployeesSickList.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tlpEmployeesSickList.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tlpEmployeesSickList.Size = new System.Drawing.Size(318, 401);
            this.tlpEmployeesSickList.TabIndex = 11;
            // 
            // tlpEmployeesSickListFunctionalButtons
            // 
            this.tlpEmployeesSickListFunctionalButtons.ColumnCount = 2;
            this.tlpEmployeesSickListFunctionalButtons.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpEmployeesSickListFunctionalButtons.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpEmployeesSickListFunctionalButtons.Controls.Add(this.btnEmployeesSickListPost, 1, 0);
            this.tlpEmployeesSickListFunctionalButtons.Controls.Add(this.btnEmployeesSickListCancel, 0, 0);
            this.tlpEmployeesSickListFunctionalButtons.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpEmployeesSickListFunctionalButtons.Location = new System.Drawing.Point(3, 363);
            this.tlpEmployeesSickListFunctionalButtons.Name = "tlpEmployeesSickListFunctionalButtons";
            this.tlpEmployeesSickListFunctionalButtons.RowCount = 1;
            this.tlpEmployeesSickListFunctionalButtons.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpEmployeesSickListFunctionalButtons.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tlpEmployeesSickListFunctionalButtons.Size = new System.Drawing.Size(312, 35);
            this.tlpEmployeesSickListFunctionalButtons.TabIndex = 2;
            // 
            // btnEmployeesSickListPost
            // 
            this.btnEmployeesSickListPost.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnEmployeesSickListPost.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnEmployeesSickListPost.ForeColor = System.Drawing.Color.White;
            this.btnEmployeesSickListPost.Location = new System.Drawing.Point(159, 3);
            this.btnEmployeesSickListPost.Name = "btnEmployeesSickListPost";
            this.btnEmployeesSickListPost.Size = new System.Drawing.Size(150, 29);
            this.btnEmployeesSickListPost.TabIndex = 0;
            this.btnEmployeesSickListPost.Text = "Сохранить данные";
            this.btnEmployeesSickListPost.UseVisualStyleBackColor = false;
            this.btnEmployeesSickListPost.Click += new System.EventHandler(this.btnEmployeesSickListPost_Click);
            // 
            // btnEmployeesSickListCancel
            // 
            this.btnEmployeesSickListCancel.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnEmployeesSickListCancel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnEmployeesSickListCancel.ForeColor = System.Drawing.Color.White;
            this.btnEmployeesSickListCancel.Location = new System.Drawing.Point(3, 3);
            this.btnEmployeesSickListCancel.Name = "btnEmployeesSickListCancel";
            this.btnEmployeesSickListCancel.Size = new System.Drawing.Size(150, 29);
            this.btnEmployeesSickListCancel.TabIndex = 1;
            this.btnEmployeesSickListCancel.Text = "Отмена";
            this.btnEmployeesSickListCancel.UseVisualStyleBackColor = false;
            this.btnEmployeesSickListCancel.Click += new System.EventHandler(this.btnEmployeesSickListCancel_Click);
            // 
            // tlpEmployeesSickListInput
            // 
            this.tlpEmployeesSickListInput.BackColor = System.Drawing.Color.Transparent;
            this.tlpEmployeesSickListInput.ColumnCount = 3;
            this.tlpEmployeesSickListInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tlpEmployeesSickListInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tlpEmployeesSickListInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tlpEmployeesSickListInput.Controls.Add(this.lblIllEmployee, 1, 0);
            this.tlpEmployeesSickListInput.Controls.Add(this.comboBoxIllEmployee, 1, 1);
            this.tlpEmployeesSickListInput.Controls.Add(this.lblBeginningOfPeriod, 1, 2);
            this.tlpEmployeesSickListInput.Controls.Add(this.dtpBeginningOfPeriod, 1, 3);
            this.tlpEmployeesSickListInput.Controls.Add(this.lblEndOfPeriod, 1, 4);
            this.tlpEmployeesSickListInput.Controls.Add(this.dtpEndOfPeriod, 1, 5);
            this.tlpEmployeesSickListInput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpEmployeesSickListInput.Location = new System.Drawing.Point(3, 3);
            this.tlpEmployeesSickListInput.Name = "tlpEmployeesSickListInput";
            this.tlpEmployeesSickListInput.RowCount = 7;
            this.tlpEmployeesSickListInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 32.5F));
            this.tlpEmployeesSickListInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpEmployeesSickListInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpEmployeesSickListInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpEmployeesSickListInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpEmployeesSickListInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpEmployeesSickListInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tlpEmployeesSickListInput.Size = new System.Drawing.Size(312, 354);
            this.tlpEmployeesSickListInput.TabIndex = 11;
            // 
            // lblIllEmployee
            // 
            this.lblIllEmployee.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblIllEmployee.AutoSize = true;
            this.lblIllEmployee.Location = new System.Drawing.Point(65, 95);
            this.lblIllEmployee.Name = "lblIllEmployee";
            this.lblIllEmployee.Size = new System.Drawing.Size(80, 20);
            this.lblIllEmployee.TabIndex = 1;
            this.lblIllEmployee.Text = "Сотрудник:";
            // 
            // comboBoxIllEmployee
            // 
            this.comboBoxIllEmployee.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBoxIllEmployee.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxIllEmployee.FormattingEnabled = true;
            this.comboBoxIllEmployee.Location = new System.Drawing.Point(65, 117);
            this.comboBoxIllEmployee.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.comboBoxIllEmployee.Name = "comboBoxIllEmployee";
            this.comboBoxIllEmployee.Size = new System.Drawing.Size(181, 28);
            this.comboBoxIllEmployee.TabIndex = 3;
            // 
            // lblBeginningOfPeriod
            // 
            this.lblBeginningOfPeriod.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblBeginningOfPeriod.AutoSize = true;
            this.lblBeginningOfPeriod.Location = new System.Drawing.Point(65, 147);
            this.lblBeginningOfPeriod.Name = "lblBeginningOfPeriod";
            this.lblBeginningOfPeriod.Size = new System.Drawing.Size(120, 20);
            this.lblBeginningOfPeriod.TabIndex = 2;
            this.lblBeginningOfPeriod.Text = "На больничном с:";
            // 
            // dtpBeginningOfPeriod
            // 
            this.dtpBeginningOfPeriod.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.dtpBeginningOfPeriod.Location = new System.Drawing.Point(65, 170);
            this.dtpBeginningOfPeriod.Name = "dtpBeginningOfPeriod";
            this.dtpBeginningOfPeriod.Size = new System.Drawing.Size(181, 25);
            this.dtpBeginningOfPeriod.TabIndex = 4;
            // 
            // lblEndOfPeriod
            // 
            this.lblEndOfPeriod.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblEndOfPeriod.AutoSize = true;
            this.lblEndOfPeriod.Location = new System.Drawing.Point(65, 199);
            this.lblEndOfPeriod.Name = "lblEndOfPeriod";
            this.lblEndOfPeriod.Size = new System.Drawing.Size(129, 20);
            this.lblEndOfPeriod.TabIndex = 5;
            this.lblEndOfPeriod.Text = "На больничном до:";
            // 
            // dtpEndOfPeriod
            // 
            this.dtpEndOfPeriod.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.dtpEndOfPeriod.Location = new System.Drawing.Point(65, 222);
            this.dtpEndOfPeriod.Name = "dtpEndOfPeriod";
            this.dtpEndOfPeriod.Size = new System.Drawing.Size(181, 25);
            this.dtpEndOfPeriod.TabIndex = 6;
            // 
            // tableLayoutPanel_Company
            // 
            this.tableLayoutPanel_Company.BackColor = System.Drawing.SystemColors.HotTrack;
            this.tableLayoutPanel_Company.ColumnCount = 3;
            this.tableLayoutPanel_Company.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_Company.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.tableLayoutPanel_Company.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel_Company.Controls.Add(this.pictureBoxCompany, 0, 1);
            this.tableLayoutPanel_Company.Controls.Add(this.lblCompany, 1, 1);
            this.tableLayoutPanel_Company.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Company.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel_Company.Name = "tableLayoutPanel_Company";
            this.tableLayoutPanel_Company.RowCount = 3;
            this.tableLayoutPanel_Company.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel_Company.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tableLayoutPanel_Company.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel_Company.Size = new System.Drawing.Size(378, 50);
            this.tableLayoutPanel_Company.TabIndex = 8;
            // 
            // pictureBoxCompany
            // 
            this.pictureBoxCompany.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxCompany.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxCompany.Image")));
            this.pictureBoxCompany.Location = new System.Drawing.Point(0, 2);
            this.pictureBoxCompany.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBoxCompany.Name = "pictureBoxCompany";
            this.pictureBoxCompany.Size = new System.Drawing.Size(94, 45);
            this.pictureBoxCompany.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxCompany.TabIndex = 3;
            this.pictureBoxCompany.TabStop = false;
            // 
            // lblCompany
            // 
            this.lblCompany.AutoSize = true;
            this.lblCompany.BackColor = System.Drawing.SystemColors.HotTrack;
            this.lblCompany.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCompany.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblCompany.ForeColor = System.Drawing.Color.White;
            this.lblCompany.Location = new System.Drawing.Point(97, 2);
            this.lblCompany.Name = "lblCompany";
            this.lblCompany.Size = new System.Drawing.Size(258, 45);
            this.lblCompany.TabIndex = 2;
            this.lblCompany.Text = "МЕЖРЕГИОНАЛЬНАЯ РАСПРЕДЕЛИТЕЛЬНАЯ СЕТЕВАЯ КОМПАНИЯ СЕВЕРО-ЗАПАДА";
            this.lblCompany.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // EmployeeEditForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(384, 561);
            this.Controls.Add(this.tableLayoutPanel_AllForm);
            this.Name = "EmployeeEditForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "РЕДАКТОР СВЕДЕНИЙ О КАДРАХ";
            this.Load += new System.EventHandler(this.EmployeeEditForm_Load);
            this.Shown += new System.EventHandler(this.EmployeeEditForm_Shown);
            this.tableLayoutPanel_AllForm.ResumeLayout(false);
            this.tableLayoutPanel_EditField.ResumeLayout(false);
            this.tabControlEmployeesInformationEdit.ResumeLayout(false);
            this.tabPageEmployee.ResumeLayout(false);
            this.tableLayoutPannelEmployees.ResumeLayout(false);
            this.tlpEmployeesFunctionalButtons.ResumeLayout(false);
            this.tlpEmployeesInput.ResumeLayout(false);
            this.tlpEmployeesInput.PerformLayout();
            this.tabPageEmployeesAccount.ResumeLayout(false);
            this.tlpEmployeesAccounts.ResumeLayout(false);
            this.tlpEmployeeAccountInput.ResumeLayout(false);
            this.tlpEmployeeAccountInput.PerformLayout();
            this.tlpEmployeesAccountsFunctionalButtons.ResumeLayout(false);
            this.tabPageAlternateList.ResumeLayout(false);
            this.tlpAlternateList.ResumeLayout(false);
            this.tlpAlternateListInput.ResumeLayout(false);
            this.tlpAlternateListInput.PerformLayout();
            this.tlpAltenateListFunctionalButtons.ResumeLayout(false);
            this.tabPageEmployeesSickList.ResumeLayout(false);
            this.tlpEmployeesSickList.ResumeLayout(false);
            this.tlpEmployeesSickListFunctionalButtons.ResumeLayout(false);
            this.tlpEmployeesSickListInput.ResumeLayout(false);
            this.tlpEmployeesSickListInput.PerformLayout();
            this.tableLayoutPanel_Company.ResumeLayout(false);
            this.tableLayoutPanel_Company.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCompany)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_AllForm;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Company;
        private System.Windows.Forms.PictureBox pictureBoxCompany;
        private System.Windows.Forms.Label lblCompany;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_EditField;
        private System.Windows.Forms.TabControl tabControlEmployeesInformationEdit;
        private System.Windows.Forms.TabPage tabPageEmployee;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPannelEmployees;
        private System.Windows.Forms.TableLayoutPanel tlpEmployeesFunctionalButtons;
        private System.Windows.Forms.Button btnEmployeeCancel;
        private System.Windows.Forms.Button btnEmployeePost;
        private System.Windows.Forms.TableLayoutPanel tlpEmployeesInput;
        private System.Windows.Forms.Label lBlSurname;
        private System.Windows.Forms.TextBox textBoxPassportSeries;
        private System.Windows.Forms.TextBox textBoxPassportNumber;
        private System.Windows.Forms.DateTimePicker dateTimePickerBirthday;
        private System.Windows.Forms.TextBox textBoxRegistrationPlace;
        private System.Windows.Forms.DateTimePicker dateTimePickerEmploymentDate;
        private System.Windows.Forms.TextBox textBoxFathersName;
        private System.Windows.Forms.TextBox textBoxInn;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblFathersName;
        private System.Windows.Forms.TextBox textBoxName;
        private System.Windows.Forms.TextBox textBoxSurname;
        private System.Windows.Forms.Label lblBirthday;
        private System.Windows.Forms.Label lblPasspordNumber;
        private System.Windows.Forms.Label lblPassportSeries;
        private System.Windows.Forms.ComboBox comboBoxGender;
        private System.Windows.Forms.Label labelRegistrationPlace;
        private System.Windows.Forms.Label lblGender;
        private System.Windows.Forms.Label lblSnils;
        private System.Windows.Forms.Label lblInn;
        private System.Windows.Forms.Label lblEmploymentDate;
        private System.Windows.Forms.TabPage tabPageEmployeesAccount;
        private System.Windows.Forms.TableLayoutPanel tlpEmployeesAccounts;
        private System.Windows.Forms.TabPage tabPageAlternateList;
        private System.Windows.Forms.TableLayoutPanel tlpAlternateList;
        private System.Windows.Forms.TableLayoutPanel tlpAltenateListFunctionalButtons;
        private System.Windows.Forms.Button btnAlternateListPost;
        private System.Windows.Forms.Button btnAlternateListCancel;
        private System.Windows.Forms.TableLayoutPanel tlpEmployeesAccountsFunctionalButtons;
        private System.Windows.Forms.Button btnEmployeesAccountPost;
        private System.Windows.Forms.Button btnEmployeesAccountCancel;
        private System.Windows.Forms.TableLayoutPanel tlpAlternateListInput;
        private System.Windows.Forms.Label lblVacationist;
        private System.Windows.Forms.Label lblAlternate;
        private System.Windows.Forms.ComboBox comboBoxVacationist;
        private System.Windows.Forms.TableLayoutPanel tlpEmployeeAccountInput;
        private System.Windows.Forms.Label labelEmployee;
        private System.Windows.Forms.Label labelRole;
        private System.Windows.Forms.ComboBox comboBoxEmployee;
        private System.Windows.Forms.ComboBox comboBoxRole;
        private System.Windows.Forms.Label labelLogin;
        private System.Windows.Forms.Label labelPassword;
        private System.Windows.Forms.TextBox textBoxLogin;
        private System.Windows.Forms.TextBox textBoxPassword;
        private System.Windows.Forms.Label labelStatus;
        private System.Windows.Forms.ComboBox comboBoxStatus;
        private System.Windows.Forms.ComboBox comboBoxAlternate;
        private System.Windows.Forms.TabPage tabPageEmployeesSickList;
        private System.Windows.Forms.TableLayoutPanel tlpEmployeesSickList;
        private System.Windows.Forms.TableLayoutPanel tlpEmployeesSickListFunctionalButtons;
        private System.Windows.Forms.Button btnEmployeesSickListPost;
        private System.Windows.Forms.Button btnEmployeesSickListCancel;
        private System.Windows.Forms.TableLayoutPanel tlpEmployeesSickListInput;
        private System.Windows.Forms.Label lblIllEmployee;
        private System.Windows.Forms.ComboBox comboBoxIllEmployee;
        private System.Windows.Forms.Label lblBeginningOfPeriod;
        private System.Windows.Forms.DateTimePicker dtpBeginningOfPeriod;
        private System.Windows.Forms.Label lblEndOfPeriod;
        private System.Windows.Forms.DateTimePicker dtpEndOfPeriod;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxSnils;
    }
}