﻿namespace VacationScheduleCreator
{
    partial class VacationScheduleOfAllCompanyDocumentForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(VacationScheduleOfAllCompanyDocumentForm));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tableLayoutPanel_AllForm = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel_Company = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBoxCompany = new System.Windows.Forms.PictureBox();
            this.lblCompany = new System.Windows.Forms.Label();
            this.tableLayoutPanel_Document = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel_Working_field = new System.Windows.Forms.TableLayoutPanel();
            this.groupBoxVacationScheduleOfUnit = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanelVacationScheduleOfUnit = new System.Windows.Forms.TableLayoutPanel();
            this.dataGridViewVacationSchedule = new System.Windows.Forms.DataGridView();
            this.btnVacationScheduleCompanyCreate = new System.Windows.Forms.Button();
            this.tableLayoutPanel_WindowHeader = new System.Windows.Forms.TableLayoutPanel();
            this.lblVacationScheduleOfCompanyDocument = new System.Windows.Forms.Label();
            this.tableLayoutPanel_Programm = new System.Windows.Forms.TableLayoutPanel();
            this.lblProgramm = new System.Windows.Forms.Label();
            this.tableLayoutPanel_AllForm.SuspendLayout();
            this.tableLayoutPanel_Company.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCompany)).BeginInit();
            this.tableLayoutPanel_Document.SuspendLayout();
            this.tableLayoutPanel_Working_field.SuspendLayout();
            this.groupBoxVacationScheduleOfUnit.SuspendLayout();
            this.tableLayoutPanelVacationScheduleOfUnit.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVacationSchedule)).BeginInit();
            this.tableLayoutPanel_WindowHeader.SuspendLayout();
            this.tableLayoutPanel_Programm.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel_AllForm
            // 
            this.tableLayoutPanel_AllForm.ColumnCount = 1;
            this.tableLayoutPanel_AllForm.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_AllForm.Controls.Add(this.tableLayoutPanel_Company, 0, 1);
            this.tableLayoutPanel_AllForm.Controls.Add(this.tableLayoutPanel_Document, 0, 2);
            this.tableLayoutPanel_AllForm.Controls.Add(this.tableLayoutPanel_Programm, 0, 0);
            this.tableLayoutPanel_AllForm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_AllForm.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel_AllForm.Name = "tableLayoutPanel_AllForm";
            this.tableLayoutPanel_AllForm.RowCount = 3;
            this.tableLayoutPanel_AllForm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel_AllForm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tableLayoutPanel_AllForm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 75F));
            this.tableLayoutPanel_AllForm.Size = new System.Drawing.Size(784, 497);
            this.tableLayoutPanel_AllForm.TabIndex = 11;
            // 
            // tableLayoutPanel_Company
            // 
            this.tableLayoutPanel_Company.BackColor = System.Drawing.SystemColors.HotTrack;
            this.tableLayoutPanel_Company.ColumnCount = 2;
            this.tableLayoutPanel_Company.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel_Company.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.tableLayoutPanel_Company.Controls.Add(this.pictureBoxCompany, 0, 1);
            this.tableLayoutPanel_Company.Controls.Add(this.lblCompany, 1, 1);
            this.tableLayoutPanel_Company.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Company.Location = new System.Drawing.Point(3, 52);
            this.tableLayoutPanel_Company.Name = "tableLayoutPanel_Company";
            this.tableLayoutPanel_Company.RowCount = 3;
            this.tableLayoutPanel_Company.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel_Company.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tableLayoutPanel_Company.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel_Company.Size = new System.Drawing.Size(778, 68);
            this.tableLayoutPanel_Company.TabIndex = 7;
            // 
            // pictureBoxCompany
            // 
            this.pictureBoxCompany.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxCompany.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxCompany.Image")));
            this.pictureBoxCompany.Location = new System.Drawing.Point(3, 6);
            this.pictureBoxCompany.Name = "pictureBoxCompany";
            this.pictureBoxCompany.Size = new System.Drawing.Size(227, 55);
            this.pictureBoxCompany.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxCompany.TabIndex = 3;
            this.pictureBoxCompany.TabStop = false;
            // 
            // lblCompany
            // 
            this.lblCompany.AutoSize = true;
            this.lblCompany.BackColor = System.Drawing.SystemColors.HotTrack;
            this.lblCompany.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCompany.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblCompany.ForeColor = System.Drawing.Color.White;
            this.lblCompany.Location = new System.Drawing.Point(236, 3);
            this.lblCompany.Name = "lblCompany";
            this.lblCompany.Size = new System.Drawing.Size(539, 61);
            this.lblCompany.TabIndex = 2;
            this.lblCompany.Text = "МЕЖРЕГИОНАЛЬНАЯ РАСПРЕДЕЛИТЕЛЬНАЯ СЕТЕВАЯ КОМПАНИЯ СЕВЕРО-ЗАПАДА";
            this.lblCompany.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel_Document
            // 
            this.tableLayoutPanel_Document.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPanel_Document.ColumnCount = 1;
            this.tableLayoutPanel_Document.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_Document.Controls.Add(this.tableLayoutPanel_Working_field, 0, 1);
            this.tableLayoutPanel_Document.Controls.Add(this.tableLayoutPanel_WindowHeader, 0, 0);
            this.tableLayoutPanel_Document.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Document.Location = new System.Drawing.Point(3, 126);
            this.tableLayoutPanel_Document.Name = "tableLayoutPanel_Document";
            this.tableLayoutPanel_Document.RowCount = 2;
            this.tableLayoutPanel_Document.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12F));
            this.tableLayoutPanel_Document.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 88F));
            this.tableLayoutPanel_Document.Size = new System.Drawing.Size(778, 368);
            this.tableLayoutPanel_Document.TabIndex = 6;
            // 
            // tableLayoutPanel_Working_field
            // 
            this.tableLayoutPanel_Working_field.ColumnCount = 1;
            this.tableLayoutPanel_Working_field.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_Working_field.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel_Working_field.Controls.Add(this.groupBoxVacationScheduleOfUnit, 0, 0);
            this.tableLayoutPanel_Working_field.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Working_field.Location = new System.Drawing.Point(3, 44);
            this.tableLayoutPanel_Working_field.Margin = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.tableLayoutPanel_Working_field.Name = "tableLayoutPanel_Working_field";
            this.tableLayoutPanel_Working_field.RowCount = 1;
            this.tableLayoutPanel_Working_field.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_Working_field.Size = new System.Drawing.Size(772, 321);
            this.tableLayoutPanel_Working_field.TabIndex = 7;
            // 
            // groupBoxVacationScheduleOfUnit
            // 
            this.groupBoxVacationScheduleOfUnit.Controls.Add(this.tableLayoutPanelVacationScheduleOfUnit);
            this.groupBoxVacationScheduleOfUnit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxVacationScheduleOfUnit.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBoxVacationScheduleOfUnit.ForeColor = System.Drawing.Color.White;
            this.groupBoxVacationScheduleOfUnit.Location = new System.Drawing.Point(3, 3);
            this.groupBoxVacationScheduleOfUnit.Name = "groupBoxVacationScheduleOfUnit";
            this.groupBoxVacationScheduleOfUnit.Size = new System.Drawing.Size(766, 315);
            this.groupBoxVacationScheduleOfUnit.TabIndex = 2;
            this.groupBoxVacationScheduleOfUnit.TabStop = false;
            this.groupBoxVacationScheduleOfUnit.Text = "График отпусков:";
            // 
            // tableLayoutPanelVacationScheduleOfUnit
            // 
            this.tableLayoutPanelVacationScheduleOfUnit.ColumnCount = 1;
            this.tableLayoutPanelVacationScheduleOfUnit.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelVacationScheduleOfUnit.Controls.Add(this.dataGridViewVacationSchedule, 0, 0);
            this.tableLayoutPanelVacationScheduleOfUnit.Controls.Add(this.btnVacationScheduleCompanyCreate, 0, 1);
            this.tableLayoutPanelVacationScheduleOfUnit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelVacationScheduleOfUnit.Location = new System.Drawing.Point(3, 25);
            this.tableLayoutPanelVacationScheduleOfUnit.Name = "tableLayoutPanelVacationScheduleOfUnit";
            this.tableLayoutPanelVacationScheduleOfUnit.RowCount = 2;
            this.tableLayoutPanelVacationScheduleOfUnit.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 88F));
            this.tableLayoutPanelVacationScheduleOfUnit.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12F));
            this.tableLayoutPanelVacationScheduleOfUnit.Size = new System.Drawing.Size(760, 287);
            this.tableLayoutPanelVacationScheduleOfUnit.TabIndex = 0;
            // 
            // dataGridViewVacationSchedule
            // 
            this.dataGridViewVacationSchedule.AllowUserToAddRows = false;
            this.dataGridViewVacationSchedule.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.AntiqueWhite;
            this.dataGridViewVacationSchedule.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewVacationSchedule.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewVacationSchedule.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewVacationSchedule.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewVacationSchedule.Location = new System.Drawing.Point(3, 3);
            this.dataGridViewVacationSchedule.MultiSelect = false;
            this.dataGridViewVacationSchedule.Name = "dataGridViewVacationSchedule";
            this.dataGridViewVacationSchedule.ReadOnly = true;
            this.dataGridViewVacationSchedule.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewVacationSchedule.Size = new System.Drawing.Size(754, 246);
            this.dataGridViewVacationSchedule.TabIndex = 0;
            // 
            // btnVacationScheduleCompanyCreate
            // 
            this.btnVacationScheduleCompanyCreate.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnVacationScheduleCompanyCreate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnVacationScheduleCompanyCreate.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnVacationScheduleCompanyCreate.Location = new System.Drawing.Point(3, 255);
            this.btnVacationScheduleCompanyCreate.Name = "btnVacationScheduleCompanyCreate";
            this.btnVacationScheduleCompanyCreate.Size = new System.Drawing.Size(754, 29);
            this.btnVacationScheduleCompanyCreate.TabIndex = 1;
            this.btnVacationScheduleCompanyCreate.Text = "Сформировать документ";
            this.btnVacationScheduleCompanyCreate.UseVisualStyleBackColor = false;
            this.btnVacationScheduleCompanyCreate.Click += new System.EventHandler(this.btnVacationScheduleCompanyCreate_Click);
            // 
            // tableLayoutPanel_WindowHeader
            // 
            this.tableLayoutPanel_WindowHeader.ColumnCount = 4;
            this.tableLayoutPanel_WindowHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_WindowHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_WindowHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_WindowHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_WindowHeader.Controls.Add(this.lblVacationScheduleOfCompanyDocument, 0, 0);
            this.tableLayoutPanel_WindowHeader.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_WindowHeader.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel_WindowHeader.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.tableLayoutPanel_WindowHeader.Name = "tableLayoutPanel_WindowHeader";
            this.tableLayoutPanel_WindowHeader.RowCount = 1;
            this.tableLayoutPanel_WindowHeader.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_WindowHeader.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 41F));
            this.tableLayoutPanel_WindowHeader.Size = new System.Drawing.Size(772, 41);
            this.tableLayoutPanel_WindowHeader.TabIndex = 6;
            // 
            // lblVacationScheduleOfCompanyDocument
            // 
            this.lblVacationScheduleOfCompanyDocument.AutoSize = true;
            this.tableLayoutPanel_WindowHeader.SetColumnSpan(this.lblVacationScheduleOfCompanyDocument, 4);
            this.lblVacationScheduleOfCompanyDocument.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblVacationScheduleOfCompanyDocument.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblVacationScheduleOfCompanyDocument.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblVacationScheduleOfCompanyDocument.Location = new System.Drawing.Point(3, 0);
            this.lblVacationScheduleOfCompanyDocument.Name = "lblVacationScheduleOfCompanyDocument";
            this.lblVacationScheduleOfCompanyDocument.Size = new System.Drawing.Size(766, 41);
            this.lblVacationScheduleOfCompanyDocument.TabIndex = 19;
            this.lblVacationScheduleOfCompanyDocument.Text = "ФОРМИРОВАНИЕ ДОКУМЕНТА (ГРАФИК ОТПУСКОВ)";
            this.lblVacationScheduleOfCompanyDocument.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel_Programm
            // 
            this.tableLayoutPanel_Programm.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPanel_Programm.ColumnCount = 1;
            this.tableLayoutPanel_Programm.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Programm.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Programm.Controls.Add(this.lblProgramm, 0, 0);
            this.tableLayoutPanel_Programm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Programm.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel_Programm.Name = "tableLayoutPanel_Programm";
            this.tableLayoutPanel_Programm.RowCount = 1;
            this.tableLayoutPanel_Programm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Programm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Programm.Size = new System.Drawing.Size(778, 43);
            this.tableLayoutPanel_Programm.TabIndex = 8;
            // 
            // lblProgramm
            // 
            this.lblProgramm.AutoSize = true;
            this.lblProgramm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblProgramm.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblProgramm.ForeColor = System.Drawing.Color.White;
            this.lblProgramm.Location = new System.Drawing.Point(3, 0);
            this.lblProgramm.Name = "lblProgramm";
            this.lblProgramm.Size = new System.Drawing.Size(772, 43);
            this.lblProgramm.TabIndex = 0;
            this.lblProgramm.Text = "ФОРМИРОВАНИЕ И ВЕДЕНИЕ ГРАФИКА ОТПУСКОВ СОТРУДНИКОВ";
            this.lblProgramm.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // VacationScheduleOfAllCompanyDocumentForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 497);
            this.Controls.Add(this.tableLayoutPanel_AllForm);
            this.Name = "VacationScheduleOfAllCompanyDocumentForm";
            this.Text = "ГРАФИК ОТПУСКОВ ВСЕГО ПРЕДПРИЯТИЯ";
            this.Activated += new System.EventHandler(this.VacationScheduleOfAllCompanyDocumentForm_Activated);
            this.Load += new System.EventHandler(this.VacationScheduleOfAllCompanyDocumentForm_Load);
            this.Shown += new System.EventHandler(this.VacationScheduleOfAllCompanyDocumentForm_Shown);
            this.tableLayoutPanel_AllForm.ResumeLayout(false);
            this.tableLayoutPanel_Company.ResumeLayout(false);
            this.tableLayoutPanel_Company.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCompany)).EndInit();
            this.tableLayoutPanel_Document.ResumeLayout(false);
            this.tableLayoutPanel_Working_field.ResumeLayout(false);
            this.groupBoxVacationScheduleOfUnit.ResumeLayout(false);
            this.tableLayoutPanelVacationScheduleOfUnit.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVacationSchedule)).EndInit();
            this.tableLayoutPanel_WindowHeader.ResumeLayout(false);
            this.tableLayoutPanel_WindowHeader.PerformLayout();
            this.tableLayoutPanel_Programm.ResumeLayout(false);
            this.tableLayoutPanel_Programm.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_AllForm;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Company;
        private System.Windows.Forms.PictureBox pictureBoxCompany;
        private System.Windows.Forms.Label lblCompany;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Document;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Working_field;
        private System.Windows.Forms.GroupBox groupBoxVacationScheduleOfUnit;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelVacationScheduleOfUnit;
        private System.Windows.Forms.DataGridView dataGridViewVacationSchedule;
        private System.Windows.Forms.Button btnVacationScheduleCompanyCreate;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_WindowHeader;
        private System.Windows.Forms.Label lblVacationScheduleOfCompanyDocument;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Programm;
        private System.Windows.Forms.Label lblProgramm;
    }
}