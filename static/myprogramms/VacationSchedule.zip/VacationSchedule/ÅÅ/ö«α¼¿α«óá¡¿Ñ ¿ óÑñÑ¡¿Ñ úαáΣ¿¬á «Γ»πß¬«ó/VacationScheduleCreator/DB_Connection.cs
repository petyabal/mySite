﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using MySql.Data.MySqlClient;//модуль для работы с БД MySQL

namespace VacationScheduleCreator
{
    //класс соединения и работы с БД
    class DB_Connection
    {
        //строка подключения к БД
        static string сonnectionString = @"DataBase = vacation_schedule;
        Data Source = localhost; userID = root; password = qwerty";

        static MySqlConnection msConnect;//объект для установления соединения с БД
        static MySqlCommand msCommand;//объект для выполнения запросов
        static MySqlDataAdapter msDataAdapter;//набор данных и подключение к БД для заполнения DataSet и обновления БД

        static public string ActiveRole; //строка хранит роль текущего пользователя
        static public string ActiveUser; //строка хранит Фамилию и инициалы текущего пользователя
        static public string ActiveLogin;//строка хранит логин текущего пользователя

        //наборы данных для вывода содержимого таблиц БД
        static public DataTable dtEmployees = new DataTable();
        static public DataTable dtFunctions = new DataTable();
        static public DataTable dtVacationLog = new DataTable();
        static public DataTable dtAlternateList = new DataTable();
        static public DataTable dtStaffingTable = new DataTable();
        static public DataTable dtVacationTypes = new DataTable();       
        static public DataTable dtHierarchyLevels = new DataTable();
        static public DataTable dtStructuralUnits = new DataTable();
        static public DataTable dtUnitVacationLog = new DataTable();
        static public DataTable dtEmployeesAccounts = new DataTable();
        static public DataTable dtStateHolidaysList = new DataTable();
        static public DataTable dtVacationSchedules = new DataTable();
        static public DataTable dtCompanyInformation = new DataTable();
        static public DataTable dtEmployeesSickLists = new DataTable();
        static public DataTable dtEmployeesVacations = new DataTable();
        static public DataTable dtStaffingTablesList = new DataTable();
        static public DataTable dtEmployeesPaidTravel = new DataTable();
        static public DataTable dtPersonnelCategories = new DataTable();
        static public DataTable dtSpendingOfVacations = new DataTable();
        static public DataTable dtRealVacationSpending = new DataTable();
        static public DataTable dtUnitEmployeesVacations = new DataTable();
        static public DataTable dtEmployeesVacationsBalance = new DataTable();
        static public DataTable dtActualVacationScheduleStatus = new DataTable();        

        //наборы данных для вывода отчетов
        static public DataTable dtDaysCreditReport = new DataTable();
        static public DataTable dtDaysRemainReport = new DataTable();
        static public DataTable dtUnitVacationScheduleDocument = new DataTable();
        static public DataTable dtAllCompanyVacationScheduleDocument = new DataTable();
        static public DataTable dtVacationsSchedulesForReport = new DataTable();
        static public DataTable dtVacationLogReport = new DataTable();

        //наборы данных для выпадающих списков
        static public DataTable dtComboBoxEmployees = new DataTable();
        static public DataTable dtComboboxParentUnit = new DataTable();
        static public DataTable dtUnitEmployees = new DataTable();

        //процедура открытия соединения с БД
        //(выполняется при загрузке главной формы)
        static public bool Connect()
        {
            try//пытаться
            {
                //создание объекта соединения с заданной строкой подключения
                msConnect = new MySqlConnection(сonnectionString);
                msConnect.Open();//открытие соединения с БД

                //создание объекта - запрос
                msCommand = new MySqlCommand();
                msCommand.Connection = msConnect;

                msDataAdapter = new MySqlDataAdapter(msCommand);
                return true;//вернуть значение "истина"
            }
            catch (Exception ex)//в случае возникновения ошибки
            {
                System.Windows.Forms.MessageBox.Show(ex.ToString(), "Ошибка");
                //вывести сообщение об ошибке с описнием ошибки
                return false;//вернуть значение "ложь"
            }
        }

        //процедура закрытия соединения 
        //(выполняется при событии закрытия главной формы)
        static public void Close()
        {
            msConnect.Close();
        }

        //процедура авторизации
        static public bool Authorization(string login, string password)
        {
            msCommand.CommandText = @"SELECT Password FROM employees_accounts WHERE 
            BINARY Login = '" + login + "';";
            Object pass = msCommand.ExecuteScalar();
            if (pass != null)
            {
                msCommand.CommandText = @"SELECT Attempts_quantity FROM employees_accounts
                WHERE Login = '" + login + "';";
                byte AttemptsQuantity = Convert.ToByte(msCommand.ExecuteScalar());
                {
                    if (AttemptsQuantity > 0)
                    {
                        if (pass.ToString() == password)
                        {
                            msCommand.CommandText = @"UPDATE employees_accounts SET 
                            Attempts_quantity = 3 WHERE Login = '" + login + "';";
                            msCommand.ExecuteNonQuery();
                            ActiveLogin = login;
                            msCommand.CommandText = @"SELECT Role FROM employees_accounts 
                            WHERE BINARY login = '" + login + "' AND BINARY Password = '"
                                + password + "';";
                            ActiveRole = Convert.ToString(msCommand.ExecuteScalar());
                            msCommand.CommandText = "SELECT e.Surname_NF FROM " +
                            "employees e, employees_accounts ea WHERE (e.Personnel_number = " +
                            "ea.Personnel_number) AND (ea.Login = '" + login + "');";
                            ActiveUser = msCommand.ExecuteScalar().ToString();
                            System.Windows.Forms.MessageBox.Show("Авторизация пройдена!");
                            return true;
                        }
                        else
                        {
                            msCommand.CommandText = @"UPDATE employees_accounts SET
                            Attempts_quantity = Attempts_quantity - 1 WHERE BINARY Login = '"
                                + login + "';";
                            msCommand.ExecuteNonQuery();
                            AttemptsQuantity--;
                            System.Windows.Forms.MessageBox.Show("Пароль введен неверно! "
                            + "Осталось попыток ввода пароля: " + AttemptsQuantity);
                            return false;
                        }
                    }
                    else
                    {
                        System.Windows.Forms.MessageBox.Show("Израсходовано число попыток " +
                        "ввода пароля!\nСвяжитесть с администратором!");
                        return false;
                    }
                }
            }
            else
            {
                System.Windows.Forms.MessageBox.Show("Логин указан неверно!");
                return false;
            }
        }


        //ТАБЛИЦА "СОТРУДНИКИ"
        //процедура отображения содержимого таблицы "Список сотрудников"
        static public void ShowEmployees()
        {
            msCommand.CommandText = @"SELECT Personnel_number as 'Табельный номер',
            Surname as 'Фамилия', Name as 'Имя', Fathers_name as 'Отчество', Surname_NF,
            Birthday as 'Дата рождения', Gender as 'Пол', Passport_series as 
            'Серия паспорта', Passport_number as 'Номер паспорта', SNILS as 'СНИЛС',
            INN as 'ИНН', Registration_place as 'Место регистрации', Employment_date as
            'Дата приема на работу' FROM employees ORDER BY Surname_NF;";
            msDataAdapter = new MySqlDataAdapter(msCommand);
            dtEmployees.Clear();
            msDataAdapter.Fill(dtEmployees);
        }

        //процедура добавления записи в таблицу "Сотрудники"
        static public void AddEmployee(string surname, string name, string fathersName,
            string birthday, string gender, string passportSeries, string passportNumber,
            string snils, string inn, string registration, string employmentDate)
        {
            string account = surname + " " + name[0] + "." + fathersName[0] + ".";
            msCommand.CommandText = @"INSERT INTO employees VALUES(null,'" + surname + "','"
                + name + "','" + fathersName + "','" + account + "','" + birthday + "','" +
                gender + "','" + passportSeries + "','" + passportNumber + "','" + snils +
                "','" + inn + "','" + registration + "','" + employmentDate + "');";
            msCommand.ExecuteNonQuery();
        }

        //процедура редактирования записи в таблице "Сотрудники"
        static public void EditEmployee(string personnelNumber, string surname, string name,
            string fathersName, string birthday, string gender, string passportSeries,
            string passportNumber, string snils, string inn, string registration, string employmentDate)
        {
            string account = surname + " " + name[0] + "." + fathersName[0] + ".";
            msCommand.CommandText = @"UPDATE employees SET Surname = '" + surname + "', Name = '"
                + name + "', Fathers_name = '" + fathersName + "', Surname_NF = '" + account +
                "', Birthday = '" + birthday + "', Gender = '" + gender + "', Passport_series = '"
                + passportSeries + "', Passport_number = '" + passportNumber + "', SNILS  = '" +
                snils + "', INN = '" + inn + "', Registration_place = '" + registration +
                "', Employment_date = '" + employmentDate + "' WHERE Personnel_number = '" +
                personnelNumber + "';";
            msCommand.ExecuteNonQuery();
        }


        //СПРАВОЧНИК "ДОЛЖНОСТИ"
        //процедура отображения содержимого справочника "Должности"
        static public void ShowFunctions()
        {
            msCommand.CommandText = @"SELECT Function_id, Function as 'Должность'
            FROM functions ORDER BY Function;";
            msDataAdapter = new MySqlDataAdapter(msCommand);
            dtFunctions.Clear();
            msDataAdapter.Fill(dtFunctions);
        }

        //процедура добавления записи в справочник "Должности"
        static public void AddFunction(string functionName)
        {
            msCommand.CommandText = @"INSERT INTO functions VALUES(null,'" +
                functionName + "');";
            msCommand.ExecuteNonQuery();
        }

        //процедура редактирования записи в справочнике "Должности"
        static public void EditFunction(string number, string functionName)
        {
            msCommand.CommandText = @"UPDATE functions SET Function = '" + functionName
                + "' WHERE Function_id = '" + number + "';";
            msCommand.ExecuteNonQuery();
        }

        //процедура удаления записи из справочника "Должности"
        static public void DeleteFunction(string number)
        {
            msCommand.CommandText = "DELETE FROM functions WHERE Function_id = '" +
                number + "';";
            msCommand.ExecuteNonQuery();
        }

        //процедура проверки существования конкретной должности
        static public bool FunctionExists(string TheFunction)
        {
            msCommand.CommandText = @"SELECT Function_id FROM functions WHERE 
            Function = '" + TheFunction + "';";
            Object result = msCommand.ExecuteScalar();
            if (result != null) return true;
            else return false;
        }

        //проверка наличия должности в штатном расписании перед удалением должности
        static public bool FunctionInStaffingTable(string TheFunction)
        {
            msCommand.CommandText = @"SELECT Position_id FROM staffing_table WHERE 
            Function_id = " + TheFunction + ";";
            Object result = msCommand.ExecuteScalar();
            if (result != null) return true;
            else return false;
        }

        //процедура получения идентификатора должности по наименованию
        static public string GetFunctionId(string TheFunction)
        {
            msCommand.CommandText = @"SELECT Function_id FROM functions WHERE
            Function = '" + TheFunction + "';";
            Object result = msCommand.ExecuteScalar();
            return result.ToString();
        }


        //ТАБЛИЦА "ЖУРНАЛ ВЕДЕНИЯ ОТПУСКОВ"
        //процедура показа содержимого таблицы "Журнал ведения отпусков"
        //при указании графика отпусков
        static public void ShowVacationLog(string number)
        {
            msCommand.CommandText = @"SELECT vl.Vacation_schedule_id,
            vl.Position_id, e.Surname_NF as 'Сотрудник', 
            vt.Vacation_type as 'Вид отпуска', vl.Vacation_start_date as 
            'Начало отпуска', vl.Vacation_finish_date
            as 'Конец отпуска', vl.Days_quantity as 'Итого дней отпуска'
            FROM employees e, vacation_schedules vs, vacation_types vt, 
            vacation_log vl 
            WHERE (e.Personnel_number = vl.Personnel_number) AND
            (vs.Vacation_schedule_id = vl.Vacation_schedule_id) AND
            (vt.Vacation_type_id = vl.Vacation_type_id) AND
            (vl.Vacation_schedule_id = '" + number + "');";
            msDataAdapter = new MySqlDataAdapter(msCommand);
            dtVacationLog.Clear();
            msDataAdapter.Fill(dtVacationLog);
        }
        
        //процедура показа содержимого таблицы "Журнал ведения отпусков"
        //при указании структурного подразделения
        static public void ShowUnitVacationLog(string unit)
        {
            msCommand.CommandText = @"SELECT vl.Vacation_schedule_id,
            vl.Position_id, e.Surname_NF as 'Сотрудник', 
            vt.Vacation_type as 'Вид отпуска', vl.Vacation_start_date as 
            'Начало отпуска', vl.Vacation_finish_date
            as 'Конец отпуска', vl.Days_quantity as 'Итого дней отпуска'
            FROM employees e, vacation_schedules vs, vacation_types vt, 
            vacation_log vl 
            WHERE (e.Personnel_number = vl.Personnel_number) AND
            (vs.Vacation_schedule_id = vl.Vacation_schedule_id) AND
            (vt.Vacation_type_id = vl.Vacation_type_id) AND
            (vs.Structural_unit_id = '" + unit + "');";
            msDataAdapter = new MySqlDataAdapter(msCommand);
            dtUnitVacationLog.Clear();
            msDataAdapter.Fill(dtUnitVacationLog);
        }

        //процедура показа таблицы "Расходование фактических отпусков" для выбора отпуска
        static public void ShowEmployeeRealVacationsBalance(string employee)
        {
            msCommand.CommandText = @"SELECT rvs.Position_id, e.Personnel_number,
            rvs.Year as 'За календарный год', vt.Vacation_type as 'Вид отпуска', 
            rvs.Paid_days as 'Оплачиваемых дней', rvs.Paid_days_balance as 
            'Осталось оплачиваемых дней' FROM real_vacation_spending rvs, employees e,
            vacation_types vt WHERE (rvs.Personnel_number=e.Personnel_number) AND 
            (rvs.Vacation_type_id=vt.Vacation_type_id) AND (e.Personnel_number = '"
                + employee + "') ORDER BY rvs.Year;";
            msDataAdapter = new MySqlDataAdapter(msCommand);
            dtRealVacationSpending.Clear();
            msDataAdapter.Fill(dtRealVacationSpending);
        }

        //процедура добавления записи в таблицу "Журнал ведения отпусков"
        static public void AddToVacationLog(string personnelNumber, string vacationSchedule,
            string vacationStart, string vacationFinish, string vacationType,
            string daysQuantity)
        {
            msCommand.CommandText = "INSERT INTO vacation_log VALUES(null, '" +
                personnelNumber + "','" + vacationSchedule + "','" + vacationStart +
                "','" + vacationFinish + "','" + daysQuantity + "','" + vacationType + "');";
            msCommand.ExecuteNonQuery();
        }

        //процедура редактирования записи в таблице "Журнал ведения отпусков"
        static public void EditInVacationLog(string number, string personnelNumber, string
            vacationSchedule, string vacationStart, string vacationFinish, string vacationType,
            string daysQuantity)
        {
            msCommand.CommandText = "UPDATE vacation_log SET Personnel_number = '" +
                personnelNumber + "', Vacation_schedule_id = '" + vacationSchedule +
                "', Vacation_start_date = '" + vacationStart + "', Vacation_finish_date = '"
                + vacationFinish + "', Days_quantity = '" + daysQuantity +
                "', Vacation_type_id = '" + vacationType + "';";
            msCommand.ExecuteNonQuery();
        }

        //процедура удаления записи из таблицы "Журнал ведения отпусков"
        static public void DeleteFromVacationLog(string number)
        {
            msCommand.CommandText = "DELETE FROM vacation_log WHERE Position_id = '"
                + number + "';";
            msCommand.ExecuteNonQuery();
        }


        //ТАБЛИЦА "СПИСОК ЗАМЕЩАЮЩИХ ЛИЦ"
        //процедура отображения содержимого таблицы "Список замещающих лиц"
        static public void ShowAlternateList()
        {
            msCommand.CommandText = @"SELECT al.Position_id, 
            v.Surname_NF as 'Отпускник',e.Surname_NF as 'Замещающее лицо'
            FROM vacationists v, employees e, alternate_list al
            WHERE (v.Position_id = al.Position_id) and
            (e.Personnel_number = al.Alternate_personnel_number)
            ORDER BY v.Surname_NF;";
            /* для вывода информации создано представление:
            create view Vacationists as 
            select al.Position_id, e.Surname_NF from alternate_list al, employees e
            where al.Vacationist_personnel_number = e.Personnel_number;*/
            msDataAdapter = new MySqlDataAdapter(msCommand);
            dtAlternateList.Clear();
            msDataAdapter.Fill(dtAlternateList);
        }

        //процедура добавления записи в таблицу "Список замещающих лиц"
        static public void AddAlternate(string vacationist, string alternate)
        {
            msCommand.CommandText = "INSERT INTO alternate_list VALUES (null, '"
                + vacationist + "', '" + alternate + "');";
            msCommand.ExecuteNonQuery();
        }

        //процедура редактирования записи в таблице "Список замещающих лиц"
        static public void EditAlternate(string number, string vacationist, string alternate)
        {
            msCommand.CommandText = "UPDATE alternate_list SET Vacationist_personnel_number ='"
                + vacationist + "', Alternate_personnel_number = '" + alternate +
                "' WHERE Position_id = '" + number + "';";
            msCommand.ExecuteNonQuery();
        }

        //процедура удаления записи из таблицы "Список замещающих лиц"
        static public void DeleteAlternate(string number)
        {
            msCommand.CommandText = "DELETE FROM alternate_list WHERE Position_id = '"
                + number + "';";
            msCommand.ExecuteNonQuery();
        }

        //процедура проверки дублирования записи в таблице "Список замещающих лиц"
        static public bool AlreadyInAlternateList(string vacationist, string alternate)
        {
            msCommand.CommandText = "SELECT Position_id FROM alternate_list WHERE " +
            "Vacationist_personnel_number = '" + vacationist + "' AND Alternate_personnel_number = '"
            + alternate + "';";
            Object result = msCommand.ExecuteScalar();
            if (result != null) return true;
            else return false;
        }

        //вывод данных из таблицы "Сотрудники" для заполнения выпадающего списка
        static public void ShowComboBoxEmployees()
        {
            msCommand.CommandText = "SELECT Personnel_number, Surname_NF FROM employees ORDER BY Surname_NF;";
            msDataAdapter = new MySqlDataAdapter(msCommand);
            dtComboBoxEmployees.Clear();
            msDataAdapter.Fill(dtComboBoxEmployees);
        }

        //процедура получения табельного номера заместителя при известном ФИО
        static public string GetPersonnelNumberFromEmployees(string fio)
        {
            msCommand.CommandText = "SELECT Personnel_number FROM employees " +
                "WHERE Surname_NF = '" + fio + "';";
            Object result = msCommand.ExecuteScalar();
            return result.ToString();
        }


        //ТАБЛИЦА "ШТАТНОЕ РАСПИСАНИЕ"
        //процедура отображения содержимого таблицы "Штатное расписание"
        static public void ShowStaffingTable()
        {
            msCommand.CommandText = @"SELECT st.staffing_table_id,
            st.Position_id, su.Unit_short_title as
            'Структурное подразделение', f.Function as 'Должность',
            pc.Category_short_name as 'Категория персонала',
            st.Add_to_vacation as 'Дополнительных дней к отпуску',
            e.Surname_NF as 'Сотрудник' 
            FROM functions f, personnel_categories pc,
            structural_units su, staffing_table st, employees e        
            WHERE (su.Unit_id=st.Unit_id)AND(f.Function_id=st.Function_id)
            AND(pc.Category_id=st.Category_id)AND
            (e.Personnel_number=st.Personnel_number);";
            msDataAdapter = new MySqlDataAdapter(msCommand);
            dtStaffingTable.Clear();
            msDataAdapter.Fill(dtStaffingTable);
        }

        //процедура добавления записи с в таблицу "Штатное расписание"
        static public void AddToStaffingTable(string function, string category,
            string personnelNumber, string addToVacation, string unit)
        {
            msCommand.CommandText = @"INSERT INTO staffing_table VALUES(null, '"
            + function + "','" + category + "','" + personnelNumber + "','" +
            addToVacation + "','" + unit + "',1);";
            msCommand.ExecuteNonQuery();
        }

        //процедура редактирования записи в таблице "Штатное расписание"
        static public void EditInStaffingTable(string number, string function,
            string category, string personnelNumber, string addToVacation,
            string unit)
        {
            msCommand.CommandText = @"UPDATE staffing_table SET Function_id = '"
                + function + "', Category_id = '" + category + "', Personnel_number = '"
                + personnelNumber + "', Add_to_vacation = '" + addToVacation +
                "', Unit_id = '" + unit + "', staffing_table_id = 1 WHERE Position_id = '" 
                + number + "';";
            msCommand.ExecuteNonQuery();
        }

        //процедура удаления записи из таблицы "Штатное расписание"
        static public void DeleteFromStaffingTable(string number)
        {
            msCommand.CommandText = "DELETE FROM staffing_table WHERE Position_id = '"
                + number + "';";
            msCommand.ExecuteNonQuery();
        }

        //процедура проверки утверждения штатного расписания
        static public bool StaffingTableIsApproved()
        {
            msCommand.CommandText = @"SELECT Staffing_table_id FROM staffing_table_status 
            WHERE (Staffing_table_id = 1) AND (Staffing_table_status = 'Утверждено');";
            Object result = msCommand.ExecuteScalar();
            if (result != null) return true;
            else return false;
        }
        
        //процедура проверки занимает ли сотрудник какую-нибудь должность
        static public bool EmployeeAlreadyWorking(string number)
        {
            msCommand.CommandText = @"SELECT Position_id FROM staffing_table WHERE 
            Personnel_number = '" + number + "';";
            Object result = msCommand.ExecuteScalar();
            if (result != null) return true;
            else return false;
        }


        //СПРАВОЧНИК "ВИДЫ ОТПУСКОВ"
        //процедура отображения содержимого справочника "Виды отпусков"
        static public void ShowVacationTypes()
        {
            msCommand.CommandText = @"SELECT Vacation_type_id,
            Vacation_type as 'Вид отпуска',
            Paid_days as 'Количество оплачиваемых дней',
            Unpaid_days as 'Количество неоплачиваемых дней'
            FROM vacation_types;";
            msDataAdapter = new MySqlDataAdapter(msCommand);
            dtVacationTypes.Clear();
            msDataAdapter.Fill(dtVacationTypes);
        }

        //процедура добвления записи с в справочник "Виды отпусков"
        static public void AddVacationType(string VacationType, string PaidDays,
            string UnpaidDays)
        {
            msCommand.CommandText = @"INSERT INTO vacation_types VALUES (null,'"
                + VacationType + "','" + PaidDays + "','" + UnpaidDays + "');";
            msCommand.ExecuteNonQuery();
        }

        //процедура редактирования записи в справочнике "Виды отпусков"
        static public void EditVacationType(string number, string VacationType,
            string PaidDays, string UnpaidDays)
        {
            msCommand.CommandText = @"UPDATE vacation_types SET Vacation_type = '"
                + VacationType + "',Paid_days = '" + PaidDays + "',Unpaid_days = '"
                + UnpaidDays + "' WHERE Vacation_type_id = '" + number + "';";
            msCommand.ExecuteNonQuery();
        }

        //процедура удаления записи из справочника "Виды отпусков"
        static public void DeleteVacationType(string number)
        {
            msCommand.CommandText = "DELETE FROM vacation_types WHERE " +
            "Vacation_type_id = " + number + ";";
            msCommand.ExecuteNonQuery();
        }

        //Процедура проверки существования конкретного вида отпуска
        static public bool VacationTypeExists(string VacationType)
        {
            msCommand.CommandText = @"SELECT Vacation_type_id FROM vacation_types 
            WHERE Vacation_type = '" + VacationType + "';";
            Object result = msCommand.ExecuteScalar();
            if (result != null) return true;
            else return false;
        }

        //проверка использования вида отпуска в графике отпусков перед удалением
        static public bool VacationTypeInEmployeesVacations(string TheVacationType)
        {
            msCommand.CommandText = @"SELECT Position_id FROM employees_vacations
            WHERE Vacation_type_id = '" + TheVacationType + "';";
            Object result = msCommand.ExecuteScalar();
            if (result != null) return true;
            else return false;
        }
       

        //ТАБЛИЦА "СТАТУС ШТАТНОГО РАСПИСАНИЯ"
        //процедура отображения содержимого таблицы "Штатные расписания"
        static public void ShowStaffingTableStatus()
        {
            msCommand.CommandText = @"SELECT Staffing_table_id, Year as 
            'Составлено на год', Staffing_table_status as 'Статус штатного расписания', 
            Comment as 'Комментарий' FROM staffing_table_status;";
            msDataAdapter = new MySqlDataAdapter(msCommand);
            dtStaffingTablesList.Clear();
            msDataAdapter.Fill(dtStaffingTablesList);
        }

        //процедура редактирования записи в таблице "Штатные расписания"
        static public void EditStafingTable(string id, string year,
            string staffingTableStatus, string comment)
        {
            msCommand.CommandText = "UPDATE staffing_table_status SET year = '" + year +
                "', Staffing_table_status = '" + staffingTableStatus + "', Comment = '"
                + comment + "';";
            msCommand.ExecuteNonQuery();
        }


        //СПРАВОЧНИК "УРОВНИ ИЕРАРХИИ ПОДРАЗДЕЛЕНИЙ"
        //процедура отображения содержимого справочника "Уровни иерархи подразделений"
        static public void ShowHierarchyLevels()
        {
            msCommand.CommandText = @"SELECT Hierarchy_level_id, 
            Hierarchy_level as 'Уровень иерархии' FROM hierarchy_levels;";
            msDataAdapter = new MySqlDataAdapter(msCommand);
            dtHierarchyLevels.Clear();
            msDataAdapter.Fill(dtHierarchyLevels);
        }

        //процедура добавления записи в справочник "Уровни иерархии подразделений"
        static public void AddHierarchyLevel(string hierarchyName)
        {
            msCommand.CommandText = "INSERT INTO hierarchy_levels VALUES(null, '" +
                hierarchyName + "');";
            msCommand.ExecuteNonQuery();
        }

        //процедура редактирования записи в справочнике "Уровни иерархии подразделений"
        static public void EditHierarchyLevel(string number, string hierarchyName)
        {
            msCommand.CommandText = "UPDATE hierarchy_levels SET Hierarchy_level = '" +
                hierarchyName + "' WHERE Hierarchy_level_id = '" + number + "';";
            msCommand.ExecuteNonQuery();
        }

        //процедура удаления записи из справочника "Уровни иерархии подразделений"
        static public void DeleteHierarchyLevel(string number)
        {
            msCommand.CommandText = "DELETE FROM hierarchy_levels WHERE Hierarchy_level_id = '"
                + number + "';";
            msCommand.ExecuteNonQuery();
        }

        //процедура проверки существования конкретного уровня иерархии подразделения
        static public bool HierarhyLevelExists(string TheHierarchyLevel)
        {
            msCommand.CommandText = @"SELECT Hierarchy_level_id FROM hierarchy_levels
            WHERE Hierarchy_level = '" + TheHierarchyLevel + "';";
            Object result = msCommand.ExecuteScalar();
            if (result != null) return true;
            else return false;
        }

        //проверка наличия уровня иерархии в перечне структурных подразделений перед удалением
        static public bool HierarchyLevelInStructuralUnits(string TheHierarchyLevel)
        {
            msCommand.CommandText = @"SELECT Unit_id FROM structural_units WHERE
            Hierarchy_level_id = '" + TheHierarchyLevel + "';";
            Object result = msCommand.ExecuteScalar();
            if (result != null) return true;
            else return false;
        }

        //получение идентификатора уровня иерархии по наименованию
        static public string GetHierarchyLevelId(string level)
        {
            msCommand.CommandText = @"SELECT Hierarchy_level_id FROM hierarchy_levels
            WHERE Hierarchy_level = '" + level + "';";
            Object result = msCommand.ExecuteScalar();
            return result.ToString();
        }


        //ТАБЛИЦА "СТРУКТУРНЫЕ ПОДРАЗДЕЛЕНИЯ"
        //процедура отображения содержимого таблицы "Структурные подразделения"
        static public void ShowStructuralUnits()
        {
            msCommand.CommandText = @"SELECT su.Unit_id, su.Unit_full_title as 
            'Полное наименование', su.Unit_Short_title as 
            'Сокращенное наименование', hl.Hierarchy_level as 'Уровень иерархии',
            pu.Unit_full_title as 'Подчинено подразделению (полное наименование)',
            pu.Unit_short_title as 'Подчинено подразделению (сокращенное наименование)',
            e.Surname_NF as 'Руководитель'
            FROM structural_units su, hierarchy_levels hl, parent_units pu, employees e 
            WHERE (su.Hierarchy_level_id = hl.Hierarchy_level_id) AND 
            (e.Personnel_number = su.Unit_chief) AND (su.Parent_unit = pu.Unit_id)  ;";
            /* для вывода информации создано представление:
            create view Parent_Units as
            select Unit_id, Unit_full_title, Unit_short_title
            from structural_units;*/
            msDataAdapter = new MySqlDataAdapter(msCommand);
            dtStructuralUnits.Clear();
            msDataAdapter.Fill(dtStructuralUnits);
        }

        //процедура добавления записи в таблицу "Структурные подразделения"
        static public void AddStructuralUnit(string hierarchyLevel, string fullTitle, string shortName,
            string chief, string parentUnit)
        {
            msCommand.CommandText = @"INSERT INTO structural_units VALUES(null, '" + hierarchyLevel +
                "','" + fullTitle + "','" + shortName + "','" + chief + "','" + parentUnit + "');";
            msCommand.ExecuteNonQuery();
        }

        //процедура редактирования записи в таблице "Структурные подразделения"
        static public void EditStructuralUnit(string id, string hierarchyLevel, string fullTitle,
            string shortName, string chief, string parentUnit)
        {
            msCommand.CommandText = @"UPDATE structural_units SET Hierarchy_level_id = '" +
            hierarchyLevel + "', Unit_full_title = '" + fullTitle + "', Unit_short_title = '"
            + shortName + "', Unit_chief = '" + chief + "', Parent_unit = '" + parentUnit +
            "' WHERE Unit_id = '" + id + "';";
            msCommand.ExecuteNonQuery();
        }

        //процедура удаления записи из таблицы "Структурные подразделения"
        static public void DeleteStructuralUnit(string id)
        {
            msCommand.CommandText = "DELETE FROM structural_units WHERE Unit_id = '" + id + "';";
            msCommand.ExecuteNonQuery();
        }

        //процедура проверки существования полного наименования структурного подразделения
        static public bool StructuralUnitFullTitleExists(string fullTitle)
        {
            msCommand.CommandText = "SELECT Unit_id FROM structural_units WHERE Unit_full_title = '"
                + fullTitle + "';";
            Object result = msCommand.ExecuteScalar();
            if (result != null) return true;
            else return false;
        }

        //процедура проверки существования краткого наименования структурного подразделения
        static public bool StructuralUnitShortTitleExists(string shortTitle)
        {
            msCommand.CommandText = "SELECT Unit_id FROM structural_units WHERE Unit_short_title = '"
                + shortTitle + "';";
            Object result = msCommand.ExecuteScalar();
            if (result != null) return true;
            else return false;
        }

        //проверка наличия структурного подразделения в штатном расписании перед удалением
        static public bool StructuralUnitInStaffingTable(string TheUnit)
        {
            msCommand.CommandText = "SELECT Position_id FROM staffing_table WHERE Unit_id = '"
                + TheUnit + "';";
            Object result = msCommand.ExecuteScalar();
            if (result != null) return true;
            else return false;
        }

        //проверка наличия у подразделения дочерних подразделений перед удалением
        static public bool StucturalUnitIsParent(string unit)
        {
            msCommand.CommandText = @"SELECT Unit_id FROM structural_units 
            WHERE Parent_unit = '" + unit + "';";
            Object result = msCommand.ExecuteScalar();
            if (result != null) return true;
            else return false;
        }

        //процедура вывода данных для выпадающего списка
        static public void ShowParentUnit()
        {
            msCommand.CommandText = @"SELECT Unit_id, Unit_full_title, 
            Unit_short_title FROM structural_units;";
            msDataAdapter = new MySqlDataAdapter(msCommand);
            dtComboboxParentUnit.Clear();
            msDataAdapter.Fill(dtComboboxParentUnit);
        }

        //получение идентификатора структурного подразделения 
        //по сокращенному названию
        static public string GetStructuralUnitId(string shortName)
        {
            msCommand.CommandText = @"SELECT Unit_id FROM structural_units 
            WHERE Unit_Short_title = '" + shortName + "';";
            Object result = msCommand.ExecuteScalar();
            return result.ToString();
        }


        //ТАБЛИЦА "ГРАФИКИ ОТПУСКОВ"
        //процедура отображения содержимого таблицы "Графики отпусков"
        /*для показа таблицы создано представление:
        CREATE VIEW vacation_schedules_list as SELECT 
        vs.Vacation_schedule_id, vs.Created as 'Дата составления', 
        vs.Title_vacation_schedule as 'Название графика отпусков',
        su.Unit_short_title as 'Структурное подразделение', 
        vs.Vacation_schedule_year as 'На год', vs.Status as 'Утвержден', 
        vs.Approved_by as 'Утвердившее лицо',
        vs.Approvement_date as 'Дата утверждения'
        FROM vacation_schedules vs, structural_units su
        WHERE (vs.Structural_unit_id = su.Unit_id);
        */
        static public void ShowVacationSchedules()
        {
            msCommand.CommandText = @"SELECT Vacation_schedule_id, 
            `Дата составления`, `Название графика отпусков`, 
            `Структурное подразделение`, `На год`, `Утвержден`, 
            employees.Surname_NF as 'Утвердившее лицо', `Дата утверждения`
            FROM vacation_schedules_list vsl LEFT JOIN employees 
            ON `Утвердившее лицо` = Personnel_number;";
            msDataAdapter = new MySqlDataAdapter(msCommand);
            dtVacationSchedules.Clear();
            msDataAdapter.Fill(dtVacationSchedules);

            /* старая версия
             SELECT vs.Vacation_schedule_id,
            vs.Created as 'Дата составления', vs.Title_vacation_schedule
            as 'Название графика отпусков', vs.Vacation_schedule_year as 
            'На год', vs.Status as 'Утвержден', vs.Approved_by as 
            'Утвердившее лицо', vs.Approvement_date as 'Дата утверждения',
            su.Unit_short_title as 'Структурное подразделение' 
            FROM vacation_schedules vs, structural_units su 
            WHERE vs.Structural_unit_id = su.Unit_id*/
        }

        //процедура отображения 1й записи из таблицы "Графики отпусков"
        static public void ShowActualVacationScheduleStatus(string unit)
        {
            msCommand.CommandText = @"SELECT vs.Vacation_schedule_id,
            vs.Created as 'Дата составления', vs.Title_vacation_schedule
            as 'Название графика отпусков', vs.Vacation_schedule_year as 
            'На год', vs.Status as 'Утвержден', vs.Approved_by as 
            'Утвердившее лицо', vs.Approvement_date as 'Дата утверждения',
            su.Unit_short_title as 'Структурное подразделение' 
            FROM vacation_schedules vs, structural_units su 
            WHERE (vs.Structural_unit_id = su.Unit_id) AND 
            (vs.Structural_unit_id = '" + unit + "')";
            msDataAdapter = new MySqlDataAdapter(msCommand);
            dtActualVacationScheduleStatus.Clear();
            msDataAdapter.Fill(dtActualVacationScheduleStatus);
        }

        //процедура добавления записи в таблицу "Графики отпусков"
        static public void AddVacationSchedule(string created, string title, string
        year, string approved, string approvedBy, string approvementDate, string unit,
        string mode)
        {
            switch (mode)
            {
                case "Не утвержден":
                    msCommand.CommandText = @"INSERT INTO vacation_schedules VALUES(null, '"
                        + created + "', '" + title + "', '" + year + "', '" + approved +
                        "', null, null, '" + unit + "');";
                    break;
                case "Утвержден":
                    msCommand.CommandText = @"INSERT INTO vacation_schedules VALUES(null, '"
                        + created + "', '" + title + "', '" + year + "', '" + approved +
                        "', '" + approvedBy + "', '" + approvementDate + "', '" + unit + "');";
                    break;
            }
            msCommand.ExecuteNonQuery();
        }

        //процедура редактирования записи в таблице "Графики отпусков"
        static public void EditVacationSchedule(string number, string created, string title,
        string year, string approved, string approvedBy, string approvementDate, string unit,
        string mode)
        {
            switch (mode)
            {
                case "Не утвержден":
                    msCommand.CommandText = "UPDATE vacation_schedules SET Created = '" + created
                    + "', Title_vacation_schedule = '" + title + "', Vacation_schedule_year = '"
                    + year + "', Status = '" + approved +
                    "', Approved_by = null, Approvement_date = null, Structural_unit_id = '" +
                    unit + "' WHERE Vacation_schedule_id = '" + number + "';";
                    break;
                case "Утвержден":
                    msCommand.CommandText = "UPDATE vacation_schedules SET Created = '" + created
                    + "', Title_vacation_schedule = '" + title + "', Vacation_schedule_year = '"
                    + year + "', Status = '" + approved + "', Approved_by = '" + approvedBy +
                    "', Approvement_date = '" + approvementDate + "', Structural_unit_id = '" +
                    unit + "' WHERE Vacation_schedule_id = '" + number + "';";
                    break;
            }
            msCommand.ExecuteNonQuery();
        }

        //процедура удаления записи из таблицы "Графики отпусков"
        static public void DeleteVacationSchedule(string number)
        {
            msCommand.CommandText = @"DELETE FROM vacation_schedules WHERE Vacation_schedule_id
            = '" + number + "';";
            msCommand.ExecuteNonQuery();
        }

        //проверка наличия графика отпусков для конкретного отдела за активный период
        static public bool VacationScheduleAlreadyExists(string unit)
        {
            msCommand.CommandText = "SELECT Vacation_schedule_id FROM vacation_schedules " +
            "WHERE Structural_unit_id = '" + unit + "';";
            Object result = msCommand.ExecuteScalar();
            if (result != null) return true;
            else return false;
        }

        //проверка наличия записи в графике отпусков пред удалением
        static public bool VacationScheduleIsNotEmpty(string number)
        {
            msCommand.CommandText = @"SELECT Position_id FROM employees_vacations WHERE 
                Vacation_schedule_id = '" + number + "';";
            Object result = msCommand.ExecuteScalar();
            if (result != null) return true;
            else return false;
        }        


        //ТАБЛИЦА "УЧЕТНЫЕ ЗАПИСИ СОТРУДНИКОВ"
        //процедура отображения содержимого таблицы "Учетные записи сотрудников"
        static public void ShowEmployeesAccounts()
        {
            msCommand.CommandText = @"SELECT ea.Personnel_number as 'Табельный номер',
            e.Surname_NF as 'Сотрудник',
            ea.Login as 'Логин', ea.Password as 'Пароль', ea.Role as'Роль',
            ea.Attempts_quantity as'Число попыток ввода пароля' FROM employees e,
            employees_accounts ea WHERE ea.Personnel_number = e.Personnel_number;";
            msDataAdapter = new MySqlDataAdapter(msCommand);
            dtEmployeesAccounts.Clear();
            msDataAdapter.Fill(dtEmployeesAccounts);
        }

        //процедура добавления записи в таблицу "Учетные записи пользователей"
        static public void AddEmployeesAccount(string PersonnelNumber, string login,
            string password, string role, string AttemptsQuantity)
        {
            msCommand.CommandText = @"INSERT INTO employees_accounts VALUES('" + PersonnelNumber +
                "','" + login + "','" + password + "','" + role + "','" + AttemptsQuantity + "');";
            msCommand.ExecuteNonQuery();
        }

        //процедура редактирования записи в таблице "Учетные записи пользователей"
        static public void EditEmployeesAccount(string PersonnelNumber, string login, string password,
            string role, string AttemptsQuantity)
        {
            msCommand.CommandText = @"UPDATE employees_accounts SET Login = '" + login + "', Password ='" +
                password + "', Role = '" + role + "'Access_permission = '" + AttemptsQuantity +
                "' WHERE Personnel_number = '" + PersonnelNumber + "';";
            msCommand.ExecuteNonQuery();
        }

        //процедура удаления записи из таблицы "Учетные записи пользователей"
        static public void DeleteEmployeesAccount(string PersonnelNumber)
        {
            msCommand.CommandText = @"DELETE FROM employees_acconts WHERE Personnel_number = '" + PersonnelNumber + "');";
            msCommand.ExecuteNonQuery();
        }

        //процедура проверки существования учетной записи конкретного сотрудника
        static public bool EmployeesAccountExists(string employee)
        {
            msCommand.CommandText = "SELECT Login FROM employees_accounts WHERE Personnel_number = '" + employee + "';";
            Object result = msCommand.ExecuteScalar();
            if (result != null) return true;
            else return false;
        }

        //процедура проверки существования логина (для добавления или редактирования учетной записи)
        static public bool LoginExists(string login)
        {
            msCommand.CommandText = "SELECT Personnel_number FROM employees_accounts WHERE Login = '" + login + "';";
            Object result = msCommand.ExecuteScalar();
            if (result != null) return true;
            else return false;
        }


        //СПРАВОЧНИК "СПИСОК ВЫХОДНЫХ ПРАЗДНИЧНЫХ ДНЕЙ"
        //процедура отображения содержимого таблицы "Список выходных праздничных дней"
        static public void ShowStateHolidaysList()
        {
            msCommand.CommandText = @"SELECT State_holiday as 'Название праздника',
            State_holiday_date as 'Дата' FROM state_holidays_list ORDER BY State_holiday_date ASC;";
            msDataAdapter = new MySqlDataAdapter(msCommand);
            dtStateHolidaysList.Clear();
            msDataAdapter.Fill(dtStateHolidaysList);
        }

        //процедура добавления записи в справочник "Выходные праздничные дни"
        static public void AddStateHoliday(string holiday, string date)
        {
            msCommand.CommandText = @"INSERT INTO state_holidays_list VALUES ('" +
            holiday + "','" + date + "');";
            msCommand.ExecuteNonQuery();
        }

        //процедура редактирования записи в справочнике "Выходные праздничные дни"
        static public void EditStateHoliday(string oldDate, string holiday, string newDate)
        {
            msCommand.CommandText = "UPDATE state_holidays_list SET State_holiday = '"
            + holiday + "', State_holiday_date = '" + newDate + "' WHERE State_holiday_date = '"
            + oldDate + "';";
            msCommand.ExecuteNonQuery();
        }

        //процедура удаления записи из справочника "Выходные праздничные дни"
        static public void DeleteStateHoliday(string date)
        {
            msCommand.CommandText = "DELETE FROM state_holidays_list WHERE State_holiday_date = '"
               + date + "';";
            msCommand.ExecuteNonQuery();
        }

        //процедура проверки существования указанной даты в перечне праздничных дней
        static public bool StateHolidayExists(string date)
        {
            msCommand.CommandText = @"SELECT State_holiday FROM state_holidays_list WHERE
            State_holiday_date = '" + date + "';";
            Object result = msCommand.ExecuteScalar();
            if (result != null) return true;
            else return false;
        }


        //ТАБЛИЦА "СВЕДЕНИЯ О ПРЕДПРИЯТИИ"
        //процедура отображения содержимого таблицы "Сведения о предприятии"
        static public void ShowCompanyInformation()
        {
            msCommand.CommandText = @"SELECT Short_title as 'Сокращенное наименование',
            INN as 'ИНН', KPP as 'КПП', OKPO as 'ОКПО', Full_title as 'Полное наименование',
            Legal_address as 'Юридический адрес', Actual_address as 'Фактический адрес'
            FROM company_information;";
            msDataAdapter = new MySqlDataAdapter(msCommand);
            dtCompanyInformation.Clear();
            msDataAdapter.Fill(dtCompanyInformation);
        }

        //процедура редактирования записи в таблице "Сведения о предприятии"
        static public void EditCompanyInformation(string shortName, string inn, string kpp,
            string okpo, string fullTitle, string legalAddress, string actualAddress)
        {
            msCommand.CommandText = "UPDATE company_information SET Short_title = '" +
                shortName + "', INN = '" + inn + "', KPP = '" + kpp + "', OKPO = '" +
                okpo + "', Full_title = '" + fullTitle + "', Legal_address = '" +
                legalAddress + "', Actual_address = '" + actualAddress + "';";
            msCommand.ExecuteNonQuery();
        }


        //ТАБЛИЦА "БОЛЬНИЧНЫЕ ЛИСТЫ СОТРУДНИКОВ"
        //процедура отображения содержимого таблицы "Больничные листы сотрудников"
        static public void ShowEmployeesSickLists()
        {
            msCommand.CommandText = @"SELECT esl.Sick_list_id, e.Surname_NF as 'Сотрудник',
            esl.Beginning_of_period as 'Начало периода', esl.End_of_period as 'Конец периода'
            FROM employees_sick_lists esl, employees e WHERE e.Personnel_number = esl.Personnel_number
            ORDER BY e.Surname_NF;";
            msDataAdapter = new MySqlDataAdapter(msCommand);
            dtEmployeesSickLists.Clear();
            msDataAdapter.Fill(dtEmployeesSickLists);
        }

        //процедура добавления записи в таблицу "Больничные листы сотрудников"
        static public void AddEmployeesSickList(string employee, string beginning, string end)
        {
            msCommand.CommandText = "INSERT INTO employees_sick_lists VALUES(null, '" +
                employee + "','" + beginning + "','" + end + "');";
            msCommand.ExecuteNonQuery();
        }

        //процедура редактирования записи в таблице "Больничные листы сотрудников"
        static public void EditEmployeesSickList(string number, string employee,
            string beginning, string end)
        {
            msCommand.CommandText = "UPDATE employees_sick_lists SET Personnel_number = '"
                + employee + "',Beginning_of_period = '" + beginning + "',End_of_period = '"
                + end + "' WHERE Sick_list_id = '" + number + "';";
            msCommand.ExecuteNonQuery();
        }

        //процедура удаления записи из таблицы "Больничные листы сотрудников"
        static public void DeleteEmployeesSickList(string number)
        {
            msCommand.CommandText = "DELETE FROM employees_sick_lists WHERE Sick_list_id = '"
                + number + "';";
            msCommand.ExecuteNonQuery();
        }


        //ТАБЛИЦА "ОТПУСКА СОТРУДНИКОВ"
        //процедура отображения содержимого таблицы "Отпуска сотрудников"
        //при выборе графика отпусков
        static public void ShowEmployeesVacations(string number)
        {
            msCommand.CommandText = "SELECT " +
            "vs.Vacation_schedule_id, vs.Position_id, " +
            "vs.`Табельный номер`, vs.`Сотрудник`, " +
            "vs.`Вид отпуска`, vs.`Начало отпуска`, " +
            "vs.`Конец отпуска`, vs.`Итого дней отпуска`, " +
            "paid_travel.`Дорожные: начало периода`, " +
            "paid_travel.`Дорожные: конец периода` " +
            "FROM vacation_schedule vs LEFT JOIN paid_travel " +
            "ON `Табельный номер` = Personnel_number " +
            "where Vacation_schedule_id = '" + number +
            "' group by vs.`Сотрудник`, vs.`Начало отпуска`;";
            msDataAdapter = new MySqlDataAdapter(msCommand);
            dtEmployeesVacations.Clear();
            msDataAdapter.Fill(dtEmployeesVacations);
        }
        
        //процедура отображения содержимого таблицы "Отпуска сотрудников" при выборе подразделения
        static public void ShowUnitEmployeesVacations(string unit)
        {
            msCommand.CommandText = "SELECT " +
            "vs.Vacation_schedule_id, vs.Structural_unit_id, " +
            "vs.Position_id, vs.`Табельный номер`, vs.`Сотрудник`, " +
            "vs.`Вид отпуска`, vs.`Начало отпуска`, " +
            "vs.`Конец отпуска`, vs.`Итого дней отпуска`, " +
            "paid_travel.`Дорожные: начало периода`, " +
            "paid_travel.`Дорожные: конец периода` " +
            "FROM vacation_schedule vs LEFT JOIN paid_travel " +
            "ON `Табельный номер` = Personnel_number " +
            "where vs.Structural_unit_id = '" + unit +
            "' group by vs.`Сотрудник`, vs.`Начало отпуска`;";
            msDataAdapter = new MySqlDataAdapter(msCommand);
            dtUnitEmployeesVacations.Clear();
            msDataAdapter.Fill(dtUnitEmployeesVacations);
        }
        /*@"SELECT ev.Vacation_schedule_id,
            ev.Position_id, e.Surname_NF as 'Сотрудник', 
            vt.Vacation_type as 'Вид отпуска', ev.Vacation_start_date as 
            'Начало отпуска', ev.Vacation_finish_date
            as 'Конец отпуска', ev.Days_quantity as 'Итого дней отпуска',
            ept.Start_date as 'Дорожные: начало периода',
            ept.Finish_date as 'Дорожные: конец периода'
            FROM employees e, vacation_schedules vs, vacation_types vt, 
            employees_vacations ev, employees_paid_travel ept
            WHERE (e.Personnel_number = ev.Personnel_number) AND
            (vs.Vacation_schedule_id = ev.Vacation_schedule_id) AND
            (vt.Vacation_type_id = ev.Vacation_type_id) AND
            (ept.Personnel_number = e.Personnel_number) AND
            (vs.Structural_unit_id = '" + unit + "');";*/

        /*CREATE VIEW vacation_schedule AS  SELECT 
        ev.Vacation_schedule_id, vs.Stuctural_unit_id, 
        ev.Position_id, e.Personnel_number as 'Табельный номер', 
        e.Surname_NF as 'Сотрудник', vt.Vacation_type 
        as 'Вид отпуска', ev.Vacation_start_date as 
        'Начало отпуска', ev.Vacation_finish_date
        as 'Конец отпуска', ev.Days_quantity as 
        'Итого дней отпуска' FROM employees e, 
        vacation_schedules vs, vacation_types vt, 
        employees_vacations ev
        WHERE (e.Personnel_number = ev.Personnel_number) AND
        (vs.Vacation_schedule_id = ev.Vacation_schedule_id) AND
        (vt.Vacation_type_id = ev.Vacation_type_id); 
         
        CREATE VIEW paid_travel AS SELECT Personnel_number, 
        Start_date AS 'Дорожные: начало периода', 
        Finish_date AS 'Дорожные: конец периода' 
        FROM employees_paid_travel;*/
        
        //процедура добавления записи в таблицу "Отпуска сотрудников"
        static public void AddEmployeesVacation(string personnelNumber, string vacationSchedule,
            string vacationStart, string vacationFinish, string vacationType,
            string daysQuantity)
        {
            msCommand.CommandText = "INSERT INTO employees_vacations VALUES(null, '" +
                personnelNumber + "','" + vacationSchedule + "','" + vacationStart +
                "','" + vacationFinish + "','" + daysQuantity + "','" + vacationType + "');";
            msCommand.ExecuteNonQuery();
        }

        //процедура редактирования записи в таблице "Отпуска сотрудников"
        static public void EditEmployeesVacation(string number, string personnelNumber, string
            vacationSchedule, string vacationStart, string vacationFinish, string vacationType,
            string daysQuantity)
        {
            msCommand.CommandText = "UPDATE employees_vacations SET Personnel_number = '" +
                personnelNumber + "', Vacation_schedule_id = '" + vacationSchedule +
                "', Vacation_start_date = '" + vacationStart + "', Vacation_finish_date = '"
                + vacationFinish + "', Days_quantity = '" + daysQuantity + 
                "', Vacation_type_id = '" + vacationType + "';";
            msCommand.ExecuteNonQuery();
        }

        //процедура удаления записи из таблицы "Отпуска сотрудников"
        static public void DeleteEmployeesVacation(string number)
        {
            msCommand.CommandText = "DELETE FROM employees_vacations WHERE Position_id = '"
                + number + "';";
            msCommand.ExecuteNonQuery();
        }

        //процедура проверки утверждения графика отпусков
        static public bool VacationScheduleIsApproved(string number)
        {
            msCommand.CommandText = @"SELECT Vacation_schedule_id FROM vacation_schedules
            WHERE (Vacation_schedule_id = '" + number + "') AND (Status = 'Утвержден');";
            Object result = msCommand.ExecuteScalar();
            if (result != null) return true;
            else return false;
        }

        //процедура занесения списка сотрудников отдела в выпадающий список
        static public void ShowUnitEmployees(string number)
        {
            msCommand.CommandText = @"SELECT e.Personnel_number, e.Surname_NF 
            FROM staffing_table st, employees e WHERE (e.Personnel_number = st.Personnel_number) 
            AND (st.Unit_id = '" + number + "') ORDER BY e.Surname_NF;";
            msDataAdapter = new MySqlDataAdapter(msCommand);
            dtUnitEmployees.Clear();
            msDataAdapter.Fill(dtUnitEmployees);
        }

        //процедура показа таблицы "Расходование отпусков" для выбора отпуска
        static public void ShowEmployeeVacationsBalance(string employee)
        {
            msCommand.CommandText = @"SELECT sov.Position_id, e.Personnel_number,
            sov.Year as 'За календарный год', vt.Vacation_type as 'Вид отпуска', 
            sov.Paid_days as 'Оплачиваемых дней', sov.Paid_days_balance as 
            'Осталось оплачиваемых дней' FROM spending_of_vacations sov, employees e,
            vacation_types vt WHERE (sov.Personnel_number=e.Personnel_number) AND 
            (sov.Vacation_type_id=vt.Vacation_type_id) AND (e.Personnel_number = '" 
                + employee + "') ORDER BY sov.Year;";
            msDataAdapter = new MySqlDataAdapter(msCommand);
            dtEmployeesVacationsBalance.Clear();
            msDataAdapter.Fill(dtEmployeesVacationsBalance);
        }

        //процедура получения кода отпуска при известном названии отпуска
        static public string GetVacationTypeId(string vacationName)
        {
            msCommand.CommandText = "SELECT Vacation_type_id FROM vacation_types " +
                "WHERE Vacation_type = '" + vacationName + "';";
            Object result = msCommand.ExecuteScalar();
            return result.ToString();
        }


        //ТАБЛИЦА ОПЛАЧИВАЕМЫЙ ПРОЕЗД (ДОРОЖНЫЕ)
        //процедура отображения содержимого таблицы "Оплачиваемый проезд"
        static public void ShowEmployeesPaidTravel()
        {
            msCommand.CommandText = "SELECT ept.Position_id, e.Surname_NF " +
                "as 'Сотрудник', ept.Start_date as 'Дорожные: начало периода', "
                + "ept.Finish_date as 'Дорожные: конец периода' " +
                "FROM employees_paid_travel ept,employees e WHERE " +
                "(e.Personnel_number = ept.Personnel_number);";
            msDataAdapter = new MySqlDataAdapter(msCommand);
            dtEmployeesPaidTravel.Clear();
            msDataAdapter.Fill(dtEmployeesPaidTravel);
        }

        //процедура добавления записи в таблицу "Оплачиваемый проезд"
        static public void AddEmployeesPaidTravel(string employee, string start, string finish)
        {
            msCommand.CommandText = "INSERT INTO employees_paid_travel VALUES (null, '" +
                employee + "','" + start + "','" + finish + "');";
            msCommand.ExecuteNonQuery();
        }

        //процедура редактирования записи в таблице "Оплачиваемый проезд"
        static public void EditEmployeesPaidTravel(string number, string employee,
            string start, string finish)
        {
            msCommand.CommandText = "UPDATE employees_paid_travel SET " +
            "Personnel_number = '" + number + "', Start_date = '" + start +
            "', Finish_date = '" + finish + "' WHERE Position_id = '" + number + "';";
            msCommand.ExecuteNonQuery();
        }

        //процедура удаления записи из таблицы "Оплачиваемый проезд"
        static public void DeleteEmployeesPaidTravel(string number)
        {
            msCommand.CommandText = "DELETE FROM employees_paid_travel " + 
                "WHERE Position_id = '" + number + "';";
            msCommand.ExecuteNonQuery();        
        }

        //процедура проверки наличия периода предоставления оплачиваемого проезда сотруднику
        static public bool EmployeesPaidTravelAlreadyExists(string employee)
        {
            msCommand.CommandText = "SELECT Position_id FROM employees_paid_travel " + 
                "WHERE Personnel_number = '" + employee + "';";
            Object result = msCommand.ExecuteScalar();
            if (result != null) return true;
            else return false;
        }


        //СПРАВОЧНИК "КАТЕГОРИИ ПЕРСОНАЛА"
        //процедура отображения содержимого справочника "Категории персонала"
        static public void ShowPersonnelCategories()
        {
            msCommand.CommandText = @"SELECT Category_id, Category as 'Полное наименование',
            Category_short_name as 'Сокращенное наименование' FROM personnel_categories
            ORDER BY Category;";
            msDataAdapter = new MySqlDataAdapter(msCommand);
            dtPersonnelCategories.Clear();
            msDataAdapter.Fill(dtPersonnelCategories);
        }

        //процедура добавления записи в справочник "Категории персонала"
        static public void AddPersonnelCategory(string categoryName, string categoryShortName)
        {
            msCommand.CommandText = @"INSERT INTO personnel_categories VALUES(null, '" +
                categoryName + "','" + categoryShortName + "');";
            msCommand.ExecuteNonQuery();
        }

        //процедура редактирования записи в справочнике "Категории персонала"
        static public void EditPersonnelCategory(string id, string categoryName,
            string categoryShortName)
        {
            msCommand.CommandText = @"UPDATE personnel_categories SET Category = '" +
                categoryName + "', Category_short_name = '" + categoryShortName +
                "' WHERE Category_id = '" + id + "';";
            msCommand.ExecuteNonQuery();
        }

        //процедура удаления записи из справочника "Категории персонала"
        static public void DeletePersonnelCategory(string id)
        {
            msCommand.CommandText = @"DELETE FROM personnel_categories WHERE Category_id = '" + id + "';";
            msCommand.ExecuteNonQuery();
        }

        //процедура проверки существования конкретной категории персонала по полному наименованию
        static public bool PersonnelCategoryExists(string ThePersonnelCategory)
        {
            msCommand.CommandText = @"SELECT Category_id FROM personnel_categories WHERE Category = '" +
                ThePersonnelCategory + "';";
            Object result = msCommand.ExecuteScalar();
            if (result != null) return true;
            else return false;
        }

        //процедура проверки существования конкретной категории персонала по краткому наименованию
        static public bool PersonnelCategoryShortNameExists(string ThePersonnelCategory)
        {
            msCommand.CommandText = @"SELECT Category_id FROM personnel_categories WHERE 
            Category_short_name = '" + ThePersonnelCategory + "';";
            Object result = msCommand.ExecuteScalar();
            if (result != null) return true;
            else return false;
        }

        //проверка существования конкретной категории персонала в штатном расписании
        static public bool PersonnelCategoryInStaffingTable(string ThePersonnelCatedory)
        {
            msCommand.CommandText = "SELECT Position_id FROM staffing_table WHERE Category_id = '"
                + ThePersonnelCatedory + "';";
            Object result = msCommand.ExecuteScalar();
            if (result != null) return true;
            else return false;
        }

        //получение идентификатора категории по краткому наименованию
        static public string GetPersonnelCategoryId(string category)
        {
            msCommand.CommandText = @"SELECT Category_id FROM personnel_categories 
            WHERE Category_short_name = '" + category + "';";
            Object result = msCommand.ExecuteScalar();
            return result.ToString();
        }


        //ТАБЛИЦА "РАСХОДОВАНИЕ ОТПУСКОВ"
        //процедура отображения содержимого таблицы "Расходование отпусков"
        static public void ShowSpendingOfVacations()
        {
            msCommand.CommandText = @"SELECT sov.Position_id, e.Surname_NF as 'Сотрудник',
            sov.Year as 'За календарный год', vt.Vacation_type as 'Вид отпуска', 
            sov.Paid_days as 'Оплачиваемых дней', sov.Paid_days_balance as 'Осталось оплачиваемых дней'
            FROM spending_of_vacations sov, employees e, vacation_types vt 
            WHERE (sov.Personnel_number=e.Personnel_number) AND 
            (sov.Vacation_type_id=vt.Vacation_type_id)
            ORDER BY e.Surname_NF;";
            msDataAdapter = new MySqlDataAdapter(msCommand);
            dtSpendingOfVacations.Clear();
            msDataAdapter.Fill(dtSpendingOfVacations);
        }

        //процедура добавления записи в таблицу "Расходование отпусков"
        static public void AddToSpendingOfVacations(string employee, string year, string vacationType,
            string paidDays, string balance)
        {
            msCommand.CommandText = @"INSERT INTO spending_of_vacations VALUES(null, '" + employee +
                "','" + year + "','" + vacationType + "','" + paidDays + "','" + balance + "');";
            msCommand.ExecuteNonQuery();
        }

        //процедура редактирования записи в таблице "Расходование отпусков"
        static public void EditInSpendingOfVacations(string number, string employee, string year,
            string vacationType, string paidDays, string balance)
        {
            msCommand.CommandText = @"UPDATE spending_of_vacations SET Personnel_number = '"
                + employee + "', Year = '" + year + "', Vacation_type_id = '" + vacationType +
                "', Paid_days = '" + paidDays + "', Paid_days_balance = '" + balance + 
                "' WHERE Position_id = '" + number + "';";
            msCommand.ExecuteNonQuery();
        }

        //процедура изменение записи в таблице "Расходование отпусков"
        //при редактировании таблицы "Отпуска сотрудников"
        static public void CorrectingSpendingOfVacations(string number, string balance)
        {
            msCommand.CommandText = "UPDATE spending_of_vacations SET Paid_days_balance = '"
                + balance + "' WHERE Position_id = '" + number + "';";
            msCommand.ExecuteNonQuery();
        }

        //процедура возвращает число неизрасходованных дней отпуска по идентификатору строки
        static public int ImportDayRemainValue(string number)
        {
            msCommand.CommandText = "SELECT Paid_days_balance FROM spending_of_vacations " +
                "WHERE Position_id = '"+ number +"';";
            Object result = msCommand.ExecuteScalar();
            return Convert.ToInt16(result);
        }

        //процедура возвращает идентификатор записи в таблице 
        //"Расходование отпусков" если известен отпускник и вид отпуска
        static public string GetSpendingOfVacationRecordId(string employee, string type)
        {
            msCommand.CommandText = "SELECT sov.Position_id FROM spending_of_vacations sov, "
                + "vacation_types vt, employees e, employees_vacations ev "
                + "WHERE (sov.Personnel_number = e.Personnel_number) " 
                + "AND (e.Personnel_number = ev.Personnel_number) "
                + "AND (ev.Vacation_type_id = vt.Vacation_type_id) " 
                + "AND (e.Surname_NF = '" + employee + 
                "') AND (vt.Vacation_type = '" + type + "');";
            Object result = msCommand.ExecuteScalar();
            if (result != null) { return result.ToString(); }
            else return "NULL";
        }

        //процедура удаления записи из таблицы "Расходование отпусков"
        static public void DeleteFromSpendingOfVacations(string number)
        {
            msCommand.CommandText = "DELETE FROM spending_of_vacations WHERE Position_id = '" + number + "';";
            msCommand.ExecuteNonQuery();
        }
        
        //метод возвращает количество оплачиваемых дней отпуска у выбранного типа отпуска
        static public string PaidDaysQuantitySearch(string type)
        {
            msCommand.CommandText = "SELECT Paid_days FROM vacation_types WHERE vacation_type_id = '" + type + "';";
            Object result = msCommand.ExecuteScalar();
            return result.ToString();
        }

        //метод определяет был ли уже назначен выбранный вид отпуска сотруднику
        static public bool SpendingOfVacationAlreadyExists(string year, string vacationist, string type)
        {
            msCommand.CommandText = "SELECT Position_id FROM spending_of_vacations WHERE (Year = '"
                + year + "') AND (Personnel_number = '" + vacationist + "') AND (Vacation_type_id = '"
                + type + "');";
            Object result = msCommand.ExecuteScalar();
            if (result != null) return true;
            else return false;
        }

        //процедура проверки выпадания праздничных дней на дни отпуска
        static public int StateHolidaysInVacation(string start, string finish)
        {
            msCommand.CommandText = "SELECT COUNT(State_holiday) FROM state_holidays_list " +
                "WHERE (State_holiday_date >= '" + start + "') AND (State_holiday_date <= '" +
                finish + "');";
            Object result = msCommand.ExecuteScalar();
            return Convert.ToInt16(result);
        }

        //процедура проверки присутствия отпуска сотрудника в графике отпусков
        //(для запрета удаления сведений о расходовании отпуска)
        static public bool EmployeesVacationAlreadyInVacationSchedule(string employee, string type)
        {
            msCommand.CommandText = "SELECT Position_id FROM employees_vacations " +
            "WHERE (Personnel_number = '" + employee + "') AND (Vacation_type_id = '" + type + "');";
            Object result = msCommand.ExecuteScalar();
            if (result != null) return true;
            else return false;
        }


        //ТАБЛИЦА "РАСХОДОВАНИЕ ФАКТИЧЕСКИХ ОТПУСКОВ"
        //процедура отображения содержимого таблицы "Расходование фактических отпусков"
        static public void ShowRealVacationSpending()
        {
            msCommand.CommandText = @"SELECT rvs.Position_id, e.Surname_NF as 'Сотрудник',
            rvs.Year as 'За календарный год', vt.Vacation_type as 'Вид отпуска', 
            rvs.Paid_days as 'Оплачиваемых дней', rvs.Paid_days_balance as 'Осталось оплачиваемых дней'
            FROM real_vacation_spending rvs, employees e, vacation_types vt 
            WHERE (rvs.Personnel_number=e.Personnel_number) AND 
            (rvs.Vacation_type_id=vt.Vacation_type_id)
            ORDER BY e.Surname_NF;";
            msDataAdapter = new MySqlDataAdapter(msCommand);
            dtRealVacationSpending.Clear();
            msDataAdapter.Fill(dtRealVacationSpending);
        }

        //процедура добавления записи в таблицу "Расходование фактических отпусков"
        static public void AddToRealVacationSpending(string employee, string year, string vacationType,
            string paidDays, string balance)
        {
            msCommand.CommandText = @"INSERT INTO real_vacation_spending VALUES(null, '" + employee +
                "','" + year + "','" + vacationType + "','" + paidDays + "','" + balance + "');";
            msCommand.ExecuteNonQuery();
        }

        //процедура редактирования записи в таблице "Расходование фактических отпусков"
        static public void EditInRealVacationSpending(string number, string employee, string year,
            string vacationType, string paidDays, string balance)
        {
            msCommand.CommandText = @"UPDATE real_vacation_spending SET Personnel_number = '"
                + employee + "', Year = '" + year + "', Vacation_type_id = '" + vacationType +
                "', Paid_days = '" + paidDays + "', Paid_days_balance = '" + balance +
                "' WHERE Position_id = '" + number + "';";
            msCommand.ExecuteNonQuery();
        }

        //процедура возвращает число неизрасходованных дней (фактически) отпуска по идентификатору строки
        static public int ImportRealDayRemainValue(string number)
        {
            msCommand.CommandText = "SELECT Paid_days_balance FROM real_vacation_spending " +
                "WHERE Position_id = '" + number + "';";
            Object result = msCommand.ExecuteScalar();
            return Convert.ToInt16(result);
        }

        //процедура изменение записи в таблице "Расходование отпусков"
        //при редактировании таблицы "Отпуска сотрудников"
        static public void CorrectingRealVacationSpending(string number, string balance)
        {
            msCommand.CommandText = "UPDATE real_vacation_spending SET Paid_days_balance = '"
                + balance + "' WHERE Position_id = '" + number + "';";
            msCommand.ExecuteNonQuery();
        }

        //процедура удаления записи из таблицы "Расходование фактических отпусков"
        static public void DeleteFromRealVacationSpending(string number)
        {
            msCommand.CommandText = "DELETE FROM real_vacation_spending WHERE Position_id = '" + number + "';";
            msCommand.ExecuteNonQuery();
        }

        //процедура возвращает идентификатор записи в таблице 
        //"Расходование фактических отпусков" если известен отпускник и вид отпуска
        static public string GetRealVacationSpendingRecordId(string employee, string type)
        {
            msCommand.CommandText = "SELECT Position_id FROM real_vacation_spending rvs "
                + "WHERE (rvs.Personnel_number = '" + employee + "') "
                + "AND (rvs.Vacation_type_id = '" + type + "')";
            Object result = msCommand.ExecuteScalar();
            return result.ToString();
        }


        static public bool UsingVacationType(string vacation)
        {
            msCommand.CommandText = @"SELECT ev.Position_id FROM vacation_types vt,
            employees_vacations ev WHERE (ev.Vacation_type_id = vt.Vacation_type_id) 
            AND vt.Vacation_type = '" + vacation + "';";
            Object result = msCommand.ExecuteScalar();
            if (result != null) return true;
            else return false;
        }

        //ОТЧЕТЫ

        //график отпусков всего предприятия
        static public void AllCompanyVacationScheduleDocument()
        {
            msCommand.CommandText = @"
            SELECT `Табельный номер`,`Подразделение`,`Должность`,`Фамилия, имя, отчество`, 
            `Продолжительность отпуска`,
            `Начало отпуска`, `Окончание отпуска`,`Дни`,
            `Дорожные: начало периода`, `Дорожные: конец периода`, `Вид отпуска`
            FROM Vacation_data
            LEFT JOIN paid_travel ON `Табельный номер` = Personnel_number
            ORDER BY `Подразделение`,`Должность`,`Фамилия, имя, отчество`,`Начало отпуска`;";
            msDataAdapter = new MySqlDataAdapter(msCommand);
            dtAllCompanyVacationScheduleDocument.Clear();
            msDataAdapter.Fill(dtAllCompanyVacationScheduleDocument);
        }

        /*CREATE VIEW vacation_data AS SELECT ev.Vacation_schedule_id,
        Personnel_number as 'Табельный номер', 
        concat(e.Surname,' ',e.Name,' ',e.Fathers_name) as 'Фамилия, имя, отчество',
        su.Unit_short_title as 'Подразделение',
        f.Function as 'Должность', pc.Category_short_name as 'Категория персонала',
        ev.Days_quantity as 'Продолжительность отпуска', ev.Vacation_start_date as 'Начало отпуска',
        ev.Vacation_finish_date as 'Окончание отпуска', ev.Days_quantity as 'Дни'
        FROM employees e, staffing_table st, personnel_categories pc, functions f,
        employees_vacations ev, vacation_schedules vs, structural_units su 
        WHERE (e.Personnel_number = st.Personnel_number) 
        AND (st.Function_id = f.Function_id) AND (st.Category_id = pc.Category_id)
        AND (e.Personnel_number = ev.Personnel_number) AND 
        (ev.Vacation_schedule_id = vs.Vacation_schedule_id)
        AND (su.Unit_id = st.Unit_id)*/

        //процедура отображения содержимого таблицы "Список сотрудников, неизрасходовавших отпуска"
        static public void ShowDaysRemainReport()
        {
            msCommand.CommandText = @"SELECT e.Personnel_number as 'Табельный номер',
            e.Surname_NF as 'Сотрудник',su.Unit_short_title as 'Подразделение',
            vt.Vacation_type as 'Вид отпуска', 
            rvs.Paid_days_balance as 'Осталось оплачиваемых дней отпуска'
            FROM employees e, real_vacation_spending rvs, vacation_types vt, 
            staffing_table st, structural_units su
            WHERE (e.Personnel_number = rvs.Personnel_number) AND 
            (vt.Vacation_type_id = rvs.Vacation_type_id) AND
            (e.Personnel_number = st.Personnel_number) AND (st.Unit_id = su.Unit_id) AND 
            (rvs.Paid_days_balance > 0) GROUP BY e.Personnel_number, vt.Vacation_type
            ORDER BY rvs.Paid_days_balance DESC;";            
            msDataAdapter = new MySqlDataAdapter(msCommand);
            dtDaysRemainReport.Clear();
            msDataAdapter.Fill(dtDaysRemainReport);
        }

        //процедура отображения журнала ведения отпусков
        static public void ShowVacationLogReport()
        {
            msCommand.CommandText =
            @"SELECT e.Personnel_number as 'Табельный номер', 
            concat(e.Surname,' ',e.Name,' ',e.Fathers_name) as 
            'Фамилия, имя, отчество', vl.Vacation_start_date
            as 'Дата начала отпуска', vl.Vacation_finish_date as 
            'Дата окончания отпуска', vl.Days_quantity as 
            'Итого дней', vt.Vacation_type as 'Вид отпуска'
            FROM employees e, vacation_types vt, vacation_log vl
            WHERE (e.Personnel_number = vl.Personnel_number) AND
            (vl.Vacation_type_id = vt.Vacation_type_id)
            ORDER BY vl.Vacation_start_date;";
            msDataAdapter = new MySqlDataAdapter(msCommand);
            dtVacationLogReport.Clear();
            msDataAdapter.Fill(dtVacationLogReport);
        }

        //процедура отображения содержимого таблицы "Список сотрудников, взявших дни в счет будущего отпуска"
        static public void ShowDaysCreditReport()
        {
            msCommand.CommandText = @"SELECT e.Surname_NF as 'Сотрудник',
            su.Unit_short_title as 'Структурное подразделение', f.Function as 'Должность',
            ev.Days_credit as 'Дней в счет будущего отпуска' FROM employees_vacations ev, employees e,
            staffing_table st, structural_units su, functions f
            WHERE (ev.Personnel_number=e.Personnel_number)AND(e.Personnel_number=st.Personnel_number)
            AND(st.Unit_id=su.Unit_id)AND(st.Function_id=f.Function_id)AND(ev.Days_credit>0);";
            msDataAdapter = new MySqlDataAdapter(msCommand);
            dtDaysCreditReport.Clear();
            msDataAdapter.Fill(dtDaysCreditReport);
        }

        //процедура отображения содержимого таблицы "Штатные расписания(для отчета)"
        static public void ShowVacationsSchedulesForReport()
        {
            msCommand.CommandText = @"SELECT Vacation_schedule_year as 
            'Штатное расписание' FROM Vacation_Schedules
            WHERE (Status is not null)AND(Approvement_date is not null)
            AND(Title_vacation_schedule='Основной');";
            msDataAdapter = new MySqlDataAdapter(msCommand);
            dtVacationsSchedulesForReport.Clear();
            msDataAdapter.Fill(dtVacationsSchedulesForReport);
        }

        //
        static public void ShowCurrentVacationSchedule(string number)
        {
            msCommand.CommandText = @"SELECT Position_id, e.Surname_NF as 
            'Сотрудник',  vt.Vacation_type as 'Вид отпуска',
            ev.Vacation_start_date as 'Начало отпуска', ev.Vacation_finish_date
            as 'Конец отпуска', ev.Days_quantity as 'Итого дней отпуска',
            ev.Transit_start_date as 'Дорожные: начало периода',
            ev.Transit_finish_date as 'Дорожные: конец периода'
            FROM employees e, vacation_schedules vs, vacation_types vt, 
            employees_vacations ev
            WHERE (e.Personnel_number = ev.Personnel_number) AND
            (vs.Vacation_schedule_id = ev.Vacation_schedule_id) AND
            (vt.Vacation_type_id = ev.Vacation_type_id);";
            msCommand.ExecuteNonQuery();
        }

        //процедура отображения графика отпусков структурного подразделения
        static public void ShowUnitVacationScheduleDocument(string number)
        {
            msCommand.CommandText = @"SELECT `Табельный номер`,`Фамилия, имя, отчество`, 
            `Категория персонала`, `Должность`,`Продолжительность отпуска`,
            `Начало отпуска`, `Окончание отпуска`,`Дни`,
            `Дорожные: начало периода`, `Дорожные: конец периода`,`Вид отпуска`
            FROM Vacation_data
            LEFT JOIN paid_travel ON `Табельный номер` = Personnel_number
            where vacation_data.Vacation_schedule_id = '" + number + "';";
            msDataAdapter = new MySqlDataAdapter(msCommand);
            dtUnitVacationScheduleDocument.Clear();
            msDataAdapter.Fill(dtUnitVacationScheduleDocument);
        }

        static public byte CalculateAllVacationDaysOfEmployee(string employee, string schedule)
        {
            msCommand.CommandText = @"SELECT SUM(Days_quantity) FROM employees_vacations 
            WHERE (Personnel_number = '" + employee + "') AND (Vacation_schedule_id = '" + schedule + "');";
            Object result = msCommand.ExecuteScalar();
            if (result != null) return Convert.ToByte(result);
            else return 0;
        }

        static public string GetSumDays(string personnel, string type)
        {
            msCommand.CommandText = @"SELECT SUM(ev.Days_quantity) FROM employees_vacations ev 
            WHERE (ev.Personnel_number = '" + personnel + "') AND (ev.Vacation_type_id = '" +
            type + "');";
            Object result = msCommand.ExecuteScalar();
            return result.ToString();
        }
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////