﻿namespace VacationScheduleCreator
{
    partial class VacationLogReportForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(VacationLogReportForm));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tableLayoutPanel_AllForm = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel_Company = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBoxCompany = new System.Windows.Forms.PictureBox();
            this.lblCompany = new System.Windows.Forms.Label();
            this.tableLayoutPanel_Document = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel_Working_field = new System.Windows.Forms.TableLayoutPanel();
            this.groupBoxVacationLog = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanelVacationLog = new System.Windows.Forms.TableLayoutPanel();
            this.dataGridViewVacationLog = new System.Windows.Forms.DataGridView();
            this.btnVacationLogReportCreate = new System.Windows.Forms.Button();
            this.tableLayoutPanel_WindowHeader = new System.Windows.Forms.TableLayoutPanel();
            this.lblVacationLogReport = new System.Windows.Forms.Label();
            this.tableLayoutPanel_Programm = new System.Windows.Forms.TableLayoutPanel();
            this.lblProgramm = new System.Windows.Forms.Label();
            this.tableLayoutPanel_AllForm.SuspendLayout();
            this.tableLayoutPanel_Company.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCompany)).BeginInit();
            this.tableLayoutPanel_Document.SuspendLayout();
            this.tableLayoutPanel_Working_field.SuspendLayout();
            this.groupBoxVacationLog.SuspendLayout();
            this.tableLayoutPanelVacationLog.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVacationLog)).BeginInit();
            this.tableLayoutPanel_WindowHeader.SuspendLayout();
            this.tableLayoutPanel_Programm.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel_AllForm
            // 
            this.tableLayoutPanel_AllForm.ColumnCount = 1;
            this.tableLayoutPanel_AllForm.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_AllForm.Controls.Add(this.tableLayoutPanel_Company, 0, 1);
            this.tableLayoutPanel_AllForm.Controls.Add(this.tableLayoutPanel_Document, 0, 2);
            this.tableLayoutPanel_AllForm.Controls.Add(this.tableLayoutPanel_Programm, 0, 0);
            this.tableLayoutPanel_AllForm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_AllForm.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel_AllForm.Name = "tableLayoutPanel_AllForm";
            this.tableLayoutPanel_AllForm.RowCount = 3;
            this.tableLayoutPanel_AllForm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel_AllForm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tableLayoutPanel_AllForm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 75F));
            this.tableLayoutPanel_AllForm.Size = new System.Drawing.Size(784, 497);
            this.tableLayoutPanel_AllForm.TabIndex = 12;
            // 
            // tableLayoutPanel_Company
            // 
            this.tableLayoutPanel_Company.BackColor = System.Drawing.SystemColors.HotTrack;
            this.tableLayoutPanel_Company.ColumnCount = 2;
            this.tableLayoutPanel_Company.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel_Company.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.tableLayoutPanel_Company.Controls.Add(this.pictureBoxCompany, 0, 1);
            this.tableLayoutPanel_Company.Controls.Add(this.lblCompany, 1, 1);
            this.tableLayoutPanel_Company.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Company.Location = new System.Drawing.Point(3, 52);
            this.tableLayoutPanel_Company.Name = "tableLayoutPanel_Company";
            this.tableLayoutPanel_Company.RowCount = 3;
            this.tableLayoutPanel_Company.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel_Company.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tableLayoutPanel_Company.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel_Company.Size = new System.Drawing.Size(778, 68);
            this.tableLayoutPanel_Company.TabIndex = 7;
            // 
            // pictureBoxCompany
            // 
            this.pictureBoxCompany.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxCompany.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxCompany.Image")));
            this.pictureBoxCompany.Location = new System.Drawing.Point(3, 6);
            this.pictureBoxCompany.Name = "pictureBoxCompany";
            this.pictureBoxCompany.Size = new System.Drawing.Size(227, 55);
            this.pictureBoxCompany.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxCompany.TabIndex = 3;
            this.pictureBoxCompany.TabStop = false;
            // 
            // lblCompany
            // 
            this.lblCompany.AutoSize = true;
            this.lblCompany.BackColor = System.Drawing.SystemColors.HotTrack;
            this.lblCompany.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCompany.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblCompany.ForeColor = System.Drawing.Color.White;
            this.lblCompany.Location = new System.Drawing.Point(236, 3);
            this.lblCompany.Name = "lblCompany";
            this.lblCompany.Size = new System.Drawing.Size(539, 61);
            this.lblCompany.TabIndex = 2;
            this.lblCompany.Text = "МЕЖРЕГИОНАЛЬНАЯ РАСПРЕДЕЛИТЕЛЬНАЯ СЕТЕВАЯ КОМПАНИЯ СЕВЕРО-ЗАПАДА";
            this.lblCompany.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel_Document
            // 
            this.tableLayoutPanel_Document.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPanel_Document.ColumnCount = 1;
            this.tableLayoutPanel_Document.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_Document.Controls.Add(this.tableLayoutPanel_Working_field, 0, 1);
            this.tableLayoutPanel_Document.Controls.Add(this.tableLayoutPanel_WindowHeader, 0, 0);
            this.tableLayoutPanel_Document.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Document.Location = new System.Drawing.Point(3, 126);
            this.tableLayoutPanel_Document.Name = "tableLayoutPanel_Document";
            this.tableLayoutPanel_Document.RowCount = 2;
            this.tableLayoutPanel_Document.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12F));
            this.tableLayoutPanel_Document.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 88F));
            this.tableLayoutPanel_Document.Size = new System.Drawing.Size(778, 368);
            this.tableLayoutPanel_Document.TabIndex = 6;
            // 
            // tableLayoutPanel_Working_field
            // 
            this.tableLayoutPanel_Working_field.ColumnCount = 1;
            this.tableLayoutPanel_Working_field.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_Working_field.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel_Working_field.Controls.Add(this.groupBoxVacationLog, 0, 0);
            this.tableLayoutPanel_Working_field.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Working_field.Location = new System.Drawing.Point(3, 44);
            this.tableLayoutPanel_Working_field.Margin = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.tableLayoutPanel_Working_field.Name = "tableLayoutPanel_Working_field";
            this.tableLayoutPanel_Working_field.RowCount = 1;
            this.tableLayoutPanel_Working_field.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_Working_field.Size = new System.Drawing.Size(772, 321);
            this.tableLayoutPanel_Working_field.TabIndex = 7;
            // 
            // groupBoxVacationLog
            // 
            this.groupBoxVacationLog.Controls.Add(this.tableLayoutPanelVacationLog);
            this.groupBoxVacationLog.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxVacationLog.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBoxVacationLog.ForeColor = System.Drawing.Color.White;
            this.groupBoxVacationLog.Location = new System.Drawing.Point(3, 3);
            this.groupBoxVacationLog.Name = "groupBoxVacationLog";
            this.groupBoxVacationLog.Size = new System.Drawing.Size(766, 315);
            this.groupBoxVacationLog.TabIndex = 2;
            this.groupBoxVacationLog.TabStop = false;
            this.groupBoxVacationLog.Text = "Журнал ведения отпусков:";
            // 
            // tableLayoutPanelVacationLog
            // 
            this.tableLayoutPanelVacationLog.ColumnCount = 1;
            this.tableLayoutPanelVacationLog.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelVacationLog.Controls.Add(this.dataGridViewVacationLog, 0, 0);
            this.tableLayoutPanelVacationLog.Controls.Add(this.btnVacationLogReportCreate, 0, 1);
            this.tableLayoutPanelVacationLog.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelVacationLog.Location = new System.Drawing.Point(3, 25);
            this.tableLayoutPanelVacationLog.Name = "tableLayoutPanelVacationLog";
            this.tableLayoutPanelVacationLog.RowCount = 2;
            this.tableLayoutPanelVacationLog.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 88F));
            this.tableLayoutPanelVacationLog.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12F));
            this.tableLayoutPanelVacationLog.Size = new System.Drawing.Size(760, 287);
            this.tableLayoutPanelVacationLog.TabIndex = 0;
            // 
            // dataGridViewVacationLog
            // 
            this.dataGridViewVacationLog.AllowUserToAddRows = false;
            this.dataGridViewVacationLog.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.AntiqueWhite;
            this.dataGridViewVacationLog.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewVacationLog.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewVacationLog.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewVacationLog.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewVacationLog.Location = new System.Drawing.Point(3, 3);
            this.dataGridViewVacationLog.MultiSelect = false;
            this.dataGridViewVacationLog.Name = "dataGridViewVacationLog";
            this.dataGridViewVacationLog.ReadOnly = true;
            this.dataGridViewVacationLog.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewVacationLog.Size = new System.Drawing.Size(754, 246);
            this.dataGridViewVacationLog.TabIndex = 0;
            // 
            // btnVacationLogReportCreate
            // 
            this.btnVacationLogReportCreate.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnVacationLogReportCreate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnVacationLogReportCreate.Location = new System.Drawing.Point(3, 255);
            this.btnVacationLogReportCreate.Name = "btnVacationLogReportCreate";
            this.btnVacationLogReportCreate.Size = new System.Drawing.Size(754, 29);
            this.btnVacationLogReportCreate.TabIndex = 1;
            this.btnVacationLogReportCreate.Text = "Сформировать документ";
            this.btnVacationLogReportCreate.UseVisualStyleBackColor = false;
            this.btnVacationLogReportCreate.Click += new System.EventHandler(this.btnVacationLogReportCreate_Click);
            // 
            // tableLayoutPanel_WindowHeader
            // 
            this.tableLayoutPanel_WindowHeader.ColumnCount = 4;
            this.tableLayoutPanel_WindowHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_WindowHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_WindowHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_WindowHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_WindowHeader.Controls.Add(this.lblVacationLogReport, 0, 0);
            this.tableLayoutPanel_WindowHeader.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_WindowHeader.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel_WindowHeader.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.tableLayoutPanel_WindowHeader.Name = "tableLayoutPanel_WindowHeader";
            this.tableLayoutPanel_WindowHeader.RowCount = 1;
            this.tableLayoutPanel_WindowHeader.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_WindowHeader.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 41F));
            this.tableLayoutPanel_WindowHeader.Size = new System.Drawing.Size(772, 41);
            this.tableLayoutPanel_WindowHeader.TabIndex = 6;
            // 
            // lblVacationLogReport
            // 
            this.lblVacationLogReport.AutoSize = true;
            this.tableLayoutPanel_WindowHeader.SetColumnSpan(this.lblVacationLogReport, 4);
            this.lblVacationLogReport.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblVacationLogReport.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblVacationLogReport.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblVacationLogReport.Location = new System.Drawing.Point(3, 0);
            this.lblVacationLogReport.Name = "lblVacationLogReport";
            this.lblVacationLogReport.Size = new System.Drawing.Size(766, 41);
            this.lblVacationLogReport.TabIndex = 19;
            this.lblVacationLogReport.Text = "ФОРМИРОВАНИЕ ДОКУМЕНТА (ЖУРНАЛ ВЕДЕНИЯ ОТПУСКОВ)";
            this.lblVacationLogReport.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel_Programm
            // 
            this.tableLayoutPanel_Programm.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPanel_Programm.ColumnCount = 1;
            this.tableLayoutPanel_Programm.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Programm.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Programm.Controls.Add(this.lblProgramm, 0, 0);
            this.tableLayoutPanel_Programm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Programm.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel_Programm.Name = "tableLayoutPanel_Programm";
            this.tableLayoutPanel_Programm.RowCount = 1;
            this.tableLayoutPanel_Programm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Programm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Programm.Size = new System.Drawing.Size(778, 43);
            this.tableLayoutPanel_Programm.TabIndex = 8;
            // 
            // lblProgramm
            // 
            this.lblProgramm.AutoSize = true;
            this.lblProgramm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblProgramm.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblProgramm.ForeColor = System.Drawing.Color.White;
            this.lblProgramm.Location = new System.Drawing.Point(3, 0);
            this.lblProgramm.Name = "lblProgramm";
            this.lblProgramm.Size = new System.Drawing.Size(772, 43);
            this.lblProgramm.TabIndex = 0;
            this.lblProgramm.Text = "ФОРМИРОВАНИЕ И ВЕДЕНИЕ ГРАФИКА ОТПУСКОВ СОТРУДНИКОВ";
            this.lblProgramm.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // VacationLogReportForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 497);
            this.Controls.Add(this.tableLayoutPanel_AllForm);
            this.Name = "VacationLogReportForm";
            this.Text = "ЖУРНАЛ ВЕДЕНИЯ ОТПУСКОВ СОТРУДНИКОВ";
            this.Load += new System.EventHandler(this.VacationLogDocumentForm_Load);
            this.tableLayoutPanel_AllForm.ResumeLayout(false);
            this.tableLayoutPanel_Company.ResumeLayout(false);
            this.tableLayoutPanel_Company.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCompany)).EndInit();
            this.tableLayoutPanel_Document.ResumeLayout(false);
            this.tableLayoutPanel_Working_field.ResumeLayout(false);
            this.groupBoxVacationLog.ResumeLayout(false);
            this.tableLayoutPanelVacationLog.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVacationLog)).EndInit();
            this.tableLayoutPanel_WindowHeader.ResumeLayout(false);
            this.tableLayoutPanel_WindowHeader.PerformLayout();
            this.tableLayoutPanel_Programm.ResumeLayout(false);
            this.tableLayoutPanel_Programm.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_AllForm;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Company;
        private System.Windows.Forms.PictureBox pictureBoxCompany;
        private System.Windows.Forms.Label lblCompany;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Document;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Working_field;
        private System.Windows.Forms.GroupBox groupBoxVacationLog;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelVacationLog;
        private System.Windows.Forms.DataGridView dataGridViewVacationLog;
        private System.Windows.Forms.Button btnVacationLogReportCreate;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_WindowHeader;
        private System.Windows.Forms.Label lblVacationLogReport;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Programm;
        private System.Windows.Forms.Label lblProgramm;
    }
}