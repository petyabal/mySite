﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace VacationScheduleCreator
{
    //Класс формы с полями для ввода значений организационных настроек
    public partial class OrganizationSettingsEditForm : Form
    {
        public OrganizationSettingsEditForm()
        {
            InitializeComponent();
        }

        //процедура скрытия всех вкладок
        public void AllTabsHide()
        {
            tabPageCompanyInformation.Parent = null;
            tabPageFunctions.Parent = null;
            tabPageHierarchyLevels.Parent = null;
            tabPagePersonnelCategories.Parent = null;
            tabPageStateHolidaysList.Parent = null;
        }
        
        
        //ТАБЛИЦА "СВЕДЕНИЯ О ПРЕДПРИЯТИИ"
        //настойка формы с полями ввода для редактирования сведений о предприятии
        public void ShowCompanyInformationTab()
        {
            AllTabsHide();
            tabPageCompanyInformation.Parent = tabControlOrganizationSettingsEdit;
            tabPageCompanyInformation.Text = "Редактирование сведений о предприятии:";
        }

        //отмена добавления или редактирования записи в таблице "Сведения о предприятии"
        private void btnCompanyInformationCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //Запрет на ввод букв в поле ввода ИНН
        private void textBoxINN_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = "0123456789 \b".IndexOf(e.KeyChar) < 0;
        }

        //Запрет на ввод букв в поле ввода КПП
        private void textBoxKPP_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = "0123456789 \b".IndexOf(e.KeyChar) < 0;
        }

        //Запрет на ввод букв в поле ввода ОКПО
        private void textBoxOKPO_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = "0123456789 \b".IndexOf(e.KeyChar) < 0;
        }

        //процедура редактирования записи в таблице "Сведения о предприятии"
        private void btnCompanyInformationPost_Click(object sender, EventArgs e)
        {
            DB_Connection.EditCompanyInformation(textBoxShortTitle.Text, textBoxINN.Text,
                textBoxKPP.Text, textBoxOKPO.Text, textBoxFullTitle.Text,
                textBoxLegalAddress.Text, textBoxActualAddress.Text);
            MessageBox.Show("Сведения о предприятии изменены!");
            DB_Connection.ShowCompanyInformation();
            this.Close();
        }

        //Заполнение полей ввода изменяемыми значениями
        public void CompanyInformationImport(string shortName, string inn, string kpp,
            string okpo, string fullTitle, string legalAddress, string actualAddress)
        {
            textBoxShortTitle.Text = shortName;
            textBoxINN.Text = inn;
            textBoxKPP.Text = kpp;
            textBoxOKPO.Text = okpo;
            textBoxFullTitle.Text = fullTitle;
            textBoxLegalAddress.Text = legalAddress;
            textBoxActualAddress.Text = actualAddress;
        }


        //СПРАВОЧНИК "ДОЛЖНОСТИ"
        //Настройка формы с полями ввода для добавления новой должности
        public void ShowFunctionsTabToAdd()
        {
            AllTabsHide();
            tabPageFunctions.Parent = tabControlOrganizationSettingsEdit;
            tabPageFunctions.Text = "Добавление новой должности:";
        }

        //Настройка формы с полями ввода для редактирования должности
        public void ShowFunctionsTabToChange()
        {
            AllTabsHide();
            tabPageFunctions.Parent = tabControlOrganizationSettingsEdit;
            tabPageFunctions.Text = "Редактирование должности:";
        }

        //Заполнение поля ввода изменяемым значением
        public void FunctionImport(string function)
        {
            textBoxFunctionName.Text = function;
        }

        //отмена добавления или редактирования записи в справочнике "Должности"
        private void btnFunctionCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //процедура добавления или редактирования записи в справочнике "Должности"
        private void btnFunctionPost_Click(object sender, EventArgs e)
        {
            if (textBoxFunctionName.Text == "")
            {
                MessageBox.Show("Необходимо указать название должности!");
                return;
            }
            else
            {
                if (DB_Connection.FunctionExists(textBoxFunctionName.Text))
                {
                    MessageBox.Show("Эта должность уже имеется в справочнике!");
                    return;
                }
                else
                {
                    if (tabPageFunctions.Text == "Добавление новой должности:")
                    {
                        DB_Connection.AddFunction(textBoxFunctionName.Text);
                        MessageBox.Show("Должность добавлена в справочник!");
                        DB_Connection.ShowFunctions();
                        this.Close();
                    }
                    if (tabPageFunctions.Text == "Редактирование должности:")
                    {
                        DB_Connection.EditFunction(OrganizationSettingsDetailForm.
                            NumberOfEditRecord, textBoxFunctionName.Text);
                        MessageBox.Show("Должность изменена!");
                        DB_Connection.ShowFunctions();
                        this.Close();
                    }
                }
            }
        }
        

        //СПРАВОЧНИК "УРОВНИ ИЕРАРХИИ ПОДРАЗДЕЛЕНИЙ"
        //Настройка формы с полями ввода для добавления нового уровня иерархии подразделений
        public void ShowHierarchyLevelsTabToAdd()
        {
            AllTabsHide();
            tabPageHierarchyLevels.Parent = tabControlOrganizationSettingsEdit;
            tabPageHierarchyLevels.Text = "Добавление нового уровня иерархии:";
        }

        //Настройка формы с полями ввода для редактирования уровня иерархии подразделений
        public void ShowHierarchyLevelsTabToChange()
        {
            AllTabsHide();
            tabPageHierarchyLevels.Parent = tabControlOrganizationSettingsEdit;
            tabPageHierarchyLevels.Text = "Редактирование уровня иерархии:";
        }

        //отмена добавления или редактирования записи в справочнике "Уровни иерархии подразделений"
        private void btnHierarchyLevelCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //Заполнение поля ввода изменяемым значением
        public void HierarchyLevelImport(string HierarchyLevel)
        {
            textBoxHierarchyName.Text = HierarchyLevel;
        }

        //процедура добавления или редактирования записи в справочнике "Уровни иерархии подразделений"
        private void btnHierarchyLevelPost_Click(object sender, EventArgs e)
        {
            if (textBoxHierarchyName.Text == "")
            {
                MessageBox.Show("Необходимо указать уровень иерархии!");
                return;
            }
            else
            {
                if (DB_Connection.HierarhyLevelExists(textBoxHierarchyName.Text))
                {
                    MessageBox.Show("Этот уровень иерархии уже имеется в справочнике!");
                    return;
                }
                else
                {
                    if (tabPageHierarchyLevels.Text == "Добавление нового уровня иерархии:")
                    {
                        DB_Connection.AddHierarchyLevel(textBoxHierarchyName.Text);
                        MessageBox.Show("Уровень иерархии подразделений добавлен в справочник!");
                        DB_Connection.ShowHierarchyLevels();
                        this.Close();
                    }
                    if (tabPageHierarchyLevels.Text == "Редактирование уровня иерархии:")
                    {
                        DB_Connection.EditHierarchyLevel(OrganizationSettingsDetailForm.
                            NumberOfEditRecord, textBoxHierarchyName.Text);
                        MessageBox.Show("Уровень иерархии подразделений изменен!");
                        DB_Connection.ShowHierarchyLevels();
                        this.Close();
                    }
                }
            }
        }

        
        //СПРАВОЧНИК "КАТЕГОРИИ ПЕРСОНАЛА"
        //Настройка формы с полями ввода для добавления новой категории персонала
        public void ShowPersonnelCategoriesTabToAdd()
        {
            AllTabsHide();
            tabPagePersonnelCategories.Parent = tabControlOrganizationSettingsEdit;
            tabPagePersonnelCategories.Text = "Добавление новой категории персонала:";
        }

        //Настройка формы с полями ввода для редактирования категории персонала
        public void ShowPersonnelCategoriesTabToChange()
        {
            AllTabsHide();
            tabPagePersonnelCategories.Parent = tabControlOrganizationSettingsEdit;
            tabPagePersonnelCategories.Text = "Редактирование категории персонала:";
        }

        //Заполнение поля ввода изменяемым значением
        public void PersonnelCategoryImport(string FullName, string ShortName)
        {
            textBoxPersonnelCategoryFullName.Text = FullName;
            textBoxPersonnelCategoryShortName.Text = ShortName;
        }

        //отмена добавления или редактирования записи в справочнике "Категории персонала"
        private void btnPersonnelCategoryCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //процедура добавления или редактирования записи в справочнике "Категории персонала"
        private void btnPersonnelCategoryPost_Click(object sender, EventArgs e)
        {
            if (textBoxPersonnelCategoryFullName.Text == "" ||
                textBoxPersonnelCategoryShortName.Text == "")
            {
                MessageBox.Show(@"Необходимо указать полное и краткое 
                наименование категории персонала!");
                return;
            }
            else
            {
                if (tabPagePersonnelCategories.Text ==
                            "Добавление новой категории персонала:")
                {
                    if (DB_Connection.PersonnelCategoryExists
                    (textBoxPersonnelCategoryFullName.Text))
                    {
                        MessageBox.Show(@"Полное наименование этой категории персонала уже" +
                            "имеется в справочнике!");
                        return;
                    }
                    else
                    {
                        if (DB_Connection.PersonnelCategoryShortNameExists
                        (textBoxPersonnelCategoryShortName.Text))
                        {
                            MessageBox.Show(@"Краткое наименование этой категории персонала 
                            уже имеется в справочнике!");
                            return;
                        }
                        else
                        {
                            DB_Connection.AddPersonnelCategory(textBoxPersonnelCategoryFullName.
                                Text, textBoxPersonnelCategoryShortName.Text);
                            MessageBox.Show("Новая категория персонала добавлена в справочник!");
                            DB_Connection.ShowPersonnelCategories();
                            this.Close();
                        }
                    }
                }
                if (tabPagePersonnelCategories.Text ==
                            "Редактирование категории персонала:")
                {
                    if (!DB_Connection.PersonnelCategoryExists(textBoxPersonnelCategoryFullName.
                        Text) || !DB_Connection.PersonnelCategoryShortNameExists
                        (textBoxPersonnelCategoryShortName.Text))
                    {
                        DB_Connection.EditPersonnelCategory(OrganizationSettingsDetailForm.
                                NumberOfEditRecord, textBoxPersonnelCategoryFullName.Text,
                                textBoxPersonnelCategoryShortName.Text);
                            MessageBox.Show("Категория персонала изменена!");
                            DB_Connection.ShowPersonnelCategories();
                            this.Close();
                    }
                    else MessageBox.Show("Такая категория персонала уже имеется в справочнике!");
                }
            }
        }


        //СПРАВОЧНИК "СПИСОК ВЫХОДНЫХ ПРАЗДНИЧНЫХ ДНЕЙ"
        //Настройка формы с полями ввода для добавления новой праздничной даты
        public void ShowStateHolidaysListTabToAdd()
        {
            AllTabsHide();
            tabPageStateHolidaysList.Parent = tabControlOrganizationSettingsEdit;
            tabPageStateHolidaysList.Text = "Добавление выходного праздничного дня:";
        }

        //Настройка формы с полями ввода для редактирования редактирования праздничной даты
        public void ShowStateHolidaysListTabToChange()
        {
            AllTabsHide();
            tabPageStateHolidaysList.Parent = tabControlOrganizationSettingsEdit;
            tabPageStateHolidaysList.Text = "Редактирование выходного праздничного дня:";
        }

        //Заполнение поля ввода изменяемым значением
        public void StateHolidayImport(string holiday, string date)
        {
            dtpStateHolidayDate.Value = Convert.ToDateTime(date);
            textBoxStateHolidayName.Text = holiday;
        }

        //отмена добавления или редактирования записи в справочнике "Список выходных праздничных дней"
        private void btnStateHolidayCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //процедура добавления или редактирования записи в справочнике "Список выходных праздничных дней"
        private void btnStateHolidayPost_Click(object sender, EventArgs e)
        {
            if (textBoxStateHolidayName.Text == "")
            {
                MessageBox.Show("Необходимо указать название праздника!");
                return;
            }
            else
            {
                if (tabPageStateHolidaysList.Text == "Добавление выходного праздничного дня:")
                {
                    if (DB_Connection.StateHolidayExists(dtpStateHolidayDate.Value.ToString("yyyy-MM-dd")))
                    {
                        MessageBox.Show("Данная дата уже указана как праздничная!");
                        return;
                    }
                    else
                    {
                        DB_Connection.AddStateHoliday(textBoxStateHolidayName.Text,
                            dtpStateHolidayDate.Value.ToString("yyyy-MM-dd"));
                        MessageBox.Show("Добавлен новый выходной праздничный день!");
                        DB_Connection.ShowStateHolidaysList();
                        this.Close();
                    }
                }
                if (tabPageStateHolidaysList.Text == "Редактирование выходного праздничного дня:")
                {
                    DateTime d;
                    d = Convert.ToDateTime(OrganizationSettingsDetailForm.TheDate);
                    if (DB_Connection.StateHolidayExists(dtpStateHolidayDate.Value.ToString("yyyy-MM-dd")) &&
                        dtpStateHolidayDate.Value.ToString("yyyy-MM-dd") != d.ToString("yyyy-MM-dd"))
                    {
                        MessageBox.Show("Данная дата уже указана как праздничная!");
                        return;
                    }
                    else
                    {                        
                        DB_Connection.EditStateHoliday(d.ToString("yyyy-MM-dd"),
                        textBoxStateHolidayName.Text, dtpStateHolidayDate.Value.ToString("yyyy-MM-dd"));
                        MessageBox.Show("Выходной праздничный день отредактирован!");
                        DB_Connection.ShowStateHolidaysList();
                        this.Close();
                    }
                }
            }
        }
    }
}
