﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace VacationScheduleCreator
{
    public partial class EmployeesDetailForm : Form
    {
        public EmployeesDetailForm()
        {
            InitializeComponent();
        }
        
        //переменная хранит номер редактируемой записи для выполнения редактирования из других модулей
        static public string NumberOfEditRecord;

        //переменные для занесения изначальных значений в выпадающие  
        //списки при изменении записи в списке замещающих лиц
        static public string importVacationist;
        static public string importAlternate;
        static public string importIllEmployee;

        //процедура скрытия всех вкладок
        void AllTabsHide()
        {
            tabPageEmployees.Parent = null;
            tabPageAlternateList.Parent = null;
            tabPageEmployeesSickLists.Parent = null;
        }

        //процедура загрузки данных из таблиц БД
        private void EmployeesDetailForm_Load(object sender, EventArgs e)
        {
            if (tabPageEmployees.Parent == tabControlEmployeesInformation)
            {
                DB_Connection.ShowEmployees();
                dataGridViewEmployees.DataSource = DB_Connection.dtEmployees;
                dataGridViewEmployees.Columns["Табельный номер"].Visible = false;
                dataGridViewEmployees.Columns["Surname_NF"].Visible = false;
                if (dataGridViewEmployees.RowCount != 0)
                    dataGridViewEmployees.Rows[0].Cells[1].Selected = true;
            }
            if (tabPageAlternateList.Parent == tabControlEmployeesInformation)
            {
                DB_Connection.ShowAlternateList();
                dataGridViewAlternateList.DataSource = DB_Connection.dtAlternateList;
                dataGridViewAlternateList.Columns["Position_id"].Visible = false;
                if (dataGridViewAlternateList.RowCount != 0)
                    dataGridViewAlternateList.Rows[0].Cells[1].Selected = true;
                
            }
            if (tabPageEmployeesSickLists.Parent == tabControlEmployeesInformation)
            {
                //DB_Connection.ShowEmployees();
                DB_Connection.ShowEmployeesSickLists();
                dataGridViewEmployeesSickLists.DataSource = DB_Connection.dtEmployeesSickLists;
                dataGridViewEmployeesSickLists.Columns["Sick_list_id"].Visible = false;
                if (dataGridViewEmployeesSickLists.RowCount != 0)
                    dataGridViewEmployeesSickLists.Rows[0].Cells[1].Selected = true;
            }
        }

        //метод-диалог для подтверждения желания пользователя удалить выбранную запись
        bool UserAgree()
        {
            DialogResult dialogResult = new DialogResult();
            dialogResult = MessageBox.Show("Вы действительно хотите удалить выбранную запись?",
                "Удаление данных!", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes) return true;
            else return false;
        }

        
        //ТАБЛИЦА "СОТРУДНИКИ"
        //процедура показа только одной вкладки ("Сотрудники")
        public void ShowEmployeesTab()
        {
            AllTabsHide();
            tabPageEmployees.Parent = tabControlEmployeesInformation;
        }

        //процедура открытия формы с полями ввода для добавления данных в таблицу "Сотрудники"
        private void btnAddEmployee_Click(object sender, EventArgs e)
        {
            EmployeeEditForm Employee = new EmployeeEditForm();
            Employee.ShowEmployeeTabToAdd();
            Employee.ShowDialog();
        }

        //процедура открытия формы с полями ввода для редактирования данных в таблице "Сотрудники"
        private void btnChangeEmployee_Click(object sender, EventArgs e)
        {
            EmployeeEditForm Employee = new EmployeeEditForm();
            NumberOfEditRecord = dataGridViewEmployees.CurrentRow.
                Cells["Табельный номер"].Value.ToString();
            Employee.EmployeeImport(
                dataGridViewEmployees.CurrentRow.Cells["Фамилия"].Value.ToString(),
                dataGridViewEmployees.CurrentRow.Cells["Имя"].Value.ToString(),
                dataGridViewEmployees.CurrentRow.Cells["Отчество"].Value.ToString(),
                dataGridViewEmployees.CurrentRow.Cells["Дата рождения"].Value.ToString(),
                dataGridViewEmployees.CurrentRow.Cells["Пол"].Value.ToString(),
                dataGridViewEmployees.CurrentRow.Cells["Серия паспорта"].Value.ToString(),
                dataGridViewEmployees.CurrentRow.Cells["Номер паспорта"].Value.ToString(),
                dataGridViewEmployees.CurrentRow.Cells["СНИЛС"].Value.ToString(),
                dataGridViewEmployees.CurrentRow.Cells["ИНН"].Value.ToString(),
                dataGridViewEmployees.CurrentRow.Cells["Место регистрации"].Value.ToString(),
                dataGridViewEmployees.CurrentRow.Cells["Дата приема на работу"].Value.ToString());
            Employee.ShowEmployeeTabToChange();
            Employee.ShowDialog();
        }    

        //ТАБЛИЦА "СПИСОК ЗАМЕЩАЮЩИХ ЛИЦ"
        //процедура показа только одной вкладки ("Список замещающих лиц")
        public void ShowAlternateListTab()
        {
            AllTabsHide();
            tabPageAlternateList.Parent = tabControlEmployeesInformation;
        }

        //процедура открытия формы с полями ввода для добавления данных в таблицу "Список замещающих лиц"
        private void btnAddToAlternateList_Click(object sender, EventArgs e)
        {
            EmployeeEditForm Employee = new EmployeeEditForm();
            Employee.ShowAlternateListTabToAdd();
            Employee.ShowDialog();
        }

        //процедура открытия формы с полями ввода для редактирования данных в таблице "Список замещающих лиц"
        private void btnChangeInAlternateList_Click(object sender, EventArgs e)
        {
            EmployeeEditForm Employee = new EmployeeEditForm();
            Employee.ShowAlternateListTabToChange();
            NumberOfEditRecord = dataGridViewAlternateList.CurrentRow.
                Cells["Position_id"].Value.ToString();
            importVacationist = DB_Connection.GetPersonnelNumberFromEmployees(
                dataGridViewAlternateList.CurrentRow.Cells["Отпускник"].Value.ToString());
            importAlternate = DB_Connection.GetPersonnelNumberFromEmployees(
                dataGridViewAlternateList.CurrentRow.Cells["Замещающее лицо"].Value.ToString());
            Employee.ShowDialog();
        }

        //процедура удаления записи из таблицы "Список замещающих лиц"
        private void DeleteFromAlternateList_Click(object sender, EventArgs e)
        {
            if (UserAgree())
            {
                DB_Connection.DeleteAlternate(dataGridViewAlternateList.
                    CurrentRow.Cells[0].Value.ToString());
                MessageBox.Show("Запись удалена!");
                DB_Connection.ShowAlternateList();
            }
        }


        //ТАБЛИЦА "БОЛЬНИЧНЫЕ ЛИСТЫ СОТРУДНИКОВ" 
        //процедура показа только одной вкладки ("Больничные листы сотрудников")
        public void ShowEmployeesSickListsTab()
        {
            AllTabsHide();
            tabPageEmployeesSickLists.Parent = tabControlEmployeesInformation;
        }

        //процедура открытия формы с полями ввода для добавления данных в таблицу "Больничные листы сотрудников"
        private void btnAddSickList_Click(object sender, EventArgs e)
        {
            EmployeeEditForm Employee = new EmployeeEditForm();
            Employee.ShowEmployeesSickListToAdd();
            Employee.ShowDialog();
        }

        //процедура открытия формы с полями ввода для редактирования данных в таблице "Больничные листы сотрудников"
        private void btnChangeSickList_Click(object sender, EventArgs e)
        {
            EmployeeEditForm Employee = new EmployeeEditForm();
            Employee.ShowEmployeesSickListToChange();
            NumberOfEditRecord = dataGridViewEmployeesSickLists.CurrentRow.
                Cells["Sick_list_id"].Value.ToString();
            Employee.EmployeesSickListImport(
                dataGridViewEmployeesSickLists.CurrentRow.Cells["Начало периода"].Value.ToString(),
                dataGridViewEmployeesSickLists.CurrentRow.Cells["Конец периода"].Value.ToString());
            importIllEmployee = DB_Connection.GetPersonnelNumberFromEmployees(
                dataGridViewEmployeesSickLists.CurrentRow.Cells["Сотрудник"].Value.ToString());
            Employee.ShowDialog();
        }

        //процедура удаления записи из таблицы "Больничные листы сотрудников"
        private void btnDeleteSickList_Click(object sender, EventArgs e)
        {
            if (UserAgree())
            {
                DB_Connection.DeleteEmployeesSickList(dataGridViewEmployeesSickLists.
                    CurrentRow.Cells["Sick_list_id"].Value.ToString());
                MessageBox.Show("Запись удалена!");
                DB_Connection.ShowEmployeesSickLists();
            }
        } 
    }
}
