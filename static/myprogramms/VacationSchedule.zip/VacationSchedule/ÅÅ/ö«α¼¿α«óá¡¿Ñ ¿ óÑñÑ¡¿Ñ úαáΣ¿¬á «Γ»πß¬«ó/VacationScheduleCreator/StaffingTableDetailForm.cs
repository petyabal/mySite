﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace VacationScheduleCreator
{
    public partial class StaffingTableDetailForm : Form
    {
        //класс формы для детального отображения одной таблицы ("Штатное расписание",
        //"Перечень штатных расписаний", "Структурные подразделения"
        public StaffingTableDetailForm()
        {
            InitializeComponent();
        }
        
        //переменная хранит номер редактируемой записи для выполнения редактирования из других модулей
        static public string NumberOfEditRecord;
        //переменные для хранения параметров проверки отсутствия дублирования
        //полного и краткого названии
        static public string FullTitle, ShortTitle;
        //проверяет табельный номер сотрудника при изменении записи в штатном расписании
        static public string ChangingEmployee;

        //переменные хранят изменяемые значения для выпадающих списков заполняемых из БД
        static public string importFunction;
        static public string importCategory;
        static public string importEmployee;
        static public string importUnit;
        static public string importHierarchy;
        static public string importChief;
        static public string importParentUnit;

        //процедура скрытия всех вкладок 
        void AllTabsHide()
        {
            tabPageStaffingTable.Parent = null;
            tabPageStaffingTableStatus.Parent = null;
            tabPageStructuralUnits.Parent = null;
        }

        //метод-диалог для подтверждения желания пользователя удалить выбранную запись
        bool UserAgree()
        {
            DialogResult dialogResult = new DialogResult();
            dialogResult = MessageBox.Show("Вы действительно хотите удалить выбранную запись?",
                "Удаление данных!", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes) return true;
            else return false;
        }

        //процедура загрузки данных из таблиц БД
        private void StaffingTableDetailForm_Load(object sender, EventArgs e)
        {
            if (tabPageStaffingTable.Parent == tabControlStaffingTable)
            {
                DB_Connection.ShowStaffingTable();
                dataGridViewStaffingTable.DataSource = DB_Connection.dtStaffingTable;
                dataGridViewStaffingTable.Columns["Position_id"].Visible = false;
                dataGridViewStaffingTable.Columns["staffing_table_id"].Visible = false;
                if (dataGridViewStaffingTable.RowCount != 0)
                dataGridViewStaffingTable.Rows[0].Cells["Должность"].Selected = true;
            }
            if (tabPageStaffingTableStatus.Parent == tabControlStaffingTable)
            {
                DB_Connection.ShowStaffingTableStatus();
                dataGridViewStaffingTableStatus.DataSource = DB_Connection.dtStaffingTablesList;
                dataGridViewStaffingTableStatus.Columns["Staffing_table_id"].Visible = false;
                dataGridViewStaffingTableStatus.Rows[0].Cells["Составлено на год"].Selected = true;
            }
            if (tabPageStructuralUnits.Parent == tabControlStaffingTable)
            {
                DB_Connection.ShowStructuralUnits();
                dataGridViewStructuralUnits.DataSource = DB_Connection.dtStructuralUnits;
                dataGridViewStructuralUnits.Columns["Unit_id"].Visible = false;
                if (dataGridViewStructuralUnits.RowCount != 0)
                dataGridViewStructuralUnits.Rows[0].Cells["Полное наименование"].Selected = true;
            }
        }


        //ТАБЛИЦА "ШТАТНОЕ РАСПИСАНИЕ"
        //процедура показа только одной вкладки ("Штатное расписание")
        public void ShowStaffingTableTab()
        {
            AllTabsHide();
            tabPageStaffingTable.Parent = tabControlStaffingTable;
        }

        //процедура открытия формы с полями ввода для добавления в таблицу "Штатное расписание"
        private void btnAddToStaffingTable_Click(object sender, EventArgs e)
        {
            if (!DB_Connection.StaffingTableIsApproved())
            {
                StaffingTableEditForm StaffingTableEdit = new StaffingTableEditForm();
                StaffingTableEdit.ShowStaffingTableTabToAdd();
                StaffingTableEdit.ShowDialog();
            }
            else MessageBox.Show("Нельзя вносить изменения в утвержденное штатное расписание!");
        }

        //процедура открытия формы с полями ввода для редактирования данных в таблице "Штатное расписание"
        private void btnChangeInStaffingTable_Click(object sender, EventArgs e)
        {
            if (!DB_Connection.StaffingTableIsApproved())
            {
                StaffingTableEditForm StaffingTableEdit = new StaffingTableEditForm();
                StaffingTableEdit.ShowStaffingTableTabToChange();
                NumberOfEditRecord = dataGridViewStaffingTable.CurrentRow.
                    Cells["Position_id"].Value.ToString();
                importFunction = DB_Connection.GetFunctionId(
                    dataGridViewStaffingTable.CurrentRow.Cells["Должность"].Value.ToString());
                importCategory = DB_Connection.GetPersonnelCategoryId(
                    dataGridViewStaffingTable.CurrentRow.Cells["Категория персонала"].Value.ToString());
                importEmployee = DB_Connection.GetPersonnelNumberFromEmployees(
                    dataGridViewStaffingTable.CurrentRow.Cells["Сотрудник"].Value.ToString());
                importUnit = DB_Connection.GetStructuralUnitId(
                    dataGridViewStaffingTable.CurrentRow.Cells["Структурное подразделение"].Value.ToString());
                ChangingEmployee = dataGridViewStaffingTable.CurrentRow.Cells["Сотрудник"].Value.ToString();
                StaffingTableEdit.ShowDialog();
            }
            else MessageBox.Show("Нельзя вносить изменения в утвержденное штатное расписание!");
        }

        //процедура удаления записи из таблицы "Штатное расписание"
        private void btnDeleteFromStaffingTable_Click(object sender, EventArgs e)
        {
            if (!DB_Connection.StaffingTableIsApproved())
            {
                if (UserAgree())
                {
                    DB_Connection.DeleteFromStaffingTable(dataGridViewStaffingTable.
                    CurrentRow.Cells["Position_id"].Value.ToString());
                    MessageBox.Show("Запись удалена!");
                    DB_Connection.ShowStaffingTable();
                }
            }
            else MessageBox.Show("Нельзя вносить изменения в утвержденное штатное расписание!");
        }


        //ТАБЛИЦА "СВОЙСТВА ШТАТНОГО РАСПИСАНИЯ"
        //процедура показа только одной вкладки ("Штатные расписания")       
        public void ShowStaffingTableStatusTab()
        {
            AllTabsHide();
            tabPageStaffingTableStatus.Parent = tabControlStaffingTable;
        }

        //процедура открытия формы с полями ввода для редактирования данных в таблице "Штатные расписания"
        private void btnChangeStaffingTableStatus_Click(object sender, EventArgs e)
        {
            StaffingTableEditForm StaffingTableEdit = new StaffingTableEditForm();
            StaffingTableEdit.ShowStaffingTableStatusTabToChange();
            NumberOfEditRecord = "1";
            //dataGridViewStaffingTableStatus.CurrentRow.Cells["Staffing_table_id"].Value.ToString();
            StaffingTableEdit.StaffingTableInformationImport(
                dataGridViewStaffingTableStatus.CurrentRow.Cells["Составлено на год"].Value.ToString(),
                dataGridViewStaffingTableStatus.CurrentRow.Cells["Статус штатного расписания"].Value.ToString(),
                dataGridViewStaffingTableStatus.CurrentRow.Cells["Комментарий"].Value.ToString());
            StaffingTableEdit.ShowDialog();
        }


        //ТАБЛИЦА "СТРУКТУРНЫЕ ПОДРАЗДЕЛЕНИЯ"
        //процедура показа только одной вкладки ("Структурные подразделения")
        public void ShowStructuralUnitsTab()
        {
            AllTabsHide();
            tabPageStructuralUnits.Parent = tabControlStaffingTable;
        }

        //процедура открытия формы с полями ввода для добавления в таблицу "Структурные подразделения"
        private void btnAddStructuralUnit_Click(object sender, EventArgs e)
        {
            StaffingTableEditForm StaffingTableEdit = new StaffingTableEditForm();
            StaffingTableEdit.ShowStructuralUnitsTabToAdd();           
            StaffingTableEdit.ShowDialog();
        }

        //процедура открытия формы с полями ввода для редактирования данных в таблице "Структурные подразделения"
        private void btnChangeStructuralUnit_Click(object sender, EventArgs e)
        {
            StaffingTableEditForm StaffingTableEdit = new StaffingTableEditForm();
            StaffingTableEdit.ShowStructuralUnitsTabToChange();
            NumberOfEditRecord = dataGridViewStructuralUnits.CurrentRow.Cells["Unit_id"].Value.ToString();
            FullTitle = dataGridViewStructuralUnits.CurrentRow.Cells[1].Value.ToString();
            ShortTitle = dataGridViewStructuralUnits.CurrentRow.Cells[2].Value.ToString();
            importHierarchy = DB_Connection.GetHierarchyLevelId(
                dataGridViewStructuralUnits.CurrentRow.Cells["Уровень иерархии"].Value.ToString());
            importChief = DB_Connection.GetPersonnelNumberFromEmployees(
                dataGridViewStructuralUnits.CurrentRow.Cells["Руководитель"].Value.ToString());
            importParentUnit = DB_Connection.GetStructuralUnitId(
                dataGridViewStructuralUnits.CurrentRow.Cells
                ["Подчинено подразделению (сокращенное наименование)"].Value.ToString());
            StaffingTableEdit.StructuralUnitImport(dataGridViewStructuralUnits.CurrentRow.
                Cells["Уровень иерархии"].Value.ToString(), FullTitle, ShortTitle,
                dataGridViewStructuralUnits.CurrentRow.Cells["Руководитель"].Value.ToString(),
            dataGridViewStructuralUnits.CurrentRow.
            Cells["Подчинено подразделению (сокращенное наименование)"].Value.ToString());
            StaffingTableEdit.ShowDialog();
        }

        //процедура удаления записи из таблицы "Структурные подразделения"
        private void btnDeleteStructralUnit_Click(object sender, EventArgs e)
        {
            if (UserAgree())
            {
                if (!DB_Connection.StucturalUnitIsParent(dataGridViewStructuralUnits.CurrentRow.Cells["Unit_id"].
                        Value.ToString()))
                {
                    if (!DB_Connection.StructuralUnitInStaffingTable(dataGridViewStructuralUnits.CurrentRow.
                        Cells["Unit_id"].Value.ToString()))
                    {
                        DB_Connection.DeleteStructuralUnit(dataGridViewStructuralUnits.CurrentRow.Cells["Unit_id"].
                        Value.ToString());
                        MessageBox.Show("Запись удалена!");
                        DB_Connection.ShowStructuralUnits();
                    }
                    else MessageBox.Show("Сперва необходимо удалить сведения о структурном подразделении"
                    + " из штатного расписания!");
                }
                else MessageBox.Show("Данное подразделение является родительским! " +
                "Для удаления необходимо сперва удалить или переназначить свойства дочерних подразделений!");
            }
        }
    }
}
