﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace VacationScheduleCreator
{
    //класс формы с полями ввода для занесения штатного расписания и сопутствующей информации 
    public partial class EmployeeEditForm : Form
    {
        public EmployeeEditForm()
        {
            InitializeComponent();
        }

        //процедура скрытия всех вкладок 
        public void AllTabsHide()
        {
            tabPageEmployee.Parent = null;
            tabPageEmployeesAccount.Parent = null;
            tabPageAlternateList.Parent = null;
            tabPageEmployeesSickList.Parent = null;
        }

        //процедура заполнения выпадающих списков данными из БД
        private void EmployeeEditForm_Load(object sender, EventArgs e)
        {
            if (tabPageEmployeesAccount.Parent == tabControlEmployeesInformationEdit)
            {
                DB_Connection.ShowEmployees();
                comboBoxEmployee.DataSource = DB_Connection.dtEmployees;
                comboBoxEmployee.DisplayMember = "Surname_NF";
                comboBoxEmployee.ValueMember = "Табельный номер";
            }

            comboBoxVacationist.DataSource = DB_Connection.dtEmployees;
            comboBoxVacationist.DisplayMember = "Surname_NF";
            comboBoxVacationist.ValueMember = "Табельный номер";
            DB_Connection.ShowComboBoxEmployees();
            comboBoxAlternate.DataSource = DB_Connection.dtComboBoxEmployees;
            comboBoxAlternate.DisplayMember = "Surname_NF";
            comboBoxAlternate.ValueMember = "Personnel_number";

            comboBoxIllEmployee.DataSource = DB_Connection.dtEmployees;
            comboBoxIllEmployee.DisplayMember = "Surname_NF";
            comboBoxIllEmployee.ValueMember = "Табельный номер";
        }
        
        //процедура подстановки изменяемых значений при показе формы
        private void EmployeeEditForm_Shown(object sender, EventArgs e)
        {
            if (tabPageAlternateList.Parent == tabControlEmployeesInformationEdit)
            {
                if (tabPageAlternateList.Text == "Редактирование записи в списке замещающих лиц:")
                {
                    comboBoxVacationist.SelectedValue = Convert.ToInt16
                        (EmployeesDetailForm.importVacationist);
                    comboBoxAlternate.SelectedValue = Convert.ToInt16
                        (EmployeesDetailForm.importAlternate);
                }
            }
            if (tabPageEmployeesSickList.Parent == tabControlEmployeesInformationEdit)
            {
                if (tabPageEmployeesSickList.Text == "Редактирование сведений о больничном листе:")
                {
                    comboBoxIllEmployee.SelectedValue = Convert.ToInt16
                        (EmployeesDetailForm.importIllEmployee);
                }
            }
        }


        //ТАБЛИЦА "СПИСОК СОТРУДНИКОВ"
        //Настройка формы с полями ввода для добавления нового сотрудника
        public void ShowEmployeeTabToAdd()
        {
            AllTabsHide();
            tabPageEmployee.Parent = tabControlEmployeesInformationEdit;
            tabPageEmployee.Text = "Добавление нового сотрудника:";
            comboBoxGender.SelectedIndex = 0;
        }

        //Настройка формы с полями ввода для редактирования сведений о сотруднике
        public void ShowEmployeeTabToChange()
        {
            AllTabsHide();
            tabPageEmployee.Parent = tabControlEmployeesInformationEdit;
            tabPageEmployee.Text = "Редактирование сведений о сотруднике:";
        }
      
        //разрешает ввод букв, дефиса и пробела в поле "фамилия"
        private void textBoxSurname_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((!Char.IsLetter(e.KeyChar)) && (e.KeyChar != 8) 
                && (e.KeyChar != '-') &&(e.KeyChar != ' '))
                e.Handled = true;
        }

        //запрет на ввод не букв
        void OnlyLetters(KeyPressEventArgs e)
        {
            if ((!Char.IsLetter(e.KeyChar)) && (e.KeyChar != 8))
                e.Handled = true;
        }

        //запрет на ввод не букв в имя
        private void textBoxName_KeyPress(object sender, KeyPressEventArgs e)
        {
            OnlyLetters(e);
        }

        //запрет на ввод не букв в отчество
        private void textBoxFathersName_KeyPress(object sender, KeyPressEventArgs e)
        {
            OnlyLetters(e);
        }

        //запрет на ввод не цифр
        void OnlyDigits(KeyPressEventArgs e)
        {
            if ((!Char.IsDigit(e.KeyChar)) && (e.KeyChar != 8))
                e.Handled = true;
        }

        //Запрет ввода не цифр в серию паспорта
        private void textBoxPassportSeries_KeyPress(object sender, KeyPressEventArgs e)
        {
            OnlyDigits(e);
        }

        //Запрет ввода не цифр в номер паспорта
        private void textBoxPassportNumber_KeyPress(object sender, KeyPressEventArgs e)
        {
            OnlyDigits(e);
        }

        //Запрет ввода не цифр в поле "ИНН"
        private void textBoxInn_KeyPress(object sender, KeyPressEventArgs e)
        {
            OnlyDigits(e);
        }

        //Заполнение полей ввода изменяемыми значениями
        public void EmployeeImport(string surname, string name, string fathersName,
            string birthday, string gender, string passportSeries, string passportNumber,
            string snils, string inn, string registration, string employmentDate)
        {
            textBoxSurname.Text = surname;
            textBoxName.Text = name;
            textBoxFathersName.Text = fathersName;
            dateTimePickerBirthday.Value = Convert.ToDateTime(birthday);
            comboBoxGender.SelectedItem = gender;
            textBoxPassportSeries.Text = passportSeries;
            textBoxPassportNumber.Text = passportNumber;
            maskedTextBoxSnils.Text = snils;
            textBoxInn.Text = inn;
            textBoxRegistrationPlace.Text = registration;
            dateTimePickerEmploymentDate.Value = Convert.ToDateTime(employmentDate);
        }

        //отмена добавления или редактирования записи в списке сотрудников
        private void btnEmployeeCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //процедура добавления или редактирования сведений о сотруднике
        private void btnEmployeePost_Click(object sender, EventArgs e)
        {
            if (textBoxSurname.Text != "" && textBoxName.Text != "" &&
                textBoxFathersName.Text != "")
            {
                if (tabPageEmployee.Text == "Добавление нового сотрудника:")
                {
                    DB_Connection.AddEmployee(textBoxSurname.Text, textBoxName.Text,
                        textBoxFathersName.Text, dateTimePickerBirthday.Value.
                        ToString("yyyy-MM-dd"), comboBoxGender.SelectedItem.ToString(),
                        textBoxPassportSeries.Text, textBoxPassportNumber.Text,
                        maskedTextBoxSnils.Text, textBoxInn.Text, textBoxRegistrationPlace.
                        Text, dateTimePickerEmploymentDate.Value.ToString("yyyy-MM-dd"));
                    MessageBox.Show("Добавлен новый сотрудник!");
                    DB_Connection.ShowEmployees();
                    this.Close();
                }
                if (tabPageEmployee.Text == "Редактирование сведений о сотруднике:")
                {
                    DB_Connection.EditEmployee(EmployeesDetailForm.NumberOfEditRecord,
                        textBoxSurname.Text, textBoxName.Text, textBoxFathersName.Text,
                        dateTimePickerBirthday.Value.ToString("yyyy-MM-dd"),
                        comboBoxGender.SelectedItem.ToString(), textBoxPassportSeries.Text,
                        textBoxPassportNumber.Text, maskedTextBoxSnils.Text, textBoxInn.
                        Text, textBoxRegistrationPlace.Text,
                        dateTimePickerEmploymentDate.Value.ToString("yyyy-MM-dd"));
                    MessageBox.Show("Сведения о сотруднике изменены!");
                    DB_Connection.ShowEmployees();
                    this.Close();
                }
            }
            else MessageBox.Show("Фамилию, имя и отчество нужно указать обязательно!");
        }


        //ТАБЛИЦА "УЧЕТНЫЕ ЗАПИСИ СОТРУДНИКОВ"
        //Настройка формы с полями ввода для добавления новой учетной записи
        public void ShowEmployeesAccountTabToAdd()
        {
            AllTabsHide();
            tabPageEmployeesAccount.Parent = tabControlEmployeesInformationEdit;
            tabPageEmployeesAccount.Text = "Добавление новой учетной записи:";
            comboBoxRole.SelectedIndex = 0;
            comboBoxStatus.SelectedIndex = 0;
        }

        //Настройка формы с полями ввода для редактирования учетной записи
        public void ShowEmployeesAccountTabToChange()
        {
            AllTabsHide();
            tabPageEmployeesAccount.Parent = tabControlEmployeesInformationEdit;
            tabPageEmployeesAccount.Text = "Редактирование учетной записи:";
        }

        //Процедура подстановки изменяемых значений в поля ввода при редактировании
        public void EmployeesAccountImport(string employee, string login, 
            string password, string role, string status)
        {
            comboBoxEmployee.SelectedItem = employee;            
            textBoxLogin.Text = login;
            textBoxPassword.Text = password;
            comboBoxRole.SelectedItem = role;            
            if (status == "0")
                comboBoxStatus.SelectedIndex = 1;
            else
                comboBoxStatus.SelectedIndex = 0;                
        }

        //отмена добавления или редактирования учетной записи сотрудника
        private void btnEmployeesAccountCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //процедура добавления или редактирования записи в таблице "Учетные записи сотрудников"
        private void btnEmployeesAccountPost_Click(object sender, EventArgs e)
        {
            if (textBoxLogin.Text != "" && textBoxPassword.Text != "")
            {
                if (tabPageEmployeesAccount.Text ==
                    "Добавление новой записи в список замещающих лиц:")
                {
                    if (!DB_Connection.EmployeesAccountExists(MaintenanceForm.employee))
                    {
                        if (!DB_Connection.LoginExists(MaintenanceForm.login))
                        {
                            byte attemptsQuantity;
                            if (comboBoxStatus.SelectedIndex == 0) attemptsQuantity = 3;
                            else attemptsQuantity = 0;
                            DB_Connection.AddEmployeesAccount(comboBoxEmployee.SelectedValue.ToString(),
                                textBoxLogin.Text, textBoxPassword.Text,
                                comboBoxRole.SelectedItem.ToString(), attemptsQuantity.ToString());
                            MessageBox.Show("Создана новая учетная запись!");
                            DB_Connection.ShowEmployeesAccounts();
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("Этот логин уже занят!");
                        }
                    }
                    else
                    {
                        MessageBox.Show("У этого пользователя уже имеется учетная запись!");
                    }
                }
                if (tabPageEmployeesAccount.Text ==
                    "Редактирование записи в списке замещающих лиц:")
                {
                    if (!DB_Connection.EmployeesAccountExists(MaintenanceForm.employee) ||
                        MaintenanceForm.employee == comboBoxEmployee.SelectedItem.ToString())
                    {
                        if (!DB_Connection.LoginExists(MaintenanceForm.login) ||
                            MaintenanceForm.login == textBoxLogin.Text)
                        {
                            byte attemptsQuantity;
                            if (comboBoxStatus.SelectedIndex == 0) attemptsQuantity = 3;
                            else attemptsQuantity = 0;
                            DB_Connection.EditEmployeesAccount(comboBoxEmployee.SelectedValue.ToString(),
                                textBoxLogin.Text, textBoxPassword.Text,
                                comboBoxRole.SelectedItem.ToString(), attemptsQuantity.ToString());
                            MessageBox.Show("Учетная запись изменена!");
                            DB_Connection.ShowEmployeesAccounts();
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("Этот логин уже занят!");
                        }
                    }
                    else
                    {
                        MessageBox.Show("У этого пользователя уже имеется учетная запись!");
                    }
                }
            }
            else MessageBox.Show("Необходимо указать логин и пароль!");
        }


        //ТАБЛИЦА "СПИСОК ЗАМЕЩАЮЩИХ ЛИЦ"
        //Настройка формы с полями ввода для добавления записи в список замещающих лиц
        public void ShowAlternateListTabToAdd()
        {
            AllTabsHide();
            tabPageAlternateList.Parent = tabControlEmployeesInformationEdit;
            tabPageAlternateList.Text = "Добавление новой записи в список замещающих лиц:";
        }

        //Настройка формы с полями ввода для редактирования записи в списке замещающих лиц
        public void ShowAlternateListTabToChange()
        {
            AllTabsHide();
            tabPageAlternateList.Parent = tabControlEmployeesInformationEdit;
            tabPageAlternateList.Text = "Редактирование записи в списке замещающих лиц:";
        }

        //отмена добавления или редактирования записи в список замещающих лиц
        private void btnAlternateListCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //процедура добавления или редактирования записи в таблице "Список замещающих лиц"
        private void btnAlternateListPost_Click(object sender, EventArgs e)
        {
            if (comboBoxVacationist.Text != comboBoxAlternate.Text)
            {
                if (!DB_Connection.AlreadyInAlternateList(comboBoxVacationist.
                    SelectedValue.ToString(), comboBoxAlternate.SelectedValue.ToString()))
                {
                    if (tabPageAlternateList.Text == "Добавление новой записи в список замещающих лиц:")
                    {
                        DB_Connection.AddAlternate(comboBoxVacationist.SelectedValue.
                            ToString(), comboBoxAlternate.SelectedValue.ToString());
                        MessageBox.Show("Добавлена новая запись в список замещающих лиц!");
                        DB_Connection.ShowAlternateList();
                        this.Close();
                    }
                    if (tabPageAlternateList.Text == "Редактирование записи в списке замещающих лиц:")
                    {
                        DB_Connection.EditAlternate(EmployeesDetailForm.NumberOfEditRecord, 
                            comboBoxVacationist.SelectedValue.ToString(), 
                            comboBoxAlternate.SelectedValue.ToString());
                        MessageBox.Show("Запись изменена!");
                        DB_Connection.ShowAlternateList();
                        this.Close();
                    }
                }
                else MessageBox.Show("Эта запись уже присутствует в списке замещающих лиц!");
            }
            else MessageBox.Show("Сотрудник не может замещать сам себя!");
        }


        //ТАБЛИЦА "БОЛЬНИЧНЫЕ ЛИСТЫ СОТРУДНИКОВ"
        //Настройка формы с полями ввода для добавления больничного листа
        public void ShowEmployeesSickListToAdd()
        {
            AllTabsHide();
            tabPageEmployeesSickList.Parent = tabControlEmployeesInformationEdit;
            tabPageEmployeesSickList.Text = "Добавление нового больничого листа:";
        }
        
        //Настройка формы с полями ввода для редактирования больничного листа
        public void ShowEmployeesSickListToChange()
        {
            AllTabsHide();
            tabPageEmployeesSickList.Parent = tabControlEmployeesInformationEdit;
            tabPageEmployeesSickList.Text = "Редактирование сведений о больничном листе:";
        }

        //Заполнение полей ввода изменяемыми значениями
        public void EmployeesSickListImport(string beginningDate, string endDate)
        {
            dtpBeginningOfPeriod.Value = Convert.ToDateTime(beginningDate);
            dtpEndOfPeriod.Value = Convert.ToDateTime(endDate);              
        }

        //отмена добавления или редактирования записи о больничном листе сотрудника
        private void btnEmployeesSickListCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //процедура добавления или редактирования записи в таблице "Больничные листы сотрудников"
        private void btnEmployeesSickListPost_Click(object sender, EventArgs e)
        {
            if (dtpBeginningOfPeriod.Value > dtpEndOfPeriod.Value)
            {
                MessageBox.Show("Дата выписки не может быть раньше даты ухода на больничный!");
                return;
            }
            else
            {
                if (tabPageEmployeesSickList.Text == "Добавление нового больничого листа:")
                {
                    DB_Connection.AddEmployeesSickList(comboBoxIllEmployee.SelectedValue.ToString(),
                        dtpBeginningOfPeriod.Value.ToString("yyyy-MM-dd"),
                        dtpEndOfPeriod.Value.ToString("yyyy-MM-dd"));
                    MessageBox.Show("Сведения о новом больничном листе добавлены!");
                    DB_Connection.ShowEmployeesSickLists();
                    this.Close();
                }
                if (tabPageEmployeesSickList.Text == "Редактирование сведений о больничном листе:")
                {
                    DB_Connection.EditEmployeesSickList(EmployeesDetailForm.NumberOfEditRecord,
                        comboBoxIllEmployee.SelectedValue.ToString(),
                        dtpBeginningOfPeriod.Value.ToString("yyyy-MM-dd"),
                        dtpEndOfPeriod.Value.ToString("yyyy-MM-dd"));
                    MessageBox.Show("Сведения о больничном листе изменены!");
                    DB_Connection.ShowEmployeesSickLists();
                    this.Close();
                }
            }
        }
    }
}
