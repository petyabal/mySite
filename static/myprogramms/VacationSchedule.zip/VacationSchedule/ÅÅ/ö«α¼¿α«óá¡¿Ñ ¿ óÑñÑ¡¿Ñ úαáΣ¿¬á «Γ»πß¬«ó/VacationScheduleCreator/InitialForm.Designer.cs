﻿namespace VacationScheduleCreator
{
    partial class InitialForm
    {
        /// <summary>
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Обязательный метод для поддержки конструктора - не изменяйте
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(InitialForm));
            this.tableLayoutPanel_AllForm = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel_Company = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBoxCompany = new System.Windows.Forms.PictureBox();
            this.lblCompany = new System.Windows.Forms.Label();
            this.panelHeader = new System.Windows.Forms.Panel();
            this.tableLayoutPanel_Programm = new System.Windows.Forms.TableLayoutPanel();
            this.lblPogramm = new System.Windows.Forms.Label();
            this.tableLayoutPanel_Process = new System.Windows.Forms.TableLayoutPanel();
            this.lblDataBaseExists = new System.Windows.Forms.Label();
            this.lblAllTablesExists = new System.Windows.Forms.Label();
            this.lblProgrammComponentsExists = new System.Windows.Forms.Label();
            this.labelCheck = new System.Windows.Forms.Label();
            this.btnExit = new System.Windows.Forms.Button();
            this.pictureBox_Check1 = new System.Windows.Forms.PictureBox();
            this.pictureBox_Check2 = new System.Windows.Forms.PictureBox();
            this.pictureBox_Check3 = new System.Windows.Forms.PictureBox();
            this.timerMakeOpacityChange = new System.Windows.Forms.Timer(this.components);
            this.timerAuthorizationDelay = new System.Windows.Forms.Timer(this.components);
            this.tableLayoutPanel_AllForm.SuspendLayout();
            this.tableLayoutPanel_Company.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCompany)).BeginInit();
            this.panelHeader.SuspendLayout();
            this.tableLayoutPanel_Programm.SuspendLayout();
            this.tableLayoutPanel_Process.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Check1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Check2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Check3)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel_AllForm
            // 
            this.tableLayoutPanel_AllForm.ColumnCount = 1;
            this.tableLayoutPanel_AllForm.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_AllForm.Controls.Add(this.tableLayoutPanel_Company, 0, 1);
            this.tableLayoutPanel_AllForm.Controls.Add(this.panelHeader, 0, 0);
            this.tableLayoutPanel_AllForm.Controls.Add(this.tableLayoutPanel_Process, 0, 2);
            this.tableLayoutPanel_AllForm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_AllForm.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel_AllForm.Name = "tableLayoutPanel_AllForm";
            this.tableLayoutPanel_AllForm.RowCount = 3;
            this.tableLayoutPanel_AllForm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tableLayoutPanel_AllForm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 36F));
            this.tableLayoutPanel_AllForm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 49F));
            this.tableLayoutPanel_AllForm.Size = new System.Drawing.Size(387, 341);
            this.tableLayoutPanel_AllForm.TabIndex = 1;
            // 
            // tableLayoutPanel_Company
            // 
            this.tableLayoutPanel_Company.BackColor = System.Drawing.SystemColors.HotTrack;
            this.tableLayoutPanel_Company.ColumnCount = 4;
            this.tableLayoutPanel_Company.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8F));
            this.tableLayoutPanel_Company.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel_Company.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 54F));
            this.tableLayoutPanel_Company.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8F));
            this.tableLayoutPanel_Company.Controls.Add(this.pictureBoxCompany, 1, 1);
            this.tableLayoutPanel_Company.Controls.Add(this.lblCompany, 2, 1);
            this.tableLayoutPanel_Company.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Company.Location = new System.Drawing.Point(3, 54);
            this.tableLayoutPanel_Company.Name = "tableLayoutPanel_Company";
            this.tableLayoutPanel_Company.RowCount = 3;
            this.tableLayoutPanel_Company.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel_Company.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tableLayoutPanel_Company.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel_Company.Size = new System.Drawing.Size(381, 116);
            this.tableLayoutPanel_Company.TabIndex = 4;
            // 
            // pictureBoxCompany
            // 
            this.pictureBoxCompany.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxCompany.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxCompany.Image")));
            this.pictureBoxCompany.Location = new System.Drawing.Point(33, 8);
            this.pictureBoxCompany.Name = "pictureBoxCompany";
            this.pictureBoxCompany.Size = new System.Drawing.Size(108, 98);
            this.pictureBoxCompany.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxCompany.TabIndex = 3;
            this.pictureBoxCompany.TabStop = false;
            // 
            // lblCompany
            // 
            this.lblCompany.AutoSize = true;
            this.lblCompany.BackColor = System.Drawing.SystemColors.HotTrack;
            this.lblCompany.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCompany.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblCompany.ForeColor = System.Drawing.Color.White;
            this.lblCompany.Location = new System.Drawing.Point(147, 5);
            this.lblCompany.Name = "lblCompany";
            this.lblCompany.Size = new System.Drawing.Size(199, 104);
            this.lblCompany.TabIndex = 2;
            this.lblCompany.Text = "МЕЖРЕГИОНАЛЬНАЯ РАСПРЕДЕЛИТЕЛЬНАЯ СЕТЕВАЯ КОМПАНИЯ СЕВЕРО-ЗАПАДА";
            this.lblCompany.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panelHeader
            // 
            this.panelHeader.BackColor = System.Drawing.Color.Tan;
            this.panelHeader.Controls.Add(this.tableLayoutPanel_Programm);
            this.panelHeader.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelHeader.Location = new System.Drawing.Point(3, 3);
            this.panelHeader.Name = "panelHeader";
            this.panelHeader.Size = new System.Drawing.Size(381, 45);
            this.panelHeader.TabIndex = 1;
            // 
            // tableLayoutPanel_Programm
            // 
            this.tableLayoutPanel_Programm.ColumnCount = 1;
            this.tableLayoutPanel_Programm.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_Programm.Controls.Add(this.lblPogramm, 0, 0);
            this.tableLayoutPanel_Programm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Programm.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel_Programm.Name = "tableLayoutPanel_Programm";
            this.tableLayoutPanel_Programm.RowCount = 1;
            this.tableLayoutPanel_Programm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_Programm.Size = new System.Drawing.Size(381, 45);
            this.tableLayoutPanel_Programm.TabIndex = 0;
            // 
            // lblPogramm
            // 
            this.lblPogramm.AutoSize = true;
            this.lblPogramm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblPogramm.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblPogramm.ForeColor = System.Drawing.Color.White;
            this.lblPogramm.Location = new System.Drawing.Point(3, 0);
            this.lblPogramm.Name = "lblPogramm";
            this.lblPogramm.Size = new System.Drawing.Size(375, 45);
            this.lblPogramm.TabIndex = 0;
            this.lblPogramm.Text = "ФОРМИРОВАНИЕ И ВЕДЕНИЕ ГРАФИКА ОТПУСКОВ";
            this.lblPogramm.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // tableLayoutPanel_Process
            // 
            this.tableLayoutPanel_Process.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPanel_Process.ColumnCount = 4;
            this.tableLayoutPanel_Process.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7F));
            this.tableLayoutPanel_Process.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel_Process.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6F));
            this.tableLayoutPanel_Process.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7F));
            this.tableLayoutPanel_Process.Controls.Add(this.lblDataBaseExists, 1, 1);
            this.tableLayoutPanel_Process.Controls.Add(this.lblAllTablesExists, 1, 2);
            this.tableLayoutPanel_Process.Controls.Add(this.lblProgrammComponentsExists, 1, 3);
            this.tableLayoutPanel_Process.Controls.Add(this.labelCheck, 1, 4);
            this.tableLayoutPanel_Process.Controls.Add(this.btnExit, 0, 5);
            this.tableLayoutPanel_Process.Controls.Add(this.pictureBox_Check1, 2, 1);
            this.tableLayoutPanel_Process.Controls.Add(this.pictureBox_Check2, 2, 2);
            this.tableLayoutPanel_Process.Controls.Add(this.pictureBox_Check3, 2, 3);
            this.tableLayoutPanel_Process.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Process.Location = new System.Drawing.Point(3, 176);
            this.tableLayoutPanel_Process.Name = "tableLayoutPanel_Process";
            this.tableLayoutPanel_Process.RowCount = 7;
            this.tableLayoutPanel_Process.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel_Process.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tableLayoutPanel_Process.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tableLayoutPanel_Process.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tableLayoutPanel_Process.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_Process.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel_Process.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel_Process.Size = new System.Drawing.Size(381, 162);
            this.tableLayoutPanel_Process.TabIndex = 2;
            // 
            // lblDataBaseExists
            // 
            this.lblDataBaseExists.AutoSize = true;
            this.lblDataBaseExists.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblDataBaseExists.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblDataBaseExists.ForeColor = System.Drawing.Color.White;
            this.lblDataBaseExists.Location = new System.Drawing.Point(29, 8);
            this.lblDataBaseExists.Name = "lblDataBaseExists";
            this.lblDataBaseExists.Size = new System.Drawing.Size(298, 24);
            this.lblDataBaseExists.TabIndex = 1;
            this.lblDataBaseExists.Text = "- проверка существования базы данных";
            this.lblDataBaseExists.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.lblDataBaseExists.Visible = false;
            this.lblDataBaseExists.VisibleChanged += new System.EventHandler(this.lblDataBaseExists_VisibleChanged);
            // 
            // lblAllTablesExists
            // 
            this.lblAllTablesExists.AutoSize = true;
            this.lblAllTablesExists.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblAllTablesExists.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblAllTablesExists.ForeColor = System.Drawing.Color.White;
            this.lblAllTablesExists.Location = new System.Drawing.Point(29, 32);
            this.lblAllTablesExists.Name = "lblAllTablesExists";
            this.lblAllTablesExists.Size = new System.Drawing.Size(298, 24);
            this.lblAllTablesExists.TabIndex = 2;
            this.lblAllTablesExists.Text = "- проверка наличия всех таблиц базы данных";
            this.lblAllTablesExists.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.lblAllTablesExists.Visible = false;
            // 
            // lblProgrammComponentsExists
            // 
            this.lblProgrammComponentsExists.AutoSize = true;
            this.lblProgrammComponentsExists.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblProgrammComponentsExists.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblProgrammComponentsExists.ForeColor = System.Drawing.Color.White;
            this.lblProgrammComponentsExists.Location = new System.Drawing.Point(29, 56);
            this.lblProgrammComponentsExists.Name = "lblProgrammComponentsExists";
            this.lblProgrammComponentsExists.Size = new System.Drawing.Size(298, 24);
            this.lblProgrammComponentsExists.TabIndex = 0;
            this.lblProgrammComponentsExists.Text = "- проверка наличия всех компонентов программы";
            this.lblProgrammComponentsExists.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.lblProgrammComponentsExists.Visible = false;
            // 
            // labelCheck
            // 
            this.labelCheck.AutoSize = true;
            this.tableLayoutPanel_Process.SetColumnSpan(this.labelCheck, 2);
            this.labelCheck.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelCheck.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelCheck.ForeColor = System.Drawing.Color.White;
            this.labelCheck.Location = new System.Drawing.Point(29, 80);
            this.labelCheck.Name = "labelCheck";
            this.labelCheck.Size = new System.Drawing.Size(320, 40);
            this.labelCheck.TabIndex = 3;
            this.labelCheck.Text = "ЗАПУСК ПРИЛОЖЕНИЯ";
            this.labelCheck.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.labelCheck.Visible = false;
            this.labelCheck.VisibleChanged += new System.EventHandler(this.labelCheck_VisibleChanged);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.HotTrack;
            this.tableLayoutPanel_Process.SetColumnSpan(this.btnExit, 4);
            this.btnExit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnExit.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnExit.ForeColor = System.Drawing.Color.White;
            this.btnExit.Location = new System.Drawing.Point(3, 123);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(375, 26);
            this.btnExit.TabIndex = 4;
            this.btnExit.Text = "ЗАКРЫТЬ ПРИЛОЖЕНИЕ";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Visible = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // pictureBox_Check1
            // 
            this.pictureBox_Check1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox_Check1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox_Check1.Location = new System.Drawing.Point(333, 11);
            this.pictureBox_Check1.Name = "pictureBox_Check1";
            this.pictureBox_Check1.Size = new System.Drawing.Size(16, 18);
            this.pictureBox_Check1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox_Check1.TabIndex = 5;
            this.pictureBox_Check1.TabStop = false;
            this.pictureBox_Check1.BackgroundImageChanged += new System.EventHandler(this.pictureBox_Check1_BackgroundImageChanged);
            // 
            // pictureBox_Check2
            // 
            this.pictureBox_Check2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox_Check2.Location = new System.Drawing.Point(333, 35);
            this.pictureBox_Check2.Name = "pictureBox_Check2";
            this.pictureBox_Check2.Size = new System.Drawing.Size(16, 16);
            this.pictureBox_Check2.TabIndex = 6;
            this.pictureBox_Check2.TabStop = false;
            this.pictureBox_Check2.BackgroundImageChanged += new System.EventHandler(this.pictureBox_Check2_BackgroundImageChanged);
            // 
            // pictureBox_Check3
            // 
            this.pictureBox_Check3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox_Check3.Location = new System.Drawing.Point(333, 59);
            this.pictureBox_Check3.Name = "pictureBox_Check3";
            this.pictureBox_Check3.Size = new System.Drawing.Size(16, 16);
            this.pictureBox_Check3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox_Check3.TabIndex = 7;
            this.pictureBox_Check3.TabStop = false;
            this.pictureBox_Check3.BackgroundImageChanged += new System.EventHandler(this.pictureBox_Check3_BackgroundImageChanged);
            // 
            // timerMakeOpacityChange
            // 
            this.timerMakeOpacityChange.Interval = 20;
            this.timerMakeOpacityChange.Tick += new System.EventHandler(this.timerMakeOpacityChange_Tick);
            // 
            // timerAuthorizationDelay
            // 
            this.timerAuthorizationDelay.Interval = 1000;
            this.timerAuthorizationDelay.Tick += new System.EventHandler(this.timerAuthorizationDelay_Tick);
            // 
            // InitialForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(387, 341);
            this.Controls.Add(this.tableLayoutPanel_AllForm);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "InitialForm";
            this.Opacity = 0.4D;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Initial Form";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.InitialForm_FormClosed);
            this.Load += new System.EventHandler(this.InitialForm_Load);
            this.Shown += new System.EventHandler(this.InitialForm_Shown);
            this.tableLayoutPanel_AllForm.ResumeLayout(false);
            this.tableLayoutPanel_Company.ResumeLayout(false);
            this.tableLayoutPanel_Company.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCompany)).EndInit();
            this.panelHeader.ResumeLayout(false);
            this.tableLayoutPanel_Programm.ResumeLayout(false);
            this.tableLayoutPanel_Programm.PerformLayout();
            this.tableLayoutPanel_Process.ResumeLayout(false);
            this.tableLayoutPanel_Process.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Check1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Check2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Check3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_AllForm;
        private System.Windows.Forms.Panel panelHeader;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Programm;
        private System.Windows.Forms.Label lblPogramm;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Company;
        private System.Windows.Forms.PictureBox pictureBoxCompany;
        private System.Windows.Forms.Label lblCompany;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Process;
        private System.Windows.Forms.Label lblDataBaseExists;
        private System.Windows.Forms.Label lblAllTablesExists;
        private System.Windows.Forms.Label lblProgrammComponentsExists;
        private System.Windows.Forms.Label labelCheck;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.PictureBox pictureBox_Check1;
        private System.Windows.Forms.PictureBox pictureBox_Check2;
        private System.Windows.Forms.PictureBox pictureBox_Check3;
        private System.Windows.Forms.Timer timerMakeOpacityChange;
        private System.Windows.Forms.Timer timerAuthorizationDelay;

    }
}

