﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace VacationScheduleCreator
{
    //класс формы конструктора журнала ведения отпусков
    public partial class RealVacationLogConstructorForm : Form
    {
        public RealVacationLogConstructorForm()
        {
            InitializeComponent();
        }

        //строка хранит идентификатор назначенного отпуска
        static public string TheVacation;
        //строка хранит идентификатор нужного графика отпусков
        static public string TheVacationSchedule;

        //строка хранит идентификатор редактируемого отдела
        static public string CurrentUnit;
        //строка хранит идентификатор вида отпуска для активной записи
        static public string CurrentEmployee;

        //переменные для удаления записи из другого модуля
        static public string OldChangingRecord;
        static public int OldChangingDaysBalance;
        static public string OldChangingEmployeesVacation;

        //процедура загрузки сведений из БД
        private void RealVacationLogConstructorForm_Load(object sender, EventArgs e)
        {
            //выпадающий список "Подразделение"
            DB_Connection.ShowStructuralUnits();
            comboBoxStructuralUnit.DataSource = DB_Connection.dtStructuralUnits;
            comboBoxStructuralUnit.DisplayMember = "Сокращенное наименование";
            comboBoxStructuralUnit.ValueMember = "su.Unit_id";
            //выпадающий список "Сотрудник
            DB_Connection.ShowUnitEmployees(comboBoxStructuralUnit.SelectedValue.ToString());
            comboBoxEmployee.DataSource = DB_Connection.dtUnitEmployees;
            comboBoxEmployee.DisplayMember = "Surname_NF";
            comboBoxEmployee.ValueMember = "Personnel_number";
            //таблица "Расходование отпусков"
            DB_Connection.ShowEmployeeRealVacationsBalance(comboBoxEmployee.SelectedValue.ToString());
            dataGridViewRealVacationSpending.DataSource = DB_Connection.dtRealVacationSpending;
            dataGridViewRealVacationSpending.Columns["Position_id"].Visible = false;
            dataGridViewRealVacationSpending.Columns["Personnel_number"].Visible = false;
            if (dataGridViewRealVacationSpending.RowCount != 0)
                dataGridViewRealVacationSpending.Rows[0].Cells["За календарный год"].Selected = true;
            //таблица "Статус графика отпусков"
            DB_Connection.ShowActualVacationScheduleStatus
                (comboBoxStructuralUnit.SelectedValue.ToString());
            dataGridViewVacationStatus.DataSource = DB_Connection.dtActualVacationScheduleStatus;
            dataGridViewVacationStatus.Columns["Vacation_schedule_id"].Visible = false;
            dataGridViewVacationStatus.Columns["Утвердившее лицо"].Visible = false;
            if (dataGridViewVacationStatus.RowCount != 0)
                dataGridViewVacationStatus.Rows[0].Cells["Дата составления"].Selected = true;
            //таблица "Журнал отпусков"
            DB_Connection.ShowUnitVacationLog(comboBoxStructuralUnit.SelectedValue.ToString());
            dataGridViewVacationSchedule.DataSource = DB_Connection.dtUnitVacationLog;           
            dataGridViewVacationSchedule.Columns["Position_id"].Visible = false;
            dataGridViewVacationSchedule.Columns["Vacation_schedule_id"].Visible = false;
            if (dataGridViewVacationSchedule.RowCount != 0)
                dataGridViewVacationStatus.Rows[0].Cells["Сотрудник"].Selected = true;          
        }

        //процедура занесения сотрудников подразделения 
        //в выпадающий список при выборе подразделения
        private void comboBoxStructuralUnit_SelectedValueChanged(object sender, EventArgs e)
        {
            if (comboBoxStructuralUnit.SelectedValue != null)
            {
                //обновить список сотрудников
                DB_Connection.ShowUnitEmployees(comboBoxStructuralUnit.SelectedValue.ToString());
                //обновить журнал отпусков
                DB_Connection.ShowUnitVacationLog
                    (comboBoxStructuralUnit.SelectedValue.ToString());
                //обновить статус графика отпусков
                DB_Connection.ShowActualVacationScheduleStatus
                    (comboBoxStructuralUnit.SelectedValue.ToString());
                if (comboBoxEmployee.SelectedValue != null)
                {
                    DB_Connection.ShowEmployeeRealVacationsBalance(comboBoxEmployee.SelectedValue.ToString());
                }
                else DB_Connection.dtRealVacationSpending.Clear();
            }
            else DB_Connection.dtRealVacationSpending.Clear();
        }

        //процедура вывода списка назначеных отпусков для выбранного сотрудника
        private void comboBoxEmployee_SelectedValueChanged(object sender, EventArgs e)
        {
            if (comboBoxEmployee.SelectedValue != null)
            {
                DB_Connection.ShowEmployeeRealVacationsBalance(comboBoxEmployee.SelectedValue.ToString());
                dataGridViewRealVacationSpending.DataSource = DB_Connection.dtRealVacationSpending;
            }
            else DB_Connection.dtRealVacationSpending.Clear();
        }

        //процедура открытия формы с полями ввода для добавления отпуска в журнал ведения отпусков
        private void btnAddVacation_Click(object sender, EventArgs e)
        {
            if (dataGridViewVacationStatus.RowCount != 0)
            {
                if (dataGridViewRealVacationSpending.RowCount != 0)
                {
                    TheVacation = dataGridViewRealVacationSpending.CurrentRow.Cells["Position_id"].Value.ToString();
                    TheVacationSchedule = dataGridViewVacationStatus.
                        CurrentRow.Cells["Vacation_schedule_id"].Value.ToString();
                    EmployeesVacationsEditForm EmployeesVacationsEdit = new EmployeesVacationsEditForm();
                    EmployeesVacationsEdit.ShowVacationLogTabToAdd();
                    EmployeesVacationsEdit.RealDaysBalanceImport(dataGridViewRealVacationSpending.CurrentRow.
                        Cells["Осталось оплачиваемых дней"].Value.ToString());
                    EmployeesVacationsEdit.ImportEmployee = comboBoxEmployee.SelectedValue.ToString();
                    EmployeesVacationsEdit.ImportVacationType = dataGridViewRealVacationSpending.
                        CurrentRow.Cells["Вид отпуска"].Value.ToString();
                    EmployeesVacationsEdit.ShowDialog();
                    int temp1 = Convert.ToInt16(comboBoxStructuralUnit.SelectedValue.ToString());
                    int temp2 = Convert.ToInt16(comboBoxEmployee.SelectedValue.ToString());
                    DB_Connection.ShowStructuralUnits();
                    comboBoxStructuralUnit.SelectedValue = temp1;
                    comboBoxEmployee.SelectedValue = temp2;
                }
                else MessageBox.Show("Этому сотруднику не назначен отпуск!");
            }
            else MessageBox.Show("Для подразделения, к которому относится этот сотрудник не создан график отпусков!");
        }

        /*//процедура изменения отпуска сотрудника
        private void btnChangeVacation_Click(object sender, EventArgs e)
        {
            string TheRecord = DB_Connection.GetSpendingOfVacationRecordId(
                    dataGridViewVacationSchedule.CurrentRow.Cells["Сотрудник"].Value.ToString(),
                    dataGridViewVacationSchedule.CurrentRow.Cells["Вид отпуска"].Value.ToString());
                if (TheRecord != "NULL")
                {
                    OldChangingRecord = TheRecord;
                    OldChangingDaysBalance = DB_Connection.ImportDayRemainValue(TheRecord) +
                        Convert.ToInt16(dataGridViewVacationSchedule.CurrentRow.
                        Cells["Итого дней отпуска"].Value.ToString());
                    OldChangingEmployeesVacation = dataGridViewVacationSchedule.
                        CurrentRow.Cells["Position_id"].Value.ToString();

                    TheVacation = dataGridViewSpendingOfVacation.CurrentRow.Cells["Position_id"].Value.ToString();
                    TheVacationSchedule = dataGridViewVacationStatus.
                        CurrentRow.Cells["Vacation_schedule_id"].Value.ToString();
                    EmployeesVacationsEditForm EmployeesVacationsEdit = new EmployeesVacationsEditForm();
                    EmployeesVacationsEdit.ShowEmployeesVacationsTabToChange();
                    EmployeesVacationsEdit.DaysBalanceImport(dataGridViewSpendingOfVacation.CurrentRow.
                        Cells["Осталось оплачиваемых дней"].Value.ToString());
                    EmployeesVacationsEdit.CorrectiongDaysBalanceImport(
                        dataGridViewVacationSchedule.CurrentRow.Cells["Итого дней отпуска"].Value.ToString());
                    EmployeesVacationsEdit.ImportEmployee = comboBoxEmployee.Text;
                    MessageBox.Show(EmployeesVacationsEdit.ImportEmployee);//
                    EmployeesVacationsEdit.ImportVacationType = dataGridViewSpendingOfVacation.
                        CurrentRow.Cells["Вид отпуска"].Value.ToString();
                    MessageBox.Show(EmployeesVacationsEdit.ImportVacationType);//
                    EmployeesVacationsEdit.Show();
                }
                else MessageBox.Show("Нет сведений о назначенном сутруднику отпуске!");
        }*/

        private void btnChangeVacation_Click(object sender, EventArgs e)
        {
            if (dataGridViewVacationSchedule.RowCount == 0)
            {
                MessageBox.Show("Нет записей для редактирования!");
                return;
            } 
            string TheRecord = DB_Connection.GetRealVacationSpendingRecordId(
                    dataGridViewVacationSchedule.CurrentRow.Cells["Сотрудник"].Value.ToString(),
                    dataGridViewVacationSchedule.CurrentRow.Cells["Вид отпуска"].Value.ToString());
            if (TheRecord != "NULL")
                {
                    OldChangingRecord = TheRecord;
                    OldChangingDaysBalance = DB_Connection.ImportRealDayRemainValue(TheRecord) +
                            Convert.ToInt16(dataGridViewVacationSchedule.CurrentRow.
                            Cells["Итого дней отпуска"].Value.ToString());
                    OldChangingEmployeesVacation = dataGridViewVacationSchedule.
                            CurrentRow.Cells["Position_id"].Value.ToString();

                    TheVacation = dataGridViewRealVacationSpending.CurrentRow.Cells["Position_id"].Value.ToString();
                    TheVacationSchedule = dataGridViewVacationStatus.
                        CurrentRow.Cells["Vacation_schedule_id"].Value.ToString();
                    EmployeesVacationsEditForm EmployeesVacationsEdit = new EmployeesVacationsEditForm();
                    EmployeesVacationsEdit.ShowVacationLogTabToChange();
                    EmployeesVacationsEdit.RealDaysBalanceImport(dataGridViewRealVacationSpending.CurrentRow.
                                Cells["Осталось оплачиваемых дней"].Value.ToString());
                    EmployeesVacationsEdit.CorrectiongRealDaysBalanceImport(
                        dataGridViewVacationSchedule.CurrentRow.Cells["Итого дней отпуска"].Value.ToString());
                    EmployeesVacationsEdit.ImportEmployee = comboBoxEmployee.SelectedValue.ToString();
                    EmployeesVacationsEdit.ImportVacationType = dataGridViewRealVacationSpending.
                        CurrentRow.Cells["Вид отпуска"].Value.ToString();
                    EmployeesVacationsEdit.ShowDialog();
                    int temp1 = Convert.ToInt16(comboBoxStructuralUnit.SelectedValue.ToString());
                    int temp2 = Convert.ToInt16(comboBoxEmployee.SelectedValue.ToString());
                    DB_Connection.ShowStructuralUnits();
                    comboBoxStructuralUnit.SelectedValue = temp1;
                    comboBoxEmployee.SelectedValue = temp2;

                }
            else MessageBox.Show("Нет сведений о назначенном сутруднику отпуске!");
        }

        /*//процедура удаления выбранного отпуска из графика отпусков
        private void btnDeleteVacation_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = new DialogResult();
            dialogResult = MessageBox.Show("Вы действительно хотите удалить выбраный отпуск из графика?"
                ,"Удаление отпуска!",MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                string TheRecord = DB_Connection.GetSpendingOfVacationRecordId(
                    dataGridViewVacationSchedule.CurrentRow.Cells["Сотрудник"].Value.ToString(),
                    dataGridViewVacationSchedule.CurrentRow.Cells["Вид отпуска"].Value.ToString());
                if (TheRecord != "NULL")
                {
                    int DaysBalance = DB_Connection.ImportDayRemainValue(TheRecord) + 
                        Convert.ToInt16(dataGridViewVacationSchedule.CurrentRow.
                        Cells["Итого дней отпуска"].Value.ToString());
                    DB_Connection.CorrectingSpendingOfVacations(TheRecord, DaysBalance.ToString());
                    DB_Connection.DeleteEmployeesVacation(dataGridViewVacationSchedule.
                        CurrentRow.Cells["Position_id"].Value.ToString());
                    MessageBox.Show("График отпусков удален!");
                    DB_Connection.ShowUnitEmployeesVacations(comboBoxStructuralUnit.SelectedValue.ToString());
                }
                else MessageBox.Show("Нет сведений о назначенном сутруднику отпуске!");                
            }
        }*/

        private void btnDeleteVacation_Click(object sender, EventArgs e)
        {
            if (dataGridViewVacationSchedule.RowCount == 0)
            {
                MessageBox.Show("Нет записей для удаления!");
                return;
            }
            DialogResult dialogResult = new DialogResult();
            dialogResult = MessageBox.Show("Вы действительно хотите удалить выбраный отпуск из графика?"
                ,"Удаление отпуска!",MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {

                string TheRecord = DB_Connection.GetRealVacationSpendingRecordId(
                   dataGridViewVacationSchedule.CurrentRow.Cells["Сотрудник"].Value.ToString(),
                   dataGridViewVacationSchedule.CurrentRow.Cells["Вид отпуска"].Value.ToString());
                if (TheRecord != "NULL")
                {
                    int DaysBalance = DB_Connection.ImportRealDayRemainValue(TheRecord) +
                        Convert.ToInt16(dataGridViewVacationSchedule.CurrentRow.
                        Cells["Итого дней отпуска"].Value.ToString());
                    DB_Connection.CorrectingRealVacationSpending(TheRecord, DaysBalance.ToString());
                    DB_Connection.DeleteFromVacationLog(dataGridViewVacationSchedule.
                        CurrentRow.Cells["Position_id"].Value.ToString());
                    MessageBox.Show("Отпуск удален из журнала ведения отпусков!");
                    DB_Connection.ShowUnitEmployeesVacations(comboBoxStructuralUnit.SelectedValue.ToString());
                }
                else MessageBox.Show("Нет сведений о назначенном сутруднику отпуске!");
                int temp1 = Convert.ToInt16(comboBoxStructuralUnit.SelectedValue.ToString());
                int temp2 = Convert.ToInt16(comboBoxEmployee.SelectedValue.ToString());
                DB_Connection.ShowStructuralUnits();
                comboBoxStructuralUnit.SelectedValue = temp1;
                comboBoxEmployee.SelectedValue = temp2;
            }
        }
    }
}
