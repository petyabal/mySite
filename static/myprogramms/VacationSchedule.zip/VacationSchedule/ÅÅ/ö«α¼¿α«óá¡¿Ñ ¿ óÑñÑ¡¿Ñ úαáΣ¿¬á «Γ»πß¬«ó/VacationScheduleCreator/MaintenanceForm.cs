﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace VacationScheduleCreator
{
    public partial class MaintenanceForm : Form
    {
        public MaintenanceForm()
        {
            InitializeComponent();
        }

        static public string CurrentRecord;//хранит номер изменяемой записи
        static public string employee;//хранит Фамилию ИО пользователя
        static public string login;//хранит логин пользователя

        //процедура смены режима отображения списка пользователей
        private void btnUsersAccountsVisualization_Click(object sender, EventArgs e)
        {
            HideExitOptions();
            switch (btnUsersAccountsVisualization.Text)
            {
                case "Показать список пользователей": 
                    btnUsersAccountsVisualization.Text = "Cкрыть список пользователей";
                    groupBoxUsersAccounts.Show();
                    groupBoxSearchAccount.Show();
                    btnLoginsVisualization.Show();
                    btnPasswordsVisualization.Show();
                    break;
                case "Cкрыть список пользователей":
                    groupBoxUsersAccounts.Hide();
                    groupBoxSearchAccount.Hide();
                    btnUsersAccountsVisualization.Text = "Показать список пользователей";
                    btnLoginsVisualization.Hide();
                    btnPasswordsVisualization.Hide();
                    break;
            }
        }

        //процедура смены режима отображения логинов пользователей
        private void btnLoginsVisualization_Click(object sender, EventArgs e)
        {
            HideExitOptions();
            switch (btnLoginsVisualization.Text)
            {
                case "Отображать логины":
                    btnLoginsVisualization.Text = "Скрывать логины";
                    break;
                case "Скрывать логины":
                    btnLoginsVisualization.Text = "Отображать логины";
                    break;
            }
        }

        //процедура смены режима отображения паролей пользователей
        private void btnPasswordsVisualization_Click(object sender, EventArgs e)
        {
            HideExitOptions();
            switch (btnPasswordsVisualization.Text)
            {
                case "Отображать пароли":
                    btnPasswordsVisualization.Text = "Скрывать пароли";
                    break;
                case "Скрывать пароли":
                    btnPasswordsVisualization.Text = "Отображать пароли";
                    break;
            }
        }

        //процедура скрытия кнопок закрытия приложения и смены пользователя
        void HideExitOptions()
        {
            btnUserChange.Hide();
            btnCloseApplication.Hide();
        }

        //процедура показа кнопок закрытия приложения и смены пользователя
        private void btnPause_Click(object sender, EventArgs e)
        {
            btnUserChange.Show();
            btnCloseApplication.Show();
        }

        //процедура отображения данных из таблицы "Учетные записи пользователей"
        private void MaintenanceForm_Load(object sender, EventArgs e)
        {
            DB_Connection.ShowEmployeesAccounts();
            dataGridViewUsersAccounts.DataSource = DB_Connection.dtEmployeesAccounts;
        }

        //процедура возврата на форму авторизации
        private void btnUserChange_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //процедура закрытия приложения
        private void btnCloseApplication_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = new DialogResult();
            dialogResult = MessageBox.Show("Вы действительно хотите выйти из приложения?",
                "Завершение работы!", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                this.Close();
                InitialForm.ExitConfirm = true;
            }
        }

        private void btnAddUserAccount_Click(object sender, EventArgs e)
        {
            EmployeeEditForm EmployeeEdit = new EmployeeEditForm();
            EmployeeEdit.ShowEmployeesAccountTabToAdd();
            EmployeeEdit.Show();
        }

        private void btnChangeUserAccount_Click(object sender, EventArgs e)
        {
            EmployeeEditForm EmployeeEdit = new EmployeeEditForm();
            employee = dataGridViewUsersAccounts.CurrentRow.Cells[1].Value.ToString();
            login = dataGridViewUsersAccounts.CurrentRow.Cells[2].Value.ToString();
            EmployeeEdit.ShowEmployeesAccountTabToChange();
            CurrentRecord = dataGridViewUsersAccounts.CurrentRow.Cells["Табельный номер"].Value.ToString();
            EmployeeEdit.EmployeesAccountImport(dataGridViewUsersAccounts.CurrentRow.Cells[1].Value.ToString(),
                dataGridViewUsersAccounts.CurrentRow.Cells[2].Value.ToString(),
                dataGridViewUsersAccounts.CurrentRow.Cells[3].Value.ToString(),
                dataGridViewUsersAccounts.CurrentRow.Cells[4].Value.ToString(),
                dataGridViewUsersAccounts.CurrentRow.Cells[5].Value.ToString());
            EmployeeEdit.Show();
        }
    }
}
