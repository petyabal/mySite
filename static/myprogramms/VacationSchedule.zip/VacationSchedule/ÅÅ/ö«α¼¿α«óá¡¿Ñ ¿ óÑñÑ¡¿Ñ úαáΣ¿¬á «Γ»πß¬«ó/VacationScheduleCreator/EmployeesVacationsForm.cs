﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace VacationScheduleCreator
{
    //класс формы для отображения информации, связанной с отпусками сотрудников
    public partial class EmployeesVacationsForm : Form
    {
        public EmployeesVacationsForm()
        {
            InitializeComponent();
        }

        //переменная для определения изначального момента загрузки формы
        string InitialMoment = "now";
        //выбранный пользователем график отпусков
        static public string TheVacationSchedule;

        //процедура загрузки данных из БД
        private void EmployeesVacationsForm_Load(object sender, EventArgs e)
        {
            DB_Connection.ShowSpendingOfVacations();
            dataGridViewSpendingOfVacations.DataSource = DB_Connection.dtSpendingOfVacations;
            dataGridViewSpendingOfVacations.Columns["Position_id"].Visible = false;
            DB_Connection.ShowVacationTypes();
            dataGridViewVacationTypes.DataSource = DB_Connection.dtVacationTypes;
            dataGridViewVacationTypes.Columns["Vacation_type_id"].Visible = false;
            DB_Connection.ShowVacationSchedules();
            dataGridViewVacationSchedules.DataSource = DB_Connection.dtVacationSchedules;
            dataGridViewVacationSchedules.Columns["Vacation_schedule_id"].Visible = false;
            if (dataGridViewVacationSchedules.RowCount != 0)
            {
                if (InitialMoment == "now")
                {
                    DB_Connection.ShowEmployeesVacations(dataGridViewVacationSchedules.Rows[0].
                        Cells["Vacation_schedule_id"].Value.ToString());
                    dataGridViewEmployeesVacations.DataSource = DB_Connection.dtEmployeesVacations;
                    dataGridViewVacationSchedules.Rows[0].Cells["Дата составления"].Selected = true;
                    dataGridViewEmployeesVacations.Columns["Vacation_schedule_id"].Visible = false;
                    dataGridViewEmployeesVacations.Columns["Position_id"].Visible = false;
                    InitialMoment = "lost";
                }
                else
                {
                    DB_Connection.ShowEmployeesVacations(dataGridViewVacationSchedules.CurrentRow.
                        Cells["Vacation_schedule_id"].Value.ToString());
                    dataGridViewEmployeesVacations.DataSource = DB_Connection.dtEmployeesVacations;
                    dataGridViewEmployeesVacations.Columns["Vacation_schedule_id"].Visible = false;
                    dataGridViewEmployeesVacations.Columns["Position_id"].Visible = false;
                }
            }
        }

        //процедура обновления данных в таблицах
        void RefreshData()
        {
            DB_Connection.ShowSpendingOfVacations();
            DB_Connection.ShowVacationTypes();
            DB_Connection.ShowVacationSchedules();
            if (dataGridViewVacationSchedules.RowCount != 0)
                DB_Connection.ShowEmployeesVacations(dataGridViewVacationSchedules.Rows[0].
                        Cells["Vacation_schedule_id"].Value.ToString());
        }

        //процедура выбора конкретного графика отпусков для отображения
        private void dataGridViewVacationSchedules_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex == -1) return;
            else
            {
                DB_Connection.ShowEmployeesVacations(dataGridViewVacationSchedules.CurrentRow.
                    Cells["Vacation_schedule_id"].Value.ToString());
                dataGridViewEmployeesVacations.DataSource = DB_Connection.dtEmployeesVacations;
            }
        }

        //процедура настройки и показа формы для отображения справочника "Виды отпусков"
        private void btnVacationTypesDetail_Click(object sender, EventArgs e)
        {
            EmployeesVacationsDetailForm EmployeesVacationsDetail = new EmployeesVacationsDetailForm();
            EmployeesVacationsDetail.ShowVacationTypesTab();
            EmployeesVacationsDetail.WindowState = FormWindowState.Maximized;
            EmployeesVacationsDetail.ShowDialog();
            RefreshData();
        }

        //процедура настройки и показа формы для отображения списка графиков отпусков
        private void btnVacationSchedulesDetail_Click(object sender, EventArgs e)
        {
            EmployeesVacationsDetailForm EmployeesVacationsDetail = new EmployeesVacationsDetailForm();
            EmployeesVacationsDetail.ShowVacationSchedulesTab();
            EmployeesVacationsDetail.WindowState = FormWindowState.Maximized;
            EmployeesVacationsDetail.ShowDialog();
            RefreshData();
        }

        //процедура настройки и показа формы для отображения конкретного графика отпусков
        private void btnEmployeesVacationsDetail_Click(object sender, EventArgs e)
        {
            TheVacationSchedule = dataGridViewVacationSchedules.CurrentRow.
                Cells["Vacation_schedule_id"].Value.ToString();
            EmployeesVacationsDetailForm EmployeesVacationsDetail = new EmployeesVacationsDetailForm();
            EmployeesVacationsDetail.ShowEmployeesVacationsTab();
            EmployeesVacationsDetail.WindowState = FormWindowState.Maximized;
            EmployeesVacationsDetail.ShowDialog();
            RefreshData();
        }

        //процедура настройки и показа формы для отображения таблицы "Использование отпусков"
        private void btnSpendingOfVacationsDetail_Click(object sender, EventArgs e)
        {
            EmployeesVacationsDetailForm EmployeesVacationsDetail = new EmployeesVacationsDetailForm();
            EmployeesVacationsDetail.ShowSpendingOfVacationTub();
            EmployeesVacationsDetail.WindowState = FormWindowState.Maximized;
            EmployeesVacationsDetail.ShowDialog();
            RefreshData();
        }

        //процедура настройки и показа формы для отображения 
        //периодов предоставления оплачиваемого проезда
        private void btnEmployeesPaidTravel_Click(object sender, EventArgs e)
        {
            EmployeesVacationsDetailForm EmployeesVacationsDetail = new EmployeesVacationsDetailForm();
            EmployeesVacationsDetail.ShowEmployeesPaidTravelTab();
            EmployeesVacationsDetail.WindowState = FormWindowState.Maximized;
            EmployeesVacationsDetail.ShowDialog();
            RefreshData();
        }       
    }
}
