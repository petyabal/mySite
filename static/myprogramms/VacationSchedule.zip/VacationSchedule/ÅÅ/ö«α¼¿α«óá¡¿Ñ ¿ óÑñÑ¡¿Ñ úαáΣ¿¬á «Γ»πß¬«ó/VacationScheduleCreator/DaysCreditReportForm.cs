﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace VacationScheduleCreator
{
    public partial class DaysCreditReportForm : Form
    {
        public DaysCreditReportForm()
        {
            InitializeComponent();
        }

        private void DaysCreditReportForm_Load(object sender, EventArgs e)
        {
            DB_Connection.ShowDaysCreditReport();
            dataGridViewDaysCreditReport.DataSource = DB_Connection.dtDaysCreditReport;
            DB_Connection.ShowVacationsSchedulesForReport();
            dataGridViewVacationSchedules.DataSource = DB_Connection.dtVacationsSchedulesForReport;
        }
    }
}
