﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace VacationScheduleCreator
{
    //класс формы с полями ввода для формирования сведений об отпусках сотрудников
    public partial class EmployeesVacationsEditForm : Form
    {
        public EmployeesVacationsEditForm()
        {
            InitializeComponent();
        }
        //переменная хранит количество дней отпуска исходя из вида отпуска
        int DaysLimit;
        //переменная хранит идентификатор отпускника для выпадающего списка
        public string ImportEmployee;
        //переменная хранит идентификатор вида отпуска для выпадающего списка
        public string ImportVacationType;

        //процедура скрытия всех вкладок 
        void AllTabsHide()
        {
            tabPageEmployeesVacation.Parent = null;
            tabPageVacationSchedulesList.Parent = null;
            tabPageVacationType.Parent = null;
            tabPageSpendingOfVacations.Parent = null;
            tabPageEmployeesPaidTravel.Parent = null;
            tabPageVacationLog.Parent = null;
        }

        //процедура загрузки данных из таблиц БД
        private void EmployeesVacationsEditForm_Load(object sender, EventArgs e)
        {
            if (tabPageEmployeesVacation.Parent == tabControlEmployeesVacationsEdit)
            {
                comboBoxPersonnel.DataSource = DB_Connection.dtUnitEmployees;
                comboBoxPersonnel.DisplayMember = "Surname_NF";
                comboBoxPersonnel.ValueMember = "Personnel_number";
                comboBoxVacationType.DataSource = DB_Connection.dtVacationTypes;
                comboBoxVacationType.DisplayMember = "Вид отпуска";
                comboBoxVacationType.ValueMember = "Vacation_type_id";
            }
            if (tabPageVacationSchedulesList.Parent == tabControlEmployeesVacationsEdit)
            {
                DB_Connection.ShowEmployees();
                comboBoxApprovedBy.DataSource = DB_Connection.dtEmployees;
                comboBoxApprovedBy.DisplayMember = "Surname_NF";
                comboBoxApprovedBy.ValueMember = "Табельный номер";
                DB_Connection.ShowStructuralUnits();
                comboBoxStructuralUnit.DataSource = DB_Connection.dtStructuralUnits;
                comboBoxStructuralUnit.DisplayMember = "Сокращенное наименование";
                comboBoxStructuralUnit.ValueMember = "Unit_id";
            }
            if (tabPageSpendingOfVacations.Parent == tabControlEmployeesVacationsEdit)
            {                
                comboBoxTypeOfVacation.DataSource = DB_Connection.dtVacationTypes;
                comboBoxTypeOfVacation.DisplayMember = "Вид отпуска";
                comboBoxTypeOfVacation.ValueMember = "Vacation_type_id";
                DB_Connection.ShowEmployees();
                comboBoxVacationist.DataSource = DB_Connection.dtEmployees;
                comboBoxVacationist.DisplayMember = "Surname_NF";
                comboBoxVacationist.ValueMember = "Табельный номер";                
            }
            if (tabPageEmployeesPaidTravel.Parent == tabControlEmployeesVacationsEdit)
            {
                DB_Connection.ShowEmployees();
                comboBoxTraveler.DataSource = DB_Connection.dtEmployees;
                comboBoxTraveler.DisplayMember = "Surname_NF";
                comboBoxTraveler.ValueMember = "Табельный номер";
            }
            if (tabPageVacationLog.Parent == tabControlEmployeesVacationsEdit)
            {
                comboBoxRealPersonnel.DataSource = DB_Connection.dtUnitEmployees;
                comboBoxRealPersonnel.DisplayMember = "Surname_NF";
                comboBoxRealPersonnel.ValueMember = "Personnel_number";
                comboBoxRealVacationType.DataSource = DB_Connection.dtVacationTypes;
                comboBoxRealVacationType.DisplayMember = "Вид отпуска";
                comboBoxRealVacationType.ValueMember = "Vacation_type_id";
            }
        }

        //процедура указания изменяемых значений в выпадающих списках при изменении
        private void EmployeesVacationsEditForm_Shown(object sender, EventArgs e)
        {
            if (tabPageSpendingOfVacations.Parent == tabControlEmployeesVacationsEdit)
            {
                if (tabPageSpendingOfVacations.Text == 
                    "Изменение предоставленного сотруднику отпуска:")
                {
                    comboBoxVacationist.SelectedValue = EmployeesVacationsDetailForm.importVacationist;
                    comboBoxTypeOfVacation.SelectedValue = EmployeesVacationsDetailForm.importTypeOfVacation;
                }
            }
            if (tabPageVacationSchedulesList.Parent == tabControlEmployeesVacationsEdit)
            {
                if (tabPageVacationSchedulesList.Text == "Редактирование графика отпусков:")
                {
                    comboBoxStructuralUnit.SelectedValue = EmployeesVacationsDetailForm.importStructuralUnit;
                    if (EmployeesVacationsDetailForm.importApprovedBy != null)
                        comboBoxApprovedBy.SelectedValue = EmployeesVacationsDetailForm.importApprovedBy;
                }
            }
            if (tabPageEmployeesPaidTravel.Parent == tabControlEmployeesVacationsEdit)
            {
                if (tabPageEmployeesPaidTravel.Text == "Редактирование периода:")
                    comboBoxTraveler.SelectedValue = EmployeesVacationsDetailForm.importTraveler;               
            }
            if (tabPageEmployeesVacation.Parent == tabControlEmployeesVacationsEdit)
                comboBoxPersonnel.SelectedValue = ImportEmployee;
            if (tabPageVacationLog.Parent == tabControlEmployeesVacationsEdit)
                comboBoxRealPersonnel.SelectedValue = ImportEmployee;
        }


        //ТАБЛИЦА "ОТПУСКА СОТРУДНИКОВ"
        //Настройка формы с полями ввода для добавления нового отпуска (в график отпусков)
        public void ShowEmployeesVacationsTabToAdd()
        {
            AllTabsHide();
            tabPageEmployeesVacation.Parent = tabControlEmployeesVacationsEdit;
            tabPageEmployeesVacation.Text = "Добавление нового отпуска:";
        }

        //Настройка формы с полями ввода для редактирования отпуска (в графике отпусков)
        public void ShowEmployeesVacationsTabToChange()
        {
            AllTabsHide();
            tabPageEmployeesVacation.Parent = tabControlEmployeesVacationsEdit;
            tabPageEmployeesVacation.Text = "Редактирование отпуска:";
        }

        //процедура расчета количества дней при изменении даты начала отпуска в графике
        private void dtpVacationStart_ValueChanged(object sender, EventArgs e)
        {
            if (dtpVacationStart.Value > dtpVacationFinish.Value)
                dtpVacationFinish.Value = dtpVacationStart.Value;
            else
            {
                CalculateRange();
            }
        }

        //процедура расчета количества дней при изменении даты окончания отпуска в графике
        private void dtpVacationFinish_ValueChanged(object sender, EventArgs e)
        {
            if (dtpVacationStart.Value > dtpVacationFinish.Value)
                dtpVacationStart.Value = dtpVacationFinish.Value;
            else
            {
                CalculateRange();
            }
        }

        //процедура расчета количества дней отпуска и количество неотгуленных дней отпуска по графику
        void CalculateRange()
        {
            TimeSpan VacationTime = dtpVacationFinish.Value - dtpVacationStart.Value;
            string OldQuantity = textBoxDaysQuantity.Text;
            int HolidaysQuantity = DB_Connection.StateHolidaysInVacation
                (dtpVacationStart.Value.ToString("yyyy-MM-dd"), 
                dtpVacationFinish.Value.ToString("yyyy-MM-dd"));

            textBoxDaysQuantity.Text = (VacationTime.Days + 1
                - HolidaysQuantity).ToString();
            textBoxDaysRamain.Text = (Convert.ToInt16(textBoxDaysRamain.Text) -
            Convert.ToInt16(textBoxDaysQuantity.Text) +
            Convert.ToInt16(OldQuantity)).ToString();
            
            if (Convert.ToInt16(textBoxDaysRamain.Text) < 0)
            {
                textBoxDaysRamain.ForeColor = Color.White;
                textBoxDaysRamain.BackColor = Color.Red;
            }
            else
            {
                textBoxDaysRamain.ForeColor = Color.Black;
                textBoxDaysRamain.BackColor = Color.WhiteSmoke;                
            }
        }

        //процедура указания числа неиспользованных дней отпуска
        public void DaysBalanceImport(string balance)
        {
            textBoxDaysRamain.Text = (Convert.ToInt16(balance) -
                Convert.ToInt16(textBoxDaysQuantity.Text)).ToString();
        }

        //процедура корректировки числа 
        //неиспользованных дней отпуска при изменении записи
        public void CorrectiongDaysBalanceImport(string UpBalance)
        {
            textBoxDaysRamain.Text = (Convert.ToInt16(textBoxDaysRamain.Text) +
                Convert.ToInt16(UpBalance)).ToString();
        }

        //процедура отмены добавления или редактирования в таблице "Отпуска сотрудников"
        private void btnEmployeesVacationsCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //процедура добавления или редактирования записи в таблице "Отпуска сотрудников"
        private void btnEmployeesVacationsPost_Click(object sender, EventArgs e)
        {
            if (tabPageEmployeesVacation.Text == "Добавление нового отпуска:")
            {

                DB_Connection.AddEmployeesVacation(comboBoxPersonnel.SelectedValue.ToString(),
                    VacationScheduleConstructorForm.TheVacationSchedule,
                    dtpVacationStart.Value.ToString("yyyy-MM-dd"),
                    dtpVacationFinish.Value.ToString("yyyy-MM-dd"),
                    comboBoxVacationType.SelectedValue.ToString(),
                    textBoxDaysQuantity.Text);
                DB_Connection.CorrectingSpendingOfVacations(
                    VacationScheduleConstructorForm.TheVacation,
                    textBoxDaysRamain.Text);
                MessageBox.Show("Сотруднику добавлен отпуск!");
                /*DB_Connection.ShowEmployeesVacations
                    (VacationScheduleConstructorForm.TheVacationSchedule);
                DB_Connection.ShowEmployeeVacationsBalance
                    (comboBoxPersonnel.SelectedValue.ToString());*/
                this.Close();
            }
            if (tabPageEmployeesVacation.Text == "Редактирование отпуска:")
            {
                DB_Connection.CorrectingSpendingOfVacations
                    (VacationScheduleConstructorForm.OldChangingRecord,
                    VacationScheduleConstructorForm.OldChangingDaysBalance.ToString());
                DB_Connection.DeleteEmployeesVacation
                    (VacationScheduleConstructorForm.OldChangingEmployeesVacation);

                DB_Connection.AddEmployeesVacation(comboBoxPersonnel.SelectedValue.ToString(),
                    VacationScheduleConstructorForm.TheVacationSchedule,
                    dtpVacationStart.Value.ToString("yyyy-MM-dd"),
                    dtpVacationFinish.Value.ToString("yyyy-MM-dd"),
                    comboBoxVacationType.SelectedValue.ToString(),
                    textBoxDaysQuantity.Text);
                DB_Connection.CorrectingSpendingOfVacations(
                    VacationScheduleConstructorForm.TheVacation,
                    textBoxDaysRamain.Text);
                MessageBox.Show("Отпуск сотрудника изменен!");
               /* DB_Connection.ShowEmployeesVacations
                    (VacationScheduleConstructorForm.TheVacationSchedule);
                DB_Connection.ShowEmployeeVacationsBalance
                    (comboBoxPersonnel.SelectedValue.ToString());*/
                this.Close();           
            }
        }


        //ТАБЛИЦА "ГРАФИКИ ОТПУСКОВ"
        //Настройка формы с полями ввода для добавления графика отпусков
        public void ShowVacationSchedulesListTabToAdd()
        {
            AllTabsHide();
            tabPageVacationSchedulesList.Parent = tabControlEmployeesVacationsEdit;
            tabPageVacationSchedulesList.Text = "Добавление нового графика отпусков:";
        }

        //Настройка формы с полями ввода для редактирования графика отпусков
        public void ShowVacationSchedulesListTabToChange()
        {
            AllTabsHide();
            tabPageVacationSchedulesList.Parent = tabControlEmployeesVacationsEdit;
            tabPageVacationSchedulesList.Text = "Редактирование графика отпусков:";
        }

        //процедура указания сведений о утверждении графика отпусков
        public void VacationScheduleInformationImport(string created, string title, string year,
            string status, string approvementDate)
        {
            dtpCreated.Value = Convert.ToDateTime(created);
            textBoxVacationScheduleTitle.Text = title;
            textBoxYear.Text = year;
            comboBoxApproved.SelectedItem = status;
            if (status == "Утвержден")
            {
                dtpApprovementDate.Value = Convert.ToDateTime(approvementDate);
                ShowApprovementFields();
            }
            else HideApprovementFields();
        }

        //процедура скрытия полей ввода (для неутвержденных документов)
        void HideApprovementFields()
        {
            lblApprovedBy.Hide();
            comboBoxApprovedBy.Hide();
            lblApprovementDate.Hide();
            dtpApprovementDate.Hide();
        }

        //процедура показа полей ввода для внесения информации об утверждении документа
        void ShowApprovementFields()
        {
            lblApprovedBy.Show();
            comboBoxApprovedBy.Show();
            lblApprovementDate.Show();
            dtpApprovementDate.Show();
        }

        //показ или скрытие полей ввода при изменении статуса утверждения
        private void comboBoxApproved_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBoxApproved.SelectedIndex == 1)
            {
                ShowApprovementFields();
            }
            else
            {
                HideApprovementFields();
            }
        }

        //процедура уменьшения указываемого в графике отпусков года на 1
        private void btnYearMinus_Click(object sender, EventArgs e)
        {
            textBoxYear.Text = (Convert.ToInt16(textBoxYear.Text) - 1).ToString();
        }

        //процедура увеличения указываемого в графике отпусков года на 1
        private void btnYearPlus_Click(object sender, EventArgs e)
        {
            textBoxYear.Text = (Convert.ToInt16(textBoxYear.Text) + 1).ToString();
        }

        //отмена добавления или редактирования записи в таблице "Графики отпусков"
        private void btnVacationSchedulesCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //процедура добавления или редактирования записи в таблице "Графики отпусков"
        private void btnVacationSchedulesPost_Click(object sender, EventArgs e)
        {
            if (tabPageVacationSchedulesList.Text == "Добавление нового графика отпусков:")
            {
                if (!DB_Connection.VacationScheduleAlreadyExists(comboBoxStructuralUnit.
                    SelectedValue.ToString()))
                {
                    DB_Connection.AddVacationSchedule(dtpCreated.Value.ToString("yyyy-MM-dd"),
                    textBoxVacationScheduleTitle.Text, textBoxYear.Text, comboBoxApproved.
                    SelectedItem.ToString(), comboBoxApprovedBy.SelectedValue.ToString(),
                    dtpApprovementDate.Value.ToString("yyyy-MM-dd"),
                    comboBoxStructuralUnit.SelectedValue.ToString(),
                    comboBoxApproved.SelectedItem.ToString());
                    MessageBox.Show("Добавлен новый график отпусков");
                    DB_Connection.ShowVacationSchedules();
                    this.Close();
                }
                else MessageBox.Show("График отпусков для выбранного отдела уже сущестует");
            }
            if (tabPageVacationSchedulesList.Text == "Редактирование графика отпусков:")
            {

                if (!DB_Connection.VacationScheduleAlreadyExists(comboBoxStructuralUnit.
                    SelectedValue.ToString()) || comboBoxStructuralUnit.Text
                    == EmployeesVacationsDetailForm.UnitVacationSchedule)
                {
                    DB_Connection.EditVacationSchedule(EmployeesVacationsDetailForm.
                        NumberOfEditRecord, dtpCreated.Value.ToString("yyyy-MM-dd"),
                    textBoxVacationScheduleTitle.Text, textBoxYear.Text, comboBoxApproved.
                    SelectedItem.ToString(), comboBoxApprovedBy.SelectedValue.ToString(),
                    dtpApprovementDate.Value.ToString("yyyy-MM-dd"),
                    comboBoxStructuralUnit.SelectedValue.ToString(),
                    comboBoxApproved.SelectedItem.ToString());
                    MessageBox.Show("Изменены сведения о графике отпусков!");
                    DB_Connection.ShowVacationSchedules();
                    this.Close();
                }
                else MessageBox.Show("График отпусков для выбранного отдела уже сущестует");
            }
        }


        //СПРАВОЧНИК "ВИДЫ ОТПУСКОВ"
        //Настройка формы с полями ввода для добавления вида отпуска
        public void ShowVacationTypesTabToAdd()
        {
            AllTabsHide();
            tabPageVacationType.Parent = tabControlEmployeesVacationsEdit;
            tabPageVacationType.Text = "Добавление нового вида отпуска:";
        }

        //Настройка формы с полями ввода для редактирования вида отпуска
        public void ShowVacationTypesTabToChange()
        {
            AllTabsHide();
            tabPageVacationType.Parent = tabControlEmployeesVacationsEdit;
            tabPageVacationType.Text = "Редактирование вида отпуска:";
        }

        //отмена добавления или редактирования записи в справочнике "Виды отпусков"
        private void btnVacationTypeCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //заполнение поля для ввода изменяемым значением наименования отпуска
        public void VacationTypeImport(string VacationType, string paidDays, string unpaidDays)
        {
            textBoxVacationType.Text = VacationType;
            textBoxPaidDays.Text = paidDays;
            textBoxUnpaidDays.Text = unpaidDays;
        }

        //процедура добавления или редактирования записи в справочнике "Виды отпусков"
        private void btnVacationTypePost_Click(object sender, EventArgs e)
        {
            if (textBoxVacationType.Text == "" || textBoxPaidDays.Text == ""
                || textBoxUnpaidDays.Text == "")
            {
                MessageBox.Show("Необходимо указать наименование отпуска, количество" +
                    " оплачиваемых и неоплачиваемых дней отпуска!");
                return;
            }
            else
            {
                if (tabPageVacationType.Text == "Добавление нового вида отпуска:")
                {
                    if (DB_Connection.VacationTypeExists(textBoxVacationType.Text))
                    {
                        MessageBox.Show("Этот вид отпуска уже присутствует в справочнике!");
                        return;
                    }
                    else
                    {
                        DB_Connection.AddVacationType(textBoxVacationType.Text,
                            textBoxPaidDays.Text, textBoxUnpaidDays.Text);
                        MessageBox.Show("Вид отпуска добавлен в справичник!");
                        DB_Connection.ShowVacationTypes();
                        this.Close();
                    }
                }
                if (tabPageVacationType.Text == "Редактирование вида отпуска:")
                {
                    if (DB_Connection.VacationTypeExists(textBoxVacationType.Text) &&
                        textBoxVacationType.Text != EmployeesVacationsDetailForm.Vacation)
                    {
                        MessageBox.Show("Этот вид отпуска уже присутствует в справочнике!");
                        return;
                    }
                    else
                    {
                        DB_Connection.EditVacationType(EmployeesVacationsDetailForm.
                            NumberOfEditRecord, textBoxVacationType.Text,
                            textBoxPaidDays.Text, textBoxUnpaidDays.Text);
                        MessageBox.Show("Вид отпуска изменен!");
                        DB_Connection.ShowVacationTypes();
                        this.Close();
                    }
                }
            }
        }

        //ограничение числа возможных символов для ввода 
        //(для числа оплачиваемых дней отпуска - только цифры)
        private void textBoxPaidDays_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = "0123456789 \b ".IndexOf(e.KeyChar) < 0;
        }

        //ограничение числа возможных символов для ввода 
        //(для числа неоплачиваемых дней отпуска - только цифры)
        private void textBoxUnpaidDays_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((!Char.IsDigit(e.KeyChar)) && (e.KeyChar != 8)) e.Handled = true;
        }

        //процедура уменьшения числа оплачиваемых дней отпуска на 1
        private void btnPaidDaysMinus_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBoxPaidDays.Text != "0")
                    textBoxPaidDays.Text = (Convert.ToInt16(textBoxPaidDays.Text) - 1).ToString();
            }
            catch { textBoxPaidDays.Text = "0"; }
        }

        //процедура увеличения числа оплачиваемых дней отпуска на 1
        private void btnPaidDaysPlus_Click(object sender, EventArgs e)
        {
            try
            {
                textBoxPaidDays.Text = (Convert.ToInt16(textBoxPaidDays.Text) + 1).ToString();
            }
            catch { textBoxPaidDays.Text = "0"; }
        }

        //процедура уменьшения числа неоплачиваемых дней отпуска на 1
        private void btnUnpaidDaysMinus_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBoxUnpaidDays.Text != "0")
                    textBoxUnpaidDays.Text = (Convert.ToInt16(textBoxUnpaidDays.Text) - 1).ToString();
            }
            catch { textBoxUnpaidDays.Text = "0"; }
        }

        //процедура увеличения числа неоплачиваемых дней отпуска на 1
        private void btnUnpaidDaysPlus_Click(object sender, EventArgs e)
        {
            try
            {
                textBoxUnpaidDays.Text = (Convert.ToInt16(textBoxUnpaidDays.Text) + 1).ToString();
            }
            catch { textBoxUnpaidDays.Text = "0"; }
        }   


        //ТАБЛИЦА "РАСХОДОВАНИЕ ОТПУСКОВ"
        //Настройка формы с полями ввода для добавления сведений о расходовании отпуска
        public void ShowSpendingOfVacationsToAdd()
        {
            AllTabsHide();
            tabPageSpendingOfVacations.Parent = tabControlEmployeesVacationsEdit;
            tabPageSpendingOfVacations.Text = "Предоставление отпуска сотруднику:";
        }

        //Настройка формы с полями ввода для изменения сведений о расходовании отпуска
        public void ShowSpendingOfVacationsToChange()
        {
            AllTabsHide();
            tabPageSpendingOfVacations.Parent = tabControlEmployeesVacationsEdit;
            tabPageSpendingOfVacations.Text = "Изменение предоставленного сотруднику отпуска:";
        }

        //процедура уменьшения выбранного года на 1
        private void buttonYearMinus_Click(object sender, EventArgs e)
        {
            textBoxVacationYear.Text = (Convert.ToInt16(textBoxVacationYear.Text) - 1).ToString();
        }

        //процедура увеличения выбранного года на 1
        private void buttonPlus_Click(object sender, EventArgs e)
        {
            textBoxVacationYear.Text = (Convert.ToInt16(textBoxVacationYear.Text) + 1).ToString();
        }

        //процедура уменьшения числа дней отпуска на 1
        private void buttonVacationMinus_Click(object sender, EventArgs e)
        {
            textBoxVacationDays.Text = (Convert.ToInt16(textBoxVacationDays.Text) - 1).ToString();
        }

        //процедура увеличения числа дней отпуска на 1
        private void buttonVacationPlus_Click(object sender, EventArgs e)
        {
            textBoxVacationDays.Text = (Convert.ToInt16(textBoxVacationDays.Text) + 1).ToString();
            if (Convert.ToInt16(textBoxVacationDays.Text) > DaysLimit)
                textBoxVacationDays.Text = DaysLimit.ToString();
        }

        //автоматическая подстановка количества дней отпуска при выборе вида отпуска
        private void comboBoxTypeOfVacation_SelectedValueChanged(object sender, EventArgs e)
        {
            try
            {
                textBoxVacationDays.Text = DB_Connection.PaidDaysQuantitySearch
                    (comboBoxTypeOfVacation.SelectedValue.ToString());
                DaysLimit = Convert.ToInt16(textBoxVacationDays.Text);
            }
            catch { }
        }

        //отмена добавления или редактирования записи в таблице "Расходование отпусков"
        private void btnSpendingOfVacationCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //процедура добавления или редактирования записи в таблице "Расходование отпусков"
        private void btnSpendingOfVacationPost_Click(object sender, EventArgs e)
        {
            if (tabPageSpendingOfVacations.Text == "Предоставление отпуска сотруднику:")
            {
                if (comboBoxTypeOfVacation.Text != ""
                    && comboBoxVacationist.Text != "")
                {
                    if (!DB_Connection.SpendingOfVacationAlreadyExists
                        (textBoxVacationYear.Text,
                        comboBoxVacationist.SelectedValue.ToString(),
                        comboBoxTypeOfVacation.SelectedValue.ToString()))
                    {
                        //вносим запись в таблицу учета оставшихся дней отпуска для графика отпусков
                        DB_Connection.AddToSpendingOfVacations(comboBoxVacationist.SelectedValue.ToString(),
                        textBoxVacationYear.Text,
                        comboBoxTypeOfVacation.SelectedValue.ToString(),
                        DB_Connection.PaidDaysQuantitySearch(comboBoxTypeOfVacation.SelectedValue.ToString()),
                        textBoxVacationDays.Text);
                        //вносим запись в таблицу учета оставшихся дней отпуска для журнала ведения отпусков
                        DB_Connection.AddToRealVacationSpending(comboBoxVacationist.SelectedValue.ToString(),
                        textBoxVacationYear.Text,
                        comboBoxTypeOfVacation.SelectedValue.ToString(),
                        DB_Connection.PaidDaysQuantitySearch(comboBoxTypeOfVacation.SelectedValue.ToString()),
                        textBoxVacationDays.Text);
                        //выводим сведения о выполнении операции
                        MessageBox.Show("Сотруднику назначен отпуск!");
                        DB_Connection.ShowSpendingOfVacations();
                        this.Close();
                    }
                    else MessageBox.Show("Данный вид отпуска в указанном году уже назначен сотруднику!");
                }
                else MessageBox.Show("Для назначения отпуска сотруднику необходимо указать график отпусков, " +
                "сотрудника, и вид назначаемого отпуска!");
            }
            if (tabPageSpendingOfVacations.Text == "Изменение предоставленного сотруднику отпуска:")
            {
                if (comboBoxTypeOfVacation.Text != ""
                    && comboBoxVacationist.Text != "")
                {
                    if (!DB_Connection.SpendingOfVacationAlreadyExists
                           (textBoxVacationYear.Text,
                           comboBoxVacationist.SelectedValue.ToString(),
                           comboBoxTypeOfVacation.SelectedValue.ToString())
                           || (EmployeesVacationsDetailForm.Vacationist == comboBoxVacationist.Text 
                           && EmployeesVacationsDetailForm.vacationType == comboBoxTypeOfVacation.Text))
                    {
                        //изменяем запись в таблицу учета оставшихся дней отпуска для графика отпусков
                        DB_Connection.EditInSpendingOfVacations
                            (EmployeesVacationsDetailForm.NumberOfEditRecord,
                            comboBoxVacationist.SelectedValue.ToString(),
                            textBoxVacationYear.Text,
                            comboBoxTypeOfVacation.SelectedValue.ToString(),
                            DB_Connection.PaidDaysQuantitySearch
                            (comboBoxTypeOfVacation.SelectedValue.ToString()),
                            textBoxVacationDays.Text);
                        //изменяем запись в таблицу учета оставшихся дней отпуска для журнала ведения отпусков
                        string TheRecord =  DB_Connection.GetRealVacationSpendingRecordId
                            (comboBoxVacationist.SelectedValue.ToString(), 
                            comboBoxTypeOfVacation.SelectedValue.ToString());
                        DB_Connection.EditInRealVacationSpending(TheRecord,
                            comboBoxVacationist.SelectedValue.ToString(),
                            textBoxVacationYear.Text,
                            comboBoxTypeOfVacation.SelectedValue.ToString(),
                            DB_Connection.PaidDaysQuantitySearch
                            (comboBoxTypeOfVacation.SelectedValue.ToString()),
                            textBoxVacationDays.Text);
                        //выводим сведения о выполнении операции
                        MessageBox.Show("Назначенный отпуск изменен!");
                        DB_Connection.ShowSpendingOfVacations();
                        this.Close();
                    }
                    else MessageBox.Show("Данный вид отпуска в указанном году уже назначен сотруднику!");
                }
                else MessageBox.Show("Для изменения назначенного отпуска необходимо указать график отпусков, " +
                "сотрудника, и вид назначаемого отпуска!");
            }
        }

        
        //ТАБЛИЦА "ПЕРИОДЫ ПРЕДОСТАВЛЕНИЯ ОПЛАЧИВАЕМОГО ПРОЕЗДА" (ДОРОЖНЫЕ)
        //Настройка формы с полями ввода для добавления 
        //периода предоставления оплачиваемого отпуска сотруднику
        public void ShowEmployeesPaidTravelToAdd()
        {
            AllTabsHide();
            tabPageEmployeesPaidTravel.Parent = tabControlEmployeesVacationsEdit;
            tabPageEmployeesPaidTravel.Text = "Добавление нового периода:";
        }
        
        //Настройка формы с полями ввода для редактирования
        //периода предоставления оплачиваемого отпуска сотруднику
        public void ShowEmployeesPaidTravelToChange()
        {
            AllTabsHide();
            tabPageEmployeesPaidTravel.Parent = tabControlEmployeesVacationsEdit;
            tabPageEmployeesPaidTravel.Text = "Редактирование периода:";
        }

        //процедура заполнения полей ввода изменяемыми значениями
        public void EmployeesPaidTravelImport(string start, string finish)
        {
            dtpTransitStart.Value = Convert.ToDateTime(start);
            dtpTransitFinish.Value = Convert.ToDateTime(finish);
        }

        //отмена добавления или редактирования записи в таблице "Дорожные"
        private void btnEmployeesPaidTravelCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //процедура добавления или редактрования периода 
        //предоставления оплачиваемого отпуска сотруднику
        private void btnEmployeesPaidTravelPost_Click(object sender, EventArgs e)
        {
            if (tabPageEmployeesPaidTravel.Text == "Добавление нового периода:")
            {
                if (!DB_Connection.EmployeesPaidTravelAlreadyExists
                    (comboBoxTraveler.SelectedValue.ToString()))
                {
                    DB_Connection.AddEmployeesPaidTravel(comboBoxTraveler.SelectedValue.ToString(),
                        dtpTransitStart.Value.ToString("yyyy-MM-dd"),
                        dtpTransitFinish.Value.ToString("yyyy-MM-dd"));
                    MessageBox.Show("Указан период предоставления оплачиваемого проезда сотруднику!");
                    DB_Connection.ShowEmployeesPaidTravel();
                    this.Close();
                }
                else MessageBox.Show("Период предоставления оплачиваемого проезда для этого сотрудника уже указан!");
            }
            if (tabPageEmployeesPaidTravel.Text == "Редактирование периода:")
            {
                if (!DB_Connection.EmployeesPaidTravelAlreadyExists
                    (comboBoxTraveler.SelectedValue.ToString()) || comboBoxTraveler.SelectedValue.ToString() 
                    == EmployeesVacationsDetailForm.NumberOfEditRecord)
                {
                    DB_Connection.EditEmployeesPaidTravel(EmployeesVacationsDetailForm.NumberOfEditRecord,
                        comboBoxTraveler.SelectedValue.ToString(),
                        dtpTransitStart.Value.ToString("yyyy-MM-dd"),
                        dtpTransitFinish.Value.ToString("yyyy-MM-dd"));
                    MessageBox.Show("Период предоставления оплачиваемого проезда сотруднику изменен!");
                    DB_Connection.ShowEmployeesPaidTravel();
                    this.Close();
                }
                else MessageBox.Show("Период предоставления оплачиваемого проезда для этого сотрудника уже указан!");
            }
        }


        //ТАБЛИЦА "ЖУРНАЛ ВЕДЕНИЯ ОТПУСКОВ"
        //Настройка формы с полями ввода для добавления записи в таблицу "Журнал ведения отпусков"
        public void ShowVacationLogTabToAdd()
        {
            AllTabsHide();
            tabPageVacationLog.Parent = tabControlEmployeesVacationsEdit;
            tabPageVacationLog.Text = "Добавление записи в журнал ведения отпусков:";
        }
       
        //Настройка формы с полями ввода для редактирования записи в таблице "Журнал ведения отпусков"
        public void ShowVacationLogTabToChange()
        {
            AllTabsHide();
            tabPageVacationLog.Parent = tabControlEmployeesVacationsEdit;
            tabPageVacationLog.Text = "Редактирование записи в журнале ведения отпусков:";
        }

        //процедура расчета количества дней при изменении даты начала фактического отпуска
        private void dtpRealVacationStart_ValueChanged(object sender, EventArgs e)
        {
            if (dtpRealVacationStart.Value > dtpRealVacationFinish.Value)
                dtpRealVacationFinish.Value = dtpRealVacationStart.Value;
            else
            {
                CalculateRealRange();
            }
        }

        //процедура расчета количества дней при изменении даты окончания фактического отпуска
        private void dtpRealVacationFinish_ValueChanged(object sender, EventArgs e)
        {
            if (dtpRealVacationStart.Value > dtpRealVacationFinish.Value)
                dtpRealVacationStart.Value = dtpRealVacationFinish.Value;
            else
            {
                CalculateRealRange();
            } 
        }

        //процедура расчета количества дней отпуска и количество неотгулянных дней отпуска (фактический отпуск)
        void CalculateRealRange()
        {
            TimeSpan RealVacationTime = dtpRealVacationFinish.Value - dtpRealVacationStart.Value;
            string OldRealQuantity = textBoxRealDaysQuantity.Text;
            int RealHolidaysQuantity = DB_Connection.StateHolidaysInVacation
                (dtpRealVacationStart.Value.ToString("yyyy-MM-dd"),
                dtpRealVacationFinish.Value.ToString("yyyy-MM-dd"));

            textBoxRealDaysQuantity.Text = (RealVacationTime.Days + 1
                - RealHolidaysQuantity).ToString();
            textBoxRealDaysRemain.Text = (Convert.ToInt16(textBoxRealDaysRemain.Text) -
            Convert.ToInt16(textBoxRealDaysQuantity.Text) +
            Convert.ToInt16(OldRealQuantity)).ToString();

            if (Convert.ToInt16(textBoxRealDaysRemain.Text) < 0)
            {
                textBoxRealDaysRemain.ForeColor = Color.White;
                textBoxRealDaysRemain.BackColor = Color.Red;
            }
            else
            {
                textBoxRealDaysRemain.ForeColor = Color.Black;
                textBoxRealDaysRemain.BackColor = Color.WhiteSmoke;
            }
        }

        //процедура указания числа неиспользованных дней отпуска
        public void RealDaysBalanceImport(string realBalance)
        {
            textBoxRealDaysRemain.Text = (Convert.ToInt16(realBalance) -
                Convert.ToInt16(textBoxRealDaysQuantity.Text)).ToString();
        }

        //процедура корректировки указания числа 
        //неиспользованных дней отпуска при изменении записи
        public void CorrectiongRealDaysBalanceImport(string realUpBalance)
        {
            textBoxRealDaysRemain.Text = (Convert.ToInt16(textBoxRealDaysRemain.Text) +
                Convert.ToInt16(realUpBalance)).ToString();
        }
        
        //процедура отмены добавления или редактирования в таблице "Журнал ведения отпусков"
        private void btnVacationLogCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //процедура добавления или редактирования записи в таблице "Журнал ведения отпусков"
        private void btnVacationLogPost_Click(object sender, EventArgs e)
        {
            if (tabPageVacationLog.Text == "Добавление записи в журнал ведения отпусков:")
            {
                DB_Connection.AddToVacationLog(comboBoxRealPersonnel.SelectedValue.ToString(),
                    RealVacationLogConstructorForm.TheVacationSchedule,
                    dtpRealVacationStart.Value.ToString("yyyy-MM-dd"),
                    dtpRealVacationFinish.Value.ToString("yyyy-MM-dd"),
                    comboBoxRealVacationType.SelectedValue.ToString(),
                    textBoxRealDaysQuantity.Text);
                DB_Connection.CorrectingRealVacationSpending(
                    RealVacationLogConstructorForm.TheVacation,
                    textBoxRealDaysRemain.Text);
                MessageBox.Show("Сотруднику добавлен отпуск!");
                DB_Connection.ShowVacationLog
                    (RealVacationLogConstructorForm.TheVacationSchedule);
                DB_Connection.ShowEmployeeRealVacationsBalance
                    (comboBoxRealPersonnel.SelectedValue.ToString());
                this.Close();
            }
            if (tabPageVacationLog.Text == "Редактирование записи в журнале ведения отпусков:")
            {
                DB_Connection.CorrectingRealVacationSpending
                    (RealVacationLogConstructorForm.OldChangingRecord,
                    RealVacationLogConstructorForm.OldChangingDaysBalance.ToString());
                DB_Connection.DeleteFromVacationLog
                    (RealVacationLogConstructorForm.OldChangingEmployeesVacation);

                DB_Connection.AddToVacationLog(comboBoxRealPersonnel.SelectedValue.ToString(),
                    RealVacationLogConstructorForm.TheVacationSchedule,
                    dtpRealVacationStart.Value.ToString("yyyy-MM-dd"),
                    dtpRealVacationFinish.Value.ToString("yyyy-MM-dd"),
                    comboBoxRealVacationType.SelectedValue.ToString(),
                    textBoxRealDaysQuantity.Text);
                DB_Connection.CorrectingRealVacationSpending(
                    RealVacationLogConstructorForm.TheVacation,
                    textBoxRealDaysRemain.Text);
                MessageBox.Show("Отпуск сотрудника изменен!");
                DB_Connection.ShowVacationLog
                    (RealVacationLogConstructorForm.TheVacationSchedule);
                DB_Connection.ShowEmployeeRealVacationsBalance
                    (comboBoxRealPersonnel.SelectedValue.ToString());
                this.Close();
            }
        }
    }
}
