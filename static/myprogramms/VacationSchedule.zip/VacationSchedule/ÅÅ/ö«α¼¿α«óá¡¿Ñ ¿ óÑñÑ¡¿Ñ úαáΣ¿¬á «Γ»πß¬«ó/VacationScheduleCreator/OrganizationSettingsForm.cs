﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace VacationScheduleCreator
{
    public partial class OrganizationSettingsForm : Form
    {
        //класс формы для детального отображения организационных настроек
        public OrganizationSettingsForm()
        {
            InitializeComponent();
        }

        //процедура загрузки данных из таблиц БД
        private void OrganizationSettingsForm_Load(object sender, EventArgs e)
        {
            DB_Connection.ShowFunctions();
            dataGridViewFunctions.DataSource = DB_Connection.dtFunctions;
            DB_Connection.ShowHierarchyLevels();
            dataGridViewHierarchyLevels.DataSource = DB_Connection.dtHierarchyLevels;
            DB_Connection.ShowStateHolidaysList();
            dataGridViewStateHolidaysList.DataSource = DB_Connection.dtStateHolidaysList;
            DB_Connection.ShowCompanyInformation();
            dataGridViewCompanyInformation.DataSource = DB_Connection.dtCompanyInformation;
            DB_Connection.ShowPersonnelCategories();
            dataGridViewPersonnelCategories.DataSource = DB_Connection.dtPersonnelCategories;
            
            dataGridViewPersonnelCategories.Columns[0].Visible = false;
            dataGridViewHierarchyLevels.Columns[0].Visible = false;
            dataGridViewFunctions.Columns[0].Visible = false;
        }

        //процедура обновления данных в таблицах
        void RefreshData()
        {
            DB_Connection.ShowFunctions();
            DB_Connection.ShowHierarchyLevels();
            DB_Connection.ShowStateHolidaysList();
            DB_Connection.ShowCompanyInformation();
            DB_Connection.ShowPersonnelCategories();
        }

        //процедура настройки и показа формы для отображения списка выходных праздничных дней
        private void btnStateHolidaysList_Click(object sender, EventArgs e)
        {
            OrganizationSettingsDetailForm OrganizationSettingsDetail = new OrganizationSettingsDetailForm();
            OrganizationSettingsDetail.ShowStateHolidaysListTab();
            OrganizationSettingsDetail.WindowState = FormWindowState.Maximized;
            OrganizationSettingsDetail.ShowDialog();
            RefreshData();
        }

        //процедура настройки и показа формы для отображения перечня должностей
        private void btnFunctionsDetail_Click(object sender, EventArgs e)
        {
            OrganizationSettingsDetailForm OrganizationSettingsDetail = new OrganizationSettingsDetailForm();
            OrganizationSettingsDetail.ShowFunctionsTub();
            OrganizationSettingsDetail.WindowState = FormWindowState.Maximized;
            OrganizationSettingsDetail.ShowDialog();
            RefreshData();
        }

        //процедура настройки и показа формы для отображения перечня категорий персонала
        private void btnPersonnelCategoriesDetail_Click(object sender, EventArgs e)
        {
            OrganizationSettingsDetailForm OrganizationSettingsDetail = new OrganizationSettingsDetailForm();
            OrganizationSettingsDetail.ShowPersonnelCategoriesTab();
            OrganizationSettingsDetail.WindowState = FormWindowState.Maximized;
            OrganizationSettingsDetail.ShowDialog();
            RefreshData();
        }

        //процедура настройки и показа формы для отображения перечня уровней иерархии подразделений
        private void btnHierarchyLevelsDetail_Click(object sender, EventArgs e)
        {
            OrganizationSettingsDetailForm OrganizationSettingsDetail = new OrganizationSettingsDetailForm();
            OrganizationSettingsDetail.ShowHierearchyLevelsTab();
            OrganizationSettingsDetail.WindowState = FormWindowState.Maximized;
            OrganizationSettingsDetail.ShowDialog();
            RefreshData();
        }

        //процедура настройки и показа формы для отображения сведений о предприятии
        private void btnCompanyInformation_Click(object sender, EventArgs e)
        {
            OrganizationSettingsDetailForm OrganizationSettingsDetail = new OrganizationSettingsDetailForm();
            OrganizationSettingsDetail.ShowCompanyInformationTab();
            OrganizationSettingsDetail.WindowState = FormWindowState.Maximized;
            OrganizationSettingsDetail.ShowDialog();
            RefreshData();
        }
    }
}
