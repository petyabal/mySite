﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace VacationScheduleCreator
{
    //класс формы для детального отображения одной таблицы (справочник "Должности"\справочник
    //"Категории персонала"\справочник "Уровни иерархии подразделений"\справочник
    //"Список выходных праздничных дней в завсимости от выбора пользователя)
    public partial class OrganizationSettingsDetailForm : Form
    {
        public OrganizationSettingsDetailForm()
        {
            InitializeComponent();
        }
        
        //переменная хранит номер редактируемой записи для выполнения редактирования из других модулей
        static public string NumberOfEditRecord;
        //переменная хранит контрольное значение редактируемой даты
        static public string TheDate;

        //процедура скрытия всех вкладок
        public void HideAllTubs()
        {
            tabPageCompanyInformation.Parent = null;
            tabPageHierarchyLevels.Parent = null;
            tabPageFunctions.Parent = null;
            tabPagePersonnelCategories.Parent = null;
            tabPageStateHolidaysList.Parent = null;
        }

        //метод-диалог для подтверждения желания пользователя удалить выбранную запись
        bool UserAgree()
        {
            DialogResult dialogResult = new DialogResult();
            dialogResult = MessageBox.Show("Вы действительно хотите удалить выбранную запись?",
                "Удаление данных!", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes) return true;
            else return false;
        }

        //процедура загрузки данных из таблиц БД
        private void OrganizationSettingsDetailForm_Load(object sender, EventArgs e)
        {
            if (tabPageCompanyInformation.Parent == tabControlOrganizationSettings)
            {
                DB_Connection.ShowCompanyInformation();
                dataGridViewCompanyInformation.DataSource = DB_Connection.dtCompanyInformation;
            }
            if (tabPageHierarchyLevels.Parent == tabControlOrganizationSettings)
            {
                DB_Connection.ShowHierarchyLevels();
                dataGridViewHierarchyLevels.DataSource = DB_Connection.dtHierarchyLevels;
                dataGridViewHierarchyLevels.Columns[0].Visible = false;
                if (dataGridViewHierarchyLevels.RowCount != 0)
                dataGridViewHierarchyLevels.Rows[0].Cells[1].Selected = true;
            }
            if (tabPageFunctions.Parent == tabControlOrganizationSettings)
            {
                DB_Connection.ShowFunctions();
                dataGridViewFunctions.DataSource = DB_Connection.dtFunctions;
                dataGridViewFunctions.Columns[0].Visible = false;
                if (dataGridViewFunctions.RowCount != 0)
                dataGridViewFunctions.Rows[0].Cells[1].Selected = true;
            }
            if (tabPagePersonnelCategories.Parent == tabControlOrganizationSettings)
            {
                DB_Connection.ShowPersonnelCategories();
                dataGridViewPersonnelCategories.DataSource = DB_Connection.dtPersonnelCategories;
                dataGridViewPersonnelCategories.Columns[0].Visible = false;
                if (dataGridViewPersonnelCategories.RowCount != 0)
                dataGridViewPersonnelCategories.Rows[0].Cells[1].Selected = true;
            }
            if (tabPageStateHolidaysList.Parent == tabControlOrganizationSettings)
            {
                DB_Connection.ShowStateHolidaysList();
                dataGridViewStateHolidaysList.DataSource = DB_Connection.dtStateHolidaysList;
            }
        }
        
        
        //ТАБЛИЦА "СВЕДЕНИЯ О ПРЕДПРИЯТИИ"
        //процедура показа только одной вкладки ("Сведения о предприятии")
        public void ShowCompanyInformationTab()
        {
            HideAllTubs();
            tabPageCompanyInformation.Parent = tabControlOrganizationSettings;
        }

        //процедура открытия формы с полями ввода для редактирования данных в таблице "Сведения о предприятии"
        private void btnChangeInCompanyInformationList_Click(object sender, EventArgs e)
        {
            OrganizationSettingsEditForm OrganizationSettingsEdit = new OrganizationSettingsEditForm();
            OrganizationSettingsEdit.ShowCompanyInformationTab();
            OrganizationSettingsEdit.CompanyInformationImport(
                dataGridViewCompanyInformation.CurrentRow.Cells["Сокращенное наименование"].Value.ToString(),
                dataGridViewCompanyInformation.CurrentRow.Cells["ИНН"].Value.ToString(),
                dataGridViewCompanyInformation.CurrentRow.Cells["КПП"].Value.ToString(),
                dataGridViewCompanyInformation.CurrentRow.Cells["ОКПО"].Value.ToString(),
                dataGridViewCompanyInformation.CurrentRow.Cells["Полное наименование"].Value.ToString(),
                dataGridViewCompanyInformation.CurrentRow.Cells["Юридический адрес"].Value.ToString(),
                dataGridViewCompanyInformation.CurrentRow.Cells["Фактический адрес"].Value.ToString());
            OrganizationSettingsEdit.ShowDialog();
        }

        
        //СПРАВОЧНИК "УРОВНИ ИЕРАРХИИ ПОДРАЗДЕЛЕНИЙ"
        //процедура открытия формы с полями ввода для добавления в справочник "Уровни иерархии подразделений"
        private void btnAddToHierarchyLevelList_Click(object sender, EventArgs e)
        {
            OrganizationSettingsEditForm OrganizationSettingsEdit = new OrganizationSettingsEditForm();
            OrganizationSettingsEdit.ShowHierarchyLevelsTabToAdd();
            OrganizationSettingsEdit.ShowDialog();
        }
        
        //процедура показа только одной вкладки ("Уровни иерархии подразделений")
        public void ShowHierearchyLevelsTab()
        {
            HideAllTubs();
            tabPageHierarchyLevels.Parent = tabControlOrganizationSettings;
        }

        //процедура открытия формы с полями ввода для редактирования данных в справочнике "Уровни иерархии подразделений"
        private void btnChangeInHierarchyLevelList_Click(object sender, EventArgs e)
        {
            OrganizationSettingsEditForm OrganizationSettingsEdit = new OrganizationSettingsEditForm();
            OrganizationSettingsEdit.ShowHierarchyLevelsTabToChange();
            OrganizationSettingsEdit.HierarchyLevelImport(dataGridViewHierarchyLevels.
            CurrentRow.Cells[1].Value.ToString());
            NumberOfEditRecord = dataGridViewHierarchyLevels.CurrentRow.
                Cells["Hierarchy_level_id"].Value.ToString();
            OrganizationSettingsEdit.ShowDialog();
        }

        //процедура удаления записи из справочника "Уровни иерархии подразделений"
        private void btnDeleteFromHierarchyLevelList_Click(object sender, EventArgs e)
        {
            if (UserAgree())
            {
                if (!DB_Connection.HierarchyLevelInStructuralUnits(dataGridViewHierarchyLevels.
                    CurrentRow.Cells["Hierarchy_level_id"].Value.ToString()))
                {
                    DB_Connection.DeleteHierarchyLevel(dataGridViewHierarchyLevels.
                        CurrentRow.Cells["Hierarchy_level_id"].Value.ToString());
                    MessageBox.Show("Запись удалена!");
                    DB_Connection.ShowHierarchyLevels();
                }
                else MessageBox.Show("Перед удалением уровня иерархии необходимо удалить " +
                    "указания на этот уровень иерархии из перечня структурных подразделений!");
            }
        }


        //СПРАВОЧНИК "ДОЛЖНОСТИ"
        //процедура показа только одной вкладки ("Должности")
        public void ShowFunctionsTub()
        {
            HideAllTubs();
            tabPageFunctions.Parent = tabControlOrganizationSettings;
        }
        
        //процедура открытия формы с полями ввода для добавления в справочник "Должности"
        private void btnAddToFunctionsList_Click(object sender, EventArgs e)
        {
            OrganizationSettingsEditForm OrganizationSettingsEdit = new OrganizationSettingsEditForm();
            OrganizationSettingsEdit.ShowFunctionsTabToAdd();
            OrganizationSettingsEdit.ShowDialog();
        }

        //процедура открытия формы с полями ввода для редактирования данных в справочнике "Должности"
        private void btnChangeInFunctionsList_Click(object sender, EventArgs e)
        {
            OrganizationSettingsEditForm OrganizationSettingsEdit = new OrganizationSettingsEditForm();
            OrganizationSettingsEdit.ShowFunctionsTabToChange();
            OrganizationSettingsEdit.FunctionImport(dataGridViewFunctions.
                CurrentRow.Cells[1].Value.ToString());
            NumberOfEditRecord = dataGridViewFunctions.CurrentRow.Cells["Function_id"].Value.ToString();
            OrganizationSettingsEdit.ShowDialog();
        }

        //процедура удаления записи из справочника "Должности"
        private void btnDeleteFromFunctionsList_Click(object sender, EventArgs e)
        {
            if (UserAgree())
            {
                if (!DB_Connection.FunctionInStaffingTable(dataGridViewFunctions.CurrentRow.
                        Cells["Function_id"].Value.ToString()))
                {
                    DB_Connection.DeleteFunction(dataGridViewFunctions.CurrentRow.
                       Cells["Function_id"].Value.ToString());
                    MessageBox.Show("Запись удалена!");
                    DB_Connection.ShowFunctions();                   
                }
                else
                {
                    MessageBox.Show("Перед удалением должности из справочника необходимо "
                     + "удалить указания на эту должность из штатого расписания!");
                }
            }
        }


        //СПРАВОЧНИК "КАТЕГОРИИ ПЕРСОНАЛА"
        //процедура показа только одной вкладки ("Категории персонала")
        public void ShowPersonnelCategoriesTab()
        {
            HideAllTubs();
            tabPagePersonnelCategories.Parent = tabControlOrganizationSettings;
        }

        //процедура открытия формы с полями ввода для добавления в справочник "Категории персонала"
        private void btnAddToPersonnelCategoryList_Click(object sender, EventArgs e)
        {
            OrganizationSettingsEditForm OrganizationSettingsEdit = new OrganizationSettingsEditForm();
            OrganizationSettingsEdit.ShowPersonnelCategoriesTabToAdd();
            OrganizationSettingsEdit.ShowDialog();
        }

        //процедура открытия формы с полями ввода для редактирования данных в справочнике "Категории персонала"
        private void btnChangeInPersonnelCategoryList_Click(object sender, EventArgs e)
        {
            OrganizationSettingsEditForm OrganizationSettingsEdit = new OrganizationSettingsEditForm();
            OrganizationSettingsEdit.ShowPersonnelCategoriesTabToChange();
            OrganizationSettingsEdit.PersonnelCategoryImport(dataGridViewPersonnelCategories.
                    CurrentRow.Cells[1].Value.ToString(), dataGridViewPersonnelCategories.
                    CurrentRow.Cells[2].Value.ToString());
            NumberOfEditRecord = dataGridViewPersonnelCategories.CurrentRow.Cells["Category_id"].Value.ToString();
            OrganizationSettingsEdit.ShowDialog();
        }

        //процедура удаления записи из справочника "Категории персонала"
        private void btnDeleteFromPersonnelCategoryList_Click(object sender, EventArgs e)
        {
            if (UserAgree())
            {
                if (!DB_Connection.PersonnelCategoryInStaffingTable(dataGridViewPersonnelCategories.
                    CurrentRow.Cells["Category_id"].Value.ToString()))
                {
                    DB_Connection.DeletePersonnelCategory(dataGridViewPersonnelCategories.
                        CurrentRow.Cells["Category_id"].Value.ToString());
                    MessageBox.Show("Запись удалена!");
                    DB_Connection.ShowPersonnelCategories();
                }
                else MessageBox.Show("Перед удалением категории персонала из справочника" 
                + "необходимо удалить все ссылки на эту категорию пермсонала из штатного расписания!");
            }
        }


        //СПРАВОЧНИК "СПИСОК ВЫХОДНЫХ ПРАЗДНЕЧНЫХ ДНЕЙ"
        //процедура показа только одной вкладки ("Список выходных праздничных дней")
        public void ShowStateHolidaysListTab()
        {
            HideAllTubs();
            tabPageStateHolidaysList.Parent = tabControlOrganizationSettings;
        }

        //процедура открытия формы с полями ввода для добавления в справочник "Список выходных праздничных дней"
        private void btnAddToStateHolidaysList_Click(object sender, EventArgs e)
        {
            OrganizationSettingsEditForm OrganizationSettingsEdit = new OrganizationSettingsEditForm();
            OrganizationSettingsEdit.ShowStateHolidaysListTabToAdd();
            OrganizationSettingsEdit.ShowDialog();
        }

        //процедура открытия формы с полями ввода для редактирования данных 
        //в справочнике "Список выходных праздничных дней"
        private void ChangeInStateHolidaysList_Click(object sender, EventArgs e)
        {
            OrganizationSettingsEditForm OrganizationSettingsEdit = new OrganizationSettingsEditForm();
            OrganizationSettingsEdit.ShowStateHolidaysListTabToChange();
            OrganizationSettingsEdit.StateHolidayImport(dataGridViewStateHolidaysList.
                CurrentRow.Cells[0].Value.ToString(), dataGridViewStateHolidaysList.
                CurrentRow.Cells[1].Value.ToString());
            TheDate = dataGridViewStateHolidaysList.CurrentRow.Cells["Дата"].Value.ToString();
            OrganizationSettingsEdit.ShowDialog();
        }
        
        //процедура удаления записи из справочника "Список выходных праздничных дней"
        private void DeleteFromStateHolidaysList_Click(object sender, EventArgs e)
        {
            if (UserAgree())
            {
                TheDate = dataGridViewStateHolidaysList.CurrentRow.Cells["Дата"].Value.ToString();
                DB_Connection.DeleteStateHoliday(Convert.ToDateTime(TheDate).ToString("yyyy-MM-dd"));
                MessageBox.Show("Запись удалена!");
                DB_Connection.ShowStateHolidaysList();
            }
        }
    }
}
