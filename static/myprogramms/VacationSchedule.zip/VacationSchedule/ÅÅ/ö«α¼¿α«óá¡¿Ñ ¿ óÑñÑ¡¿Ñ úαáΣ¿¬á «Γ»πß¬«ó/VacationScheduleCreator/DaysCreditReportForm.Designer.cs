﻿namespace VacationScheduleCreator
{
    partial class DaysCreditReportForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DaysCreditReportForm));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tableLayoutPanel_AllForm = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel_Company = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBoxCompany = new System.Windows.Forms.PictureBox();
            this.lblCompany = new System.Windows.Forms.Label();
            this.tableLayoutPanel_Employees = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel_Working_field = new System.Windows.Forms.TableLayoutPanel();
            this.groupBoxVacationSchedules = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanelVacationSchedules = new System.Windows.Forms.TableLayoutPanel();
            this.dataGridViewVacationSchedules = new System.Windows.Forms.DataGridView();
            this.labelVacationSchedules = new System.Windows.Forms.Label();
            this.groupBoxDaysCreditReport = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanelDaysCreditReport = new System.Windows.Forms.TableLayoutPanel();
            this.dataGridViewDaysCreditReport = new System.Windows.Forms.DataGridView();
            this.btnDaysCreditReportCreate = new System.Windows.Forms.Button();
            this.groupBoxReportArguments = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanelReportArguments = new System.Windows.Forms.TableLayoutPanel();
            this.lblReportDate = new System.Windows.Forms.Label();
            this.lblReportTime = new System.Windows.Forms.Label();
            this.lblSortingArgument = new System.Windows.Forms.Label();
            this.lblSortingDirection = new System.Windows.Forms.Label();
            this.lblReportDayteValue = new System.Windows.Forms.Label();
            this.lblReportTimeValue = new System.Windows.Forms.Label();
            this.comboBoxSortingArgumentValue = new System.Windows.Forms.ComboBox();
            this.comboBoxCortingDirectionValue = new System.Windows.Forms.ComboBox();
            this.tableLayoutPanel_WindowHeader = new System.Windows.Forms.TableLayoutPanel();
            this.lblDaysCreditReport = new System.Windows.Forms.Label();
            this.tableLayoutPanel_Programm = new System.Windows.Forms.TableLayoutPanel();
            this.lblProgramm = new System.Windows.Forms.Label();
            this.tableLayoutPanel_AllForm.SuspendLayout();
            this.tableLayoutPanel_Company.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCompany)).BeginInit();
            this.tableLayoutPanel_Employees.SuspendLayout();
            this.tableLayoutPanel_Working_field.SuspendLayout();
            this.groupBoxVacationSchedules.SuspendLayout();
            this.tableLayoutPanelVacationSchedules.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVacationSchedules)).BeginInit();
            this.groupBoxDaysCreditReport.SuspendLayout();
            this.tableLayoutPanelDaysCreditReport.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDaysCreditReport)).BeginInit();
            this.groupBoxReportArguments.SuspendLayout();
            this.tableLayoutPanelReportArguments.SuspendLayout();
            this.tableLayoutPanel_WindowHeader.SuspendLayout();
            this.tableLayoutPanel_Programm.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel_AllForm
            // 
            this.tableLayoutPanel_AllForm.ColumnCount = 1;
            this.tableLayoutPanel_AllForm.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_AllForm.Controls.Add(this.tableLayoutPanel_Company, 0, 1);
            this.tableLayoutPanel_AllForm.Controls.Add(this.tableLayoutPanel_Employees, 0, 2);
            this.tableLayoutPanel_AllForm.Controls.Add(this.tableLayoutPanel_Programm, 0, 0);
            this.tableLayoutPanel_AllForm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_AllForm.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel_AllForm.Name = "tableLayoutPanel_AllForm";
            this.tableLayoutPanel_AllForm.RowCount = 3;
            this.tableLayoutPanel_AllForm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel_AllForm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tableLayoutPanel_AllForm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 75F));
            this.tableLayoutPanel_AllForm.Size = new System.Drawing.Size(784, 497);
            this.tableLayoutPanel_AllForm.TabIndex = 10;
            // 
            // tableLayoutPanel_Company
            // 
            this.tableLayoutPanel_Company.BackColor = System.Drawing.SystemColors.HotTrack;
            this.tableLayoutPanel_Company.ColumnCount = 2;
            this.tableLayoutPanel_Company.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel_Company.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.tableLayoutPanel_Company.Controls.Add(this.pictureBoxCompany, 0, 1);
            this.tableLayoutPanel_Company.Controls.Add(this.lblCompany, 1, 1);
            this.tableLayoutPanel_Company.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Company.Location = new System.Drawing.Point(3, 52);
            this.tableLayoutPanel_Company.Name = "tableLayoutPanel_Company";
            this.tableLayoutPanel_Company.RowCount = 3;
            this.tableLayoutPanel_Company.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel_Company.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tableLayoutPanel_Company.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel_Company.Size = new System.Drawing.Size(778, 68);
            this.tableLayoutPanel_Company.TabIndex = 7;
            // 
            // pictureBoxCompany
            // 
            this.pictureBoxCompany.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxCompany.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxCompany.Image")));
            this.pictureBoxCompany.Location = new System.Drawing.Point(3, 6);
            this.pictureBoxCompany.Name = "pictureBoxCompany";
            this.pictureBoxCompany.Size = new System.Drawing.Size(227, 55);
            this.pictureBoxCompany.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxCompany.TabIndex = 3;
            this.pictureBoxCompany.TabStop = false;
            // 
            // lblCompany
            // 
            this.lblCompany.AutoSize = true;
            this.lblCompany.BackColor = System.Drawing.SystemColors.HotTrack;
            this.lblCompany.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCompany.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblCompany.ForeColor = System.Drawing.Color.White;
            this.lblCompany.Location = new System.Drawing.Point(236, 3);
            this.lblCompany.Name = "lblCompany";
            this.lblCompany.Size = new System.Drawing.Size(539, 61);
            this.lblCompany.TabIndex = 2;
            this.lblCompany.Text = "МЕЖРЕГИОНАЛЬНАЯ РАСПРЕДЕЛИТЕЛЬНАЯ СЕТЕВАЯ КОМПАНИЯ СЕВЕРО-ЗАПАДА";
            this.lblCompany.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel_Employees
            // 
            this.tableLayoutPanel_Employees.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPanel_Employees.ColumnCount = 1;
            this.tableLayoutPanel_Employees.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_Employees.Controls.Add(this.tableLayoutPanel_Working_field, 0, 1);
            this.tableLayoutPanel_Employees.Controls.Add(this.tableLayoutPanel_WindowHeader, 0, 0);
            this.tableLayoutPanel_Employees.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Employees.Location = new System.Drawing.Point(3, 126);
            this.tableLayoutPanel_Employees.Name = "tableLayoutPanel_Employees";
            this.tableLayoutPanel_Employees.RowCount = 2;
            this.tableLayoutPanel_Employees.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12F));
            this.tableLayoutPanel_Employees.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 88F));
            this.tableLayoutPanel_Employees.Size = new System.Drawing.Size(778, 368);
            this.tableLayoutPanel_Employees.TabIndex = 6;
            // 
            // tableLayoutPanel_Working_field
            // 
            this.tableLayoutPanel_Working_field.ColumnCount = 2;
            this.tableLayoutPanel_Working_field.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel_Working_field.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.tableLayoutPanel_Working_field.Controls.Add(this.groupBoxVacationSchedules, 0, 0);
            this.tableLayoutPanel_Working_field.Controls.Add(this.groupBoxDaysCreditReport, 1, 0);
            this.tableLayoutPanel_Working_field.Controls.Add(this.groupBoxReportArguments, 0, 1);
            this.tableLayoutPanel_Working_field.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Working_field.Location = new System.Drawing.Point(3, 44);
            this.tableLayoutPanel_Working_field.Margin = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.tableLayoutPanel_Working_field.Name = "tableLayoutPanel_Working_field";
            this.tableLayoutPanel_Working_field.RowCount = 2;
            this.tableLayoutPanel_Working_field.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Working_field.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Working_field.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel_Working_field.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel_Working_field.Size = new System.Drawing.Size(772, 321);
            this.tableLayoutPanel_Working_field.TabIndex = 7;
            // 
            // groupBoxVacationSchedules
            // 
            this.groupBoxVacationSchedules.Controls.Add(this.tableLayoutPanelVacationSchedules);
            this.groupBoxVacationSchedules.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxVacationSchedules.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBoxVacationSchedules.ForeColor = System.Drawing.Color.White;
            this.groupBoxVacationSchedules.Location = new System.Drawing.Point(3, 3);
            this.groupBoxVacationSchedules.Name = "groupBoxVacationSchedules";
            this.groupBoxVacationSchedules.Size = new System.Drawing.Size(225, 154);
            this.groupBoxVacationSchedules.TabIndex = 1;
            this.groupBoxVacationSchedules.TabStop = false;
            this.groupBoxVacationSchedules.Text = "Выберите график отпусков:";
            // 
            // tableLayoutPanelVacationSchedules
            // 
            this.tableLayoutPanelVacationSchedules.ColumnCount = 1;
            this.tableLayoutPanelVacationSchedules.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelVacationSchedules.Controls.Add(this.dataGridViewVacationSchedules, 0, 0);
            this.tableLayoutPanelVacationSchedules.Controls.Add(this.labelVacationSchedules, 0, 1);
            this.tableLayoutPanelVacationSchedules.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelVacationSchedules.Location = new System.Drawing.Point(3, 25);
            this.tableLayoutPanelVacationSchedules.Name = "tableLayoutPanelVacationSchedules";
            this.tableLayoutPanelVacationSchedules.RowCount = 2;
            this.tableLayoutPanelVacationSchedules.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 87.5F));
            this.tableLayoutPanelVacationSchedules.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanelVacationSchedules.Size = new System.Drawing.Size(219, 126);
            this.tableLayoutPanelVacationSchedules.TabIndex = 0;
            // 
            // dataGridViewVacationSchedules
            // 
            this.dataGridViewVacationSchedules.AllowUserToAddRows = false;
            this.dataGridViewVacationSchedules.AllowUserToDeleteRows = false;
            this.dataGridViewVacationSchedules.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewVacationSchedules.DefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewVacationSchedules.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewVacationSchedules.Location = new System.Drawing.Point(3, 3);
            this.dataGridViewVacationSchedules.MultiSelect = false;
            this.dataGridViewVacationSchedules.Name = "dataGridViewVacationSchedules";
            this.dataGridViewVacationSchedules.ReadOnly = true;
            this.dataGridViewVacationSchedules.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewVacationSchedules.Size = new System.Drawing.Size(213, 104);
            this.dataGridViewVacationSchedules.TabIndex = 0;
            // 
            // labelVacationSchedules
            // 
            this.labelVacationSchedules.AutoSize = true;
            this.labelVacationSchedules.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelVacationSchedules.Location = new System.Drawing.Point(3, 110);
            this.labelVacationSchedules.Name = "labelVacationSchedules";
            this.labelVacationSchedules.Size = new System.Drawing.Size(213, 16);
            this.labelVacationSchedules.TabIndex = 1;
            this.labelVacationSchedules.Text = "для форирования отчета";
            // 
            // groupBoxDaysCreditReport
            // 
            this.groupBoxDaysCreditReport.Controls.Add(this.tableLayoutPanelDaysCreditReport);
            this.groupBoxDaysCreditReport.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxDaysCreditReport.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBoxDaysCreditReport.ForeColor = System.Drawing.Color.White;
            this.groupBoxDaysCreditReport.Location = new System.Drawing.Point(234, 3);
            this.groupBoxDaysCreditReport.Name = "groupBoxDaysCreditReport";
            this.tableLayoutPanel_Working_field.SetRowSpan(this.groupBoxDaysCreditReport, 2);
            this.groupBoxDaysCreditReport.Size = new System.Drawing.Size(535, 315);
            this.groupBoxDaysCreditReport.TabIndex = 2;
            this.groupBoxDaysCreditReport.TabStop = false;
            this.groupBoxDaysCreditReport.Text = "Список сотрудников, взявших дни в счет будущего отпуска:";
            // 
            // tableLayoutPanelDaysCreditReport
            // 
            this.tableLayoutPanelDaysCreditReport.ColumnCount = 1;
            this.tableLayoutPanelDaysCreditReport.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelDaysCreditReport.Controls.Add(this.dataGridViewDaysCreditReport, 0, 0);
            this.tableLayoutPanelDaysCreditReport.Controls.Add(this.btnDaysCreditReportCreate, 0, 1);
            this.tableLayoutPanelDaysCreditReport.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelDaysCreditReport.Location = new System.Drawing.Point(3, 25);
            this.tableLayoutPanelDaysCreditReport.Name = "tableLayoutPanelDaysCreditReport";
            this.tableLayoutPanelDaysCreditReport.RowCount = 2;
            this.tableLayoutPanelDaysCreditReport.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 88F));
            this.tableLayoutPanelDaysCreditReport.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12F));
            this.tableLayoutPanelDaysCreditReport.Size = new System.Drawing.Size(529, 287);
            this.tableLayoutPanelDaysCreditReport.TabIndex = 0;
            // 
            // dataGridViewDaysCreditReport
            // 
            this.dataGridViewDaysCreditReport.AllowUserToAddRows = false;
            this.dataGridViewDaysCreditReport.AllowUserToDeleteRows = false;
            this.dataGridViewDaysCreditReport.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewDaysCreditReport.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewDaysCreditReport.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewDaysCreditReport.Location = new System.Drawing.Point(3, 3);
            this.dataGridViewDaysCreditReport.MultiSelect = false;
            this.dataGridViewDaysCreditReport.Name = "dataGridViewDaysCreditReport";
            this.dataGridViewDaysCreditReport.ReadOnly = true;
            this.dataGridViewDaysCreditReport.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewDaysCreditReport.Size = new System.Drawing.Size(523, 246);
            this.dataGridViewDaysCreditReport.TabIndex = 0;
            // 
            // btnDaysCreditReportCreate
            // 
            this.btnDaysCreditReportCreate.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnDaysCreditReportCreate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnDaysCreditReportCreate.Location = new System.Drawing.Point(3, 255);
            this.btnDaysCreditReportCreate.Name = "btnDaysCreditReportCreate";
            this.btnDaysCreditReportCreate.Size = new System.Drawing.Size(523, 29);
            this.btnDaysCreditReportCreate.TabIndex = 1;
            this.btnDaysCreditReportCreate.Text = "Сформировать отчет";
            this.btnDaysCreditReportCreate.UseVisualStyleBackColor = false;
            // 
            // groupBoxReportArguments
            // 
            this.groupBoxReportArguments.Controls.Add(this.tableLayoutPanelReportArguments);
            this.groupBoxReportArguments.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxReportArguments.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBoxReportArguments.ForeColor = System.Drawing.Color.White;
            this.groupBoxReportArguments.Location = new System.Drawing.Point(3, 163);
            this.groupBoxReportArguments.Name = "groupBoxReportArguments";
            this.groupBoxReportArguments.Size = new System.Drawing.Size(225, 155);
            this.groupBoxReportArguments.TabIndex = 3;
            this.groupBoxReportArguments.TabStop = false;
            this.groupBoxReportArguments.Text = "Параметры отчета:";
            // 
            // tableLayoutPanelReportArguments
            // 
            this.tableLayoutPanelReportArguments.ColumnCount = 2;
            this.tableLayoutPanelReportArguments.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelReportArguments.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelReportArguments.Controls.Add(this.lblReportDate, 0, 0);
            this.tableLayoutPanelReportArguments.Controls.Add(this.lblReportTime, 0, 1);
            this.tableLayoutPanelReportArguments.Controls.Add(this.lblSortingArgument, 0, 2);
            this.tableLayoutPanelReportArguments.Controls.Add(this.lblSortingDirection, 0, 3);
            this.tableLayoutPanelReportArguments.Controls.Add(this.lblReportDayteValue, 1, 0);
            this.tableLayoutPanelReportArguments.Controls.Add(this.lblReportTimeValue, 1, 1);
            this.tableLayoutPanelReportArguments.Controls.Add(this.comboBoxSortingArgumentValue, 1, 2);
            this.tableLayoutPanelReportArguments.Controls.Add(this.comboBoxCortingDirectionValue, 1, 3);
            this.tableLayoutPanelReportArguments.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelReportArguments.Location = new System.Drawing.Point(3, 25);
            this.tableLayoutPanelReportArguments.Name = "tableLayoutPanelReportArguments";
            this.tableLayoutPanelReportArguments.RowCount = 4;
            this.tableLayoutPanelReportArguments.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanelReportArguments.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanelReportArguments.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanelReportArguments.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanelReportArguments.Size = new System.Drawing.Size(219, 127);
            this.tableLayoutPanelReportArguments.TabIndex = 0;
            // 
            // lblReportDate
            // 
            this.lblReportDate.AutoSize = true;
            this.lblReportDate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblReportDate.Location = new System.Drawing.Point(3, 0);
            this.lblReportDate.Name = "lblReportDate";
            this.lblReportDate.Size = new System.Drawing.Size(103, 31);
            this.lblReportDate.TabIndex = 0;
            this.lblReportDate.Text = "Дата отчета:";
            this.lblReportDate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblReportTime
            // 
            this.lblReportTime.AutoSize = true;
            this.lblReportTime.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblReportTime.Location = new System.Drawing.Point(3, 31);
            this.lblReportTime.Name = "lblReportTime";
            this.lblReportTime.Size = new System.Drawing.Size(103, 31);
            this.lblReportTime.TabIndex = 1;
            this.lblReportTime.Text = "Время отчета:";
            this.lblReportTime.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblSortingArgument
            // 
            this.lblSortingArgument.AutoSize = true;
            this.lblSortingArgument.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblSortingArgument.Location = new System.Drawing.Point(3, 62);
            this.lblSortingArgument.Name = "lblSortingArgument";
            this.lblSortingArgument.Size = new System.Drawing.Size(103, 31);
            this.lblSortingArgument.TabIndex = 2;
            this.lblSortingArgument.Text = "Сортировать:";
            this.lblSortingArgument.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblSortingDirection
            // 
            this.lblSortingDirection.AutoSize = true;
            this.lblSortingDirection.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblSortingDirection.Location = new System.Drawing.Point(3, 93);
            this.lblSortingDirection.Name = "lblSortingDirection";
            this.lblSortingDirection.Size = new System.Drawing.Size(103, 34);
            this.lblSortingDirection.TabIndex = 3;
            this.lblSortingDirection.Text = "Сортировка по:";
            this.lblSortingDirection.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblReportDayteValue
            // 
            this.lblReportDayteValue.AutoSize = true;
            this.lblReportDayteValue.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblReportDayteValue.Location = new System.Drawing.Point(112, 0);
            this.lblReportDayteValue.Name = "lblReportDayteValue";
            this.lblReportDayteValue.Size = new System.Drawing.Size(104, 31);
            this.lblReportDayteValue.TabIndex = 4;
            this.lblReportDayteValue.Text = "текущая";
            this.lblReportDayteValue.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblReportTimeValue
            // 
            this.lblReportTimeValue.AutoSize = true;
            this.lblReportTimeValue.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblReportTimeValue.Location = new System.Drawing.Point(112, 31);
            this.lblReportTimeValue.Name = "lblReportTimeValue";
            this.lblReportTimeValue.Size = new System.Drawing.Size(104, 31);
            this.lblReportTimeValue.TabIndex = 5;
            this.lblReportTimeValue.Text = "текущее";
            this.lblReportTimeValue.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // comboBoxSortingArgumentValue
            // 
            this.comboBoxSortingArgumentValue.FormattingEnabled = true;
            this.comboBoxSortingArgumentValue.Items.AddRange(new object[] {
            "по ФИО",
            "по числу дней"});
            this.comboBoxSortingArgumentValue.Location = new System.Drawing.Point(112, 65);
            this.comboBoxSortingArgumentValue.Name = "comboBoxSortingArgumentValue";
            this.comboBoxSortingArgumentValue.Size = new System.Drawing.Size(104, 31);
            this.comboBoxSortingArgumentValue.TabIndex = 6;
            // 
            // comboBoxCortingDirectionValue
            // 
            this.comboBoxCortingDirectionValue.FormattingEnabled = true;
            this.comboBoxCortingDirectionValue.Items.AddRange(new object[] {
            "возрастанию",
            "убыванию"});
            this.comboBoxCortingDirectionValue.Location = new System.Drawing.Point(112, 96);
            this.comboBoxCortingDirectionValue.Name = "comboBoxCortingDirectionValue";
            this.comboBoxCortingDirectionValue.Size = new System.Drawing.Size(104, 31);
            this.comboBoxCortingDirectionValue.TabIndex = 7;
            // 
            // tableLayoutPanel_WindowHeader
            // 
            this.tableLayoutPanel_WindowHeader.ColumnCount = 4;
            this.tableLayoutPanel_WindowHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_WindowHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_WindowHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_WindowHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_WindowHeader.Controls.Add(this.lblDaysCreditReport, 0, 0);
            this.tableLayoutPanel_WindowHeader.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_WindowHeader.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel_WindowHeader.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.tableLayoutPanel_WindowHeader.Name = "tableLayoutPanel_WindowHeader";
            this.tableLayoutPanel_WindowHeader.RowCount = 1;
            this.tableLayoutPanel_WindowHeader.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_WindowHeader.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 41F));
            this.tableLayoutPanel_WindowHeader.Size = new System.Drawing.Size(772, 41);
            this.tableLayoutPanel_WindowHeader.TabIndex = 6;
            // 
            // lblDaysCreditReport
            // 
            this.lblDaysCreditReport.AutoSize = true;
            this.tableLayoutPanel_WindowHeader.SetColumnSpan(this.lblDaysCreditReport, 4);
            this.lblDaysCreditReport.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblDaysCreditReport.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblDaysCreditReport.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblDaysCreditReport.Location = new System.Drawing.Point(3, 0);
            this.lblDaysCreditReport.Name = "lblDaysCreditReport";
            this.lblDaysCreditReport.Size = new System.Drawing.Size(766, 41);
            this.lblDaysCreditReport.TabIndex = 19;
            this.lblDaysCreditReport.Text = "СОЗДАНИЕ ОТЧЕТА (СПИСОК СОТРУДНИКОВ, ВЗЯВШИХ ДНИ В СЧЕТ БУДУЩЕГО ОТПУСКА)";
            this.lblDaysCreditReport.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel_Programm
            // 
            this.tableLayoutPanel_Programm.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPanel_Programm.ColumnCount = 1;
            this.tableLayoutPanel_Programm.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Programm.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Programm.Controls.Add(this.lblProgramm, 0, 0);
            this.tableLayoutPanel_Programm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Programm.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel_Programm.Name = "tableLayoutPanel_Programm";
            this.tableLayoutPanel_Programm.RowCount = 1;
            this.tableLayoutPanel_Programm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Programm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Programm.Size = new System.Drawing.Size(778, 43);
            this.tableLayoutPanel_Programm.TabIndex = 8;
            // 
            // lblProgramm
            // 
            this.lblProgramm.AutoSize = true;
            this.lblProgramm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblProgramm.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblProgramm.ForeColor = System.Drawing.Color.White;
            this.lblProgramm.Location = new System.Drawing.Point(3, 0);
            this.lblProgramm.Name = "lblProgramm";
            this.lblProgramm.Size = new System.Drawing.Size(772, 43);
            this.lblProgramm.TabIndex = 0;
            this.lblProgramm.Text = "ФОРМИРОВАНИЕ И ВЕДЕНИЕ ГРАФИКА ОТПУСКОВ СОТРУДНИКОВ";
            this.lblProgramm.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // DaysCreditReportForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 497);
            this.Controls.Add(this.tableLayoutPanel_AllForm);
            this.Name = "DaysCreditReportForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DaysCreditReportForm";
            this.Load += new System.EventHandler(this.DaysCreditReportForm_Load);
            this.tableLayoutPanel_AllForm.ResumeLayout(false);
            this.tableLayoutPanel_Company.ResumeLayout(false);
            this.tableLayoutPanel_Company.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCompany)).EndInit();
            this.tableLayoutPanel_Employees.ResumeLayout(false);
            this.tableLayoutPanel_Working_field.ResumeLayout(false);
            this.groupBoxVacationSchedules.ResumeLayout(false);
            this.tableLayoutPanelVacationSchedules.ResumeLayout(false);
            this.tableLayoutPanelVacationSchedules.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVacationSchedules)).EndInit();
            this.groupBoxDaysCreditReport.ResumeLayout(false);
            this.tableLayoutPanelDaysCreditReport.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDaysCreditReport)).EndInit();
            this.groupBoxReportArguments.ResumeLayout(false);
            this.tableLayoutPanelReportArguments.ResumeLayout(false);
            this.tableLayoutPanelReportArguments.PerformLayout();
            this.tableLayoutPanel_WindowHeader.ResumeLayout(false);
            this.tableLayoutPanel_WindowHeader.PerformLayout();
            this.tableLayoutPanel_Programm.ResumeLayout(false);
            this.tableLayoutPanel_Programm.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_AllForm;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Company;
        private System.Windows.Forms.PictureBox pictureBoxCompany;
        private System.Windows.Forms.Label lblCompany;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Employees;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Working_field;
        private System.Windows.Forms.GroupBox groupBoxVacationSchedules;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelVacationSchedules;
        private System.Windows.Forms.DataGridView dataGridViewVacationSchedules;
        private System.Windows.Forms.Label labelVacationSchedules;
        private System.Windows.Forms.GroupBox groupBoxDaysCreditReport;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelDaysCreditReport;
        private System.Windows.Forms.DataGridView dataGridViewDaysCreditReport;
        private System.Windows.Forms.Button btnDaysCreditReportCreate;
        private System.Windows.Forms.GroupBox groupBoxReportArguments;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelReportArguments;
        private System.Windows.Forms.Label lblReportDate;
        private System.Windows.Forms.Label lblReportTime;
        private System.Windows.Forms.Label lblSortingArgument;
        private System.Windows.Forms.Label lblSortingDirection;
        private System.Windows.Forms.Label lblReportDayteValue;
        private System.Windows.Forms.Label lblReportTimeValue;
        private System.Windows.Forms.ComboBox comboBoxSortingArgumentValue;
        private System.Windows.Forms.ComboBox comboBoxCortingDirectionValue;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_WindowHeader;
        private System.Windows.Forms.Label lblDaysCreditReport;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Programm;
        private System.Windows.Forms.Label lblProgramm;
    }
}