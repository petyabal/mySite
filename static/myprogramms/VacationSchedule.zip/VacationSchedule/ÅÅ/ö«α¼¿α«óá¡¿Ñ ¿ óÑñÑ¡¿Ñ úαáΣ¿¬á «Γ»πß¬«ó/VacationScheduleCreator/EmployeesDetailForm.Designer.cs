﻿namespace VacationScheduleCreator
{
    partial class EmployeesDetailForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EmployeesDetailForm));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tableLayoutPanel_AllForm = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel_Company = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBoxCompany = new System.Windows.Forms.PictureBox();
            this.lblCompany = new System.Windows.Forms.Label();
            this.tableLayoutPanel_Employees = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel_Working_field = new System.Windows.Forms.TableLayoutPanel();
            this.tabControlEmployeesInformation = new System.Windows.Forms.TabControl();
            this.tabPageEmployees = new System.Windows.Forms.TabPage();
            this.tableLayoutPanelEmployees = new System.Windows.Forms.TableLayoutPanel();
            this.btnAddEmployee = new System.Windows.Forms.Button();
            this.dataGridViewEmployees = new System.Windows.Forms.DataGridView();
            this.btnChangeEmployee = new System.Windows.Forms.Button();
            this.tabPageAlternateList = new System.Windows.Forms.TabPage();
            this.tableLayoutPanelAlternateList = new System.Windows.Forms.TableLayoutPanel();
            this.btnAddToAlternateList = new System.Windows.Forms.Button();
            this.DeleteFromAlternateList = new System.Windows.Forms.Button();
            this.btnChangeInAlternateList = new System.Windows.Forms.Button();
            this.dataGridViewAlternateList = new System.Windows.Forms.DataGridView();
            this.tabPageEmployeesSickLists = new System.Windows.Forms.TabPage();
            this.tableLayoutPanelEmployeesSickLists = new System.Windows.Forms.TableLayoutPanel();
            this.btnDeleteSickList = new System.Windows.Forms.Button();
            this.btnChangeSickList = new System.Windows.Forms.Button();
            this.btnAddSickList = new System.Windows.Forms.Button();
            this.dataGridViewEmployeesSickLists = new System.Windows.Forms.DataGridView();
            this.tableLayoutPanel_WindowHeader = new System.Windows.Forms.TableLayoutPanel();
            this.lblEmployeesInformation = new System.Windows.Forms.Label();
            this.tableLayoutPanel_Programm = new System.Windows.Forms.TableLayoutPanel();
            this.lblProgramm = new System.Windows.Forms.Label();
            this.tableLayoutPanel_AllForm.SuspendLayout();
            this.tableLayoutPanel_Company.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCompany)).BeginInit();
            this.tableLayoutPanel_Employees.SuspendLayout();
            this.tableLayoutPanel_Working_field.SuspendLayout();
            this.tabControlEmployeesInformation.SuspendLayout();
            this.tabPageEmployees.SuspendLayout();
            this.tableLayoutPanelEmployees.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewEmployees)).BeginInit();
            this.tabPageAlternateList.SuspendLayout();
            this.tableLayoutPanelAlternateList.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAlternateList)).BeginInit();
            this.tabPageEmployeesSickLists.SuspendLayout();
            this.tableLayoutPanelEmployeesSickLists.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewEmployeesSickLists)).BeginInit();
            this.tableLayoutPanel_WindowHeader.SuspendLayout();
            this.tableLayoutPanel_Programm.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel_AllForm
            // 
            this.tableLayoutPanel_AllForm.ColumnCount = 1;
            this.tableLayoutPanel_AllForm.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_AllForm.Controls.Add(this.tableLayoutPanel_Company, 0, 1);
            this.tableLayoutPanel_AllForm.Controls.Add(this.tableLayoutPanel_Employees, 0, 2);
            this.tableLayoutPanel_AllForm.Controls.Add(this.tableLayoutPanel_Programm, 0, 0);
            this.tableLayoutPanel_AllForm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_AllForm.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel_AllForm.Name = "tableLayoutPanel_AllForm";
            this.tableLayoutPanel_AllForm.RowCount = 3;
            this.tableLayoutPanel_AllForm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel_AllForm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tableLayoutPanel_AllForm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 75F));
            this.tableLayoutPanel_AllForm.Size = new System.Drawing.Size(784, 497);
            this.tableLayoutPanel_AllForm.TabIndex = 7;
            // 
            // tableLayoutPanel_Company
            // 
            this.tableLayoutPanel_Company.BackColor = System.Drawing.SystemColors.HotTrack;
            this.tableLayoutPanel_Company.ColumnCount = 2;
            this.tableLayoutPanel_Company.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel_Company.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.tableLayoutPanel_Company.Controls.Add(this.pictureBoxCompany, 0, 1);
            this.tableLayoutPanel_Company.Controls.Add(this.lblCompany, 1, 1);
            this.tableLayoutPanel_Company.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Company.Location = new System.Drawing.Point(3, 52);
            this.tableLayoutPanel_Company.Name = "tableLayoutPanel_Company";
            this.tableLayoutPanel_Company.RowCount = 3;
            this.tableLayoutPanel_Company.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel_Company.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tableLayoutPanel_Company.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel_Company.Size = new System.Drawing.Size(778, 68);
            this.tableLayoutPanel_Company.TabIndex = 7;
            // 
            // pictureBoxCompany
            // 
            this.pictureBoxCompany.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxCompany.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxCompany.Image")));
            this.pictureBoxCompany.Location = new System.Drawing.Point(3, 6);
            this.pictureBoxCompany.Name = "pictureBoxCompany";
            this.pictureBoxCompany.Size = new System.Drawing.Size(227, 55);
            this.pictureBoxCompany.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxCompany.TabIndex = 3;
            this.pictureBoxCompany.TabStop = false;
            // 
            // lblCompany
            // 
            this.lblCompany.AutoSize = true;
            this.lblCompany.BackColor = System.Drawing.SystemColors.HotTrack;
            this.lblCompany.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCompany.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblCompany.ForeColor = System.Drawing.Color.White;
            this.lblCompany.Location = new System.Drawing.Point(236, 3);
            this.lblCompany.Name = "lblCompany";
            this.lblCompany.Size = new System.Drawing.Size(539, 61);
            this.lblCompany.TabIndex = 2;
            this.lblCompany.Text = "МЕЖРЕГИОНАЛЬНАЯ РАСПРЕДЕЛИТЕЛЬНАЯ СЕТЕВАЯ КОМПАНИЯ СЕВЕРО-ЗАПАДА";
            this.lblCompany.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel_Employees
            // 
            this.tableLayoutPanel_Employees.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPanel_Employees.ColumnCount = 1;
            this.tableLayoutPanel_Employees.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_Employees.Controls.Add(this.tableLayoutPanel_Working_field, 0, 1);
            this.tableLayoutPanel_Employees.Controls.Add(this.tableLayoutPanel_WindowHeader, 0, 0);
            this.tableLayoutPanel_Employees.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Employees.Location = new System.Drawing.Point(3, 126);
            this.tableLayoutPanel_Employees.Name = "tableLayoutPanel_Employees";
            this.tableLayoutPanel_Employees.RowCount = 2;
            this.tableLayoutPanel_Employees.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12F));
            this.tableLayoutPanel_Employees.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 88F));
            this.tableLayoutPanel_Employees.Size = new System.Drawing.Size(778, 368);
            this.tableLayoutPanel_Employees.TabIndex = 6;
            // 
            // tableLayoutPanel_Working_field
            // 
            this.tableLayoutPanel_Working_field.ColumnCount = 1;
            this.tableLayoutPanel_Working_field.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_Working_field.Controls.Add(this.tabControlEmployeesInformation, 0, 0);
            this.tableLayoutPanel_Working_field.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Working_field.Location = new System.Drawing.Point(3, 44);
            this.tableLayoutPanel_Working_field.Margin = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.tableLayoutPanel_Working_field.Name = "tableLayoutPanel_Working_field";
            this.tableLayoutPanel_Working_field.RowCount = 1;
            this.tableLayoutPanel_Working_field.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_Working_field.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 321F));
            this.tableLayoutPanel_Working_field.Size = new System.Drawing.Size(772, 321);
            this.tableLayoutPanel_Working_field.TabIndex = 7;
            // 
            // tabControlEmployeesInformation
            // 
            this.tabControlEmployeesInformation.Controls.Add(this.tabPageEmployees);
            this.tabControlEmployeesInformation.Controls.Add(this.tabPageAlternateList);
            this.tabControlEmployeesInformation.Controls.Add(this.tabPageEmployeesSickLists);
            this.tabControlEmployeesInformation.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlEmployeesInformation.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tabControlEmployeesInformation.Location = new System.Drawing.Point(3, 3);
            this.tabControlEmployeesInformation.Name = "tabControlEmployeesInformation";
            this.tabControlEmployeesInformation.SelectedIndex = 0;
            this.tabControlEmployeesInformation.Size = new System.Drawing.Size(766, 315);
            this.tabControlEmployeesInformation.TabIndex = 2;
            // 
            // tabPageEmployees
            // 
            this.tabPageEmployees.Controls.Add(this.tableLayoutPanelEmployees);
            this.tabPageEmployees.Location = new System.Drawing.Point(4, 32);
            this.tabPageEmployees.Name = "tabPageEmployees";
            this.tabPageEmployees.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageEmployees.Size = new System.Drawing.Size(758, 279);
            this.tabPageEmployees.TabIndex = 0;
            this.tabPageEmployees.Text = "Список сотрудников";
            this.tabPageEmployees.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanelEmployees
            // 
            this.tableLayoutPanelEmployees.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPanelEmployees.ColumnCount = 2;
            this.tableLayoutPanelEmployees.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelEmployees.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelEmployees.Controls.Add(this.btnAddEmployee, 0, 1);
            this.tableLayoutPanelEmployees.Controls.Add(this.dataGridViewEmployees, 0, 0);
            this.tableLayoutPanelEmployees.Controls.Add(this.btnChangeEmployee, 1, 1);
            this.tableLayoutPanelEmployees.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelEmployees.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanelEmployees.Name = "tableLayoutPanelEmployees";
            this.tableLayoutPanelEmployees.RowCount = 2;
            this.tableLayoutPanelEmployees.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 88F));
            this.tableLayoutPanelEmployees.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12F));
            this.tableLayoutPanelEmployees.Size = new System.Drawing.Size(752, 273);
            this.tableLayoutPanelEmployees.TabIndex = 0;
            // 
            // btnAddEmployee
            // 
            this.btnAddEmployee.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnAddEmployee.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnAddEmployee.ForeColor = System.Drawing.Color.White;
            this.btnAddEmployee.Location = new System.Drawing.Point(3, 243);
            this.btnAddEmployee.Name = "btnAddEmployee";
            this.btnAddEmployee.Size = new System.Drawing.Size(370, 27);
            this.btnAddEmployee.TabIndex = 6;
            this.btnAddEmployee.Text = "Добавить нового сотрудника";
            this.btnAddEmployee.UseVisualStyleBackColor = false;
            this.btnAddEmployee.Click += new System.EventHandler(this.btnAddEmployee_Click);
            // 
            // dataGridViewEmployees
            // 
            this.dataGridViewEmployees.AllowUserToAddRows = false;
            this.dataGridViewEmployees.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.AntiqueWhite;
            this.dataGridViewEmployees.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewEmployees.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tableLayoutPanelEmployees.SetColumnSpan(this.dataGridViewEmployees, 2);
            this.dataGridViewEmployees.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewEmployees.Location = new System.Drawing.Point(3, 3);
            this.dataGridViewEmployees.MultiSelect = false;
            this.dataGridViewEmployees.Name = "dataGridViewEmployees";
            this.dataGridViewEmployees.ReadOnly = true;
            this.dataGridViewEmployees.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewEmployees.Size = new System.Drawing.Size(746, 234);
            this.dataGridViewEmployees.TabIndex = 4;
            // 
            // btnChangeEmployee
            // 
            this.btnChangeEmployee.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnChangeEmployee.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnChangeEmployee.ForeColor = System.Drawing.Color.White;
            this.btnChangeEmployee.Location = new System.Drawing.Point(379, 243);
            this.btnChangeEmployee.Name = "btnChangeEmployee";
            this.btnChangeEmployee.Size = new System.Drawing.Size(370, 27);
            this.btnChangeEmployee.TabIndex = 5;
            this.btnChangeEmployee.Text = "Редактировать сведения о сотруднике";
            this.btnChangeEmployee.UseVisualStyleBackColor = false;
            this.btnChangeEmployee.Click += new System.EventHandler(this.btnChangeEmployee_Click);
            // 
            // tabPageAlternateList
            // 
            this.tabPageAlternateList.Controls.Add(this.tableLayoutPanelAlternateList);
            this.tabPageAlternateList.Location = new System.Drawing.Point(4, 32);
            this.tabPageAlternateList.Name = "tabPageAlternateList";
            this.tabPageAlternateList.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageAlternateList.Size = new System.Drawing.Size(758, 279);
            this.tabPageAlternateList.TabIndex = 1;
            this.tabPageAlternateList.Text = "Список замещающих лиц";
            this.tabPageAlternateList.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanelAlternateList
            // 
            this.tableLayoutPanelAlternateList.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPanelAlternateList.ColumnCount = 3;
            this.tableLayoutPanelAlternateList.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanelAlternateList.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanelAlternateList.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanelAlternateList.Controls.Add(this.btnAddToAlternateList, 0, 1);
            this.tableLayoutPanelAlternateList.Controls.Add(this.DeleteFromAlternateList, 0, 1);
            this.tableLayoutPanelAlternateList.Controls.Add(this.btnChangeInAlternateList, 0, 1);
            this.tableLayoutPanelAlternateList.Controls.Add(this.dataGridViewAlternateList, 0, 0);
            this.tableLayoutPanelAlternateList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelAlternateList.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanelAlternateList.Name = "tableLayoutPanelAlternateList";
            this.tableLayoutPanelAlternateList.RowCount = 2;
            this.tableLayoutPanelAlternateList.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 88F));
            this.tableLayoutPanelAlternateList.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12F));
            this.tableLayoutPanelAlternateList.Size = new System.Drawing.Size(752, 273);
            this.tableLayoutPanelAlternateList.TabIndex = 0;
            // 
            // btnAddToAlternateList
            // 
            this.btnAddToAlternateList.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnAddToAlternateList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnAddToAlternateList.ForeColor = System.Drawing.Color.White;
            this.btnAddToAlternateList.Location = new System.Drawing.Point(3, 243);
            this.btnAddToAlternateList.Name = "btnAddToAlternateList";
            this.btnAddToAlternateList.Size = new System.Drawing.Size(244, 27);
            this.btnAddToAlternateList.TabIndex = 9;
            this.btnAddToAlternateList.Text = "Добавить в список";
            this.btnAddToAlternateList.UseVisualStyleBackColor = false;
            this.btnAddToAlternateList.Click += new System.EventHandler(this.btnAddToAlternateList_Click);
            // 
            // DeleteFromAlternateList
            // 
            this.DeleteFromAlternateList.BackColor = System.Drawing.SystemColors.HotTrack;
            this.DeleteFromAlternateList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DeleteFromAlternateList.ForeColor = System.Drawing.Color.White;
            this.DeleteFromAlternateList.Location = new System.Drawing.Point(503, 243);
            this.DeleteFromAlternateList.Name = "DeleteFromAlternateList";
            this.DeleteFromAlternateList.Size = new System.Drawing.Size(246, 27);
            this.DeleteFromAlternateList.TabIndex = 8;
            this.DeleteFromAlternateList.Text = "Удалить запись из списка";
            this.DeleteFromAlternateList.UseVisualStyleBackColor = false;
            this.DeleteFromAlternateList.Click += new System.EventHandler(this.DeleteFromAlternateList_Click);
            // 
            // btnChangeInAlternateList
            // 
            this.btnChangeInAlternateList.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnChangeInAlternateList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnChangeInAlternateList.ForeColor = System.Drawing.Color.White;
            this.btnChangeInAlternateList.Location = new System.Drawing.Point(253, 243);
            this.btnChangeInAlternateList.Name = "btnChangeInAlternateList";
            this.btnChangeInAlternateList.Size = new System.Drawing.Size(244, 27);
            this.btnChangeInAlternateList.TabIndex = 7;
            this.btnChangeInAlternateList.Text = "Редактировать запись";
            this.btnChangeInAlternateList.UseVisualStyleBackColor = false;
            this.btnChangeInAlternateList.Click += new System.EventHandler(this.btnChangeInAlternateList_Click);
            // 
            // dataGridViewAlternateList
            // 
            this.dataGridViewAlternateList.AllowUserToAddRows = false;
            this.dataGridViewAlternateList.AllowUserToDeleteRows = false;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.AntiqueWhite;
            this.dataGridViewAlternateList.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewAlternateList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tableLayoutPanelAlternateList.SetColumnSpan(this.dataGridViewAlternateList, 3);
            this.dataGridViewAlternateList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewAlternateList.Location = new System.Drawing.Point(3, 3);
            this.dataGridViewAlternateList.MultiSelect = false;
            this.dataGridViewAlternateList.Name = "dataGridViewAlternateList";
            this.dataGridViewAlternateList.ReadOnly = true;
            this.dataGridViewAlternateList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewAlternateList.Size = new System.Drawing.Size(746, 234);
            this.dataGridViewAlternateList.TabIndex = 5;
            // 
            // tabPageEmployeesSickLists
            // 
            this.tabPageEmployeesSickLists.Controls.Add(this.tableLayoutPanelEmployeesSickLists);
            this.tabPageEmployeesSickLists.Location = new System.Drawing.Point(4, 25);
            this.tabPageEmployeesSickLists.Name = "tabPageEmployeesSickLists";
            this.tabPageEmployeesSickLists.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageEmployeesSickLists.Size = new System.Drawing.Size(758, 286);
            this.tabPageEmployeesSickLists.TabIndex = 2;
            this.tabPageEmployeesSickLists.Text = "Больничные листы сотрудников";
            this.tabPageEmployeesSickLists.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanelEmployeesSickLists
            // 
            this.tableLayoutPanelEmployeesSickLists.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPanelEmployeesSickLists.ColumnCount = 3;
            this.tableLayoutPanelEmployeesSickLists.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanelEmployeesSickLists.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanelEmployeesSickLists.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanelEmployeesSickLists.Controls.Add(this.btnDeleteSickList, 2, 1);
            this.tableLayoutPanelEmployeesSickLists.Controls.Add(this.btnChangeSickList, 1, 1);
            this.tableLayoutPanelEmployeesSickLists.Controls.Add(this.btnAddSickList, 0, 1);
            this.tableLayoutPanelEmployeesSickLists.Controls.Add(this.dataGridViewEmployeesSickLists, 0, 0);
            this.tableLayoutPanelEmployeesSickLists.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelEmployeesSickLists.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanelEmployeesSickLists.Name = "tableLayoutPanelEmployeesSickLists";
            this.tableLayoutPanelEmployeesSickLists.RowCount = 2;
            this.tableLayoutPanelEmployeesSickLists.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 88F));
            this.tableLayoutPanelEmployeesSickLists.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12F));
            this.tableLayoutPanelEmployeesSickLists.Size = new System.Drawing.Size(752, 280);
            this.tableLayoutPanelEmployeesSickLists.TabIndex = 0;
            // 
            // btnDeleteSickList
            // 
            this.btnDeleteSickList.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnDeleteSickList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnDeleteSickList.ForeColor = System.Drawing.Color.White;
            this.btnDeleteSickList.Location = new System.Drawing.Point(503, 249);
            this.btnDeleteSickList.Name = "btnDeleteSickList";
            this.btnDeleteSickList.Size = new System.Drawing.Size(246, 28);
            this.btnDeleteSickList.TabIndex = 12;
            this.btnDeleteSickList.Text = "Удалить больничный лист";
            this.btnDeleteSickList.UseVisualStyleBackColor = false;
            this.btnDeleteSickList.Click += new System.EventHandler(this.btnDeleteSickList_Click);
            // 
            // btnChangeSickList
            // 
            this.btnChangeSickList.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnChangeSickList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnChangeSickList.ForeColor = System.Drawing.Color.White;
            this.btnChangeSickList.Location = new System.Drawing.Point(253, 249);
            this.btnChangeSickList.Name = "btnChangeSickList";
            this.btnChangeSickList.Size = new System.Drawing.Size(244, 28);
            this.btnChangeSickList.TabIndex = 11;
            this.btnChangeSickList.Text = "Редактировать больничный лист";
            this.btnChangeSickList.UseVisualStyleBackColor = false;
            this.btnChangeSickList.Click += new System.EventHandler(this.btnChangeSickList_Click);
            // 
            // btnAddSickList
            // 
            this.btnAddSickList.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnAddSickList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnAddSickList.ForeColor = System.Drawing.Color.White;
            this.btnAddSickList.Location = new System.Drawing.Point(3, 249);
            this.btnAddSickList.Name = "btnAddSickList";
            this.btnAddSickList.Size = new System.Drawing.Size(244, 28);
            this.btnAddSickList.TabIndex = 10;
            this.btnAddSickList.Text = "Добавить больничный лист";
            this.btnAddSickList.UseVisualStyleBackColor = false;
            this.btnAddSickList.Click += new System.EventHandler(this.btnAddSickList_Click);
            // 
            // dataGridViewEmployeesSickLists
            // 
            this.dataGridViewEmployeesSickLists.AllowUserToAddRows = false;
            this.dataGridViewEmployeesSickLists.AllowUserToDeleteRows = false;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.AntiqueWhite;
            this.dataGridViewEmployeesSickLists.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridViewEmployeesSickLists.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tableLayoutPanelEmployeesSickLists.SetColumnSpan(this.dataGridViewEmployeesSickLists, 3);
            this.dataGridViewEmployeesSickLists.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewEmployeesSickLists.Location = new System.Drawing.Point(3, 3);
            this.dataGridViewEmployeesSickLists.MultiSelect = false;
            this.dataGridViewEmployeesSickLists.Name = "dataGridViewEmployeesSickLists";
            this.dataGridViewEmployeesSickLists.ReadOnly = true;
            this.dataGridViewEmployeesSickLists.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewEmployeesSickLists.Size = new System.Drawing.Size(746, 240);
            this.dataGridViewEmployeesSickLists.TabIndex = 6;
            // 
            // tableLayoutPanel_WindowHeader
            // 
            this.tableLayoutPanel_WindowHeader.ColumnCount = 4;
            this.tableLayoutPanel_WindowHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_WindowHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_WindowHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_WindowHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_WindowHeader.Controls.Add(this.lblEmployeesInformation, 0, 0);
            this.tableLayoutPanel_WindowHeader.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_WindowHeader.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel_WindowHeader.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.tableLayoutPanel_WindowHeader.Name = "tableLayoutPanel_WindowHeader";
            this.tableLayoutPanel_WindowHeader.RowCount = 1;
            this.tableLayoutPanel_WindowHeader.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_WindowHeader.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 41F));
            this.tableLayoutPanel_WindowHeader.Size = new System.Drawing.Size(772, 41);
            this.tableLayoutPanel_WindowHeader.TabIndex = 6;
            // 
            // lblEmployeesInformation
            // 
            this.lblEmployeesInformation.AutoSize = true;
            this.tableLayoutPanel_WindowHeader.SetColumnSpan(this.lblEmployeesInformation, 4);
            this.lblEmployeesInformation.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblEmployeesInformation.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblEmployeesInformation.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblEmployeesInformation.Location = new System.Drawing.Point(3, 0);
            this.lblEmployeesInformation.Name = "lblEmployeesInformation";
            this.lblEmployeesInformation.Size = new System.Drawing.Size(766, 41);
            this.lblEmployeesInformation.TabIndex = 19;
            this.lblEmployeesInformation.Text = "СВЕДЕНИЯ О СОТРУДНИКАХ";
            this.lblEmployeesInformation.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel_Programm
            // 
            this.tableLayoutPanel_Programm.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPanel_Programm.ColumnCount = 1;
            this.tableLayoutPanel_Programm.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Programm.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Programm.Controls.Add(this.lblProgramm, 0, 0);
            this.tableLayoutPanel_Programm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Programm.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel_Programm.Name = "tableLayoutPanel_Programm";
            this.tableLayoutPanel_Programm.RowCount = 1;
            this.tableLayoutPanel_Programm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Programm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Programm.Size = new System.Drawing.Size(778, 43);
            this.tableLayoutPanel_Programm.TabIndex = 8;
            // 
            // lblProgramm
            // 
            this.lblProgramm.AutoSize = true;
            this.lblProgramm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblProgramm.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblProgramm.ForeColor = System.Drawing.Color.White;
            this.lblProgramm.Location = new System.Drawing.Point(3, 0);
            this.lblProgramm.Name = "lblProgramm";
            this.lblProgramm.Size = new System.Drawing.Size(772, 43);
            this.lblProgramm.TabIndex = 0;
            this.lblProgramm.Text = "ФОРМИРОВАНИЕ И ВЕДЕНИЕ ГРАФИКА ОТПУСКОВ СОТРУДНИКОВ";
            this.lblProgramm.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // EmployeesDetailForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 497);
            this.Controls.Add(this.tableLayoutPanel_AllForm);
            this.Name = "EmployeesDetailForm";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "СВЕДЕНИЯ О СОТРУДНИКАХ";
            this.Load += new System.EventHandler(this.EmployeesDetailForm_Load);
            this.tableLayoutPanel_AllForm.ResumeLayout(false);
            this.tableLayoutPanel_Company.ResumeLayout(false);
            this.tableLayoutPanel_Company.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCompany)).EndInit();
            this.tableLayoutPanel_Employees.ResumeLayout(false);
            this.tableLayoutPanel_Working_field.ResumeLayout(false);
            this.tabControlEmployeesInformation.ResumeLayout(false);
            this.tabPageEmployees.ResumeLayout(false);
            this.tableLayoutPanelEmployees.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewEmployees)).EndInit();
            this.tabPageAlternateList.ResumeLayout(false);
            this.tableLayoutPanelAlternateList.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAlternateList)).EndInit();
            this.tabPageEmployeesSickLists.ResumeLayout(false);
            this.tableLayoutPanelEmployeesSickLists.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewEmployeesSickLists)).EndInit();
            this.tableLayoutPanel_WindowHeader.ResumeLayout(false);
            this.tableLayoutPanel_WindowHeader.PerformLayout();
            this.tableLayoutPanel_Programm.ResumeLayout(false);
            this.tableLayoutPanel_Programm.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_AllForm;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Company;
        private System.Windows.Forms.PictureBox pictureBoxCompany;
        private System.Windows.Forms.Label lblCompany;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Employees;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Working_field;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_WindowHeader;
        private System.Windows.Forms.Label lblEmployeesInformation;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Programm;
        private System.Windows.Forms.Label lblProgramm;
        private System.Windows.Forms.TabControl tabControlEmployeesInformation;
        private System.Windows.Forms.TabPage tabPageEmployees;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelEmployees;
        private System.Windows.Forms.Button btnAddEmployee;
        private System.Windows.Forms.DataGridView dataGridViewEmployees;
        private System.Windows.Forms.Button btnChangeEmployee;
        private System.Windows.Forms.TabPage tabPageAlternateList;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelAlternateList;
        private System.Windows.Forms.DataGridView dataGridViewAlternateList;
        private System.Windows.Forms.Button btnAddToAlternateList;
        private System.Windows.Forms.Button DeleteFromAlternateList;
        private System.Windows.Forms.Button btnChangeInAlternateList;
        private System.Windows.Forms.TabPage tabPageEmployeesSickLists;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelEmployeesSickLists;
        private System.Windows.Forms.Button btnDeleteSickList;
        private System.Windows.Forms.Button btnChangeSickList;
        private System.Windows.Forms.Button btnAddSickList;
        private System.Windows.Forms.DataGridView dataGridViewEmployeesSickLists;
    }
}