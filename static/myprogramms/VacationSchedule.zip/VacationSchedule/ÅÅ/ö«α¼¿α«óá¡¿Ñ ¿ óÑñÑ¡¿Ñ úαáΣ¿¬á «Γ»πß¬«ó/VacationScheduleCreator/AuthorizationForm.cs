﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace VacationScheduleCreator
{
    //класс формы авторизации
    public partial class AuthorizationForm : Form
    {
        public AuthorizationForm()
        {
            InitializeComponent();
        }

        //переменная, по которй проверяется режим отображения пароля
        bool PasswordIsViseble = false;

        //процедура смены режимов отображения пароля
        private void pictureBoxViewIndicator_Click(object sender, EventArgs e)
        {
            switch (PasswordIsViseble)
            {
                case false: textBoxPassword.PasswordChar = '\0';
                    pictureBoxViewIndicator.Image = Image.FromFile
                        (Directory.GetCurrentDirectory() + "/icons/basic-eye-closed.png");
                    PasswordIsViseble = true;
                    break;
                case true: textBoxPassword.PasswordChar = '*';
                    pictureBoxViewIndicator.Image = Image.FromFile
                        (Directory.GetCurrentDirectory() + "/icons/basic-eye.png");
                    PasswordIsViseble = false;
                    break;
            }
        }

        //процедура авторизации
        private void btnEnter_Click(object sender, EventArgs e)
        {
            if (DB_Connection.Authorization(textBoxLogin.Text, textBoxPassword.Text))
            {
                this.Hide();
                switch (DB_Connection.ActiveRole)
                {
                    case "Инспектор отдела кадров":
                        {
                            MainForm mainForm = new MainForm();
                            mainForm.ImportUserInformation();                           
                            mainForm.ShowDialog();
                            break;
                        }
                    case "Руководитель":
                        {
                            MainForm mainForm = new MainForm();
                            mainForm.ImportUserInformation();
                            mainForm.ShowDialog();
                            break;
                        }
                    case "Администратор":
                        {
                            MaintenanceForm Maintenance = new MaintenanceForm();
                            Maintenance.ShowDialog();
                            break;
                        }
                }
                if (InitialForm.ExitConfirm == true)
                {
                    this.Close();
                }
                textBoxLogin.Text = "";
                textBoxPassword.Text = "";
                this.Show();
            }
        }

        //процедура завершения работы приложения
        private void btnExit_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = new DialogResult();
            dialogResult = MessageBox.Show("Вы действительно хотите выйти из приложения?",
                "Завершение работы!", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                InitialForm.ExitConfirm = true;
                this.Close();
            }
        }
    }
}
