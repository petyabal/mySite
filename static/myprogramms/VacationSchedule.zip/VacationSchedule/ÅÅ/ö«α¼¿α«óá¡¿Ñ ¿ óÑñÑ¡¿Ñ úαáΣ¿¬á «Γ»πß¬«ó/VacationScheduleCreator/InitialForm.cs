﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace VacationScheduleCreator
{
    public partial class InitialForm : Form
    {
        public InitialForm()
        {
            InitializeComponent();
        }

        public const double Proportion = 0.6339285714286;
        static public bool ExitConfirm = false;

        //процедура настройки и показа загрузочной (первоначальной формы)
        private void InitialForm_Shown(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;
            timerMakeOpacityChange.Enabled = true;
        }

        //изменение прозрачности формы при срабатывании первого таймера (анимация загрузки)
        private void timerMakeOpacityChange_Tick(object sender, EventArgs e)
        {
            if (this.Opacity == 1)
            {
                timerMakeOpacityChange.Enabled = false;
                lblDataBaseExists.Show();
                lblAllTablesExists.Show();
                lblProgrammComponentsExists.Show();
                return;
            }
            this.Opacity += 0.01;
        }

        //загрузка изображения при изменении видимости лейбла (часть анимации загрузки)
        private void lblDataBaseExists_VisibleChanged(object sender, EventArgs e)
        { 
            pictureBox_Check1.BackgroundImage = Image.FromFile(Directory.GetCurrentDirectory() +"/icons/ok.png");
        }

        //загрузка следующего изображения (часть анимации загрузки)
        private void pictureBox_Check1_BackgroundImageChanged(object sender, EventArgs e)
        {
            pictureBox_Check2.BackgroundImage = Image.FromFile(Directory.GetCurrentDirectory() + "/icons/ok.png");
        }
        //загрузка последнего изображения (часть анимации загрузки)
        private void pictureBox_Check2_BackgroundImageChanged(object sender, EventArgs e)
        {
            pictureBox_Check3.BackgroundImage = Image.FromFile(Directory.GetCurrentDirectory() + "/icons/ok.png");
        }

        //показ метки и установление обычного типа курсора (часть анимации загрузки)
        private void pictureBox_Check3_BackgroundImageChanged(object sender, EventArgs e)
        {
            labelCheck.Show();
            this.Cursor = Cursors.Default;
        }

        //включение второго таймера
        private void labelCheck_VisibleChanged(object sender, EventArgs e)
        {
            timerAuthorizationDelay.Enabled = true;
        }

        //показ формы авторизации при срабатывании второго таймера (завершение анимации загрузки)
        private void timerAuthorizationDelay_Tick(object sender, EventArgs e)
        {
            AuthorizationForm Authorization = new AuthorizationForm();
            timerAuthorizationDelay.Enabled = false;
            this.Hide();
            Authorization.ShowDialog();
            CloseApplication();
        }

        //процедура закрытия приложения
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //процедура закрытия приложения
        void CloseApplication()
        {
            if (ExitConfirm == true)
                this.Close();
        }

        //Эти две процедуры необходимы для подключения к БД

        //Процедура попытки установить соединение с БД при загрузке формы
        private void InitialForm_Load(object sender, EventArgs e)
        {
            if (!DB_Connection.Connect())
            {
                this.Close();
            }
        }

        //Процедура закрытия соединения с БД при закрытии главной формы
        private void InitialForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            DB_Connection.Close();
        }
    }
}
