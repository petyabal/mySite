﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace VacationScheduleCreator
{
    //класс формы для детального отображения отпусков сотрудников
    public partial class EmployeesVacationsDetailForm : Form
    {
        public EmployeesVacationsDetailForm()
        {
            InitializeComponent();
        }

        //хранит номер редактируемой записи для работы из других модулей
        static public string NumberOfEditRecord;
        //хранит выбранный пользователем вид отпуска
        static public string Vacation;
        //хранит информацию о выбранном графике отпусков для редактирования из другого модуля
        static public string UnitVacationSchedule;
        //хранит имя сотрудника для изменения записи о предоставляемом отпуске
        static public string Vacationist;
        //переменная для определения изначального момента загрузки формы
        string InitialMoment = "now";
        //переменная для определения подтверждения вида назначенного отпуска при редактировании
        static public string vacationType;
        
        //переменные для выбора изменяемого значения в выпадающих списках
        //заполняемых из бд
        static public string importVacationist;
        static public string importTypeOfVacation;
        static public string importApprovedBy;
        static public string importStructuralUnit;
        static public string importTraveler;

        //процедура скрытия всех вкладок
        void AllTabsHide()
        {
            tabPageEmployeesVacations.Parent = null;
            tabPageVacationSchedules.Parent = null;
            tabPageVacationTypes.Parent = null;
            tabPageSpendingOfVacations.Parent = null;
            tabPageEmployeesPaidTravel.Parent = null;
        }

        //процедура загрузки данных в таблиц из БД
        private void EmployeesVacationsDetailForm_Load(object sender, EventArgs e)
        {
            if (tabPageEmployeesVacations.Parent == tabControlEmployeesVacations)
            {
                dataGridViewVacationsSchedulesList.DataSource = DB_Connection.dtVacationSchedules;
                dataGridViewVacationsSchedulesList.Columns["Vacation_schedule_id"].Visible = false;
                if (dataGridViewVacationsSchedulesList.RowCount != 0)
                {
                    if (InitialMoment == "now")
                    {
                        //показ таблицы "График отпусков"
                        DB_Connection.ShowEmployeesVacations(dataGridViewVacationsSchedulesList.Rows[0].
                            Cells["Vacation_schedule_id"].Value.ToString());
                        dataGridViewEmployeesVacations.DataSource = DB_Connection.dtEmployeesVacations;
                        dataGridViewVacationsSchedulesList.Rows[0].Cells["Дата составления"].Selected = true;
                        dataGridViewEmployeesVacations.Columns["Vacation_schedule_id"].Visible = false;
                        dataGridViewEmployeesVacations.Columns["Position_id"].Visible = false;
                        //показ таблицы "Журнал ведения отпусков"
                        DB_Connection.ShowVacationLog(dataGridViewVacationsSchedulesList.Rows[0].
                            Cells["Vacation_schedule_id"].Value.ToString());
                        dataGridViewVacationLog.DataSource = DB_Connection.dtVacationLog;
                        dataGridViewVacationLog.Columns["Vacation_schedule_id"].Visible = false;
                        dataGridViewVacationLog.Columns["Position_id"].Visible = false;
                        InitialMoment = "lost";
                    }
                    else
                    {
                        DB_Connection.ShowEmployeesVacations(dataGridViewVacationsSchedulesList.CurrentRow.
                            Cells["Vacation_schedule_id"].Value.ToString());
                        dataGridViewEmployeesVacations.DataSource = DB_Connection.dtEmployeesVacations;
                        dataGridViewEmployeesVacations.Columns["Vacation_schedule_id"].Visible = false;
                        dataGridViewEmployeesVacations.Columns["Position_id"].Visible = false;
                    }
                }
            }
            if (tabPageVacationSchedules.Parent == tabControlEmployeesVacations)
            {
                DB_Connection.ShowVacationSchedules();
                dataGridViewVacationSchedules.DataSource = DB_Connection.dtVacationSchedules;
                dataGridViewVacationSchedules.Columns["Vacation_schedule_id"].Visible = false;
                dataGridViewVacationSchedules.Rows[0].Cells["Дата составления"].Selected = true;
            }
            if (tabPageVacationTypes.Parent == tabControlEmployeesVacations)
            {
                DB_Connection.ShowVacationTypes();
                dataGridViewVacationTypes.DataSource = DB_Connection.dtVacationTypes;
                dataGridViewVacationTypes.Columns["Vacation_type_id"].Visible = false;
                dataGridViewVacationTypes.Rows[0].Cells["Вид отпуска"].Selected = true;
            }
            if (tabPageSpendingOfVacations.Parent == tabControlEmployeesVacations)
            {
                DB_Connection.ShowSpendingOfVacations();
                dataGridViewSpendingOfVacations.DataSource = DB_Connection.dtSpendingOfVacations;
                dataGridViewSpendingOfVacations.Columns["Position_id"].Visible = false;
                if (dataGridViewSpendingOfVacations.RowCount != 0)
                dataGridViewSpendingOfVacations.Rows[0].Cells["Сотрудник"].Selected = true;
            }
            if (tabPageEmployeesPaidTravel.Parent == tabControlEmployeesVacations)
            {
                DB_Connection.ShowEmployeesPaidTravel();
                dataGridViewEmployeesPaidTravel.DataSource = DB_Connection.dtEmployeesPaidTravel;
                dataGridViewEmployeesPaidTravel.Columns["Position_id"].Visible = false;
                if (dataGridViewEmployeesPaidTravel.RowCount != 0)
                dataGridViewEmployeesPaidTravel.Rows[0].Cells["Сотрудник"].Selected = true;
            }
        }

        //процедура выбора графика отпусков
        private void dataGridViewVacationsSchedulesList_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex == -1) return;
            else
            {
                DB_Connection.ShowEmployeesVacations(dataGridViewVacationsSchedulesList.CurrentRow.
                    Cells["Vacation_schedule_id"].Value.ToString());
                DB_Connection.ShowVacationLog(dataGridViewVacationsSchedulesList.CurrentRow.
                    Cells["Vacation_schedule_id"].Value.ToString());
            }
        }

        //метод-диалог для подтверждения желания пользователя удалить выбранную запись
        bool UserAgree()
        {
            DialogResult dialogResult = new DialogResult();
            dialogResult = MessageBox.Show("Вы действительно хотите удалить выбранную запись?",
                "Удаление данных!", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes) return true;
            else return false;
        }


        //ТАБЛИЦА "ОТПУСКА СОТРУДНИКОВ"
        //процедура настройки и показа формы для отображения графика отпусков
        public void ShowEmployeesVacationsTab()
        {
            AllTabsHide();
            tabPageEmployeesVacations.Parent = tabControlEmployeesVacations;
        }

        //процедура открытия конструктора графика отпусков
        private void btnOpenVacationScheduleConstructior_Click(object sender, EventArgs e)
        {
            VacationScheduleConstructorForm VacationScheduleConstructor = new VacationScheduleConstructorForm();
            VacationScheduleConstructor.WindowState = FormWindowState.Maximized;
            VacationScheduleConstructor.ShowDialog();
            if (dataGridViewVacationsSchedulesList.RowCount != 0)
            {
            DB_Connection.ShowEmployeesVacations(dataGridViewVacationsSchedulesList.Rows[0].
                            Cells["Vacation_schedule_id"].Value.ToString());
            DB_Connection.ShowVacationLog(dataGridViewVacationsSchedulesList.Rows[0].
                            Cells["Vacation_schedule_id"].Value.ToString());
            }
        }

        //процедура открытия конструктора журнала ведения отпусков
        private void btnOpenVacationLogConstructor_Click(object sender, EventArgs e)
        {
            RealVacationLogConstructorForm RealVacationLogConstructor = new RealVacationLogConstructorForm();
            RealVacationLogConstructor.WindowState = FormWindowState.Maximized;
            RealVacationLogConstructor.ShowDialog();
            if (dataGridViewVacationsSchedulesList.RowCount != 0)
            {
            DB_Connection.ShowEmployeesVacations(dataGridViewVacationsSchedulesList.Rows[0].
                            Cells["Vacation_schedule_id"].Value.ToString());
            DB_Connection.ShowVacationLog(dataGridViewVacationsSchedulesList.Rows[0].
                            Cells["Vacation_schedule_id"].Value.ToString());
            }
        }

        //ТАБЛИЦА "ГРАФИКИ ОТПУСКОВ"
        //процедура настройки и показа формы для отображения перечня графиков отпусков
        public void ShowVacationSchedulesTab()
        {
            AllTabsHide();
            tabPageVacationSchedules.Parent = tabControlEmployeesVacations;
        }

        //процедура открытия формы с полями ввода для добавления графика отпусков 
        private void btnAddVacationSchedule_Click(object sender, EventArgs e)
        {
            EmployeesVacationsEditForm EmployeesVacationsEdit = new EmployeesVacationsEditForm();
            EmployeesVacationsEdit.ShowVacationSchedulesListTabToAdd();
            EmployeesVacationsEdit.VacationScheduleInformationImport(DateTime.Now.ToString(),
                "", "2018", "Не утвержден", null);
            EmployeesVacationsEdit.ShowDialog();
        }

        //процедура открытия формы с полями ввода для редактирования информации о графике отпусков
        private void btnChangeVacationSchedule_Click(object sender, EventArgs e)
        {
            NumberOfEditRecord = dataGridViewVacationSchedules.CurrentRow.
                Cells["Vacation_schedule_id"].Value.ToString();
            UnitVacationSchedule = dataGridViewVacationSchedules.CurrentRow.
                Cells["Структурное подразделение"].Value.ToString();
            importStructuralUnit = DB_Connection.GetStructuralUnitId(
                dataGridViewVacationSchedules.CurrentRow.Cells["Структурное подразделение"].Value.ToString());
            if (dataGridViewVacationSchedules.CurrentRow.Cells["Утвержден"].Value.ToString() == "Утвержден")
                importApprovedBy = DB_Connection.GetPersonnelNumberFromEmployees(
                    dataGridViewVacationSchedules.CurrentRow.Cells["Утвердившее лицо"].Value.ToString());
            else importApprovedBy = null;
            EmployeesVacationsEditForm EmployeesVacationsEdit = new EmployeesVacationsEditForm();
            EmployeesVacationsEdit.ShowVacationSchedulesListTabToChange();
            EmployeesVacationsEdit.VacationScheduleInformationImport(
                dataGridViewVacationSchedules.CurrentRow.Cells["Дата составления"].Value.ToString(),
                dataGridViewVacationSchedules.CurrentRow.Cells["Название графика отпусков"].Value.ToString(),
                dataGridViewVacationSchedules.CurrentRow.Cells["На год"].Value.ToString(),
                dataGridViewVacationSchedules.CurrentRow.Cells["Утвержден"].Value.ToString(),
                dataGridViewVacationSchedules.CurrentRow.Cells["Дата утверждения"].Value.ToString());
            EmployeesVacationsEdit.ShowDialog();
        }

        //процедура удаления графика отпусков 
        private void DeleteVacationSchedule_Click(object sender, EventArgs e)
        {
            if (UserAgree())
            {
                if (!DB_Connection.VacationScheduleIsNotEmpty(dataGridViewVacationSchedules.
                    CurrentRow.Cells["Vacation_schedule_id"].Value.ToString()))
                {
                    DB_Connection.DeleteVacationSchedule(dataGridViewVacationSchedules.
                    CurrentRow.Cells["Vacation_schedule_id"].Value.ToString());
                    MessageBox.Show("График отпусков удален!");
                    DB_Connection.ShowVacationSchedules();
                }
                else MessageBox.Show("Перед удалением графика отпусков необходимо удалить все имеющиеся в нем записи!");
            }
        }

        
        //СПРАВОЧНИК "ВИДЫ ОТПУСКОВ"
        //процедура настройки и показа формы для отображения справочника "Виды отпусков"
        public void ShowVacationTypesTab()
        {
            AllTabsHide();
            tabPageVacationTypes.Parent = tabControlEmployeesVacations;
        }

        //процедура открытия формы с полями ввода для добавления в справочник "Виды отпусков"
        private void btnAddVacationType_Click(object sender, EventArgs e)
        {
            EmployeesVacationsEditForm EmployeesVacationsEdit = new EmployeesVacationsEditForm();
            EmployeesVacationsEdit.ShowVacationTypesTabToAdd();
            EmployeesVacationsEdit.ShowDialog();
        }

        //процедура открытия формы с полями ввода для редактирования данных в справочнике "Виды отпусков"
        private void btnChangeVacationType_Click(object sender, EventArgs e)
        {
            NumberOfEditRecord = dataGridViewVacationTypes.CurrentRow.Cells["Vacation_type_id"].Value.ToString();
            Vacation = dataGridViewVacationTypes.CurrentRow.Cells[1].Value.ToString();           
            EmployeesVacationsEditForm EmployeesVacationsEdit = new EmployeesVacationsEditForm();
            EmployeesVacationsEdit.ShowVacationTypesTabToChange();
            EmployeesVacationsEdit.VacationTypeImport(Vacation, 
                dataGridViewVacationTypes.CurrentRow.Cells["Количество оплачиваемых дней"].Value.ToString(),
                dataGridViewVacationTypes.CurrentRow.Cells["Количество неоплачиваемых дней"].Value.ToString());
            EmployeesVacationsEdit.ShowDialog();
        }

        //процедура удаления записи из справочника "Виды отпусков"
        private void btnDeleteVacationType_Click(object sender, EventArgs e)
        {
            if (dataGridViewVacationTypes.CurrentRow.Cells["Вид отпуска"].Value.ToString() ==
                "основной оплачиваемый")
            {
                MessageBox.Show("Данный вид отпуска не может быть удален!");
                return;
            }
            if (DB_Connection.UsingVacationType(dataGridViewVacationTypes.
                CurrentRow.Cells["Вид отпуска"].Value.ToString()))
            {
                MessageBox.Show("Данный вид отпуска используется! Удаление невозможно!");
                return;
            }
            if (UserAgree())
            {
                DB_Connection.DeleteVacationType(dataGridViewVacationTypes.CurrentRow.
                    Cells["Vacation_type_id"].Value.ToString());               
                MessageBox.Show("Запись удалена!");
                DB_Connection.ShowVacationTypes();
            }
        }


        //ТАБЛИЦА "РАСХОДОВАНИЕ ОТПУСКОВ"
        //процедура настройки и показа формы для отображения таблицы "Расходование отпусков"
        public void ShowSpendingOfVacationTub()
        {
            AllTabsHide();
            tabPageSpendingOfVacations.Parent = tabControlEmployeesVacations;
        }

        //процедура открытия формы с полями ввода для добавления в таблицу "Расходование отпусков" 
        private void btnAddSpendingOfVacationInformation_Click(object sender, EventArgs e)
        {
            EmployeesVacationsEditForm EmployeesVacationsEdit = new EmployeesVacationsEditForm();
            EmployeesVacationsEdit.ShowSpendingOfVacationsToAdd();
            EmployeesVacationsEdit.ShowDialog();
        }

        //процедура открытия формы с полями ввода для редактирования данных в таблице "Расходование отпусков"
        private void btnChangeSpendingOfVacationInformation_Click(object sender, EventArgs e)
        {
            string TheNumber = DB_Connection.GetPersonnelNumberFromEmployees(
                dataGridViewSpendingOfVacations.CurrentRow.Cells["Сотрудник"].Value.ToString());
            string TheVacation = DB_Connection.GetVacationTypeId(
                dataGridViewSpendingOfVacations.CurrentRow.Cells["Вид отпуска"].Value.ToString());
            if (!DB_Connection.EmployeesVacationAlreadyInVacationSchedule(TheNumber, TheVacation))
            {
                NumberOfEditRecord = dataGridViewSpendingOfVacations.CurrentRow.
                    Cells["Position_id"].Value.ToString();
                importVacationist = DB_Connection.GetPersonnelNumberFromEmployees(
                    dataGridViewSpendingOfVacations.CurrentRow.Cells["Сотрудник"].Value.ToString());
                importTypeOfVacation = DB_Connection.GetVacationTypeId(
                    dataGridViewSpendingOfVacations.CurrentRow.Cells["Вид отпуска"].Value.ToString());
                Vacationist = dataGridViewSpendingOfVacations.CurrentRow.Cells["Сотрудник"].Value.ToString();
                vacationType = dataGridViewSpendingOfVacations.CurrentRow.Cells["Вид отпуска"].Value.ToString();
                EmployeesVacationsEditForm EmployeesVacationsEdit = new EmployeesVacationsEditForm();
                EmployeesVacationsEdit.ShowSpendingOfVacationsToChange();
                EmployeesVacationsEdit.ShowDialog();
            }
            else MessageBox.Show("Перед изменением назначеного отпуска необходимо удалить " +
                "сведения об его использовании в графике отпусков!");
        }

        //процедура удаления записи из таблицы "Расходование отпусков"
        private void btnDeleteSpendingOfVacationInformation_Click(object sender, EventArgs e)
        {
            string TheNumber = DB_Connection.GetPersonnelNumberFromEmployees(
                dataGridViewSpendingOfVacations.CurrentRow.Cells["Сотрудник"].Value.ToString());
            string TheVacation = DB_Connection.GetVacationTypeId(
                dataGridViewSpendingOfVacations.CurrentRow.Cells["Вид отпуска"].Value.ToString());
            if (!DB_Connection.EmployeesVacationAlreadyInVacationSchedule(TheNumber,TheVacation))
            {
                if (UserAgree())
                {
                    //удаляем запись из таблицы учета отсавшихся дней отпуска в графике отпусков
                    DB_Connection.DeleteFromSpendingOfVacations(dataGridViewSpendingOfVacations.
                        CurrentRow.Cells["Position_id"].Value.ToString());
                    //удаляем запись из таблицы учета отсавшихся дней отпуска в журнале ведения отпусков
                    string TheRecord = DB_Connection.GetRealVacationSpendingRecordId(TheNumber, TheVacation);
                    DB_Connection.DeleteFromRealVacationSpending(TheRecord);
                    //информируем пользователя о выполнении операции
                    MessageBox.Show("Запись удалена!");
                    DB_Connection.ShowSpendingOfVacations();
                }
            }
            else MessageBox.Show("Перед удалением назначенного отпуска необходимо удалить " +
                "сведения об его использовании в графике отпусков!");
        }

        //ТАБЛИЦА "ПЕРИОДЫ ПРЕДОСТАВЛЕНИЯ ОПЛАЧИВАЕМОГО ПРОЕЗДА" (ДОРОЖНЫЕ)
        //процедура настройки и показа формы для отображения
        //таблицы "Периоды предоставления оплачиваемого проезда"
        public void ShowEmployeesPaidTravelTab()
        {
            AllTabsHide();
            tabPageEmployeesPaidTravel.Parent = tabControlEmployeesVacations;
        }

        //процедура открытия формы с полями ввода для добавления
        //в таблицу "Периоды предоставления оплачиваемого проезда"
        private void btnAddEmployeesPaidTravel_Click(object sender, EventArgs e)
        {
            EmployeesVacationsEditForm EmployeesVacationsEdit = new EmployeesVacationsEditForm();
            EmployeesVacationsEdit.ShowEmployeesPaidTravelToAdd();
            EmployeesVacationsEdit.ShowDialog();
        }

        //процедура открытия формы с полями ввода для редактирования
        //данных в таблице "Периоды предоставления оплачиваемого проезда"
        private void btnChangeEmployeesPaidTravel_Click(object sender, EventArgs e)
        {
            NumberOfEditRecord = dataGridViewEmployeesPaidTravel.
                CurrentRow.Cells["Position_id"].Value.ToString();
            EmployeesVacationsEditForm EmployeesVacationsEdit = new EmployeesVacationsEditForm();
            EmployeesVacationsEdit.EmployeesPaidTravelImport(
                dataGridViewEmployeesPaidTravel.CurrentRow.Cells["Дорожные: начало периода"].Value.ToString(),
                dataGridViewEmployeesPaidTravel.CurrentRow.Cells["Дорожные: конец периода"].Value.ToString());
            importTraveler = DB_Connection.GetPersonnelNumberFromEmployees(
                dataGridViewEmployeesPaidTravel.CurrentRow.Cells["Сотрудник"].Value.ToString());
            EmployeesVacationsEdit.ShowEmployeesPaidTravelToChange();
            EmployeesVacationsEdit.ShowDialog();
        }

        //процедура удаления периода предоставления оплачиваемого проезда сотруднику
        private void btnDeleteEmployeesPaidTravel_Click(object sender, EventArgs e)
        {
            if (UserAgree())
            {
                DB_Connection.DeleteEmployeesPaidTravel(dataGridViewEmployeesPaidTravel.
                    CurrentRow.Cells["Position_id"].Value.ToString());
                MessageBox.Show("Сведения о периоде предоставления оплачиваемого проезда сотруднику удалены!");
                DB_Connection.ShowEmployeesPaidTravel();
            }
        }
    }
}
