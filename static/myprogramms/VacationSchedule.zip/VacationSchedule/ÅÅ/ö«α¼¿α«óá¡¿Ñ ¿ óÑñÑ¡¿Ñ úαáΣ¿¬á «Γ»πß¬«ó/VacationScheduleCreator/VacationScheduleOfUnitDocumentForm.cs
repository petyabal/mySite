﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace VacationScheduleCreator
{
    public partial class VacationScheduleOfUnitDocumentForm : Form
    {
        public VacationScheduleOfUnitDocumentForm()
        {
            InitializeComponent();
        }
        string initialMoment = "now";

        //процедура загрузки информации из таблиц БД
        private void VacationScheduleOfUnitDocumentForm_Load(object sender, EventArgs e)
        {
            DB_Connection.ShowVacationSchedules();
            dataGridViewVacationSchedules.DataSource = DB_Connection.dtVacationSchedules;
            if (dataGridViewVacationSchedules.RowCount != 0)
            {
                if (initialMoment == "now")
                {
                    DB_Connection.ShowUnitVacationScheduleDocument(dataGridViewVacationSchedules.
                        Rows[0].Cells["Vacation_schedule_id"].Value.ToString());
                    dataGridViewVacationScheduleOfUnit.DataSource = DB_Connection.dtUnitVacationScheduleDocument;
                    dataGridViewVacationScheduleOfUnit.Columns["Вид отпуска"].Visible = false;
                    initialMoment = "lost";
                }
                else
                {
                    DB_Connection.ShowUnitVacationScheduleDocument(dataGridViewVacationSchedules.
                        CurrentRow.Cells["Vacation_schedule_id"].Value.ToString());
                    dataGridViewVacationScheduleOfUnit.DataSource = DB_Connection.dtUnitVacationScheduleDocument;
                    dataGridViewVacationScheduleOfUnit.Columns["Вид отпуска"].Visible = false;
                }
            }
        }

        //процедура формирования графика отпусков из таблицы
        private void btnVacationScheduleOfUnitCreate_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;
            Excel.OpenExcel(Application.StartupPath + @"\UnitVacationScheduleTemplate.xlsx");
            string Path_to_file = Application.StartupPath + @"\Excel documents\График отпусков_" +
                DateTime.Now.ToString("yyyy-MM-dd_hh-mm-ss") + ".xlsx";
            Excel.workSheet.Cells[8, 4].Value = dataGridViewVacationSchedules.
                CurrentRow.Cells["Структурное подразделение"].Value.ToString();
            DateTime theDate = Convert.ToDateTime(dataGridViewVacationSchedules.
                CurrentRow.Cells["Дата составления"].Value);
            Excel.workSheet.Cells[8, 5].Value = theDate.ToString("dd.MM.yyyy");
            Excel.workSheet.Cells[8, 6].Value = dataGridViewVacationSchedules.
                CurrentRow.Cells["На год"].Value.ToString();
            int k = -1;
            string tab = dataGridViewVacationScheduleOfUnit.Rows[0].Cells[0].Value.ToString();
            for (Int32 i = 0; i < dataGridViewVacationScheduleOfUnit.RowCount; i++)
            {
                if (tab == dataGridViewVacationScheduleOfUnit.Rows[i].Cells[0].Value.ToString())
                    k++;
                else
                {
                    Excel.workSheet.Range[Excel.workSheet.Cells[i - k + 13, 2], Excel.workSheet.Cells[i + 13, 2]].Merge();
                    Excel.workSheet.Range[Excel.workSheet.Cells[i - k + 13, 3], Excel.workSheet.Cells[i + 13, 3]].Merge();
                    Excel.workSheet.Range[Excel.workSheet.Cells[i - k + 13, 3], Excel.workSheet.Cells[i + 13, 3]].HorizontalAlignment = Excel.excelAlign;
                    //Excel.workSheet.Range[Excel.workSheet.Cells[i - k + 13, 4], Excel.workSheet.Cells[i - k + 13, 4]].AutoFit();
                    Excel.workSheet.Range[Excel.workSheet.Cells[i - k + 13, 4], Excel.workSheet.Cells[i + 13, 4]].Merge();
                    k = 0;
                    tab = dataGridViewVacationScheduleOfUnit.Rows[i].Cells[0].Value.ToString();
                }
                for (Int32 j = 1; j < dataGridViewVacationScheduleOfUnit.ColumnCount - 1; j++)
                {
                    Excel.workSheet.Cells[i + 14, j + 1].Value =
                        dataGridViewVacationScheduleOfUnit.Rows[i].Cells[j].Value;
                }
            }
            for (Int32 i = 0; i < dataGridViewVacationScheduleOfUnit.RowCount; i++)
                Excel.workSheet.Cells[i + 14, 1].Value = (i + 1).ToString();
            Excel.workBook.SaveAs(Path_to_file);
            MessageBox.Show("Данные успешно сохранены в файл!");
            this.Cursor = Cursors.Default;
        }

        //выбор нужного графика отпусков из таблицы
        private void dataGridViewVacationSchedules_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridViewVacationSchedules.RowCount != 0)
            {
                if (e.RowIndex != -1)
                {
                    DB_Connection.ShowUnitVacationScheduleDocument(dataGridViewVacationSchedules.CurrentRow.
                        Cells["Vacation_schedule_id"].Value.ToString());
                    CalculateDays();
                }
                else return;
            } 
        }

        void CalculateDays()
        {
            for (int i = 0; i < dataGridViewVacationScheduleOfUnit.RowCount; i++)
            {
                string person = dataGridViewVacationScheduleOfUnit.Rows[i].Cells["Табельный номер"].
                    Value.ToString();
                string type = DB_Connection.GetVacationTypeId(
                    dataGridViewVacationScheduleOfUnit.Rows[i].Cells["Вид отпуска"].Value.ToString());
                dataGridViewVacationScheduleOfUnit.Rows[i].Cells["Продолжительность отпуска"].
                    Value = DB_Connection.GetSumDays(person, type);
            }
        }
    }
}
