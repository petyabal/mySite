﻿namespace VacationScheduleCreator
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.statusStripActiveUser = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusUser = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusActiveUser = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusDelimiter = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusRole = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusActiveRole = new System.Windows.Forms.ToolStripStatusLabel();
            this.tableLayoutPanel_AllForm = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel_Company = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBoxCompany = new System.Windows.Forms.PictureBox();
            this.lblCompany = new System.Windows.Forms.Label();
            this.tableLayoutPanel_MainMenu = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel_MenuOptions = new System.Windows.Forms.TableLayoutPanel();
            this.btnVacationLogReport = new System.Windows.Forms.Button();
            this.btnAllCompanyVacationSchedule = new System.Windows.Forms.Button();
            this.btnVacationScheduleOfUnit = new System.Windows.Forms.Button();
            this.btnOrganizationSettings = new System.Windows.Forms.Button();
            this.btnUserChange = new System.Windows.Forms.Button();
            this.btnCloseApplication = new System.Windows.Forms.Button();
            this.btnEmployees = new System.Windows.Forms.Button();
            this.btnEmployeesVacations = new System.Windows.Forms.Button();
            this.btnStaffingTable = new System.Windows.Forms.Button();
            this.btnDaysCreditReport = new System.Windows.Forms.Button();
            this.btnDaysRemainReport = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.tableLayoutPanel_MenuHeader = new System.Windows.Forms.TableLayoutPanel();
            this.btnPause = new System.Windows.Forms.Button();
            this.btnUserProfile = new System.Windows.Forms.Button();
            this.btnReports = new System.Windows.Forms.Button();
            this.btnInformation = new System.Windows.Forms.Button();
            this.lblMainMenu = new System.Windows.Forms.Label();
            this.tableLayoutPanel_Programm = new System.Windows.Forms.TableLayoutPanel();
            this.lblProgramm = new System.Windows.Forms.Label();
            this.statusStripActiveUser.SuspendLayout();
            this.tableLayoutPanel_AllForm.SuspendLayout();
            this.tableLayoutPanel_Company.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCompany)).BeginInit();
            this.tableLayoutPanel_MainMenu.SuspendLayout();
            this.tableLayoutPanel_MenuOptions.SuspendLayout();
            this.tableLayoutPanel_MenuHeader.SuspendLayout();
            this.tableLayoutPanel_Programm.SuspendLayout();
            this.SuspendLayout();
            // 
            // statusStripActiveUser
            // 
            this.statusStripActiveUser.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.statusStripActiveUser.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusUser,
            this.toolStripStatusActiveUser,
            this.toolStripStatusDelimiter,
            this.toolStripStatusRole,
            this.toolStripStatusActiveRole});
            this.statusStripActiveUser.Location = new System.Drawing.Point(0, 571);
            this.statusStripActiveUser.Name = "statusStripActiveUser";
            this.statusStripActiveUser.Size = new System.Drawing.Size(989, 28);
            this.statusStripActiveUser.TabIndex = 3;
            this.statusStripActiveUser.Text = "statusStrip1";
            // 
            // toolStripStatusUser
            // 
            this.toolStripStatusUser.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.toolStripStatusUser.Name = "toolStripStatusUser";
            this.toolStripStatusUser.Size = new System.Drawing.Size(117, 23);
            this.toolStripStatusUser.Text = "Пользователь:";
            // 
            // toolStripStatusActiveUser
            // 
            this.toolStripStatusActiveUser.Name = "toolStripStatusActiveUser";
            this.toolStripStatusActiveUser.Size = new System.Drawing.Size(0, 23);
            // 
            // toolStripStatusDelimiter
            // 
            this.toolStripStatusDelimiter.Name = "toolStripStatusDelimiter";
            this.toolStripStatusDelimiter.Size = new System.Drawing.Size(22, 23);
            this.toolStripStatusDelimiter.Text = "   ";
            // 
            // toolStripStatusRole
            // 
            this.toolStripStatusRole.Name = "toolStripStatusRole";
            this.toolStripStatusRole.Size = new System.Drawing.Size(50, 23);
            this.toolStripStatusRole.Text = "Роль:";
            // 
            // toolStripStatusActiveRole
            // 
            this.toolStripStatusActiveRole.Name = "toolStripStatusActiveRole";
            this.toolStripStatusActiveRole.Size = new System.Drawing.Size(0, 23);
            // 
            // tableLayoutPanel_AllForm
            // 
            this.tableLayoutPanel_AllForm.ColumnCount = 1;
            this.tableLayoutPanel_AllForm.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_AllForm.Controls.Add(this.tableLayoutPanel_Company, 0, 1);
            this.tableLayoutPanel_AllForm.Controls.Add(this.tableLayoutPanel_MainMenu, 0, 2);
            this.tableLayoutPanel_AllForm.Controls.Add(this.tableLayoutPanel_Programm, 0, 0);
            this.tableLayoutPanel_AllForm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_AllForm.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel_AllForm.Name = "tableLayoutPanel_AllForm";
            this.tableLayoutPanel_AllForm.RowCount = 3;
            this.tableLayoutPanel_AllForm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel_AllForm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel_AllForm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.tableLayoutPanel_AllForm.Size = new System.Drawing.Size(989, 571);
            this.tableLayoutPanel_AllForm.TabIndex = 6;
            // 
            // tableLayoutPanel_Company
            // 
            this.tableLayoutPanel_Company.BackColor = System.Drawing.SystemColors.HotTrack;
            this.tableLayoutPanel_Company.ColumnCount = 4;
            this.tableLayoutPanel_Company.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8F));
            this.tableLayoutPanel_Company.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel_Company.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 54F));
            this.tableLayoutPanel_Company.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8F));
            this.tableLayoutPanel_Company.Controls.Add(this.pictureBoxCompany, 1, 1);
            this.tableLayoutPanel_Company.Controls.Add(this.lblCompany, 2, 1);
            this.tableLayoutPanel_Company.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Company.Location = new System.Drawing.Point(3, 60);
            this.tableLayoutPanel_Company.Name = "tableLayoutPanel_Company";
            this.tableLayoutPanel_Company.RowCount = 3;
            this.tableLayoutPanel_Company.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel_Company.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tableLayoutPanel_Company.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel_Company.Size = new System.Drawing.Size(983, 108);
            this.tableLayoutPanel_Company.TabIndex = 7;
            // 
            // pictureBoxCompany
            // 
            this.pictureBoxCompany.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxCompany.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxCompany.Image")));
            this.pictureBoxCompany.Location = new System.Drawing.Point(81, 8);
            this.pictureBoxCompany.Name = "pictureBoxCompany";
            this.pictureBoxCompany.Size = new System.Drawing.Size(288, 91);
            this.pictureBoxCompany.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxCompany.TabIndex = 3;
            this.pictureBoxCompany.TabStop = false;
            // 
            // lblCompany
            // 
            this.lblCompany.AutoSize = true;
            this.lblCompany.BackColor = System.Drawing.SystemColors.HotTrack;
            this.lblCompany.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCompany.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblCompany.ForeColor = System.Drawing.Color.White;
            this.lblCompany.Location = new System.Drawing.Point(375, 5);
            this.lblCompany.Name = "lblCompany";
            this.lblCompany.Size = new System.Drawing.Size(524, 97);
            this.lblCompany.TabIndex = 2;
            this.lblCompany.Text = "МЕЖРЕГИОНАЛЬНАЯ РАСПРЕДЕЛИТЕЛЬНАЯ СЕТЕВАЯ КОМПАНИЯ СЕВЕРО-ЗАПАДА";
            this.lblCompany.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel_MainMenu
            // 
            this.tableLayoutPanel_MainMenu.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPanel_MainMenu.ColumnCount = 1;
            this.tableLayoutPanel_MainMenu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_MainMenu.Controls.Add(this.tableLayoutPanel_MenuOptions, 0, 1);
            this.tableLayoutPanel_MainMenu.Controls.Add(this.tableLayoutPanel_MenuHeader, 0, 0);
            this.tableLayoutPanel_MainMenu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_MainMenu.Location = new System.Drawing.Point(3, 174);
            this.tableLayoutPanel_MainMenu.Name = "tableLayoutPanel_MainMenu";
            this.tableLayoutPanel_MainMenu.RowCount = 2;
            this.tableLayoutPanel_MainMenu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel_MainMenu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.tableLayoutPanel_MainMenu.Size = new System.Drawing.Size(983, 394);
            this.tableLayoutPanel_MainMenu.TabIndex = 6;
            // 
            // tableLayoutPanel_MenuOptions
            // 
            this.tableLayoutPanel_MenuOptions.ColumnCount = 4;
            this.tableLayoutPanel_MenuOptions.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_MenuOptions.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_MenuOptions.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_MenuOptions.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_MenuOptions.Controls.Add(this.btnVacationLogReport, 1, 2);
            this.tableLayoutPanel_MenuOptions.Controls.Add(this.btnAllCompanyVacationSchedule, 1, 0);
            this.tableLayoutPanel_MenuOptions.Controls.Add(this.btnVacationScheduleOfUnit, 1, 1);
            this.tableLayoutPanel_MenuOptions.Controls.Add(this.btnOrganizationSettings, 0, 0);
            this.tableLayoutPanel_MenuOptions.Controls.Add(this.btnUserChange, 3, 0);
            this.tableLayoutPanel_MenuOptions.Controls.Add(this.btnCloseApplication, 3, 1);
            this.tableLayoutPanel_MenuOptions.Controls.Add(this.btnEmployees, 0, 1);
            this.tableLayoutPanel_MenuOptions.Controls.Add(this.btnEmployeesVacations, 0, 2);
            this.tableLayoutPanel_MenuOptions.Controls.Add(this.btnStaffingTable, 0, 3);
            this.tableLayoutPanel_MenuOptions.Controls.Add(this.btnDaysCreditReport, 1, 4);
            this.tableLayoutPanel_MenuOptions.Controls.Add(this.btnDaysRemainReport, 1, 3);
            this.tableLayoutPanel_MenuOptions.Controls.Add(this.button8, 2, 0);
            this.tableLayoutPanel_MenuOptions.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_MenuOptions.Location = new System.Drawing.Point(3, 118);
            this.tableLayoutPanel_MenuOptions.Margin = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.tableLayoutPanel_MenuOptions.Name = "tableLayoutPanel_MenuOptions";
            this.tableLayoutPanel_MenuOptions.RowCount = 6;
            this.tableLayoutPanel_MenuOptions.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel_MenuOptions.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel_MenuOptions.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel_MenuOptions.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel_MenuOptions.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel_MenuOptions.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel_MenuOptions.Size = new System.Drawing.Size(977, 273);
            this.tableLayoutPanel_MenuOptions.TabIndex = 7;
            // 
            // btnVacationLogReport
            // 
            this.btnVacationLogReport.BackColor = System.Drawing.SystemColors.Control;
            this.btnVacationLogReport.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnVacationLogReport.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnVacationLogReport.Font = new System.Drawing.Font("Arial Narrow", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnVacationLogReport.Location = new System.Drawing.Point(246, 90);
            this.btnVacationLogReport.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.btnVacationLogReport.Name = "btnVacationLogReport";
            this.btnVacationLogReport.Size = new System.Drawing.Size(240, 45);
            this.btnVacationLogReport.TabIndex = 16;
            this.btnVacationLogReport.Text = "Журнал фактических отпусков";
            this.btnVacationLogReport.UseVisualStyleBackColor = false;
            this.btnVacationLogReport.Visible = false;
            this.btnVacationLogReport.Click += new System.EventHandler(this.btnVacationLogReport_Click);
            // 
            // btnAllCompanyVacationSchedule
            // 
            this.btnAllCompanyVacationSchedule.BackColor = System.Drawing.SystemColors.Control;
            this.btnAllCompanyVacationSchedule.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnAllCompanyVacationSchedule.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAllCompanyVacationSchedule.Font = new System.Drawing.Font("Arial Narrow", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnAllCompanyVacationSchedule.Location = new System.Drawing.Point(246, 0);
            this.btnAllCompanyVacationSchedule.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.btnAllCompanyVacationSchedule.Name = "btnAllCompanyVacationSchedule";
            this.btnAllCompanyVacationSchedule.Size = new System.Drawing.Size(240, 45);
            this.btnAllCompanyVacationSchedule.TabIndex = 15;
            this.btnAllCompanyVacationSchedule.Text = "График отпусков предприятия";
            this.btnAllCompanyVacationSchedule.UseVisualStyleBackColor = false;
            this.btnAllCompanyVacationSchedule.Visible = false;
            this.btnAllCompanyVacationSchedule.Click += new System.EventHandler(this.btnAllCompanyVacationSchedule_Click);
            // 
            // btnVacationScheduleOfUnit
            // 
            this.btnVacationScheduleOfUnit.BackColor = System.Drawing.SystemColors.Control;
            this.btnVacationScheduleOfUnit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnVacationScheduleOfUnit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnVacationScheduleOfUnit.Font = new System.Drawing.Font("Arial Narrow", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnVacationScheduleOfUnit.Location = new System.Drawing.Point(246, 45);
            this.btnVacationScheduleOfUnit.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.btnVacationScheduleOfUnit.Name = "btnVacationScheduleOfUnit";
            this.btnVacationScheduleOfUnit.Size = new System.Drawing.Size(240, 45);
            this.btnVacationScheduleOfUnit.TabIndex = 14;
            this.btnVacationScheduleOfUnit.Text = "График отпусков подразделения";
            this.btnVacationScheduleOfUnit.UseVisualStyleBackColor = false;
            this.btnVacationScheduleOfUnit.Visible = false;
            this.btnVacationScheduleOfUnit.Click += new System.EventHandler(this.btnVacationScheduleOfUnit_Click);
            // 
            // btnOrganizationSettings
            // 
            this.btnOrganizationSettings.BackColor = System.Drawing.SystemColors.Control;
            this.btnOrganizationSettings.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnOrganizationSettings.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnOrganizationSettings.Font = new System.Drawing.Font("Arial Narrow", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnOrganizationSettings.Location = new System.Drawing.Point(2, 0);
            this.btnOrganizationSettings.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.btnOrganizationSettings.Name = "btnOrganizationSettings";
            this.btnOrganizationSettings.Size = new System.Drawing.Size(240, 45);
            this.btnOrganizationSettings.TabIndex = 13;
            this.btnOrganizationSettings.Text = "Организационные настройки";
            this.btnOrganizationSettings.UseVisualStyleBackColor = false;
            this.btnOrganizationSettings.Visible = false;
            this.btnOrganizationSettings.Click += new System.EventHandler(this.btnOrganizationSettings_Click);
            // 
            // btnUserChange
            // 
            this.btnUserChange.BackColor = System.Drawing.SystemColors.Control;
            this.btnUserChange.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnUserChange.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnUserChange.Font = new System.Drawing.Font("Arial Narrow", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnUserChange.Location = new System.Drawing.Point(734, 0);
            this.btnUserChange.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.btnUserChange.Name = "btnUserChange";
            this.btnUserChange.Size = new System.Drawing.Size(241, 45);
            this.btnUserChange.TabIndex = 0;
            this.btnUserChange.Text = "Сменить пользователя";
            this.btnUserChange.UseVisualStyleBackColor = false;
            this.btnUserChange.Visible = false;
            this.btnUserChange.Click += new System.EventHandler(this.btnUserChange_Click);
            // 
            // btnCloseApplication
            // 
            this.btnCloseApplication.BackColor = System.Drawing.SystemColors.Control;
            this.btnCloseApplication.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnCloseApplication.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCloseApplication.Font = new System.Drawing.Font("Arial Narrow", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnCloseApplication.Location = new System.Drawing.Point(734, 45);
            this.btnCloseApplication.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.btnCloseApplication.Name = "btnCloseApplication";
            this.btnCloseApplication.Size = new System.Drawing.Size(241, 45);
            this.btnCloseApplication.TabIndex = 4;
            this.btnCloseApplication.Text = "Закрыть приложение";
            this.btnCloseApplication.UseVisualStyleBackColor = false;
            this.btnCloseApplication.Visible = false;
            this.btnCloseApplication.Click += new System.EventHandler(this.btnCloseApplication_Click);
            // 
            // btnEmployees
            // 
            this.btnEmployees.BackColor = System.Drawing.SystemColors.Control;
            this.btnEmployees.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnEmployees.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnEmployees.Font = new System.Drawing.Font("Arial Narrow", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnEmployees.Location = new System.Drawing.Point(2, 45);
            this.btnEmployees.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.btnEmployees.Name = "btnEmployees";
            this.btnEmployees.Size = new System.Drawing.Size(240, 45);
            this.btnEmployees.TabIndex = 5;
            this.btnEmployees.Text = "Сотрудники";
            this.btnEmployees.UseVisualStyleBackColor = false;
            this.btnEmployees.Visible = false;
            this.btnEmployees.Click += new System.EventHandler(this.btnEmployees_Click);
            // 
            // btnEmployeesVacations
            // 
            this.btnEmployeesVacations.BackColor = System.Drawing.SystemColors.Control;
            this.btnEmployeesVacations.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnEmployeesVacations.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnEmployeesVacations.Font = new System.Drawing.Font("Arial Narrow", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnEmployeesVacations.Location = new System.Drawing.Point(2, 90);
            this.btnEmployeesVacations.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.btnEmployeesVacations.Name = "btnEmployeesVacations";
            this.btnEmployeesVacations.Size = new System.Drawing.Size(240, 45);
            this.btnEmployeesVacations.TabIndex = 6;
            this.btnEmployeesVacations.Text = "Отпуска сотрудников";
            this.btnEmployeesVacations.UseVisualStyleBackColor = false;
            this.btnEmployeesVacations.Visible = false;
            this.btnEmployeesVacations.Click += new System.EventHandler(this.btnVacationSchedules_Click);
            // 
            // btnStaffingTable
            // 
            this.btnStaffingTable.BackColor = System.Drawing.SystemColors.Control;
            this.btnStaffingTable.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnStaffingTable.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnStaffingTable.Font = new System.Drawing.Font("Arial Narrow", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnStaffingTable.Location = new System.Drawing.Point(2, 135);
            this.btnStaffingTable.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.btnStaffingTable.Name = "btnStaffingTable";
            this.btnStaffingTable.Size = new System.Drawing.Size(240, 45);
            this.btnStaffingTable.TabIndex = 7;
            this.btnStaffingTable.Text = "Штатное расписание";
            this.btnStaffingTable.UseVisualStyleBackColor = false;
            this.btnStaffingTable.Visible = false;
            this.btnStaffingTable.Click += new System.EventHandler(this.btnStaffingTable_Click);
            // 
            // btnDaysCreditReport
            // 
            this.btnDaysCreditReport.BackColor = System.Drawing.SystemColors.Control;
            this.btnDaysCreditReport.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnDaysCreditReport.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnDaysCreditReport.Font = new System.Drawing.Font("Arial Narrow", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnDaysCreditReport.Location = new System.Drawing.Point(246, 180);
            this.btnDaysCreditReport.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.btnDaysCreditReport.Name = "btnDaysCreditReport";
            this.btnDaysCreditReport.Size = new System.Drawing.Size(240, 45);
            this.btnDaysCreditReport.TabIndex = 8;
            this.btnDaysCreditReport.Text = "Дни в счет будущего отпуска";
            this.btnDaysCreditReport.UseVisualStyleBackColor = false;
            this.btnDaysCreditReport.Visible = false;
            this.btnDaysCreditReport.Click += new System.EventHandler(this.btnDaysCreditReport_Click);
            // 
            // btnDaysRemainReport
            // 
            this.btnDaysRemainReport.BackColor = System.Drawing.SystemColors.Control;
            this.btnDaysRemainReport.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnDaysRemainReport.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnDaysRemainReport.Font = new System.Drawing.Font("Arial Narrow", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnDaysRemainReport.Location = new System.Drawing.Point(246, 135);
            this.btnDaysRemainReport.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.btnDaysRemainReport.Name = "btnDaysRemainReport";
            this.btnDaysRemainReport.Size = new System.Drawing.Size(240, 45);
            this.btnDaysRemainReport.TabIndex = 9;
            this.btnDaysRemainReport.Text = "Неизрасходованные дни отпуска";
            this.btnDaysRemainReport.UseVisualStyleBackColor = false;
            this.btnDaysRemainReport.Visible = false;
            this.btnDaysRemainReport.Click += new System.EventHandler(this.btnDaysRemainReport_Click);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.SystemColors.Control;
            this.button8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button8.Font = new System.Drawing.Font("Arial Narrow", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button8.Location = new System.Drawing.Point(490, 0);
            this.button8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(240, 45);
            this.button8.TabIndex = 12;
            this.button8.Text = "Редактировать учетную запись";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Visible = false;
            // 
            // tableLayoutPanel_MenuHeader
            // 
            this.tableLayoutPanel_MenuHeader.ColumnCount = 4;
            this.tableLayoutPanel_MenuHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_MenuHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_MenuHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_MenuHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_MenuHeader.Controls.Add(this.btnPause, 3, 1);
            this.tableLayoutPanel_MenuHeader.Controls.Add(this.btnUserProfile, 2, 1);
            this.tableLayoutPanel_MenuHeader.Controls.Add(this.btnReports, 1, 1);
            this.tableLayoutPanel_MenuHeader.Controls.Add(this.btnInformation, 0, 1);
            this.tableLayoutPanel_MenuHeader.Controls.Add(this.lblMainMenu, 0, 0);
            this.tableLayoutPanel_MenuHeader.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_MenuHeader.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel_MenuHeader.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.tableLayoutPanel_MenuHeader.Name = "tableLayoutPanel_MenuHeader";
            this.tableLayoutPanel_MenuHeader.RowCount = 2;
            this.tableLayoutPanel_MenuHeader.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_MenuHeader.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_MenuHeader.Size = new System.Drawing.Size(977, 115);
            this.tableLayoutPanel_MenuHeader.TabIndex = 6;
            // 
            // btnPause
            // 
            this.btnPause.BackColor = System.Drawing.SystemColors.Control;
            this.btnPause.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnPause.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPause.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnPause.Location = new System.Drawing.Point(732, 57);
            this.btnPause.Margin = new System.Windows.Forms.Padding(0);
            this.btnPause.Name = "btnPause";
            this.btnPause.Size = new System.Drawing.Size(245, 58);
            this.btnPause.TabIndex = 18;
            this.btnPause.Text = "Завершение работы";
            this.btnPause.UseVisualStyleBackColor = false;
            this.btnPause.Click += new System.EventHandler(this.btnPause_Click);
            // 
            // btnUserProfile
            // 
            this.btnUserProfile.BackColor = System.Drawing.SystemColors.Control;
            this.btnUserProfile.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnUserProfile.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUserProfile.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnUserProfile.Location = new System.Drawing.Point(488, 57);
            this.btnUserProfile.Margin = new System.Windows.Forms.Padding(0);
            this.btnUserProfile.Name = "btnUserProfile";
            this.btnUserProfile.Size = new System.Drawing.Size(244, 58);
            this.btnUserProfile.TabIndex = 17;
            this.btnUserProfile.Text = "Профиль";
            this.btnUserProfile.UseVisualStyleBackColor = false;
            this.btnUserProfile.Click += new System.EventHandler(this.btnUserProfile_Click);
            // 
            // btnReports
            // 
            this.btnReports.BackColor = System.Drawing.SystemColors.Control;
            this.btnReports.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnReports.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReports.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnReports.Location = new System.Drawing.Point(244, 57);
            this.btnReports.Margin = new System.Windows.Forms.Padding(0);
            this.btnReports.Name = "btnReports";
            this.btnReports.Size = new System.Drawing.Size(244, 58);
            this.btnReports.TabIndex = 16;
            this.btnReports.Text = "Отчеты";
            this.btnReports.UseVisualStyleBackColor = false;
            this.btnReports.Click += new System.EventHandler(this.btnReports_Click);
            // 
            // btnInformation
            // 
            this.btnInformation.BackColor = System.Drawing.SystemColors.Control;
            this.btnInformation.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnInformation.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnInformation.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnInformation.Location = new System.Drawing.Point(0, 57);
            this.btnInformation.Margin = new System.Windows.Forms.Padding(0);
            this.btnInformation.Name = "btnInformation";
            this.btnInformation.Size = new System.Drawing.Size(244, 58);
            this.btnInformation.TabIndex = 15;
            this.btnInformation.Text = "Информационная база";
            this.btnInformation.UseVisualStyleBackColor = false;
            this.btnInformation.Click += new System.EventHandler(this.btnInformation_Click);
            // 
            // lblMainMenu
            // 
            this.lblMainMenu.AutoSize = true;
            this.tableLayoutPanel_MenuHeader.SetColumnSpan(this.lblMainMenu, 4);
            this.lblMainMenu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblMainMenu.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblMainMenu.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblMainMenu.Location = new System.Drawing.Point(3, 0);
            this.lblMainMenu.Name = "lblMainMenu";
            this.lblMainMenu.Size = new System.Drawing.Size(971, 57);
            this.lblMainMenu.TabIndex = 19;
            this.lblMainMenu.Text = "ГЛАВНОЕ МЕНЮ";
            this.lblMainMenu.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel_Programm
            // 
            this.tableLayoutPanel_Programm.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPanel_Programm.ColumnCount = 1;
            this.tableLayoutPanel_Programm.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Programm.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Programm.Controls.Add(this.lblProgramm, 0, 0);
            this.tableLayoutPanel_Programm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Programm.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel_Programm.Name = "tableLayoutPanel_Programm";
            this.tableLayoutPanel_Programm.RowCount = 1;
            this.tableLayoutPanel_Programm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Programm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Programm.Size = new System.Drawing.Size(983, 51);
            this.tableLayoutPanel_Programm.TabIndex = 8;
            // 
            // lblProgramm
            // 
            this.lblProgramm.AutoSize = true;
            this.lblProgramm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblProgramm.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblProgramm.ForeColor = System.Drawing.Color.White;
            this.lblProgramm.Location = new System.Drawing.Point(3, 0);
            this.lblProgramm.Name = "lblProgramm";
            this.lblProgramm.Size = new System.Drawing.Size(977, 51);
            this.lblProgramm.TabIndex = 0;
            this.lblProgramm.Text = "ФОРМИРОВАНИЕ И ВЕДЕНИЕ ГРАФИКА ОТПУСКОВ СОТРУДНИКОВ";
            this.lblProgramm.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(989, 599);
            this.Controls.Add(this.tableLayoutPanel_AllForm);
            this.Controls.Add(this.statusStripActiveUser);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ГЛАВНОЕ МЕНЮ";
            this.Activated += new System.EventHandler(this.MainForm_Activated);
            this.statusStripActiveUser.ResumeLayout(false);
            this.statusStripActiveUser.PerformLayout();
            this.tableLayoutPanel_AllForm.ResumeLayout(false);
            this.tableLayoutPanel_Company.ResumeLayout(false);
            this.tableLayoutPanel_Company.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCompany)).EndInit();
            this.tableLayoutPanel_MainMenu.ResumeLayout(false);
            this.tableLayoutPanel_MenuOptions.ResumeLayout(false);
            this.tableLayoutPanel_MenuHeader.ResumeLayout(false);
            this.tableLayoutPanel_MenuHeader.PerformLayout();
            this.tableLayoutPanel_Programm.ResumeLayout(false);
            this.tableLayoutPanel_Programm.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.StatusStrip statusStripActiveUser;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_AllForm;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_MainMenu;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_MenuOptions;
        private System.Windows.Forms.Button btnUserChange;
        private System.Windows.Forms.Button btnCloseApplication;
        private System.Windows.Forms.Button btnEmployees;
        private System.Windows.Forms.Button btnEmployeesVacations;
        private System.Windows.Forms.Button btnStaffingTable;
        private System.Windows.Forms.Button btnDaysCreditReport;
        private System.Windows.Forms.Button btnDaysRemainReport;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_MenuHeader;
        private System.Windows.Forms.Button btnPause;
        private System.Windows.Forms.Button btnUserProfile;
        private System.Windows.Forms.Button btnReports;
        private System.Windows.Forms.Button btnInformation;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Company;
        private System.Windows.Forms.PictureBox pictureBoxCompany;
        private System.Windows.Forms.Label lblCompany;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Programm;
        private System.Windows.Forms.Label lblProgramm;
        private System.Windows.Forms.Label lblMainMenu;
        private System.Windows.Forms.Button btnOrganizationSettings;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusUser;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusActiveUser;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusRole;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusActiveRole;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusDelimiter;
        private System.Windows.Forms.Button btnVacationScheduleOfUnit;
        private System.Windows.Forms.Button btnAllCompanyVacationSchedule;
        private System.Windows.Forms.Button btnVacationLogReport;
    }
}