﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MsExcel = Microsoft.Office.Interop.Excel;//подключение библиотеки для работы с Excel
using System.Diagnostics;

namespace VacationScheduleCreator
{
    class Excel//Класс для работы с Excel-документами
    {
        static public MsExcel._Application excelApplication;//открытие MsExcel
        static public MsExcel._Workbook workBook;
        static public MsExcel._Worksheet workSheet;//лист документа
        static public MsExcel.Range excelRange;
        static public MsExcel.XlHAlign excelAlign;//для выравнивания по центру

        //процедура открытия документа Excel
        static public void OpenExcel(string FullFileName)
        {
            if (excelApplication != null) excelApplication.Quit();
            CloseExcelProcess();
            excelApplication = new MsExcel.Application();
            excelApplication.Visible = false;
            excelApplication.DisplayAlerts = false;
            workBook = excelApplication.Workbooks.Open(FullFileName);
            workSheet = excelApplication.ActiveSheet;
            excelRange = workSheet.UsedRange;
            excelAlign = MsExcel.XlHAlign.xlHAlignCenter;//значение выравнивания
        }

        //Завершение процесса работы с Excel-документом
        static public void CloseExcelProcess() 
        {
            Process[] List;
            List = Process.GetProcessesByName("EXCEL");
            foreach (Process proc in List)
            {
                proc.Kill();
            }
        }
    }
}
