﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace VacationScheduleCreator
{
    public partial class StaffingTableEditForm : Form
    {
        public StaffingTableEditForm()
        {
            InitializeComponent();
        }

        //процедура скрытия всех вкладок 
        void AllTabsHide()
        {
            tabPageStaffingTable.Parent = null;
            tabPageStaffingTablesList.Parent = null;
            tabPageStucturalUnits.Parent = null;
        }

        //процедура загрузки данных из таблиц БД
        private void StaffingTableEditForm_Load(object sender, EventArgs e)
        {

            if (tabPageStaffingTable.Parent == tabControlStaffingTableEdit)
            {
                DB_Connection.ShowFunctions();
                comboBoxFunction.DataSource = DB_Connection.dtFunctions;
                comboBoxFunction.DisplayMember = "Должность";
                comboBoxFunction.ValueMember = "Function_id";
                DB_Connection.ShowPersonnelCategories();
                comboBoxCategory.DataSource = DB_Connection.dtPersonnelCategories;
                comboBoxCategory.DisplayMember = "Сокращенное наименование";
                comboBoxCategory.ValueMember = "Category_id";
                DB_Connection.ShowEmployees();
                comboBoxEmployee.DataSource = DB_Connection.dtEmployees;
                comboBoxEmployee.DisplayMember = "Surname_NF";
                comboBoxEmployee.ValueMember = "Табельный номер";
                DB_Connection.ShowStructuralUnits();
                comboBoxStructuralUnit.DataSource = DB_Connection.dtStructuralUnits;
                comboBoxStructuralUnit.DisplayMember = "Сокращенное наименование";
                comboBoxStructuralUnit.ValueMember = "Unit_id";
            }
            if (tabPageStucturalUnits.Parent == tabControlStaffingTableEdit)
            {               
                DB_Connection.ShowHierarchyLevels();
                comboBoxHierarchyLevel.DataSource = DB_Connection.dtHierarchyLevels;
                comboBoxHierarchyLevel.DisplayMember = "Уровень иерархии";
                comboBoxHierarchyLevel.ValueMember = "Hierarchy_level_id";
                DB_Connection.ShowEmployees();
                comboBoxChief.DataSource = DB_Connection.dtEmployees;
                comboBoxChief.DisplayMember = "Surname_NF";
                comboBoxChief.ValueMember = "Табельный номер";
                DB_Connection.ShowParentUnit();
                comboBoxParentUnit.DataSource = DB_Connection.dtComboboxParentUnit;
                comboBoxParentUnit.DisplayMember = "Unit_short_title";
                comboBoxParentUnit.ValueMember = "Unit_id";
            }     
        }

        //процедура настойки формы при ее показе
        private void StaffingTableEditForm_Shown(object sender, EventArgs e)
        {
            if (tabPageStaffingTable.Parent == tabControlStaffingTableEdit)
            {
                if (tabPageStaffingTable.Text == "Редактирование записи в штатном расписании:")
                { 
                    comboBoxFunction.SelectedValue = StaffingTableDetailForm.importFunction;
                    comboBoxCategory.SelectedValue = StaffingTableDetailForm.importCategory;
                    comboBoxEmployee.SelectedValue = StaffingTableDetailForm.importEmployee;
                    comboBoxStructuralUnit.SelectedValue = StaffingTableDetailForm.importUnit;
                }
            }
            if (tabPageStucturalUnits.Parent == tabControlStaffingTableEdit)
            {
                if (tabPageStucturalUnits.Text == "Редактирование сведений о подразденении:")
                {
                    comboBoxHierarchyLevel.SelectedValue = StaffingTableDetailForm.importHierarchy;
                    comboBoxChief.SelectedValue = StaffingTableDetailForm.importChief;
                    comboBoxParentUnit.SelectedValue = StaffingTableDetailForm.importParentUnit;
                }
            }
        }

        //ТАБЛИЦА "ШТАТНОЕ РАСПИСАНИЕ"
        //Настройка формы с полями ввода для добавления новой записи в штатное расписание
        public void ShowStaffingTableTabToAdd()
        {
            AllTabsHide();
            tabPageStaffingTable.Parent = tabControlStaffingTableEdit;
            tabPageStaffingTable.Text = "Добавление записи в штатное расписание:";
        }

        //настройка формы с полями ввода для редактирования записи в штатном расписании
        public void ShowStaffingTableTabToChange()
        {
            AllTabsHide();
            tabPageStaffingTable.Parent = tabControlStaffingTableEdit;
            tabPageStaffingTable.Text = "Редактирование записи в штатном расписании:";
        }

        //процедура уменьшения, выбираемого числа дней, 
        //добавляемых к отпуску, за занимаемую должность
        private void btnToMin_Click(object sender, EventArgs e)
        {
            if (textBoxAddToVacation.Text != "0")
                textBoxAddToVacation.Text = (Convert.ToInt32(textBoxAddToVacation.Text) - 1).ToString();
        }

        //процедура увеличения, выбираемого числа дней, 
        //добавляемых к отпуску, за занимаемую должность
        private void btnToMax_Click(object sender, EventArgs e)
        {
            textBoxAddToVacation.Text = (Convert.ToInt32(textBoxAddToVacation.Text) + 1).ToString();
        }

        //отмена добавления или редактирования записи в штатном расписании
        private void btnStaffingTableCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //процедура добавления или редактрования записи в штатном расписании 
        private void btnStaffingTablePost_Click(object sender, EventArgs e)
        {
            if (!DB_Connection.StaffingTableIsApproved())
            {
                if (tabPageStaffingTable.Text == "Добавление записи в штатное расписание:")
                {
                    if (!DB_Connection.EmployeeAlreadyWorking(comboBoxEmployee.SelectedValue.ToString()))
                    {
                        DB_Connection.AddToStaffingTable(comboBoxFunction.SelectedValue.ToString(),
                            comboBoxCategory.SelectedValue.ToString(),
                            comboBoxEmployee.SelectedValue.ToString(),
                            textBoxAddToVacation.Text,
                            comboBoxStructuralUnit.SelectedValue.ToString());
                        MessageBox.Show("Запись добавлена в штатное расписание!");
                        DB_Connection.ShowStaffingTable();
                        this.Close();
                    }
                    else MessageBox.Show("Этот сотрудник уже занимает другую должность!");
                }
                if (tabPageStaffingTable.Text == "Редактирование записи в штатном расписании:")
                {
                    if (!DB_Connection.EmployeeAlreadyWorking(comboBoxEmployee.SelectedValue.ToString()) ||
                        StaffingTableDetailForm.ChangingEmployee == comboBoxEmployee.Text)
                    {
                        DB_Connection.EditInStaffingTable(StaffingTableDetailForm.NumberOfEditRecord,
                            comboBoxFunction.SelectedValue.ToString(),
                            comboBoxCategory.SelectedValue.ToString(),
                            comboBoxEmployee.SelectedValue.ToString(),
                            textBoxAddToVacation.Text,
                            comboBoxStructuralUnit.SelectedValue.ToString());
                        MessageBox.Show("Запись изменена!");
                        DB_Connection.ShowStaffingTable();
                        this.Close();
                    }
                    else MessageBox.Show("Этот сотрудник уже занимает другую должность!");
                }
            }
        }


        //ТАБЛИЦА "СВОЙСТВА ШТАТНОГО РАСПИСАНИЯ"       
        //настройка формы с полями ввода для редактирования сведений о штатном расписании
        public void ShowStaffingTableStatusTabToChange()
        {
            AllTabsHide();
            tabPageStaffingTablesList.Parent = tabControlStaffingTableEdit;
            tabPageStaffingTablesList.Text = "Редактирование сведений о штатном расписании:";
        }

        //процедура уменьшения значения года на 1 для выбора нужного года
        private void btnMinus_Click(object sender, EventArgs e)
        {
            textBoxYear.Text = (Convert.ToInt32(textBoxYear.Text) - 1).ToString();
        }

        //процедура увеличения значения года на 1 для выбора нужного года
        private void btnPlus_Click(object sender, EventArgs e)
        {
            textBoxYear.Text = (Convert.ToInt32(textBoxYear.Text) + 1).ToString();
        }

        //процедура заполнения полей ввода изменяемыми значениями
        public void StaffingTableInformationImport(string year, string status, string comment)
        {
            textBoxYear.Text = year;
            comboBoxStatus.SelectedItem = status;
            textBoxComment.Text = comment;
        }

        //отмена добавления или редактирования записи в таблице "Штатные расписания"
        private void btnStaffingTablesCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //процедура редактирования записи в таблице "Штатные расписания"
        private void btnStaffingTablesPost_Click(object sender, EventArgs e)
        {

           
            DB_Connection.EditStafingTable(StaffingTableDetailForm.NumberOfEditRecord,
            textBoxYear.Text, comboBoxStatus.SelectedItem.ToString(), textBoxComment.Text);
            MessageBox.Show("Сведения о штатном расписани изменены!");
            DB_Connection.ShowStaffingTableStatus();
            this.Close();

        }


        //ТАБЛИЦА "СТРУКТУРНЫЕ ПОДРАЗДЕЛЕНИЯ"
        //Настройка формы с полями ввода для добавления нового структурного подразделения
        public void ShowStructuralUnitsTabToAdd()
        {
            AllTabsHide();
            tabPageStucturalUnits.Parent = tabControlStaffingTableEdit;
            tabPageStucturalUnits.Text = "Добавление структурного подразделения:";
        }

        //настройка формы с полями ввода для редактирования структурного подразделения
        public void ShowStructuralUnitsTabToChange()
        {
            AllTabsHide();
            tabPageStucturalUnits.Parent = tabControlStaffingTableEdit;
            tabPageStucturalUnits.Text = "Редактирование сведений о подразденении:";
        }

        //процедура заполнения полей ввода изменяемыми значениями
        public void StructuralUnitImport(string hierarchyLevel, string fullTitle,
            string shortTitle, string chief, string parentUnit)
        {
            comboBoxHierarchyLevel.SelectedItem = hierarchyLevel;
            textBoxFullTitle.Text = fullTitle;
            textBoxShortTitle.Text = shortTitle;
            comboBoxChief.SelectedItem = chief;
            comboBoxParentUnit.SelectedItem = parentUnit;
        }

        //отмена добавления или редактирования записи в таблице "Структурные подразделения"
        private void btnStructuralUnitCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //процедура добавления или редактирования записи в таблице "Структурные подразделения"
        private void btnStructuralUnitPost_Click(object sender, EventArgs e)
        {
            if (textBoxFullTitle.Text == "" || textBoxShortTitle.Text == "")
            {
                MessageBox.Show("Необходимо указать полное и краткое наименование подразделения!");
                return;
            }
            else
            {
                if (tabPageStucturalUnits.Text == "Добавление структурного подразделения:")
                {
                    if (!DB_Connection.StructuralUnitFullTitleExists(textBoxFullTitle.Text))
                    {
                        if (!DB_Connection.StructuralUnitShortTitleExists(textBoxShortTitle.Text))
                        {
                            DB_Connection.AddStructuralUnit(comboBoxHierarchyLevel.SelectedValue.ToString(),
                                textBoxFullTitle.Text, textBoxShortTitle.Text, comboBoxChief.SelectedValue.
                                ToString(), comboBoxParentUnit.SelectedValue.ToString());
                            MessageBox.Show("Структурное подразделение добавлено!");
                            DB_Connection.ShowStructuralUnits();
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("Краткое наименование структурого подразделения уже используется!");
                            return;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Полное наименование структурого подразделения уже используется!");
                        return;
                    }
                }
                if (tabPageStucturalUnits.Text == "Редактирование сведений о подразденении:")
                {
                    if (!DB_Connection.StructuralUnitFullTitleExists(textBoxFullTitle.Text) ||
                        textBoxFullTitle.Text == StaffingTableDetailForm.FullTitle)
                    {
                        if (!DB_Connection.StructuralUnitShortTitleExists(textBoxShortTitle.Text) ||
                            textBoxShortTitle.Text == StaffingTableDetailForm.ShortTitle)
                        {
                            DB_Connection.EditStructuralUnit(StaffingTableDetailForm.NumberOfEditRecord,
                                comboBoxHierarchyLevel.SelectedValue.ToString(), textBoxFullTitle.Text,
                                textBoxShortTitle.Text, comboBoxChief.SelectedValue.ToString(),
                                comboBoxParentUnit.SelectedValue.ToString());
                            MessageBox.Show("Сведения о структурном подразделении изменены!");
                            DB_Connection.ShowStructuralUnits();
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("Краткое наименование структурого подразделения уже используется!");
                            return;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Полное наименование структурого подразделения уже используется!");
                        return;
                    }
                }
            }
        }
    }
}
