﻿namespace VacationScheduleCreator
{
    partial class EmployeesVacationsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EmployeesVacationsForm));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tableLayoutPanel_AllForm = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel_Company = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBoxCompany = new System.Windows.Forms.PictureBox();
            this.lblCompany = new System.Windows.Forms.Label();
            this.tableLayoutPanel_Employees = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel_Working_field = new System.Windows.Forms.TableLayoutPanel();
            this.groupBoxVacationTypes = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanelVacationTypes = new System.Windows.Forms.TableLayoutPanel();
            this.dataGridViewVacationTypes = new System.Windows.Forms.DataGridView();
            this.btnVacationTypesDetail = new System.Windows.Forms.Button();
            this.groupBoxVacationSchedules = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanelVacationSchedules = new System.Windows.Forms.TableLayoutPanel();
            this.dataGridViewVacationSchedules = new System.Windows.Forms.DataGridView();
            this.btnVacationSchedulesDetail = new System.Windows.Forms.Button();
            this.groupBoxEmployeesVacations = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanelEmployeesVacations = new System.Windows.Forms.TableLayoutPanel();
            this.btnEmployeesPaidTravel = new System.Windows.Forms.Button();
            this.dataGridViewEmployeesVacations = new System.Windows.Forms.DataGridView();
            this.btnEmployeesVacationsDetail = new System.Windows.Forms.Button();
            this.groupBoxSpendingOfVacations = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanelSpendingOfVacations = new System.Windows.Forms.TableLayoutPanel();
            this.btnSpendingOfVacationsDetail = new System.Windows.Forms.Button();
            this.dataGridViewSpendingOfVacations = new System.Windows.Forms.DataGridView();
            this.tableLayoutPanel_WindowHeader = new System.Windows.Forms.TableLayoutPanel();
            this.lblEmployeesVacations = new System.Windows.Forms.Label();
            this.tableLayoutPanel_Programm = new System.Windows.Forms.TableLayoutPanel();
            this.lblProgramm = new System.Windows.Forms.Label();
            this.tableLayoutPanel_AllForm.SuspendLayout();
            this.tableLayoutPanel_Company.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCompany)).BeginInit();
            this.tableLayoutPanel_Employees.SuspendLayout();
            this.tableLayoutPanel_Working_field.SuspendLayout();
            this.groupBoxVacationTypes.SuspendLayout();
            this.tableLayoutPanelVacationTypes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVacationTypes)).BeginInit();
            this.groupBoxVacationSchedules.SuspendLayout();
            this.tableLayoutPanelVacationSchedules.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVacationSchedules)).BeginInit();
            this.groupBoxEmployeesVacations.SuspendLayout();
            this.tableLayoutPanelEmployeesVacations.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewEmployeesVacations)).BeginInit();
            this.groupBoxSpendingOfVacations.SuspendLayout();
            this.tableLayoutPanelSpendingOfVacations.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSpendingOfVacations)).BeginInit();
            this.tableLayoutPanel_WindowHeader.SuspendLayout();
            this.tableLayoutPanel_Programm.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel_AllForm
            // 
            this.tableLayoutPanel_AllForm.ColumnCount = 1;
            this.tableLayoutPanel_AllForm.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_AllForm.Controls.Add(this.tableLayoutPanel_Company, 0, 1);
            this.tableLayoutPanel_AllForm.Controls.Add(this.tableLayoutPanel_Employees, 0, 2);
            this.tableLayoutPanel_AllForm.Controls.Add(this.tableLayoutPanel_Programm, 0, 0);
            this.tableLayoutPanel_AllForm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_AllForm.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel_AllForm.Name = "tableLayoutPanel_AllForm";
            this.tableLayoutPanel_AllForm.RowCount = 3;
            this.tableLayoutPanel_AllForm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel_AllForm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tableLayoutPanel_AllForm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 75F));
            this.tableLayoutPanel_AllForm.Size = new System.Drawing.Size(784, 497);
            this.tableLayoutPanel_AllForm.TabIndex = 8;
            // 
            // tableLayoutPanel_Company
            // 
            this.tableLayoutPanel_Company.BackColor = System.Drawing.SystemColors.HotTrack;
            this.tableLayoutPanel_Company.ColumnCount = 2;
            this.tableLayoutPanel_Company.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel_Company.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.tableLayoutPanel_Company.Controls.Add(this.pictureBoxCompany, 0, 1);
            this.tableLayoutPanel_Company.Controls.Add(this.lblCompany, 1, 1);
            this.tableLayoutPanel_Company.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Company.Location = new System.Drawing.Point(3, 52);
            this.tableLayoutPanel_Company.Name = "tableLayoutPanel_Company";
            this.tableLayoutPanel_Company.RowCount = 3;
            this.tableLayoutPanel_Company.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel_Company.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tableLayoutPanel_Company.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel_Company.Size = new System.Drawing.Size(778, 68);
            this.tableLayoutPanel_Company.TabIndex = 7;
            // 
            // pictureBoxCompany
            // 
            this.pictureBoxCompany.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxCompany.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxCompany.Image")));
            this.pictureBoxCompany.Location = new System.Drawing.Point(3, 6);
            this.pictureBoxCompany.Name = "pictureBoxCompany";
            this.pictureBoxCompany.Size = new System.Drawing.Size(227, 55);
            this.pictureBoxCompany.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxCompany.TabIndex = 3;
            this.pictureBoxCompany.TabStop = false;
            // 
            // lblCompany
            // 
            this.lblCompany.AutoSize = true;
            this.lblCompany.BackColor = System.Drawing.SystemColors.HotTrack;
            this.lblCompany.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCompany.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblCompany.ForeColor = System.Drawing.Color.White;
            this.lblCompany.Location = new System.Drawing.Point(236, 3);
            this.lblCompany.Name = "lblCompany";
            this.lblCompany.Size = new System.Drawing.Size(539, 61);
            this.lblCompany.TabIndex = 2;
            this.lblCompany.Text = "МЕЖРЕГИОНАЛЬНАЯ РАСПРЕДЕЛИТЕЛЬНАЯ СЕТЕВАЯ КОМПАНИЯ СЕВЕРО-ЗАПАДА";
            this.lblCompany.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel_Employees
            // 
            this.tableLayoutPanel_Employees.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPanel_Employees.ColumnCount = 1;
            this.tableLayoutPanel_Employees.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_Employees.Controls.Add(this.tableLayoutPanel_Working_field, 0, 1);
            this.tableLayoutPanel_Employees.Controls.Add(this.tableLayoutPanel_WindowHeader, 0, 0);
            this.tableLayoutPanel_Employees.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Employees.Location = new System.Drawing.Point(3, 126);
            this.tableLayoutPanel_Employees.Name = "tableLayoutPanel_Employees";
            this.tableLayoutPanel_Employees.RowCount = 2;
            this.tableLayoutPanel_Employees.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12F));
            this.tableLayoutPanel_Employees.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 88F));
            this.tableLayoutPanel_Employees.Size = new System.Drawing.Size(778, 368);
            this.tableLayoutPanel_Employees.TabIndex = 6;
            // 
            // tableLayoutPanel_Working_field
            // 
            this.tableLayoutPanel_Working_field.ColumnCount = 2;
            this.tableLayoutPanel_Working_field.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel_Working_field.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel_Working_field.Controls.Add(this.groupBoxVacationTypes, 0, 0);
            this.tableLayoutPanel_Working_field.Controls.Add(this.groupBoxVacationSchedules, 1, 0);
            this.tableLayoutPanel_Working_field.Controls.Add(this.groupBoxEmployeesVacations, 1, 1);
            this.tableLayoutPanel_Working_field.Controls.Add(this.groupBoxSpendingOfVacations, 0, 1);
            this.tableLayoutPanel_Working_field.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Working_field.Location = new System.Drawing.Point(3, 44);
            this.tableLayoutPanel_Working_field.Margin = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.tableLayoutPanel_Working_field.Name = "tableLayoutPanel_Working_field";
            this.tableLayoutPanel_Working_field.RowCount = 2;
            this.tableLayoutPanel_Working_field.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Working_field.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Working_field.Size = new System.Drawing.Size(772, 321);
            this.tableLayoutPanel_Working_field.TabIndex = 7;
            // 
            // groupBoxVacationTypes
            // 
            this.groupBoxVacationTypes.Controls.Add(this.tableLayoutPanelVacationTypes);
            this.groupBoxVacationTypes.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxVacationTypes.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBoxVacationTypes.ForeColor = System.Drawing.Color.White;
            this.groupBoxVacationTypes.Location = new System.Drawing.Point(3, 3);
            this.groupBoxVacationTypes.Name = "groupBoxVacationTypes";
            this.groupBoxVacationTypes.Size = new System.Drawing.Size(302, 154);
            this.groupBoxVacationTypes.TabIndex = 0;
            this.groupBoxVacationTypes.TabStop = false;
            this.groupBoxVacationTypes.Text = "Виды отпусков:";
            // 
            // tableLayoutPanelVacationTypes
            // 
            this.tableLayoutPanelVacationTypes.ColumnCount = 1;
            this.tableLayoutPanelVacationTypes.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelVacationTypes.Controls.Add(this.dataGridViewVacationTypes, 0, 0);
            this.tableLayoutPanelVacationTypes.Controls.Add(this.btnVacationTypesDetail, 0, 1);
            this.tableLayoutPanelVacationTypes.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelVacationTypes.Location = new System.Drawing.Point(3, 25);
            this.tableLayoutPanelVacationTypes.Name = "tableLayoutPanelVacationTypes";
            this.tableLayoutPanelVacationTypes.RowCount = 2;
            this.tableLayoutPanelVacationTypes.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 75F));
            this.tableLayoutPanelVacationTypes.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanelVacationTypes.Size = new System.Drawing.Size(296, 126);
            this.tableLayoutPanelVacationTypes.TabIndex = 0;
            // 
            // dataGridViewVacationTypes
            // 
            this.dataGridViewVacationTypes.AllowUserToAddRows = false;
            this.dataGridViewVacationTypes.AllowUserToDeleteRows = false;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.AntiqueWhite;
            this.dataGridViewVacationTypes.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle9;
            this.dataGridViewVacationTypes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewVacationTypes.DefaultCellStyle = dataGridViewCellStyle10;
            this.dataGridViewVacationTypes.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewVacationTypes.Location = new System.Drawing.Point(3, 3);
            this.dataGridViewVacationTypes.MultiSelect = false;
            this.dataGridViewVacationTypes.Name = "dataGridViewVacationTypes";
            this.dataGridViewVacationTypes.ReadOnly = true;
            this.dataGridViewVacationTypes.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewVacationTypes.Size = new System.Drawing.Size(290, 88);
            this.dataGridViewVacationTypes.TabIndex = 0;
            // 
            // btnVacationTypesDetail
            // 
            this.btnVacationTypesDetail.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnVacationTypesDetail.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnVacationTypesDetail.Location = new System.Drawing.Point(3, 97);
            this.btnVacationTypesDetail.Name = "btnVacationTypesDetail";
            this.btnVacationTypesDetail.Size = new System.Drawing.Size(290, 26);
            this.btnVacationTypesDetail.TabIndex = 1;
            this.btnVacationTypesDetail.Text = "Перейти к видам отпусков";
            this.btnVacationTypesDetail.UseVisualStyleBackColor = false;
            this.btnVacationTypesDetail.Click += new System.EventHandler(this.btnVacationTypesDetail_Click);
            // 
            // groupBoxVacationSchedules
            // 
            this.groupBoxVacationSchedules.Controls.Add(this.tableLayoutPanelVacationSchedules);
            this.groupBoxVacationSchedules.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxVacationSchedules.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBoxVacationSchedules.ForeColor = System.Drawing.Color.White;
            this.groupBoxVacationSchedules.Location = new System.Drawing.Point(311, 3);
            this.groupBoxVacationSchedules.Name = "groupBoxVacationSchedules";
            this.groupBoxVacationSchedules.Size = new System.Drawing.Size(458, 154);
            this.groupBoxVacationSchedules.TabIndex = 1;
            this.groupBoxVacationSchedules.TabStop = false;
            this.groupBoxVacationSchedules.Text = "Графики отпусков:";
            // 
            // tableLayoutPanelVacationSchedules
            // 
            this.tableLayoutPanelVacationSchedules.ColumnCount = 1;
            this.tableLayoutPanelVacationSchedules.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelVacationSchedules.Controls.Add(this.dataGridViewVacationSchedules, 0, 0);
            this.tableLayoutPanelVacationSchedules.Controls.Add(this.btnVacationSchedulesDetail, 0, 1);
            this.tableLayoutPanelVacationSchedules.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelVacationSchedules.Location = new System.Drawing.Point(3, 25);
            this.tableLayoutPanelVacationSchedules.Name = "tableLayoutPanelVacationSchedules";
            this.tableLayoutPanelVacationSchedules.RowCount = 2;
            this.tableLayoutPanelVacationSchedules.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 75F));
            this.tableLayoutPanelVacationSchedules.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanelVacationSchedules.Size = new System.Drawing.Size(452, 126);
            this.tableLayoutPanelVacationSchedules.TabIndex = 0;
            // 
            // dataGridViewVacationSchedules
            // 
            this.dataGridViewVacationSchedules.AllowUserToAddRows = false;
            this.dataGridViewVacationSchedules.AllowUserToDeleteRows = false;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.AntiqueWhite;
            this.dataGridViewVacationSchedules.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle11;
            this.dataGridViewVacationSchedules.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewVacationSchedules.DefaultCellStyle = dataGridViewCellStyle12;
            this.dataGridViewVacationSchedules.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewVacationSchedules.Location = new System.Drawing.Point(3, 3);
            this.dataGridViewVacationSchedules.MultiSelect = false;
            this.dataGridViewVacationSchedules.Name = "dataGridViewVacationSchedules";
            this.dataGridViewVacationSchedules.ReadOnly = true;
            this.dataGridViewVacationSchedules.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewVacationSchedules.Size = new System.Drawing.Size(446, 88);
            this.dataGridViewVacationSchedules.TabIndex = 0;
            this.dataGridViewVacationSchedules.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewVacationSchedules_CellClick);
            // 
            // btnVacationSchedulesDetail
            // 
            this.btnVacationSchedulesDetail.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnVacationSchedulesDetail.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnVacationSchedulesDetail.Location = new System.Drawing.Point(3, 97);
            this.btnVacationSchedulesDetail.Name = "btnVacationSchedulesDetail";
            this.btnVacationSchedulesDetail.Size = new System.Drawing.Size(446, 26);
            this.btnVacationSchedulesDetail.TabIndex = 1;
            this.btnVacationSchedulesDetail.Text = "Перейти к перечню графиков отпусков";
            this.btnVacationSchedulesDetail.UseVisualStyleBackColor = false;
            this.btnVacationSchedulesDetail.Click += new System.EventHandler(this.btnVacationSchedulesDetail_Click);
            // 
            // groupBoxEmployeesVacations
            // 
            this.groupBoxEmployeesVacations.Controls.Add(this.tableLayoutPanelEmployeesVacations);
            this.groupBoxEmployeesVacations.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxEmployeesVacations.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBoxEmployeesVacations.ForeColor = System.Drawing.Color.White;
            this.groupBoxEmployeesVacations.Location = new System.Drawing.Point(311, 163);
            this.groupBoxEmployeesVacations.Name = "groupBoxEmployeesVacations";
            this.groupBoxEmployeesVacations.Size = new System.Drawing.Size(458, 155);
            this.groupBoxEmployeesVacations.TabIndex = 2;
            this.groupBoxEmployeesVacations.TabStop = false;
            this.groupBoxEmployeesVacations.Text = "График отпусков:";
            // 
            // tableLayoutPanelEmployeesVacations
            // 
            this.tableLayoutPanelEmployeesVacations.ColumnCount = 2;
            this.tableLayoutPanelEmployeesVacations.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelEmployeesVacations.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelEmployeesVacations.Controls.Add(this.btnEmployeesPaidTravel, 1, 1);
            this.tableLayoutPanelEmployeesVacations.Controls.Add(this.dataGridViewEmployeesVacations, 0, 0);
            this.tableLayoutPanelEmployeesVacations.Controls.Add(this.btnEmployeesVacationsDetail, 0, 1);
            this.tableLayoutPanelEmployeesVacations.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelEmployeesVacations.Location = new System.Drawing.Point(3, 25);
            this.tableLayoutPanelEmployeesVacations.Name = "tableLayoutPanelEmployeesVacations";
            this.tableLayoutPanelEmployeesVacations.RowCount = 2;
            this.tableLayoutPanelEmployeesVacations.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 75F));
            this.tableLayoutPanelEmployeesVacations.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanelEmployeesVacations.Size = new System.Drawing.Size(452, 127);
            this.tableLayoutPanelEmployeesVacations.TabIndex = 0;
            // 
            // btnEmployeesPaidTravel
            // 
            this.btnEmployeesPaidTravel.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnEmployeesPaidTravel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnEmployeesPaidTravel.Location = new System.Drawing.Point(229, 98);
            this.btnEmployeesPaidTravel.Name = "btnEmployeesPaidTravel";
            this.btnEmployeesPaidTravel.Size = new System.Drawing.Size(220, 26);
            this.btnEmployeesPaidTravel.TabIndex = 2;
            this.btnEmployeesPaidTravel.Text = "Указать периоды льготного проезда";
            this.btnEmployeesPaidTravel.UseVisualStyleBackColor = false;
            this.btnEmployeesPaidTravel.Click += new System.EventHandler(this.btnEmployeesPaidTravel_Click);
            // 
            // dataGridViewEmployeesVacations
            // 
            this.dataGridViewEmployeesVacations.AllowUserToAddRows = false;
            this.dataGridViewEmployeesVacations.AllowUserToDeleteRows = false;
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.AntiqueWhite;
            this.dataGridViewEmployeesVacations.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle13;
            this.dataGridViewEmployeesVacations.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tableLayoutPanelEmployeesVacations.SetColumnSpan(this.dataGridViewEmployeesVacations, 2);
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle14.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewEmployeesVacations.DefaultCellStyle = dataGridViewCellStyle14;
            this.dataGridViewEmployeesVacations.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewEmployeesVacations.Location = new System.Drawing.Point(3, 3);
            this.dataGridViewEmployeesVacations.MultiSelect = false;
            this.dataGridViewEmployeesVacations.Name = "dataGridViewEmployeesVacations";
            this.dataGridViewEmployeesVacations.ReadOnly = true;
            this.dataGridViewEmployeesVacations.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewEmployeesVacations.Size = new System.Drawing.Size(446, 89);
            this.dataGridViewEmployeesVacations.TabIndex = 0;
            // 
            // btnEmployeesVacationsDetail
            // 
            this.btnEmployeesVacationsDetail.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnEmployeesVacationsDetail.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnEmployeesVacationsDetail.Location = new System.Drawing.Point(3, 98);
            this.btnEmployeesVacationsDetail.Name = "btnEmployeesVacationsDetail";
            this.btnEmployeesVacationsDetail.Size = new System.Drawing.Size(220, 26);
            this.btnEmployeesVacationsDetail.TabIndex = 1;
            this.btnEmployeesVacationsDetail.Text = "Перейти к графикам отпусков";
            this.btnEmployeesVacationsDetail.UseVisualStyleBackColor = false;
            this.btnEmployeesVacationsDetail.Click += new System.EventHandler(this.btnEmployeesVacationsDetail_Click);
            // 
            // groupBoxSpendingOfVacations
            // 
            this.groupBoxSpendingOfVacations.Controls.Add(this.tableLayoutPanelSpendingOfVacations);
            this.groupBoxSpendingOfVacations.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxSpendingOfVacations.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBoxSpendingOfVacations.ForeColor = System.Drawing.Color.White;
            this.groupBoxSpendingOfVacations.Location = new System.Drawing.Point(3, 163);
            this.groupBoxSpendingOfVacations.Name = "groupBoxSpendingOfVacations";
            this.groupBoxSpendingOfVacations.Size = new System.Drawing.Size(302, 155);
            this.groupBoxSpendingOfVacations.TabIndex = 3;
            this.groupBoxSpendingOfVacations.TabStop = false;
            this.groupBoxSpendingOfVacations.Text = "Предоставление отпусков:";
            // 
            // tableLayoutPanelSpendingOfVacations
            // 
            this.tableLayoutPanelSpendingOfVacations.ColumnCount = 1;
            this.tableLayoutPanelSpendingOfVacations.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelSpendingOfVacations.Controls.Add(this.btnSpendingOfVacationsDetail, 0, 1);
            this.tableLayoutPanelSpendingOfVacations.Controls.Add(this.dataGridViewSpendingOfVacations, 0, 0);
            this.tableLayoutPanelSpendingOfVacations.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelSpendingOfVacations.Location = new System.Drawing.Point(3, 25);
            this.tableLayoutPanelSpendingOfVacations.Name = "tableLayoutPanelSpendingOfVacations";
            this.tableLayoutPanelSpendingOfVacations.RowCount = 2;
            this.tableLayoutPanelSpendingOfVacations.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 75F));
            this.tableLayoutPanelSpendingOfVacations.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanelSpendingOfVacations.Size = new System.Drawing.Size(296, 127);
            this.tableLayoutPanelSpendingOfVacations.TabIndex = 0;
            // 
            // btnSpendingOfVacationsDetail
            // 
            this.btnSpendingOfVacationsDetail.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnSpendingOfVacationsDetail.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnSpendingOfVacationsDetail.Location = new System.Drawing.Point(3, 98);
            this.btnSpendingOfVacationsDetail.Name = "btnSpendingOfVacationsDetail";
            this.btnSpendingOfVacationsDetail.Size = new System.Drawing.Size(290, 26);
            this.btnSpendingOfVacationsDetail.TabIndex = 0;
            this.btnSpendingOfVacationsDetail.Text = "Перейти";
            this.btnSpendingOfVacationsDetail.UseVisualStyleBackColor = false;
            this.btnSpendingOfVacationsDetail.Click += new System.EventHandler(this.btnSpendingOfVacationsDetail_Click);
            // 
            // dataGridViewSpendingOfVacations
            // 
            this.dataGridViewSpendingOfVacations.AllowUserToAddRows = false;
            this.dataGridViewSpendingOfVacations.AllowUserToDeleteRows = false;
            dataGridViewCellStyle15.BackColor = System.Drawing.Color.AntiqueWhite;
            this.dataGridViewSpendingOfVacations.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle15;
            this.dataGridViewSpendingOfVacations.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle16.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle16.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle16.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewSpendingOfVacations.DefaultCellStyle = dataGridViewCellStyle16;
            this.dataGridViewSpendingOfVacations.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewSpendingOfVacations.Location = new System.Drawing.Point(3, 3);
            this.dataGridViewSpendingOfVacations.MultiSelect = false;
            this.dataGridViewSpendingOfVacations.Name = "dataGridViewSpendingOfVacations";
            this.dataGridViewSpendingOfVacations.ReadOnly = true;
            this.dataGridViewSpendingOfVacations.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewSpendingOfVacations.Size = new System.Drawing.Size(290, 89);
            this.dataGridViewSpendingOfVacations.TabIndex = 1;
            // 
            // tableLayoutPanel_WindowHeader
            // 
            this.tableLayoutPanel_WindowHeader.ColumnCount = 4;
            this.tableLayoutPanel_WindowHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_WindowHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_WindowHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_WindowHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_WindowHeader.Controls.Add(this.lblEmployeesVacations, 0, 0);
            this.tableLayoutPanel_WindowHeader.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_WindowHeader.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel_WindowHeader.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.tableLayoutPanel_WindowHeader.Name = "tableLayoutPanel_WindowHeader";
            this.tableLayoutPanel_WindowHeader.RowCount = 1;
            this.tableLayoutPanel_WindowHeader.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_WindowHeader.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 41F));
            this.tableLayoutPanel_WindowHeader.Size = new System.Drawing.Size(772, 41);
            this.tableLayoutPanel_WindowHeader.TabIndex = 6;
            // 
            // lblEmployeesVacations
            // 
            this.lblEmployeesVacations.AutoSize = true;
            this.tableLayoutPanel_WindowHeader.SetColumnSpan(this.lblEmployeesVacations, 4);
            this.lblEmployeesVacations.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblEmployeesVacations.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblEmployeesVacations.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblEmployeesVacations.Location = new System.Drawing.Point(3, 0);
            this.lblEmployeesVacations.Name = "lblEmployeesVacations";
            this.lblEmployeesVacations.Size = new System.Drawing.Size(766, 41);
            this.lblEmployeesVacations.TabIndex = 19;
            this.lblEmployeesVacations.Text = "ОТПУСКА СОТРУДНИКОВ";
            this.lblEmployeesVacations.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel_Programm
            // 
            this.tableLayoutPanel_Programm.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPanel_Programm.ColumnCount = 1;
            this.tableLayoutPanel_Programm.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Programm.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Programm.Controls.Add(this.lblProgramm, 0, 0);
            this.tableLayoutPanel_Programm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Programm.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel_Programm.Name = "tableLayoutPanel_Programm";
            this.tableLayoutPanel_Programm.RowCount = 1;
            this.tableLayoutPanel_Programm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Programm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Programm.Size = new System.Drawing.Size(778, 43);
            this.tableLayoutPanel_Programm.TabIndex = 8;
            // 
            // lblProgramm
            // 
            this.lblProgramm.AutoSize = true;
            this.lblProgramm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblProgramm.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblProgramm.ForeColor = System.Drawing.Color.White;
            this.lblProgramm.Location = new System.Drawing.Point(3, 0);
            this.lblProgramm.Name = "lblProgramm";
            this.lblProgramm.Size = new System.Drawing.Size(772, 43);
            this.lblProgramm.TabIndex = 0;
            this.lblProgramm.Text = "ФОРМИРОВАНИЕ И ВЕДЕНИЕ ГРАФИКА ОТПУСКОВ СОТРУДНИКОВ";
            this.lblProgramm.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // EmployeesVacationsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 497);
            this.Controls.Add(this.tableLayoutPanel_AllForm);
            this.Name = "EmployeesVacationsForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ОТПУСКА";
            this.Load += new System.EventHandler(this.EmployeesVacationsForm_Load);
            this.tableLayoutPanel_AllForm.ResumeLayout(false);
            this.tableLayoutPanel_Company.ResumeLayout(false);
            this.tableLayoutPanel_Company.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCompany)).EndInit();
            this.tableLayoutPanel_Employees.ResumeLayout(false);
            this.tableLayoutPanel_Working_field.ResumeLayout(false);
            this.groupBoxVacationTypes.ResumeLayout(false);
            this.tableLayoutPanelVacationTypes.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVacationTypes)).EndInit();
            this.groupBoxVacationSchedules.ResumeLayout(false);
            this.tableLayoutPanelVacationSchedules.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVacationSchedules)).EndInit();
            this.groupBoxEmployeesVacations.ResumeLayout(false);
            this.tableLayoutPanelEmployeesVacations.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewEmployeesVacations)).EndInit();
            this.groupBoxSpendingOfVacations.ResumeLayout(false);
            this.tableLayoutPanelSpendingOfVacations.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSpendingOfVacations)).EndInit();
            this.tableLayoutPanel_WindowHeader.ResumeLayout(false);
            this.tableLayoutPanel_WindowHeader.PerformLayout();
            this.tableLayoutPanel_Programm.ResumeLayout(false);
            this.tableLayoutPanel_Programm.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_AllForm;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Company;
        private System.Windows.Forms.PictureBox pictureBoxCompany;
        private System.Windows.Forms.Label lblCompany;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Employees;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Working_field;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_WindowHeader;
        private System.Windows.Forms.Label lblEmployeesVacations;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Programm;
        private System.Windows.Forms.Label lblProgramm;
        private System.Windows.Forms.GroupBox groupBoxVacationTypes;
        private System.Windows.Forms.GroupBox groupBoxVacationSchedules;
        private System.Windows.Forms.GroupBox groupBoxEmployeesVacations;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelVacationTypes;
        private System.Windows.Forms.DataGridView dataGridViewVacationTypes;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelVacationSchedules;
        private System.Windows.Forms.DataGridView dataGridViewVacationSchedules;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelEmployeesVacations;
        private System.Windows.Forms.DataGridView dataGridViewEmployeesVacations;
        private System.Windows.Forms.Button btnVacationTypesDetail;
        private System.Windows.Forms.Button btnVacationSchedulesDetail;
        private System.Windows.Forms.Button btnEmployeesVacationsDetail;
        private System.Windows.Forms.GroupBox groupBoxSpendingOfVacations;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelSpendingOfVacations;
        private System.Windows.Forms.Button btnSpendingOfVacationsDetail;
        private System.Windows.Forms.DataGridView dataGridViewSpendingOfVacations;
        private System.Windows.Forms.Button btnEmployeesPaidTravel;
    }
}