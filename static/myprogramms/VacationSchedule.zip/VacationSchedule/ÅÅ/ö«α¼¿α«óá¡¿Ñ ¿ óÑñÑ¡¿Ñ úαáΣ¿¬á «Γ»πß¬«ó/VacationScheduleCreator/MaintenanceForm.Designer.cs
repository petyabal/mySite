﻿namespace VacationScheduleCreator
{
    partial class MaintenanceForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MaintenanceForm));
            this.tableLayoutPanel_AllForm = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel_Company = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBoxCompany = new System.Windows.Forms.PictureBox();
            this.lblCompany = new System.Windows.Forms.Label();
            this.tableLayoutPanel_MainMenu = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel_MenuOptions = new System.Windows.Forms.TableLayoutPanel();
            this.btnUserChange = new System.Windows.Forms.Button();
            this.btnCloseApplication = new System.Windows.Forms.Button();
            this.groupBoxSearchAccount = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanelUserSearch = new System.Windows.Forms.TableLayoutPanel();
            this.labelField = new System.Windows.Forms.Label();
            this.labelText = new System.Windows.Forms.Label();
            this.btnSearchExecute = new System.Windows.Forms.Button();
            this.comboBoxField = new System.Windows.Forms.ComboBox();
            this.textBoxSearchingValue = new System.Windows.Forms.TextBox();
            this.groupBoxUsersAccounts = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanelUsersAccounts = new System.Windows.Forms.TableLayoutPanel();
            this.btnAddUserAccount = new System.Windows.Forms.Button();
            this.btnChangeUserAccount = new System.Windows.Forms.Button();
            this.dataGridViewUsersAccounts = new System.Windows.Forms.DataGridView();
            this.tableLayoutPanel_MenuHeader = new System.Windows.Forms.TableLayoutPanel();
            this.btnPause = new System.Windows.Forms.Button();
            this.btnPasswordsVisualization = new System.Windows.Forms.Button();
            this.btnLoginsVisualization = new System.Windows.Forms.Button();
            this.btnUsersAccountsVisualization = new System.Windows.Forms.Button();
            this.lblAccessMenu = new System.Windows.Forms.Label();
            this.tableLayoutPanel_Programm = new System.Windows.Forms.TableLayoutPanel();
            this.lblProgramm = new System.Windows.Forms.Label();
            this.tableLayoutPanel_AllForm.SuspendLayout();
            this.tableLayoutPanel_Company.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCompany)).BeginInit();
            this.tableLayoutPanel_MainMenu.SuspendLayout();
            this.tableLayoutPanel_MenuOptions.SuspendLayout();
            this.groupBoxSearchAccount.SuspendLayout();
            this.tableLayoutPanelUserSearch.SuspendLayout();
            this.groupBoxUsersAccounts.SuspendLayout();
            this.tableLayoutPanelUsersAccounts.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewUsersAccounts)).BeginInit();
            this.tableLayoutPanel_MenuHeader.SuspendLayout();
            this.tableLayoutPanel_Programm.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel_AllForm
            // 
            this.tableLayoutPanel_AllForm.ColumnCount = 1;
            this.tableLayoutPanel_AllForm.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_AllForm.Controls.Add(this.tableLayoutPanel_Company, 0, 1);
            this.tableLayoutPanel_AllForm.Controls.Add(this.tableLayoutPanel_MainMenu, 0, 2);
            this.tableLayoutPanel_AllForm.Controls.Add(this.tableLayoutPanel_Programm, 0, 0);
            this.tableLayoutPanel_AllForm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_AllForm.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel_AllForm.Name = "tableLayoutPanel_AllForm";
            this.tableLayoutPanel_AllForm.RowCount = 3;
            this.tableLayoutPanel_AllForm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel_AllForm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel_AllForm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.tableLayoutPanel_AllForm.Size = new System.Drawing.Size(784, 497);
            this.tableLayoutPanel_AllForm.TabIndex = 7;
            // 
            // tableLayoutPanel_Company
            // 
            this.tableLayoutPanel_Company.BackColor = System.Drawing.SystemColors.HotTrack;
            this.tableLayoutPanel_Company.ColumnCount = 4;
            this.tableLayoutPanel_Company.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8F));
            this.tableLayoutPanel_Company.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel_Company.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 54F));
            this.tableLayoutPanel_Company.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8F));
            this.tableLayoutPanel_Company.Controls.Add(this.pictureBoxCompany, 1, 1);
            this.tableLayoutPanel_Company.Controls.Add(this.lblCompany, 2, 1);
            this.tableLayoutPanel_Company.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Company.Location = new System.Drawing.Point(3, 52);
            this.tableLayoutPanel_Company.Name = "tableLayoutPanel_Company";
            this.tableLayoutPanel_Company.RowCount = 3;
            this.tableLayoutPanel_Company.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel_Company.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tableLayoutPanel_Company.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel_Company.Size = new System.Drawing.Size(778, 93);
            this.tableLayoutPanel_Company.TabIndex = 7;
            // 
            // pictureBoxCompany
            // 
            this.pictureBoxCompany.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxCompany.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxCompany.Image")));
            this.pictureBoxCompany.Location = new System.Drawing.Point(65, 7);
            this.pictureBoxCompany.Name = "pictureBoxCompany";
            this.pictureBoxCompany.Size = new System.Drawing.Size(227, 77);
            this.pictureBoxCompany.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxCompany.TabIndex = 3;
            this.pictureBoxCompany.TabStop = false;
            // 
            // lblCompany
            // 
            this.lblCompany.AutoSize = true;
            this.lblCompany.BackColor = System.Drawing.SystemColors.HotTrack;
            this.lblCompany.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCompany.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblCompany.ForeColor = System.Drawing.Color.White;
            this.lblCompany.Location = new System.Drawing.Point(298, 4);
            this.lblCompany.Name = "lblCompany";
            this.lblCompany.Size = new System.Drawing.Size(414, 83);
            this.lblCompany.TabIndex = 2;
            this.lblCompany.Text = "МЕЖРЕГИОНАЛЬНАЯ РАСПРЕДЕЛИТЕЛЬНАЯ СЕТЕВАЯ КОМПАНИЯ СЕВЕРО-ЗАПАДА";
            this.lblCompany.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel_MainMenu
            // 
            this.tableLayoutPanel_MainMenu.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPanel_MainMenu.ColumnCount = 1;
            this.tableLayoutPanel_MainMenu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_MainMenu.Controls.Add(this.tableLayoutPanel_MenuOptions, 0, 1);
            this.tableLayoutPanel_MainMenu.Controls.Add(this.tableLayoutPanel_MenuHeader, 0, 0);
            this.tableLayoutPanel_MainMenu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_MainMenu.Location = new System.Drawing.Point(3, 151);
            this.tableLayoutPanel_MainMenu.Name = "tableLayoutPanel_MainMenu";
            this.tableLayoutPanel_MainMenu.RowCount = 2;
            this.tableLayoutPanel_MainMenu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel_MainMenu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.tableLayoutPanel_MainMenu.Size = new System.Drawing.Size(778, 343);
            this.tableLayoutPanel_MainMenu.TabIndex = 6;
            // 
            // tableLayoutPanel_MenuOptions
            // 
            this.tableLayoutPanel_MenuOptions.ColumnCount = 4;
            this.tableLayoutPanel_MenuOptions.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_MenuOptions.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_MenuOptions.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_MenuOptions.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_MenuOptions.Controls.Add(this.btnUserChange, 3, 0);
            this.tableLayoutPanel_MenuOptions.Controls.Add(this.btnCloseApplication, 3, 1);
            this.tableLayoutPanel_MenuOptions.Controls.Add(this.groupBoxSearchAccount, 3, 3);
            this.tableLayoutPanel_MenuOptions.Controls.Add(this.groupBoxUsersAccounts, 0, 0);
            this.tableLayoutPanel_MenuOptions.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_MenuOptions.Location = new System.Drawing.Point(3, 102);
            this.tableLayoutPanel_MenuOptions.Margin = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.tableLayoutPanel_MenuOptions.Name = "tableLayoutPanel_MenuOptions";
            this.tableLayoutPanel_MenuOptions.RowCount = 4;
            this.tableLayoutPanel_MenuOptions.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tableLayoutPanel_MenuOptions.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tableLayoutPanel_MenuOptions.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tableLayoutPanel_MenuOptions.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 55F));
            this.tableLayoutPanel_MenuOptions.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel_MenuOptions.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel_MenuOptions.Size = new System.Drawing.Size(772, 238);
            this.tableLayoutPanel_MenuOptions.TabIndex = 7;
            // 
            // btnUserChange
            // 
            this.btnUserChange.BackColor = System.Drawing.SystemColors.Control;
            this.btnUserChange.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnUserChange.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnUserChange.Location = new System.Drawing.Point(581, 0);
            this.btnUserChange.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.btnUserChange.Name = "btnUserChange";
            this.btnUserChange.Size = new System.Drawing.Size(189, 35);
            this.btnUserChange.TabIndex = 0;
            this.btnUserChange.Text = "Сменить пользователя";
            this.btnUserChange.UseVisualStyleBackColor = false;
            this.btnUserChange.Visible = false;
            this.btnUserChange.Click += new System.EventHandler(this.btnUserChange_Click);
            // 
            // btnCloseApplication
            // 
            this.btnCloseApplication.BackColor = System.Drawing.SystemColors.Control;
            this.btnCloseApplication.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnCloseApplication.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCloseApplication.Location = new System.Drawing.Point(581, 35);
            this.btnCloseApplication.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.btnCloseApplication.Name = "btnCloseApplication";
            this.btnCloseApplication.Size = new System.Drawing.Size(189, 35);
            this.btnCloseApplication.TabIndex = 4;
            this.btnCloseApplication.Text = "Закрыть приложение";
            this.btnCloseApplication.UseVisualStyleBackColor = false;
            this.btnCloseApplication.Visible = false;
            this.btnCloseApplication.Click += new System.EventHandler(this.btnCloseApplication_Click);
            // 
            // groupBoxSearchAccount
            // 
            this.groupBoxSearchAccount.Controls.Add(this.tableLayoutPanelUserSearch);
            this.groupBoxSearchAccount.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxSearchAccount.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBoxSearchAccount.Location = new System.Drawing.Point(582, 108);
            this.groupBoxSearchAccount.Name = "groupBoxSearchAccount";
            this.groupBoxSearchAccount.Size = new System.Drawing.Size(187, 127);
            this.groupBoxSearchAccount.TabIndex = 5;
            this.groupBoxSearchAccount.TabStop = false;
            this.groupBoxSearchAccount.Text = "Поиск пользователя:";
            this.groupBoxSearchAccount.Visible = false;
            // 
            // tableLayoutPanelUserSearch
            // 
            this.tableLayoutPanelUserSearch.ColumnCount = 2;
            this.tableLayoutPanelUserSearch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 42F));
            this.tableLayoutPanelUserSearch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 58F));
            this.tableLayoutPanelUserSearch.Controls.Add(this.labelField, 0, 0);
            this.tableLayoutPanelUserSearch.Controls.Add(this.labelText, 0, 1);
            this.tableLayoutPanelUserSearch.Controls.Add(this.btnSearchExecute, 0, 2);
            this.tableLayoutPanelUserSearch.Controls.Add(this.comboBoxField, 1, 0);
            this.tableLayoutPanelUserSearch.Controls.Add(this.textBoxSearchingValue, 1, 1);
            this.tableLayoutPanelUserSearch.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelUserSearch.Location = new System.Drawing.Point(3, 18);
            this.tableLayoutPanelUserSearch.Name = "tableLayoutPanelUserSearch";
            this.tableLayoutPanelUserSearch.RowCount = 3;
            this.tableLayoutPanelUserSearch.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.85F));
            this.tableLayoutPanelUserSearch.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.85F));
            this.tableLayoutPanelUserSearch.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 32.3F));
            this.tableLayoutPanelUserSearch.Size = new System.Drawing.Size(181, 106);
            this.tableLayoutPanelUserSearch.TabIndex = 0;
            // 
            // labelField
            // 
            this.labelField.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.labelField.AutoSize = true;
            this.labelField.Location = new System.Drawing.Point(3, 9);
            this.labelField.Name = "labelField";
            this.labelField.Size = new System.Drawing.Size(70, 16);
            this.labelField.TabIndex = 0;
            this.labelField.Text = "по:";
            // 
            // labelText
            // 
            this.labelText.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.labelText.AutoSize = true;
            this.labelText.Location = new System.Drawing.Point(3, 36);
            this.labelText.Name = "labelText";
            this.labelText.Size = new System.Drawing.Size(70, 32);
            this.labelText.TabIndex = 1;
            this.labelText.Text = "со значением:";
            // 
            // btnSearchExecute
            // 
            this.btnSearchExecute.BackColor = System.Drawing.SystemColors.HotTrack;
            this.tableLayoutPanelUserSearch.SetColumnSpan(this.btnSearchExecute, 2);
            this.btnSearchExecute.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnSearchExecute.ForeColor = System.Drawing.Color.White;
            this.btnSearchExecute.Location = new System.Drawing.Point(3, 73);
            this.btnSearchExecute.Name = "btnSearchExecute";
            this.btnSearchExecute.Size = new System.Drawing.Size(175, 30);
            this.btnSearchExecute.TabIndex = 2;
            this.btnSearchExecute.Text = "Осуществить поиск";
            this.btnSearchExecute.UseVisualStyleBackColor = false;
            // 
            // comboBoxField
            // 
            this.comboBoxField.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBoxField.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxField.FormattingEnabled = true;
            this.comboBoxField.Items.AddRange(new object[] {
            "табельному №",
            "Фамилии И.О."});
            this.comboBoxField.Location = new System.Drawing.Point(79, 7);
            this.comboBoxField.Name = "comboBoxField";
            this.comboBoxField.Size = new System.Drawing.Size(99, 24);
            this.comboBoxField.TabIndex = 3;
            // 
            // textBoxSearchingValue
            // 
            this.textBoxSearchingValue.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxSearchingValue.Location = new System.Drawing.Point(79, 41);
            this.textBoxSearchingValue.Name = "textBoxSearchingValue";
            this.textBoxSearchingValue.Size = new System.Drawing.Size(99, 22);
            this.textBoxSearchingValue.TabIndex = 4;
            // 
            // groupBoxUsersAccounts
            // 
            this.tableLayoutPanel_MenuOptions.SetColumnSpan(this.groupBoxUsersAccounts, 3);
            this.groupBoxUsersAccounts.Controls.Add(this.tableLayoutPanelUsersAccounts);
            this.groupBoxUsersAccounts.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxUsersAccounts.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBoxUsersAccounts.Location = new System.Drawing.Point(3, 3);
            this.groupBoxUsersAccounts.Name = "groupBoxUsersAccounts";
            this.tableLayoutPanel_MenuOptions.SetRowSpan(this.groupBoxUsersAccounts, 4);
            this.groupBoxUsersAccounts.Size = new System.Drawing.Size(573, 232);
            this.groupBoxUsersAccounts.TabIndex = 6;
            this.groupBoxUsersAccounts.TabStop = false;
            this.groupBoxUsersAccounts.Text = "Список учетных записей пользователей:";
            this.groupBoxUsersAccounts.Visible = false;
            // 
            // tableLayoutPanelUsersAccounts
            // 
            this.tableLayoutPanelUsersAccounts.ColumnCount = 2;
            this.tableLayoutPanelUsersAccounts.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelUsersAccounts.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelUsersAccounts.Controls.Add(this.btnAddUserAccount, 0, 1);
            this.tableLayoutPanelUsersAccounts.Controls.Add(this.btnChangeUserAccount, 1, 1);
            this.tableLayoutPanelUsersAccounts.Controls.Add(this.dataGridViewUsersAccounts, 0, 0);
            this.tableLayoutPanelUsersAccounts.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelUsersAccounts.Location = new System.Drawing.Point(3, 18);
            this.tableLayoutPanelUsersAccounts.Name = "tableLayoutPanelUsersAccounts";
            this.tableLayoutPanelUsersAccounts.RowCount = 2;
            this.tableLayoutPanelUsersAccounts.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 83F));
            this.tableLayoutPanelUsersAccounts.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 17F));
            this.tableLayoutPanelUsersAccounts.Size = new System.Drawing.Size(567, 211);
            this.tableLayoutPanelUsersAccounts.TabIndex = 0;
            // 
            // btnAddUserAccount
            // 
            this.btnAddUserAccount.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnAddUserAccount.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnAddUserAccount.ForeColor = System.Drawing.Color.White;
            this.btnAddUserAccount.Location = new System.Drawing.Point(3, 178);
            this.btnAddUserAccount.Name = "btnAddUserAccount";
            this.btnAddUserAccount.Size = new System.Drawing.Size(277, 30);
            this.btnAddUserAccount.TabIndex = 0;
            this.btnAddUserAccount.Text = "Добавить учетную запись";
            this.btnAddUserAccount.UseVisualStyleBackColor = false;
            this.btnAddUserAccount.Click += new System.EventHandler(this.btnAddUserAccount_Click);
            // 
            // btnChangeUserAccount
            // 
            this.btnChangeUserAccount.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnChangeUserAccount.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnChangeUserAccount.ForeColor = System.Drawing.Color.White;
            this.btnChangeUserAccount.Location = new System.Drawing.Point(286, 178);
            this.btnChangeUserAccount.Name = "btnChangeUserAccount";
            this.btnChangeUserAccount.Size = new System.Drawing.Size(278, 30);
            this.btnChangeUserAccount.TabIndex = 1;
            this.btnChangeUserAccount.Text = "Редактировать учетную запись";
            this.btnChangeUserAccount.UseVisualStyleBackColor = false;
            this.btnChangeUserAccount.Click += new System.EventHandler(this.btnChangeUserAccount_Click);
            // 
            // dataGridViewUsersAccounts
            // 
            this.dataGridViewUsersAccounts.AllowUserToAddRows = false;
            this.dataGridViewUsersAccounts.AllowUserToDeleteRows = false;
            this.dataGridViewUsersAccounts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tableLayoutPanelUsersAccounts.SetColumnSpan(this.dataGridViewUsersAccounts, 2);
            this.dataGridViewUsersAccounts.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewUsersAccounts.Location = new System.Drawing.Point(3, 3);
            this.dataGridViewUsersAccounts.MultiSelect = false;
            this.dataGridViewUsersAccounts.Name = "dataGridViewUsersAccounts";
            this.dataGridViewUsersAccounts.ReadOnly = true;
            this.dataGridViewUsersAccounts.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewUsersAccounts.Size = new System.Drawing.Size(561, 169);
            this.dataGridViewUsersAccounts.TabIndex = 2;
            // 
            // tableLayoutPanel_MenuHeader
            // 
            this.tableLayoutPanel_MenuHeader.ColumnCount = 4;
            this.tableLayoutPanel_MenuHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_MenuHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_MenuHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_MenuHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_MenuHeader.Controls.Add(this.btnPause, 3, 1);
            this.tableLayoutPanel_MenuHeader.Controls.Add(this.btnPasswordsVisualization, 2, 1);
            this.tableLayoutPanel_MenuHeader.Controls.Add(this.btnLoginsVisualization, 1, 1);
            this.tableLayoutPanel_MenuHeader.Controls.Add(this.btnUsersAccountsVisualization, 0, 1);
            this.tableLayoutPanel_MenuHeader.Controls.Add(this.lblAccessMenu, 0, 0);
            this.tableLayoutPanel_MenuHeader.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_MenuHeader.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel_MenuHeader.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.tableLayoutPanel_MenuHeader.Name = "tableLayoutPanel_MenuHeader";
            this.tableLayoutPanel_MenuHeader.RowCount = 2;
            this.tableLayoutPanel_MenuHeader.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_MenuHeader.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_MenuHeader.Size = new System.Drawing.Size(772, 99);
            this.tableLayoutPanel_MenuHeader.TabIndex = 6;
            // 
            // btnPause
            // 
            this.btnPause.BackColor = System.Drawing.SystemColors.Control;
            this.btnPause.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnPause.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPause.Location = new System.Drawing.Point(579, 49);
            this.btnPause.Margin = new System.Windows.Forms.Padding(0);
            this.btnPause.Name = "btnPause";
            this.btnPause.Size = new System.Drawing.Size(193, 50);
            this.btnPause.TabIndex = 18;
            this.btnPause.Text = "Завершение работы";
            this.btnPause.UseVisualStyleBackColor = false;
            this.btnPause.Click += new System.EventHandler(this.btnPause_Click);
            // 
            // btnPasswordsVisualization
            // 
            this.btnPasswordsVisualization.BackColor = System.Drawing.SystemColors.Control;
            this.btnPasswordsVisualization.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnPasswordsVisualization.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPasswordsVisualization.Location = new System.Drawing.Point(386, 49);
            this.btnPasswordsVisualization.Margin = new System.Windows.Forms.Padding(0);
            this.btnPasswordsVisualization.Name = "btnPasswordsVisualization";
            this.btnPasswordsVisualization.Size = new System.Drawing.Size(193, 50);
            this.btnPasswordsVisualization.TabIndex = 17;
            this.btnPasswordsVisualization.Text = "Отображать пароли";
            this.btnPasswordsVisualization.UseVisualStyleBackColor = false;
            this.btnPasswordsVisualization.Click += new System.EventHandler(this.btnPasswordsVisualization_Click);
            // 
            // btnLoginsVisualization
            // 
            this.btnLoginsVisualization.BackColor = System.Drawing.SystemColors.Control;
            this.btnLoginsVisualization.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnLoginsVisualization.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLoginsVisualization.Location = new System.Drawing.Point(193, 49);
            this.btnLoginsVisualization.Margin = new System.Windows.Forms.Padding(0);
            this.btnLoginsVisualization.Name = "btnLoginsVisualization";
            this.btnLoginsVisualization.Size = new System.Drawing.Size(193, 50);
            this.btnLoginsVisualization.TabIndex = 16;
            this.btnLoginsVisualization.Text = "Отображать логины";
            this.btnLoginsVisualization.UseVisualStyleBackColor = false;
            this.btnLoginsVisualization.Click += new System.EventHandler(this.btnLoginsVisualization_Click);
            // 
            // btnUsersAccountsVisualization
            // 
            this.btnUsersAccountsVisualization.BackColor = System.Drawing.SystemColors.Control;
            this.btnUsersAccountsVisualization.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnUsersAccountsVisualization.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUsersAccountsVisualization.Location = new System.Drawing.Point(0, 49);
            this.btnUsersAccountsVisualization.Margin = new System.Windows.Forms.Padding(0);
            this.btnUsersAccountsVisualization.Name = "btnUsersAccountsVisualization";
            this.btnUsersAccountsVisualization.Size = new System.Drawing.Size(193, 50);
            this.btnUsersAccountsVisualization.TabIndex = 15;
            this.btnUsersAccountsVisualization.Text = "Показать список пользователей";
            this.btnUsersAccountsVisualization.UseVisualStyleBackColor = false;
            this.btnUsersAccountsVisualization.Click += new System.EventHandler(this.btnUsersAccountsVisualization_Click);
            // 
            // lblAccessMenu
            // 
            this.lblAccessMenu.AutoSize = true;
            this.tableLayoutPanel_MenuHeader.SetColumnSpan(this.lblAccessMenu, 4);
            this.lblAccessMenu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblAccessMenu.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblAccessMenu.ForeColor = System.Drawing.Color.White;
            this.lblAccessMenu.Location = new System.Drawing.Point(3, 0);
            this.lblAccessMenu.Name = "lblAccessMenu";
            this.lblAccessMenu.Size = new System.Drawing.Size(766, 49);
            this.lblAccessMenu.TabIndex = 19;
            this.lblAccessMenu.Text = "НАСТРОЙКИ ДОСТУПА";
            this.lblAccessMenu.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel_Programm
            // 
            this.tableLayoutPanel_Programm.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPanel_Programm.ColumnCount = 1;
            this.tableLayoutPanel_Programm.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Programm.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Programm.Controls.Add(this.lblProgramm, 0, 0);
            this.tableLayoutPanel_Programm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Programm.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel_Programm.Name = "tableLayoutPanel_Programm";
            this.tableLayoutPanel_Programm.RowCount = 1;
            this.tableLayoutPanel_Programm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Programm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Programm.Size = new System.Drawing.Size(778, 43);
            this.tableLayoutPanel_Programm.TabIndex = 8;
            // 
            // lblProgramm
            // 
            this.lblProgramm.AutoSize = true;
            this.lblProgramm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblProgramm.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblProgramm.ForeColor = System.Drawing.Color.White;
            this.lblProgramm.Location = new System.Drawing.Point(3, 0);
            this.lblProgramm.Name = "lblProgramm";
            this.lblProgramm.Size = new System.Drawing.Size(772, 43);
            this.lblProgramm.TabIndex = 0;
            this.lblProgramm.Text = "ФОРМИРОВАНИЕ И ВЕДЕНИЕ ГРАФИКА ОТПУСКОВ СОТРУДНИКОВ";
            this.lblProgramm.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // MaintenanceForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 497);
            this.Controls.Add(this.tableLayoutPanel_AllForm);
            this.Name = "MaintenanceForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "КОНТРОЛЬ УЧЕТНЫХ ЗАПИСЕЙ ПОЛЬЗОВАТЕЛЕЙ";
            this.Load += new System.EventHandler(this.MaintenanceForm_Load);
            this.tableLayoutPanel_AllForm.ResumeLayout(false);
            this.tableLayoutPanel_Company.ResumeLayout(false);
            this.tableLayoutPanel_Company.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCompany)).EndInit();
            this.tableLayoutPanel_MainMenu.ResumeLayout(false);
            this.tableLayoutPanel_MenuOptions.ResumeLayout(false);
            this.groupBoxSearchAccount.ResumeLayout(false);
            this.tableLayoutPanelUserSearch.ResumeLayout(false);
            this.tableLayoutPanelUserSearch.PerformLayout();
            this.groupBoxUsersAccounts.ResumeLayout(false);
            this.tableLayoutPanelUsersAccounts.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewUsersAccounts)).EndInit();
            this.tableLayoutPanel_MenuHeader.ResumeLayout(false);
            this.tableLayoutPanel_MenuHeader.PerformLayout();
            this.tableLayoutPanel_Programm.ResumeLayout(false);
            this.tableLayoutPanel_Programm.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_AllForm;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Company;
        private System.Windows.Forms.PictureBox pictureBoxCompany;
        private System.Windows.Forms.Label lblCompany;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_MainMenu;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_MenuOptions;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_MenuHeader;
        private System.Windows.Forms.Label lblAccessMenu;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Programm;
        private System.Windows.Forms.Label lblProgramm;
        private System.Windows.Forms.Button btnUserChange;
        private System.Windows.Forms.Button btnCloseApplication;
        private System.Windows.Forms.Button btnPause;
        private System.Windows.Forms.Button btnPasswordsVisualization;
        private System.Windows.Forms.Button btnLoginsVisualization;
        private System.Windows.Forms.Button btnUsersAccountsVisualization;
        private System.Windows.Forms.GroupBox groupBoxSearchAccount;
        private System.Windows.Forms.GroupBox groupBoxUsersAccounts;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelUserSearch;
        private System.Windows.Forms.Label labelField;
        private System.Windows.Forms.Label labelText;
        private System.Windows.Forms.Button btnSearchExecute;
        private System.Windows.Forms.ComboBox comboBoxField;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelUsersAccounts;
        private System.Windows.Forms.Button btnAddUserAccount;
        private System.Windows.Forms.Button btnChangeUserAccount;
        private System.Windows.Forms.TextBox textBoxSearchingValue;
        private System.Windows.Forms.DataGridView dataGridViewUsersAccounts;
    }
}