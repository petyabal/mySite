﻿namespace VacationScheduleCreator
{
    partial class StaffingTableEditForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(StaffingTableEditForm));
            this.tableLayoutPanel_AllForm = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel_EditField = new System.Windows.Forms.TableLayoutPanel();
            this.tabControlStaffingTableEdit = new System.Windows.Forms.TabControl();
            this.tabPageStaffingTable = new System.Windows.Forms.TabPage();
            this.tableLayoutPannelStaffingTable = new System.Windows.Forms.TableLayoutPanel();
            this.tlpStaffingTableFunctionalButtons = new System.Windows.Forms.TableLayoutPanel();
            this.btnStaffingTableCancel = new System.Windows.Forms.Button();
            this.btnStaffingTablePost = new System.Windows.Forms.Button();
            this.tlpStaffingTableInput = new System.Windows.Forms.TableLayoutPanel();
            this.lBlFunction = new System.Windows.Forms.Label();
            this.lblCategory = new System.Windows.Forms.Label();
            this.lblEmployee = new System.Windows.Forms.Label();
            this.lblAddToVacation = new System.Windows.Forms.Label();
            this.lblStructuralUnit = new System.Windows.Forms.Label();
            this.comboBoxFunction = new System.Windows.Forms.ComboBox();
            this.comboBoxCategory = new System.Windows.Forms.ComboBox();
            this.comboBoxEmployee = new System.Windows.Forms.ComboBox();
            this.textBoxAddToVacation = new System.Windows.Forms.TextBox();
            this.comboBoxStructuralUnit = new System.Windows.Forms.ComboBox();
            this.btnToMin = new System.Windows.Forms.Button();
            this.btnToMax = new System.Windows.Forms.Button();
            this.tabPageStaffingTablesList = new System.Windows.Forms.TabPage();
            this.tlpStaffingTables = new System.Windows.Forms.TableLayoutPanel();
            this.tlpStaffingTablesInput = new System.Windows.Forms.TableLayoutPanel();
            this.textBoxComment = new System.Windows.Forms.TextBox();
            this.lblComment = new System.Windows.Forms.Label();
            this.comboBoxStatus = new System.Windows.Forms.ComboBox();
            this.labelStatus = new System.Windows.Forms.Label();
            this.lblYear = new System.Windows.Forms.Label();
            this.textBoxYear = new System.Windows.Forms.TextBox();
            this.btnMinus = new System.Windows.Forms.Button();
            this.btnPlus = new System.Windows.Forms.Button();
            this.tlpStaffingTablesButtons = new System.Windows.Forms.TableLayoutPanel();
            this.btnStaffingTablesPost = new System.Windows.Forms.Button();
            this.btnStaffingTablesCancel = new System.Windows.Forms.Button();
            this.tabPageStucturalUnits = new System.Windows.Forms.TabPage();
            this.tlpStructuralUnits = new System.Windows.Forms.TableLayoutPanel();
            this.tlpStucturalUnitsInput = new System.Windows.Forms.TableLayoutPanel();
            this.lblHierarchyLevel = new System.Windows.Forms.Label();
            this.comboBoxHierarchyLevel = new System.Windows.Forms.ComboBox();
            this.lblFullTitle = new System.Windows.Forms.Label();
            this.textBoxFullTitle = new System.Windows.Forms.TextBox();
            this.lblShortTitle = new System.Windows.Forms.Label();
            this.textBoxShortTitle = new System.Windows.Forms.TextBox();
            this.lblChief = new System.Windows.Forms.Label();
            this.comboBoxChief = new System.Windows.Forms.ComboBox();
            this.lblParentUnit = new System.Windows.Forms.Label();
            this.comboBoxParentUnit = new System.Windows.Forms.ComboBox();
            this.tlpStructuralUnitsFunctionalButtons = new System.Windows.Forms.TableLayoutPanel();
            this.btnStructuralUnitPost = new System.Windows.Forms.Button();
            this.btnStructuralUnitCancel = new System.Windows.Forms.Button();
            this.tableLayoutPanel_Company = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBoxCompany = new System.Windows.Forms.PictureBox();
            this.lblCompany = new System.Windows.Forms.Label();
            this.tableLayoutPanel_AllForm.SuspendLayout();
            this.tableLayoutPanel_EditField.SuspendLayout();
            this.tabControlStaffingTableEdit.SuspendLayout();
            this.tabPageStaffingTable.SuspendLayout();
            this.tableLayoutPannelStaffingTable.SuspendLayout();
            this.tlpStaffingTableFunctionalButtons.SuspendLayout();
            this.tlpStaffingTableInput.SuspendLayout();
            this.tabPageStaffingTablesList.SuspendLayout();
            this.tlpStaffingTables.SuspendLayout();
            this.tlpStaffingTablesInput.SuspendLayout();
            this.tlpStaffingTablesButtons.SuspendLayout();
            this.tabPageStucturalUnits.SuspendLayout();
            this.tlpStructuralUnits.SuspendLayout();
            this.tlpStucturalUnitsInput.SuspendLayout();
            this.tlpStructuralUnitsFunctionalButtons.SuspendLayout();
            this.tableLayoutPanel_Company.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCompany)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel_AllForm
            // 
            this.tableLayoutPanel_AllForm.ColumnCount = 1;
            this.tableLayoutPanel_AllForm.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_AllForm.Controls.Add(this.tableLayoutPanel_EditField, 0, 1);
            this.tableLayoutPanel_AllForm.Controls.Add(this.tableLayoutPanel_Company, 0, 0);
            this.tableLayoutPanel_AllForm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_AllForm.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel_AllForm.Name = "tableLayoutPanel_AllForm";
            this.tableLayoutPanel_AllForm.RowCount = 2;
            this.tableLayoutPanel_AllForm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel_AllForm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tableLayoutPanel_AllForm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel_AllForm.Size = new System.Drawing.Size(384, 561);
            this.tableLayoutPanel_AllForm.TabIndex = 3;
            // 
            // tableLayoutPanel_EditField
            // 
            this.tableLayoutPanel_EditField.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPanel_EditField.ColumnCount = 1;
            this.tableLayoutPanel_EditField.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_EditField.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel_EditField.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel_EditField.Controls.Add(this.tabControlStaffingTableEdit, 0, 0);
            this.tableLayoutPanel_EditField.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_EditField.Location = new System.Drawing.Point(3, 59);
            this.tableLayoutPanel_EditField.Name = "tableLayoutPanel_EditField";
            this.tableLayoutPanel_EditField.RowCount = 1;
            this.tableLayoutPanel_EditField.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tableLayoutPanel_EditField.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel_EditField.Size = new System.Drawing.Size(378, 499);
            this.tableLayoutPanel_EditField.TabIndex = 9;
            // 
            // tabControlStaffingTableEdit
            // 
            this.tabControlStaffingTableEdit.Controls.Add(this.tabPageStaffingTable);
            this.tabControlStaffingTableEdit.Controls.Add(this.tabPageStaffingTablesList);
            this.tabControlStaffingTableEdit.Controls.Add(this.tabPageStucturalUnits);
            this.tabControlStaffingTableEdit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlStaffingTableEdit.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tabControlStaffingTableEdit.Location = new System.Drawing.Point(3, 3);
            this.tabControlStaffingTableEdit.Name = "tabControlStaffingTableEdit";
            this.tabControlStaffingTableEdit.SelectedIndex = 0;
            this.tabControlStaffingTableEdit.Size = new System.Drawing.Size(372, 493);
            this.tabControlStaffingTableEdit.TabIndex = 0;
            // 
            // tabPageStaffingTable
            // 
            this.tabPageStaffingTable.Controls.Add(this.tableLayoutPannelStaffingTable);
            this.tabPageStaffingTable.Location = new System.Drawing.Point(4, 29);
            this.tabPageStaffingTable.Name = "tabPageStaffingTable";
            this.tabPageStaffingTable.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageStaffingTable.Size = new System.Drawing.Size(364, 460);
            this.tabPageStaffingTable.TabIndex = 0;
            this.tabPageStaffingTable.Text = "Штатное расписание";
            this.tabPageStaffingTable.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPannelStaffingTable
            // 
            this.tableLayoutPannelStaffingTable.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPannelStaffingTable.ColumnCount = 1;
            this.tableLayoutPannelStaffingTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPannelStaffingTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPannelStaffingTable.Controls.Add(this.tlpStaffingTableFunctionalButtons, 0, 1);
            this.tableLayoutPannelStaffingTable.Controls.Add(this.tlpStaffingTableInput, 0, 0);
            this.tableLayoutPannelStaffingTable.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPannelStaffingTable.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPannelStaffingTable.Name = "tableLayoutPannelStaffingTable";
            this.tableLayoutPannelStaffingTable.RowCount = 2;
            this.tableLayoutPannelStaffingTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tableLayoutPannelStaffingTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPannelStaffingTable.Size = new System.Drawing.Size(358, 454);
            this.tableLayoutPannelStaffingTable.TabIndex = 2;
            // 
            // tlpStaffingTableFunctionalButtons
            // 
            this.tlpStaffingTableFunctionalButtons.ColumnCount = 2;
            this.tlpStaffingTableFunctionalButtons.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpStaffingTableFunctionalButtons.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpStaffingTableFunctionalButtons.Controls.Add(this.btnStaffingTableCancel, 0, 0);
            this.tlpStaffingTableFunctionalButtons.Controls.Add(this.btnStaffingTablePost, 1, 0);
            this.tlpStaffingTableFunctionalButtons.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpStaffingTableFunctionalButtons.Location = new System.Drawing.Point(3, 411);
            this.tlpStaffingTableFunctionalButtons.Name = "tlpStaffingTableFunctionalButtons";
            this.tlpStaffingTableFunctionalButtons.RowCount = 1;
            this.tlpStaffingTableFunctionalButtons.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpStaffingTableFunctionalButtons.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tlpStaffingTableFunctionalButtons.Size = new System.Drawing.Size(352, 40);
            this.tlpStaffingTableFunctionalButtons.TabIndex = 17;
            // 
            // btnStaffingTableCancel
            // 
            this.btnStaffingTableCancel.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnStaffingTableCancel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnStaffingTableCancel.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnStaffingTableCancel.ForeColor = System.Drawing.Color.White;
            this.btnStaffingTableCancel.Location = new System.Drawing.Point(3, 3);
            this.btnStaffingTableCancel.Name = "btnStaffingTableCancel";
            this.btnStaffingTableCancel.Size = new System.Drawing.Size(170, 34);
            this.btnStaffingTableCancel.TabIndex = 13;
            this.btnStaffingTableCancel.Text = "Отмена";
            this.btnStaffingTableCancel.UseVisualStyleBackColor = false;
            this.btnStaffingTableCancel.Click += new System.EventHandler(this.btnStaffingTableCancel_Click);
            // 
            // btnStaffingTablePost
            // 
            this.btnStaffingTablePost.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnStaffingTablePost.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnStaffingTablePost.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnStaffingTablePost.ForeColor = System.Drawing.Color.White;
            this.btnStaffingTablePost.Location = new System.Drawing.Point(179, 3);
            this.btnStaffingTablePost.Name = "btnStaffingTablePost";
            this.btnStaffingTablePost.Size = new System.Drawing.Size(170, 34);
            this.btnStaffingTablePost.TabIndex = 15;
            this.btnStaffingTablePost.Text = "Сохранить данные";
            this.btnStaffingTablePost.UseVisualStyleBackColor = false;
            this.btnStaffingTablePost.Click += new System.EventHandler(this.btnStaffingTablePost_Click);
            // 
            // tlpStaffingTableInput
            // 
            this.tlpStaffingTableInput.BackColor = System.Drawing.Color.Tan;
            this.tlpStaffingTableInput.ColumnCount = 5;
            this.tlpStaffingTableInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tlpStaffingTableInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tlpStaffingTableInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tlpStaffingTableInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tlpStaffingTableInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tlpStaffingTableInput.Controls.Add(this.lBlFunction, 1, 0);
            this.tlpStaffingTableInput.Controls.Add(this.lblCategory, 1, 2);
            this.tlpStaffingTableInput.Controls.Add(this.lblEmployee, 1, 4);
            this.tlpStaffingTableInput.Controls.Add(this.lblAddToVacation, 1, 6);
            this.tlpStaffingTableInput.Controls.Add(this.lblStructuralUnit, 1, 8);
            this.tlpStaffingTableInput.Controls.Add(this.comboBoxFunction, 1, 1);
            this.tlpStaffingTableInput.Controls.Add(this.comboBoxCategory, 1, 3);
            this.tlpStaffingTableInput.Controls.Add(this.comboBoxEmployee, 1, 5);
            this.tlpStaffingTableInput.Controls.Add(this.textBoxAddToVacation, 2, 7);
            this.tlpStaffingTableInput.Controls.Add(this.comboBoxStructuralUnit, 1, 9);
            this.tlpStaffingTableInput.Controls.Add(this.btnToMin, 1, 7);
            this.tlpStaffingTableInput.Controls.Add(this.btnToMax, 3, 7);
            this.tlpStaffingTableInput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpStaffingTableInput.Location = new System.Drawing.Point(3, 3);
            this.tlpStaffingTableInput.Name = "tlpStaffingTableInput";
            this.tlpStaffingTableInput.RowCount = 11;
            this.tlpStaffingTableInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 17.5F));
            this.tlpStaffingTableInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpStaffingTableInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpStaffingTableInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpStaffingTableInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpStaffingTableInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpStaffingTableInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpStaffingTableInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpStaffingTableInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpStaffingTableInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpStaffingTableInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tlpStaffingTableInput.Size = new System.Drawing.Size(352, 402);
            this.tlpStaffingTableInput.TabIndex = 2;
            // 
            // lBlFunction
            // 
            this.lBlFunction.AutoSize = true;
            this.lBlFunction.BackColor = System.Drawing.Color.Transparent;
            this.tlpStaffingTableInput.SetColumnSpan(this.lBlFunction, 3);
            this.lBlFunction.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lBlFunction.ForeColor = System.Drawing.Color.Black;
            this.lBlFunction.Location = new System.Drawing.Point(73, 0);
            this.lBlFunction.Name = "lBlFunction";
            this.lBlFunction.Size = new System.Drawing.Size(204, 70);
            this.lBlFunction.TabIndex = 0;
            this.lBlFunction.Text = "Должность:";
            this.lBlFunction.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lblCategory
            // 
            this.lblCategory.AutoSize = true;
            this.tlpStaffingTableInput.SetColumnSpan(this.lblCategory, 3);
            this.lblCategory.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCategory.ForeColor = System.Drawing.Color.Black;
            this.lblCategory.Location = new System.Drawing.Point(73, 100);
            this.lblCategory.Name = "lblCategory";
            this.lblCategory.Size = new System.Drawing.Size(204, 30);
            this.lblCategory.TabIndex = 1;
            this.lblCategory.Text = "Категория:";
            this.lblCategory.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lblEmployee
            // 
            this.lblEmployee.AutoSize = true;
            this.tlpStaffingTableInput.SetColumnSpan(this.lblEmployee, 3);
            this.lblEmployee.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblEmployee.ForeColor = System.Drawing.Color.Black;
            this.lblEmployee.Location = new System.Drawing.Point(73, 160);
            this.lblEmployee.Name = "lblEmployee";
            this.lblEmployee.Size = new System.Drawing.Size(204, 30);
            this.lblEmployee.TabIndex = 3;
            this.lblEmployee.Text = "Сотрудник:";
            this.lblEmployee.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lblAddToVacation
            // 
            this.lblAddToVacation.AutoSize = true;
            this.tlpStaffingTableInput.SetColumnSpan(this.lblAddToVacation, 3);
            this.lblAddToVacation.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblAddToVacation.ForeColor = System.Drawing.Color.Black;
            this.lblAddToVacation.Location = new System.Drawing.Point(73, 220);
            this.lblAddToVacation.Name = "lblAddToVacation";
            this.lblAddToVacation.Size = new System.Drawing.Size(204, 30);
            this.lblAddToVacation.TabIndex = 4;
            this.lblAddToVacation.Text = "Дополнительно дней к отпуску:";
            this.lblAddToVacation.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lblStructuralUnit
            // 
            this.lblStructuralUnit.AutoSize = true;
            this.tlpStaffingTableInput.SetColumnSpan(this.lblStructuralUnit, 3);
            this.lblStructuralUnit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblStructuralUnit.ForeColor = System.Drawing.Color.Black;
            this.lblStructuralUnit.Location = new System.Drawing.Point(73, 280);
            this.lblStructuralUnit.Name = "lblStructuralUnit";
            this.lblStructuralUnit.Size = new System.Drawing.Size(204, 30);
            this.lblStructuralUnit.TabIndex = 14;
            this.lblStructuralUnit.Text = "Подразделение:";
            this.lblStructuralUnit.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // comboBoxFunction
            // 
            this.comboBoxFunction.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.tlpStaffingTableInput.SetColumnSpan(this.comboBoxFunction, 3);
            this.comboBoxFunction.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxFunction.FormattingEnabled = true;
            this.comboBoxFunction.Location = new System.Drawing.Point(73, 74);
            this.comboBoxFunction.Name = "comboBoxFunction";
            this.comboBoxFunction.Size = new System.Drawing.Size(204, 28);
            this.comboBoxFunction.TabIndex = 29;
            // 
            // comboBoxCategory
            // 
            this.comboBoxCategory.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.tlpStaffingTableInput.SetColumnSpan(this.comboBoxCategory, 3);
            this.comboBoxCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxCategory.FormattingEnabled = true;
            this.comboBoxCategory.Location = new System.Drawing.Point(73, 134);
            this.comboBoxCategory.Name = "comboBoxCategory";
            this.comboBoxCategory.Size = new System.Drawing.Size(204, 28);
            this.comboBoxCategory.TabIndex = 19;
            // 
            // comboBoxEmployee
            // 
            this.comboBoxEmployee.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.tlpStaffingTableInput.SetColumnSpan(this.comboBoxEmployee, 3);
            this.comboBoxEmployee.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxEmployee.FormattingEnabled = true;
            this.comboBoxEmployee.Location = new System.Drawing.Point(73, 194);
            this.comboBoxEmployee.Name = "comboBoxEmployee";
            this.comboBoxEmployee.Size = new System.Drawing.Size(204, 28);
            this.comboBoxEmployee.TabIndex = 30;
            // 
            // textBoxAddToVacation
            // 
            this.textBoxAddToVacation.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxAddToVacation.Enabled = false;
            this.textBoxAddToVacation.Location = new System.Drawing.Point(108, 253);
            this.textBoxAddToVacation.Name = "textBoxAddToVacation";
            this.textBoxAddToVacation.Size = new System.Drawing.Size(134, 25);
            this.textBoxAddToVacation.TabIndex = 25;
            this.textBoxAddToVacation.Text = "0";
            this.textBoxAddToVacation.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // comboBoxStructuralUnit
            // 
            this.comboBoxStructuralUnit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.tlpStaffingTableInput.SetColumnSpan(this.comboBoxStructuralUnit, 3);
            this.comboBoxStructuralUnit.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxStructuralUnit.FormattingEnabled = true;
            this.comboBoxStructuralUnit.Location = new System.Drawing.Point(73, 314);
            this.comboBoxStructuralUnit.Name = "comboBoxStructuralUnit";
            this.comboBoxStructuralUnit.Size = new System.Drawing.Size(204, 28);
            this.comboBoxStructuralUnit.TabIndex = 31;
            // 
            // btnToMin
            // 
            this.btnToMin.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnToMin.Location = new System.Drawing.Point(73, 250);
            this.btnToMin.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.btnToMin.Name = "btnToMin";
            this.btnToMin.Size = new System.Drawing.Size(29, 30);
            this.btnToMin.TabIndex = 32;
            this.btnToMin.Text = "<";
            this.btnToMin.UseVisualStyleBackColor = true;
            this.btnToMin.Click += new System.EventHandler(this.btnToMin_Click);
            // 
            // btnToMax
            // 
            this.btnToMax.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnToMax.Location = new System.Drawing.Point(248, 250);
            this.btnToMax.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.btnToMax.Name = "btnToMax";
            this.btnToMax.Size = new System.Drawing.Size(29, 30);
            this.btnToMax.TabIndex = 33;
            this.btnToMax.Text = ">";
            this.btnToMax.UseVisualStyleBackColor = true;
            this.btnToMax.Click += new System.EventHandler(this.btnToMax_Click);
            // 
            // tabPageStaffingTablesList
            // 
            this.tabPageStaffingTablesList.Controls.Add(this.tlpStaffingTables);
            this.tabPageStaffingTablesList.Location = new System.Drawing.Point(4, 25);
            this.tabPageStaffingTablesList.Name = "tabPageStaffingTablesList";
            this.tabPageStaffingTablesList.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageStaffingTablesList.Size = new System.Drawing.Size(324, 407);
            this.tabPageStaffingTablesList.TabIndex = 1;
            this.tabPageStaffingTablesList.Text = "Штатные расписания";
            this.tabPageStaffingTablesList.UseVisualStyleBackColor = true;
            // 
            // tlpStaffingTables
            // 
            this.tlpStaffingTables.BackColor = System.Drawing.Color.Tan;
            this.tlpStaffingTables.ColumnCount = 1;
            this.tlpStaffingTables.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpStaffingTables.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tlpStaffingTables.Controls.Add(this.tlpStaffingTablesInput, 0, 0);
            this.tlpStaffingTables.Controls.Add(this.tlpStaffingTablesButtons, 0, 1);
            this.tlpStaffingTables.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpStaffingTables.Location = new System.Drawing.Point(3, 3);
            this.tlpStaffingTables.Name = "tlpStaffingTables";
            this.tlpStaffingTables.RowCount = 2;
            this.tlpStaffingTables.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tlpStaffingTables.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tlpStaffingTables.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tlpStaffingTables.Size = new System.Drawing.Size(318, 401);
            this.tlpStaffingTables.TabIndex = 0;
            // 
            // tlpStaffingTablesInput
            // 
            this.tlpStaffingTablesInput.ColumnCount = 5;
            this.tlpStaffingTablesInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tlpStaffingTablesInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tlpStaffingTablesInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tlpStaffingTablesInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tlpStaffingTablesInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tlpStaffingTablesInput.Controls.Add(this.textBoxComment, 1, 5);
            this.tlpStaffingTablesInput.Controls.Add(this.lblComment, 1, 4);
            this.tlpStaffingTablesInput.Controls.Add(this.comboBoxStatus, 1, 3);
            this.tlpStaffingTablesInput.Controls.Add(this.labelStatus, 1, 2);
            this.tlpStaffingTablesInput.Controls.Add(this.lblYear, 1, 0);
            this.tlpStaffingTablesInput.Controls.Add(this.textBoxYear, 2, 1);
            this.tlpStaffingTablesInput.Controls.Add(this.btnMinus, 1, 1);
            this.tlpStaffingTablesInput.Controls.Add(this.btnPlus, 3, 1);
            this.tlpStaffingTablesInput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpStaffingTablesInput.Location = new System.Drawing.Point(3, 3);
            this.tlpStaffingTablesInput.Name = "tlpStaffingTablesInput";
            this.tlpStaffingTablesInput.RowCount = 7;
            this.tlpStaffingTablesInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 32.5F));
            this.tlpStaffingTablesInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpStaffingTablesInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpStaffingTablesInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpStaffingTablesInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpStaffingTablesInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpStaffingTablesInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tlpStaffingTablesInput.Size = new System.Drawing.Size(312, 354);
            this.tlpStaffingTablesInput.TabIndex = 10;
            // 
            // textBoxComment
            // 
            this.textBoxComment.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tlpStaffingTablesInput.SetColumnSpan(this.textBoxComment, 3);
            this.textBoxComment.Location = new System.Drawing.Point(65, 222);
            this.textBoxComment.MaxLength = 100;
            this.textBoxComment.Name = "textBoxComment";
            this.textBoxComment.Size = new System.Drawing.Size(180, 25);
            this.textBoxComment.TabIndex = 8;
            // 
            // lblComment
            // 
            this.lblComment.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblComment.AutoSize = true;
            this.tlpStaffingTablesInput.SetColumnSpan(this.lblComment, 3);
            this.lblComment.Location = new System.Drawing.Point(65, 199);
            this.lblComment.Name = "lblComment";
            this.lblComment.Size = new System.Drawing.Size(98, 20);
            this.lblComment.TabIndex = 6;
            this.lblComment.Text = "Комментарий:";
            // 
            // comboBoxStatus
            // 
            this.comboBoxStatus.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.tlpStaffingTablesInput.SetColumnSpan(this.comboBoxStatus, 3);
            this.comboBoxStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxStatus.FormattingEnabled = true;
            this.comboBoxStatus.Items.AddRange(new object[] {
            "Не утверждено",
            "Утверждено"});
            this.comboBoxStatus.Location = new System.Drawing.Point(65, 169);
            this.comboBoxStatus.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.comboBoxStatus.Name = "comboBoxStatus";
            this.comboBoxStatus.Size = new System.Drawing.Size(180, 28);
            this.comboBoxStatus.TabIndex = 10;
            // 
            // labelStatus
            // 
            this.labelStatus.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.labelStatus.AutoSize = true;
            this.tlpStaffingTablesInput.SetColumnSpan(this.labelStatus, 3);
            this.labelStatus.Location = new System.Drawing.Point(65, 147);
            this.labelStatus.Name = "labelStatus";
            this.labelStatus.Size = new System.Drawing.Size(55, 20);
            this.labelStatus.TabIndex = 9;
            this.labelStatus.Text = "Статус:";
            // 
            // lblYear
            // 
            this.lblYear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblYear.AutoSize = true;
            this.tlpStaffingTablesInput.SetColumnSpan(this.lblYear, 3);
            this.lblYear.Location = new System.Drawing.Point(65, 95);
            this.lblYear.Name = "lblYear";
            this.lblYear.Size = new System.Drawing.Size(129, 20);
            this.lblYear.TabIndex = 1;
            this.lblYear.Text = "Составлено на год:";
            // 
            // textBoxYear
            // 
            this.textBoxYear.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxYear.Enabled = false;
            this.textBoxYear.Location = new System.Drawing.Point(96, 118);
            this.textBoxYear.Name = "textBoxYear";
            this.textBoxYear.Size = new System.Drawing.Size(118, 25);
            this.textBoxYear.TabIndex = 7;
            this.textBoxYear.Text = "2018";
            this.textBoxYear.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnMinus
            // 
            this.btnMinus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnMinus.Location = new System.Drawing.Point(65, 115);
            this.btnMinus.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.btnMinus.Name = "btnMinus";
            this.btnMinus.Size = new System.Drawing.Size(25, 26);
            this.btnMinus.TabIndex = 11;
            this.btnMinus.Text = "<";
            this.btnMinus.UseVisualStyleBackColor = true;
            this.btnMinus.Click += new System.EventHandler(this.btnMinus_Click);
            // 
            // btnPlus
            // 
            this.btnPlus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnPlus.Location = new System.Drawing.Point(220, 115);
            this.btnPlus.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.btnPlus.Name = "btnPlus";
            this.btnPlus.Size = new System.Drawing.Size(25, 26);
            this.btnPlus.TabIndex = 12;
            this.btnPlus.Text = ">";
            this.btnPlus.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnPlus.UseVisualStyleBackColor = true;
            this.btnPlus.Click += new System.EventHandler(this.btnPlus_Click);
            // 
            // tlpStaffingTablesButtons
            // 
            this.tlpStaffingTablesButtons.ColumnCount = 2;
            this.tlpStaffingTablesButtons.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpStaffingTablesButtons.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpStaffingTablesButtons.Controls.Add(this.btnStaffingTablesPost, 1, 0);
            this.tlpStaffingTablesButtons.Controls.Add(this.btnStaffingTablesCancel, 0, 0);
            this.tlpStaffingTablesButtons.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpStaffingTablesButtons.Location = new System.Drawing.Point(3, 363);
            this.tlpStaffingTablesButtons.Name = "tlpStaffingTablesButtons";
            this.tlpStaffingTablesButtons.RowCount = 1;
            this.tlpStaffingTablesButtons.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpStaffingTablesButtons.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tlpStaffingTablesButtons.Size = new System.Drawing.Size(312, 35);
            this.tlpStaffingTablesButtons.TabIndex = 1;
            // 
            // btnStaffingTablesPost
            // 
            this.btnStaffingTablesPost.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnStaffingTablesPost.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnStaffingTablesPost.ForeColor = System.Drawing.Color.White;
            this.btnStaffingTablesPost.Location = new System.Drawing.Point(159, 3);
            this.btnStaffingTablesPost.Name = "btnStaffingTablesPost";
            this.btnStaffingTablesPost.Size = new System.Drawing.Size(150, 29);
            this.btnStaffingTablesPost.TabIndex = 0;
            this.btnStaffingTablesPost.Text = "Сохранить данные";
            this.btnStaffingTablesPost.UseVisualStyleBackColor = false;
            this.btnStaffingTablesPost.Click += new System.EventHandler(this.btnStaffingTablesPost_Click);
            // 
            // btnStaffingTablesCancel
            // 
            this.btnStaffingTablesCancel.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnStaffingTablesCancel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnStaffingTablesCancel.ForeColor = System.Drawing.Color.White;
            this.btnStaffingTablesCancel.Location = new System.Drawing.Point(3, 3);
            this.btnStaffingTablesCancel.Name = "btnStaffingTablesCancel";
            this.btnStaffingTablesCancel.Size = new System.Drawing.Size(150, 29);
            this.btnStaffingTablesCancel.TabIndex = 1;
            this.btnStaffingTablesCancel.Text = "Отмена";
            this.btnStaffingTablesCancel.UseVisualStyleBackColor = false;
            this.btnStaffingTablesCancel.Click += new System.EventHandler(this.btnStaffingTablesCancel_Click);
            // 
            // tabPageStucturalUnits
            // 
            this.tabPageStucturalUnits.Controls.Add(this.tlpStructuralUnits);
            this.tabPageStucturalUnits.Location = new System.Drawing.Point(4, 25);
            this.tabPageStucturalUnits.Name = "tabPageStucturalUnits";
            this.tabPageStucturalUnits.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageStucturalUnits.Size = new System.Drawing.Size(324, 407);
            this.tabPageStucturalUnits.TabIndex = 2;
            this.tabPageStucturalUnits.Text = "Структурные подразделения";
            this.tabPageStucturalUnits.UseVisualStyleBackColor = true;
            // 
            // tlpStructuralUnits
            // 
            this.tlpStructuralUnits.BackColor = System.Drawing.Color.Tan;
            this.tlpStructuralUnits.ColumnCount = 1;
            this.tlpStructuralUnits.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpStructuralUnits.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tlpStructuralUnits.Controls.Add(this.tlpStucturalUnitsInput, 0, 0);
            this.tlpStructuralUnits.Controls.Add(this.tlpStructuralUnitsFunctionalButtons, 0, 1);
            this.tlpStructuralUnits.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpStructuralUnits.Location = new System.Drawing.Point(3, 3);
            this.tlpStructuralUnits.Name = "tlpStructuralUnits";
            this.tlpStructuralUnits.RowCount = 2;
            this.tlpStructuralUnits.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tlpStructuralUnits.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tlpStructuralUnits.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tlpStructuralUnits.Size = new System.Drawing.Size(318, 401);
            this.tlpStructuralUnits.TabIndex = 0;
            // 
            // tlpStucturalUnitsInput
            // 
            this.tlpStucturalUnitsInput.ColumnCount = 3;
            this.tlpStucturalUnitsInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tlpStucturalUnitsInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tlpStucturalUnitsInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tlpStucturalUnitsInput.Controls.Add(this.lblHierarchyLevel, 1, 0);
            this.tlpStucturalUnitsInput.Controls.Add(this.comboBoxHierarchyLevel, 1, 1);
            this.tlpStucturalUnitsInput.Controls.Add(this.lblFullTitle, 1, 2);
            this.tlpStucturalUnitsInput.Controls.Add(this.textBoxFullTitle, 1, 3);
            this.tlpStucturalUnitsInput.Controls.Add(this.lblShortTitle, 1, 4);
            this.tlpStucturalUnitsInput.Controls.Add(this.textBoxShortTitle, 1, 5);
            this.tlpStucturalUnitsInput.Controls.Add(this.lblChief, 1, 6);
            this.tlpStucturalUnitsInput.Controls.Add(this.comboBoxChief, 1, 7);
            this.tlpStucturalUnitsInput.Controls.Add(this.lblParentUnit, 1, 8);
            this.tlpStucturalUnitsInput.Controls.Add(this.comboBoxParentUnit, 1, 9);
            this.tlpStucturalUnitsInput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpStucturalUnitsInput.Location = new System.Drawing.Point(3, 3);
            this.tlpStucturalUnitsInput.Name = "tlpStucturalUnitsInput";
            this.tlpStucturalUnitsInput.RowCount = 11;
            this.tlpStucturalUnitsInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 17.5F));
            this.tlpStucturalUnitsInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpStucturalUnitsInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpStucturalUnitsInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpStucturalUnitsInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpStucturalUnitsInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpStucturalUnitsInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpStucturalUnitsInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpStucturalUnitsInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpStucturalUnitsInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpStucturalUnitsInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tlpStucturalUnitsInput.Size = new System.Drawing.Size(312, 354);
            this.tlpStucturalUnitsInput.TabIndex = 9;
            // 
            // lblHierarchyLevel
            // 
            this.lblHierarchyLevel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblHierarchyLevel.AutoSize = true;
            this.lblHierarchyLevel.Location = new System.Drawing.Point(65, 41);
            this.lblHierarchyLevel.Name = "lblHierarchyLevel";
            this.lblHierarchyLevel.Size = new System.Drawing.Size(130, 20);
            this.lblHierarchyLevel.TabIndex = 1;
            this.lblHierarchyLevel.Text = "Уровень иерархии:";
            // 
            // comboBoxHierarchyLevel
            // 
            this.comboBoxHierarchyLevel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBoxHierarchyLevel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxHierarchyLevel.FormattingEnabled = true;
            this.comboBoxHierarchyLevel.Location = new System.Drawing.Point(65, 63);
            this.comboBoxHierarchyLevel.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.comboBoxHierarchyLevel.Name = "comboBoxHierarchyLevel";
            this.comboBoxHierarchyLevel.Size = new System.Drawing.Size(181, 28);
            this.comboBoxHierarchyLevel.TabIndex = 3;
            // 
            // lblFullTitle
            // 
            this.lblFullTitle.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblFullTitle.AutoSize = true;
            this.lblFullTitle.Location = new System.Drawing.Point(65, 93);
            this.lblFullTitle.Name = "lblFullTitle";
            this.lblFullTitle.Size = new System.Drawing.Size(153, 20);
            this.lblFullTitle.TabIndex = 7;
            this.lblFullTitle.Text = "Полное наименование:";
            // 
            // textBoxFullTitle
            // 
            this.textBoxFullTitle.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxFullTitle.Location = new System.Drawing.Point(65, 116);
            this.textBoxFullTitle.MaxLength = 80;
            this.textBoxFullTitle.Name = "textBoxFullTitle";
            this.textBoxFullTitle.Size = new System.Drawing.Size(181, 25);
            this.textBoxFullTitle.TabIndex = 5;
            // 
            // lblShortTitle
            // 
            this.lblShortTitle.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblShortTitle.AutoSize = true;
            this.lblShortTitle.Location = new System.Drawing.Point(65, 145);
            this.lblShortTitle.Name = "lblShortTitle";
            this.lblShortTitle.Size = new System.Drawing.Size(156, 20);
            this.lblShortTitle.TabIndex = 2;
            this.lblShortTitle.Text = "Краткое наименование:";
            // 
            // textBoxShortTitle
            // 
            this.textBoxShortTitle.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxShortTitle.Location = new System.Drawing.Point(65, 168);
            this.textBoxShortTitle.MaxLength = 20;
            this.textBoxShortTitle.Name = "textBoxShortTitle";
            this.textBoxShortTitle.Size = new System.Drawing.Size(181, 25);
            this.textBoxShortTitle.TabIndex = 6;
            // 
            // lblChief
            // 
            this.lblChief.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblChief.AutoSize = true;
            this.lblChief.Location = new System.Drawing.Point(65, 191);
            this.lblChief.Name = "lblChief";
            this.lblChief.Size = new System.Drawing.Size(109, 26);
            this.lblChief.TabIndex = 8;
            this.lblChief.Text = "Руководитель подразделения:";
            // 
            // comboBoxChief
            // 
            this.comboBoxChief.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBoxChief.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxChief.FormattingEnabled = true;
            this.comboBoxChief.Location = new System.Drawing.Point(65, 219);
            this.comboBoxChief.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.comboBoxChief.Name = "comboBoxChief";
            this.comboBoxChief.Size = new System.Drawing.Size(181, 28);
            this.comboBoxChief.TabIndex = 4;
            // 
            // lblParentUnit
            // 
            this.lblParentUnit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblParentUnit.AutoSize = true;
            this.lblParentUnit.Location = new System.Drawing.Point(65, 243);
            this.lblParentUnit.Name = "lblParentUnit";
            this.lblParentUnit.Size = new System.Drawing.Size(105, 26);
            this.lblParentUnit.TabIndex = 9;
            this.lblParentUnit.Text = "Родительское подразделение";
            // 
            // comboBoxParentUnit
            // 
            this.comboBoxParentUnit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBoxParentUnit.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxParentUnit.FormattingEnabled = true;
            this.comboBoxParentUnit.Location = new System.Drawing.Point(65, 271);
            this.comboBoxParentUnit.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.comboBoxParentUnit.Name = "comboBoxParentUnit";
            this.comboBoxParentUnit.Size = new System.Drawing.Size(181, 28);
            this.comboBoxParentUnit.TabIndex = 10;
            // 
            // tlpStructuralUnitsFunctionalButtons
            // 
            this.tlpStructuralUnitsFunctionalButtons.ColumnCount = 2;
            this.tlpStructuralUnitsFunctionalButtons.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpStructuralUnitsFunctionalButtons.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpStructuralUnitsFunctionalButtons.Controls.Add(this.btnStructuralUnitPost, 1, 0);
            this.tlpStructuralUnitsFunctionalButtons.Controls.Add(this.btnStructuralUnitCancel, 0, 0);
            this.tlpStructuralUnitsFunctionalButtons.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpStructuralUnitsFunctionalButtons.Location = new System.Drawing.Point(3, 363);
            this.tlpStructuralUnitsFunctionalButtons.Name = "tlpStructuralUnitsFunctionalButtons";
            this.tlpStructuralUnitsFunctionalButtons.RowCount = 1;
            this.tlpStructuralUnitsFunctionalButtons.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpStructuralUnitsFunctionalButtons.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tlpStructuralUnitsFunctionalButtons.Size = new System.Drawing.Size(312, 35);
            this.tlpStructuralUnitsFunctionalButtons.TabIndex = 1;
            // 
            // btnStructuralUnitPost
            // 
            this.btnStructuralUnitPost.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnStructuralUnitPost.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnStructuralUnitPost.ForeColor = System.Drawing.Color.White;
            this.btnStructuralUnitPost.Location = new System.Drawing.Point(159, 3);
            this.btnStructuralUnitPost.Name = "btnStructuralUnitPost";
            this.btnStructuralUnitPost.Size = new System.Drawing.Size(150, 29);
            this.btnStructuralUnitPost.TabIndex = 0;
            this.btnStructuralUnitPost.Text = "Сохранить данные";
            this.btnStructuralUnitPost.UseVisualStyleBackColor = false;
            this.btnStructuralUnitPost.Click += new System.EventHandler(this.btnStructuralUnitPost_Click);
            // 
            // btnStructuralUnitCancel
            // 
            this.btnStructuralUnitCancel.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnStructuralUnitCancel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnStructuralUnitCancel.ForeColor = System.Drawing.Color.White;
            this.btnStructuralUnitCancel.Location = new System.Drawing.Point(3, 3);
            this.btnStructuralUnitCancel.Name = "btnStructuralUnitCancel";
            this.btnStructuralUnitCancel.Size = new System.Drawing.Size(150, 29);
            this.btnStructuralUnitCancel.TabIndex = 1;
            this.btnStructuralUnitCancel.Text = "Отмена";
            this.btnStructuralUnitCancel.UseVisualStyleBackColor = false;
            this.btnStructuralUnitCancel.Click += new System.EventHandler(this.btnStructuralUnitCancel_Click);
            // 
            // tableLayoutPanel_Company
            // 
            this.tableLayoutPanel_Company.BackColor = System.Drawing.SystemColors.HotTrack;
            this.tableLayoutPanel_Company.ColumnCount = 3;
            this.tableLayoutPanel_Company.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_Company.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.tableLayoutPanel_Company.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel_Company.Controls.Add(this.pictureBoxCompany, 0, 1);
            this.tableLayoutPanel_Company.Controls.Add(this.lblCompany, 1, 1);
            this.tableLayoutPanel_Company.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Company.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel_Company.Name = "tableLayoutPanel_Company";
            this.tableLayoutPanel_Company.RowCount = 3;
            this.tableLayoutPanel_Company.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel_Company.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tableLayoutPanel_Company.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel_Company.Size = new System.Drawing.Size(378, 50);
            this.tableLayoutPanel_Company.TabIndex = 8;
            // 
            // pictureBoxCompany
            // 
            this.pictureBoxCompany.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxCompany.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxCompany.Image")));
            this.pictureBoxCompany.Location = new System.Drawing.Point(0, 2);
            this.pictureBoxCompany.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBoxCompany.Name = "pictureBoxCompany";
            this.pictureBoxCompany.Size = new System.Drawing.Size(94, 45);
            this.pictureBoxCompany.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxCompany.TabIndex = 3;
            this.pictureBoxCompany.TabStop = false;
            // 
            // lblCompany
            // 
            this.lblCompany.AutoSize = true;
            this.lblCompany.BackColor = System.Drawing.SystemColors.HotTrack;
            this.lblCompany.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCompany.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblCompany.ForeColor = System.Drawing.Color.White;
            this.lblCompany.Location = new System.Drawing.Point(97, 2);
            this.lblCompany.Name = "lblCompany";
            this.lblCompany.Size = new System.Drawing.Size(258, 45);
            this.lblCompany.TabIndex = 2;
            this.lblCompany.Text = "МЕЖРЕГИОНАЛЬНАЯ РАСПРЕДЕЛИТЕЛЬНАЯ СЕТЕВАЯ КОМПАНИЯ СЕВЕРО-ЗАПАДА";
            this.lblCompany.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // StaffingTableEditForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(384, 561);
            this.Controls.Add(this.tableLayoutPanel_AllForm);
            this.Name = "StaffingTableEditForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "РЕДАКТОР ОРГАНИЗАЦ. СТРУКТУРЫ";
            this.Load += new System.EventHandler(this.StaffingTableEditForm_Load);
            this.Shown += new System.EventHandler(this.StaffingTableEditForm_Shown);
            this.tableLayoutPanel_AllForm.ResumeLayout(false);
            this.tableLayoutPanel_EditField.ResumeLayout(false);
            this.tabControlStaffingTableEdit.ResumeLayout(false);
            this.tabPageStaffingTable.ResumeLayout(false);
            this.tableLayoutPannelStaffingTable.ResumeLayout(false);
            this.tlpStaffingTableFunctionalButtons.ResumeLayout(false);
            this.tlpStaffingTableInput.ResumeLayout(false);
            this.tlpStaffingTableInput.PerformLayout();
            this.tabPageStaffingTablesList.ResumeLayout(false);
            this.tlpStaffingTables.ResumeLayout(false);
            this.tlpStaffingTablesInput.ResumeLayout(false);
            this.tlpStaffingTablesInput.PerformLayout();
            this.tlpStaffingTablesButtons.ResumeLayout(false);
            this.tabPageStucturalUnits.ResumeLayout(false);
            this.tlpStructuralUnits.ResumeLayout(false);
            this.tlpStucturalUnitsInput.ResumeLayout(false);
            this.tlpStucturalUnitsInput.PerformLayout();
            this.tlpStructuralUnitsFunctionalButtons.ResumeLayout(false);
            this.tableLayoutPanel_Company.ResumeLayout(false);
            this.tableLayoutPanel_Company.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCompany)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_AllForm;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_EditField;
        private System.Windows.Forms.TabControl tabControlStaffingTableEdit;
        private System.Windows.Forms.TabPage tabPageStaffingTable;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPannelStaffingTable;
        private System.Windows.Forms.TableLayoutPanel tlpStaffingTableFunctionalButtons;
        private System.Windows.Forms.Button btnStaffingTableCancel;
        private System.Windows.Forms.Button btnStaffingTablePost;
        private System.Windows.Forms.TableLayoutPanel tlpStaffingTableInput;
        private System.Windows.Forms.Label lBlFunction;
        private System.Windows.Forms.TextBox textBoxAddToVacation;
        private System.Windows.Forms.Label lblCategory;
        private System.Windows.Forms.Label lblEmployee;
        private System.Windows.Forms.Label lblAddToVacation;
        private System.Windows.Forms.ComboBox comboBoxCategory;
        private System.Windows.Forms.Label lblStructuralUnit;
        private System.Windows.Forms.TabPage tabPageStaffingTablesList;
        private System.Windows.Forms.TableLayoutPanel tlpStaffingTables;
        private System.Windows.Forms.TableLayoutPanel tlpStaffingTablesInput;
        private System.Windows.Forms.Label lblYear;
        private System.Windows.Forms.TextBox textBoxYear;
        private System.Windows.Forms.Label lblComment;
        private System.Windows.Forms.TextBox textBoxComment;
        private System.Windows.Forms.Label labelStatus;
        private System.Windows.Forms.ComboBox comboBoxStatus;
        private System.Windows.Forms.TableLayoutPanel tlpStaffingTablesButtons;
        private System.Windows.Forms.Button btnStaffingTablesPost;
        private System.Windows.Forms.Button btnStaffingTablesCancel;
        private System.Windows.Forms.TabPage tabPageStucturalUnits;
        private System.Windows.Forms.TableLayoutPanel tlpStructuralUnits;
        private System.Windows.Forms.TableLayoutPanel tlpStucturalUnitsInput;
        private System.Windows.Forms.Label lblHierarchyLevel;
        private System.Windows.Forms.Label lblShortTitle;
        private System.Windows.Forms.ComboBox comboBoxHierarchyLevel;
        private System.Windows.Forms.ComboBox comboBoxChief;
        private System.Windows.Forms.TableLayoutPanel tlpStructuralUnitsFunctionalButtons;
        private System.Windows.Forms.Button btnStructuralUnitPost;
        private System.Windows.Forms.Button btnStructuralUnitCancel;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Company;
        private System.Windows.Forms.PictureBox pictureBoxCompany;
        private System.Windows.Forms.Label lblCompany;
        private System.Windows.Forms.TextBox textBoxFullTitle;
        private System.Windows.Forms.TextBox textBoxShortTitle;
        private System.Windows.Forms.Label lblFullTitle;
        private System.Windows.Forms.Label lblChief;
        private System.Windows.Forms.Label lblParentUnit;
        private System.Windows.Forms.ComboBox comboBoxParentUnit;
        private System.Windows.Forms.Button btnMinus;
        private System.Windows.Forms.Button btnPlus;
        private System.Windows.Forms.ComboBox comboBoxFunction;
        private System.Windows.Forms.ComboBox comboBoxEmployee;
        private System.Windows.Forms.ComboBox comboBoxStructuralUnit;
        private System.Windows.Forms.Button btnToMin;
        private System.Windows.Forms.Button btnToMax;
    }
}