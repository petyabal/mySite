﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace VacationScheduleCreator
{
    // класс формы для просмотра штатного расписания и сопутствующих данных
    public partial class StaffingTableForm : Form
    {
        public StaffingTableForm()
        {
            InitializeComponent();
        }

        //процедура вывода информации из таблиц БД в экранную таблицу
        private void StaffingTableForm_Load(object sender, EventArgs e)
        {
            DB_Connection.ShowStaffingTableStatus();
            dataGridViewStaffingTableStatus.DataSource = DB_Connection.dtStaffingTablesList;
            dataGridViewStaffingTableStatus.Columns["Staffing_table_id"].Visible = false;
            DB_Connection.ShowStructuralUnits();
            dataGridViewStructuralUnits.DataSource = DB_Connection.dtStructuralUnits;
            dataGridViewStructuralUnits.Columns["Unit_id"].Visible = false;
            if (dataGridViewStaffingTableStatus.RowCount != 0)
            DB_Connection.ShowStaffingTable();
            dataGridViewStaffingTable.DataSource = DB_Connection.dtStaffingTable;
            dataGridViewStaffingTable.Columns["Position_id"].Visible = false;
            dataGridViewStaffingTable.Columns["staffing_table_id"].Visible = false;              
        }

        //процедура обновления данных в таблицах
        void RefreshData()
        {
            DB_Connection.ShowStaffingTableStatus();
            DB_Connection.ShowStructuralUnits();
            DB_Connection.ShowStaffingTable();
        }

        //процедура настройки и показа формы для отображения штатного расписания
        private void btnStaffingTableDetail_Click(object sender, EventArgs e)
        {
            StaffingTableDetailForm StaffingTableDetail = new StaffingTableDetailForm();
            StaffingTableDetail.ShowStaffingTableTab();
            StaffingTableDetail.WindowState = FormWindowState.Maximized;
            StaffingTableDetail.ShowDialog();
            RefreshData();
        }

        //процедура настройки и показа форы для отображения перечня штатных расписаний
        private void btnStaffingTableStatusDetail_Click(object sender, EventArgs e)
        {
            StaffingTableDetailForm StaffingTableDetail = new StaffingTableDetailForm();
            StaffingTableDetail.ShowStaffingTableStatusTab();
            StaffingTableDetail.WindowState = FormWindowState.Maximized;
            StaffingTableDetail.ShowDialog();
            RefreshData();
        }

        //процедура настройки и показа формы для отображения структурных подразделений
        private void btnStructuralUnitsDetail_Click(object sender, EventArgs e)
        {
            StaffingTableDetailForm StaffingTableDetail = new StaffingTableDetailForm();
            StaffingTableDetail.ShowStructuralUnitsTab();
            StaffingTableDetail.WindowState = FormWindowState.Maximized;
            StaffingTableDetail.ShowDialog();
            RefreshData();
        }
    }
}
