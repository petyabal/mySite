﻿namespace VacationScheduleCreator
{
    partial class OrganizationSettingsDetailForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(OrganizationSettingsDetailForm));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tableLayoutPanel_AllForm = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel_Company = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBoxCompany = new System.Windows.Forms.PictureBox();
            this.lblCompany = new System.Windows.Forms.Label();
            this.tableLayoutPanel_OrganizationSettingsDetail = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel_Working_field = new System.Windows.Forms.TableLayoutPanel();
            this.tabControlOrganizationSettings = new System.Windows.Forms.TabControl();
            this.tabPageCompanyInformation = new System.Windows.Forms.TabPage();
            this.tableLayoutPanelCompanyInformation = new System.Windows.Forms.TableLayoutPanel();
            this.dataGridViewCompanyInformation = new System.Windows.Forms.DataGridView();
            this.btnChangeInCompanyInformationList = new System.Windows.Forms.Button();
            this.tabPageHierarchyLevels = new System.Windows.Forms.TabPage();
            this.tableLayoutPanelHierarchyLevels = new System.Windows.Forms.TableLayoutPanel();
            this.dataGridViewHierarchyLevels = new System.Windows.Forms.DataGridView();
            this.btnAddToHierarchyLevelList = new System.Windows.Forms.Button();
            this.btnChangeInHierarchyLevelList = new System.Windows.Forms.Button();
            this.btnDeleteFromHierarchyLevelList = new System.Windows.Forms.Button();
            this.tabPageFunctions = new System.Windows.Forms.TabPage();
            this.tableLayoutPanelFunctions = new System.Windows.Forms.TableLayoutPanel();
            this.dataGridViewFunctions = new System.Windows.Forms.DataGridView();
            this.btnAddToFunctionsList = new System.Windows.Forms.Button();
            this.btnChangeInFunctionsList = new System.Windows.Forms.Button();
            this.btnDeleteFromFunctionsList = new System.Windows.Forms.Button();
            this.tabPagePersonnelCategories = new System.Windows.Forms.TabPage();
            this.tableLayoutPanelPersonnelCategories = new System.Windows.Forms.TableLayoutPanel();
            this.dataGridViewPersonnelCategories = new System.Windows.Forms.DataGridView();
            this.btnAddToPersonnelCategoryList = new System.Windows.Forms.Button();
            this.btnChangeInPersonnelCategoryList = new System.Windows.Forms.Button();
            this.btnDeleteFromPersonnelCategoryList = new System.Windows.Forms.Button();
            this.tabPageStateHolidaysList = new System.Windows.Forms.TabPage();
            this.tableLayoutPanelStateHolidaysList = new System.Windows.Forms.TableLayoutPanel();
            this.btnAddToStateHolidaysList = new System.Windows.Forms.Button();
            this.dataGridViewStateHolidaysList = new System.Windows.Forms.DataGridView();
            this.ChangeInStateHolidaysList = new System.Windows.Forms.Button();
            this.DeleteFromStateHolidaysList = new System.Windows.Forms.Button();
            this.tableLayoutPanel_WindowHeader = new System.Windows.Forms.TableLayoutPanel();
            this.lblOrrganizatinSettingsDetail = new System.Windows.Forms.Label();
            this.tableLayoutPanel_Programm = new System.Windows.Forms.TableLayoutPanel();
            this.lblProgramm = new System.Windows.Forms.Label();
            this.tableLayoutPanel_AllForm.SuspendLayout();
            this.tableLayoutPanel_Company.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCompany)).BeginInit();
            this.tableLayoutPanel_OrganizationSettingsDetail.SuspendLayout();
            this.tableLayoutPanel_Working_field.SuspendLayout();
            this.tabControlOrganizationSettings.SuspendLayout();
            this.tabPageCompanyInformation.SuspendLayout();
            this.tableLayoutPanelCompanyInformation.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCompanyInformation)).BeginInit();
            this.tabPageHierarchyLevels.SuspendLayout();
            this.tableLayoutPanelHierarchyLevels.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewHierarchyLevels)).BeginInit();
            this.tabPageFunctions.SuspendLayout();
            this.tableLayoutPanelFunctions.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewFunctions)).BeginInit();
            this.tabPagePersonnelCategories.SuspendLayout();
            this.tableLayoutPanelPersonnelCategories.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPersonnelCategories)).BeginInit();
            this.tabPageStateHolidaysList.SuspendLayout();
            this.tableLayoutPanelStateHolidaysList.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewStateHolidaysList)).BeginInit();
            this.tableLayoutPanel_WindowHeader.SuspendLayout();
            this.tableLayoutPanel_Programm.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel_AllForm
            // 
            this.tableLayoutPanel_AllForm.ColumnCount = 1;
            this.tableLayoutPanel_AllForm.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_AllForm.Controls.Add(this.tableLayoutPanel_Company, 0, 1);
            this.tableLayoutPanel_AllForm.Controls.Add(this.tableLayoutPanel_OrganizationSettingsDetail, 0, 2);
            this.tableLayoutPanel_AllForm.Controls.Add(this.tableLayoutPanel_Programm, 0, 0);
            this.tableLayoutPanel_AllForm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_AllForm.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel_AllForm.Name = "tableLayoutPanel_AllForm";
            this.tableLayoutPanel_AllForm.RowCount = 3;
            this.tableLayoutPanel_AllForm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel_AllForm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tableLayoutPanel_AllForm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 75F));
            this.tableLayoutPanel_AllForm.Size = new System.Drawing.Size(784, 497);
            this.tableLayoutPanel_AllForm.TabIndex = 8;
            // 
            // tableLayoutPanel_Company
            // 
            this.tableLayoutPanel_Company.BackColor = System.Drawing.SystemColors.HotTrack;
            this.tableLayoutPanel_Company.ColumnCount = 2;
            this.tableLayoutPanel_Company.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel_Company.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.tableLayoutPanel_Company.Controls.Add(this.pictureBoxCompany, 0, 1);
            this.tableLayoutPanel_Company.Controls.Add(this.lblCompany, 1, 1);
            this.tableLayoutPanel_Company.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Company.Location = new System.Drawing.Point(3, 52);
            this.tableLayoutPanel_Company.Name = "tableLayoutPanel_Company";
            this.tableLayoutPanel_Company.RowCount = 3;
            this.tableLayoutPanel_Company.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel_Company.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tableLayoutPanel_Company.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel_Company.Size = new System.Drawing.Size(778, 68);
            this.tableLayoutPanel_Company.TabIndex = 7;
            // 
            // pictureBoxCompany
            // 
            this.pictureBoxCompany.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxCompany.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxCompany.Image")));
            this.pictureBoxCompany.Location = new System.Drawing.Point(3, 6);
            this.pictureBoxCompany.Name = "pictureBoxCompany";
            this.pictureBoxCompany.Size = new System.Drawing.Size(227, 55);
            this.pictureBoxCompany.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxCompany.TabIndex = 3;
            this.pictureBoxCompany.TabStop = false;
            // 
            // lblCompany
            // 
            this.lblCompany.AutoSize = true;
            this.lblCompany.BackColor = System.Drawing.SystemColors.HotTrack;
            this.lblCompany.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCompany.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblCompany.ForeColor = System.Drawing.Color.White;
            this.lblCompany.Location = new System.Drawing.Point(236, 3);
            this.lblCompany.Name = "lblCompany";
            this.lblCompany.Size = new System.Drawing.Size(539, 61);
            this.lblCompany.TabIndex = 2;
            this.lblCompany.Text = "МЕЖРЕГИОНАЛЬНАЯ РАСПРЕДЕЛИТЕЛЬНАЯ СЕТЕВАЯ КОМПАНИЯ СЕВЕРО-ЗАПАДА";
            this.lblCompany.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel_OrganizationSettingsDetail
            // 
            this.tableLayoutPanel_OrganizationSettingsDetail.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPanel_OrganizationSettingsDetail.ColumnCount = 1;
            this.tableLayoutPanel_OrganizationSettingsDetail.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_OrganizationSettingsDetail.Controls.Add(this.tableLayoutPanel_Working_field, 0, 1);
            this.tableLayoutPanel_OrganizationSettingsDetail.Controls.Add(this.tableLayoutPanel_WindowHeader, 0, 0);
            this.tableLayoutPanel_OrganizationSettingsDetail.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_OrganizationSettingsDetail.Location = new System.Drawing.Point(3, 126);
            this.tableLayoutPanel_OrganizationSettingsDetail.Name = "tableLayoutPanel_OrganizationSettingsDetail";
            this.tableLayoutPanel_OrganizationSettingsDetail.RowCount = 2;
            this.tableLayoutPanel_OrganizationSettingsDetail.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12F));
            this.tableLayoutPanel_OrganizationSettingsDetail.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 88F));
            this.tableLayoutPanel_OrganizationSettingsDetail.Size = new System.Drawing.Size(778, 368);
            this.tableLayoutPanel_OrganizationSettingsDetail.TabIndex = 6;
            // 
            // tableLayoutPanel_Working_field
            // 
            this.tableLayoutPanel_Working_field.ColumnCount = 1;
            this.tableLayoutPanel_Working_field.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_Working_field.Controls.Add(this.tabControlOrganizationSettings, 0, 0);
            this.tableLayoutPanel_Working_field.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Working_field.Location = new System.Drawing.Point(3, 44);
            this.tableLayoutPanel_Working_field.Margin = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.tableLayoutPanel_Working_field.Name = "tableLayoutPanel_Working_field";
            this.tableLayoutPanel_Working_field.RowCount = 1;
            this.tableLayoutPanel_Working_field.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_Working_field.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 321F));
            this.tableLayoutPanel_Working_field.Size = new System.Drawing.Size(772, 321);
            this.tableLayoutPanel_Working_field.TabIndex = 7;
            // 
            // tabControlOrganizationSettings
            // 
            this.tabControlOrganizationSettings.Controls.Add(this.tabPageCompanyInformation);
            this.tabControlOrganizationSettings.Controls.Add(this.tabPageHierarchyLevels);
            this.tabControlOrganizationSettings.Controls.Add(this.tabPageFunctions);
            this.tabControlOrganizationSettings.Controls.Add(this.tabPagePersonnelCategories);
            this.tabControlOrganizationSettings.Controls.Add(this.tabPageStateHolidaysList);
            this.tabControlOrganizationSettings.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlOrganizationSettings.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tabControlOrganizationSettings.Location = new System.Drawing.Point(3, 3);
            this.tabControlOrganizationSettings.Name = "tabControlOrganizationSettings";
            this.tabControlOrganizationSettings.SelectedIndex = 0;
            this.tabControlOrganizationSettings.Size = new System.Drawing.Size(766, 315);
            this.tabControlOrganizationSettings.TabIndex = 0;
            // 
            // tabPageCompanyInformation
            // 
            this.tabPageCompanyInformation.Controls.Add(this.tableLayoutPanelCompanyInformation);
            this.tabPageCompanyInformation.Location = new System.Drawing.Point(4, 32);
            this.tabPageCompanyInformation.Name = "tabPageCompanyInformation";
            this.tabPageCompanyInformation.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageCompanyInformation.Size = new System.Drawing.Size(758, 279);
            this.tabPageCompanyInformation.TabIndex = 0;
            this.tabPageCompanyInformation.Text = "Сведения о предприятии";
            this.tabPageCompanyInformation.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanelCompanyInformation
            // 
            this.tableLayoutPanelCompanyInformation.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPanelCompanyInformation.ColumnCount = 1;
            this.tableLayoutPanelCompanyInformation.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelCompanyInformation.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanelCompanyInformation.Controls.Add(this.dataGridViewCompanyInformation, 0, 0);
            this.tableLayoutPanelCompanyInformation.Controls.Add(this.btnChangeInCompanyInformationList, 0, 1);
            this.tableLayoutPanelCompanyInformation.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelCompanyInformation.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanelCompanyInformation.Name = "tableLayoutPanelCompanyInformation";
            this.tableLayoutPanelCompanyInformation.RowCount = 2;
            this.tableLayoutPanelCompanyInformation.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 87.5F));
            this.tableLayoutPanelCompanyInformation.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanelCompanyInformation.Size = new System.Drawing.Size(752, 273);
            this.tableLayoutPanelCompanyInformation.TabIndex = 0;
            // 
            // dataGridViewCompanyInformation
            // 
            this.dataGridViewCompanyInformation.AllowUserToAddRows = false;
            this.dataGridViewCompanyInformation.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.AntiqueWhite;
            this.dataGridViewCompanyInformation.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewCompanyInformation.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewCompanyInformation.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewCompanyInformation.Location = new System.Drawing.Point(3, 3);
            this.dataGridViewCompanyInformation.MultiSelect = false;
            this.dataGridViewCompanyInformation.Name = "dataGridViewCompanyInformation";
            this.dataGridViewCompanyInformation.ReadOnly = true;
            this.dataGridViewCompanyInformation.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewCompanyInformation.Size = new System.Drawing.Size(746, 232);
            this.dataGridViewCompanyInformation.TabIndex = 0;
            // 
            // btnChangeInCompanyInformationList
            // 
            this.btnChangeInCompanyInformationList.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnChangeInCompanyInformationList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnChangeInCompanyInformationList.ForeColor = System.Drawing.Color.White;
            this.btnChangeInCompanyInformationList.Location = new System.Drawing.Point(3, 241);
            this.btnChangeInCompanyInformationList.Name = "btnChangeInCompanyInformationList";
            this.btnChangeInCompanyInformationList.Size = new System.Drawing.Size(746, 29);
            this.btnChangeInCompanyInformationList.TabIndex = 2;
            this.btnChangeInCompanyInformationList.Text = "Редактировать сведения о предприятии";
            this.btnChangeInCompanyInformationList.UseVisualStyleBackColor = false;
            this.btnChangeInCompanyInformationList.Click += new System.EventHandler(this.btnChangeInCompanyInformationList_Click);
            // 
            // tabPageHierarchyLevels
            // 
            this.tabPageHierarchyLevels.Controls.Add(this.tableLayoutPanelHierarchyLevels);
            this.tabPageHierarchyLevels.Location = new System.Drawing.Point(4, 32);
            this.tabPageHierarchyLevels.Name = "tabPageHierarchyLevels";
            this.tabPageHierarchyLevels.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageHierarchyLevels.Size = new System.Drawing.Size(758, 279);
            this.tabPageHierarchyLevels.TabIndex = 1;
            this.tabPageHierarchyLevels.Text = "Уровни иерархии подразделений";
            this.tabPageHierarchyLevels.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanelHierarchyLevels
            // 
            this.tableLayoutPanelHierarchyLevels.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPanelHierarchyLevels.ColumnCount = 3;
            this.tableLayoutPanelHierarchyLevels.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanelHierarchyLevels.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanelHierarchyLevels.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanelHierarchyLevels.Controls.Add(this.dataGridViewHierarchyLevels, 0, 0);
            this.tableLayoutPanelHierarchyLevels.Controls.Add(this.btnAddToHierarchyLevelList, 0, 1);
            this.tableLayoutPanelHierarchyLevels.Controls.Add(this.btnChangeInHierarchyLevelList, 1, 1);
            this.tableLayoutPanelHierarchyLevels.Controls.Add(this.btnDeleteFromHierarchyLevelList, 2, 1);
            this.tableLayoutPanelHierarchyLevels.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelHierarchyLevels.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanelHierarchyLevels.Name = "tableLayoutPanelHierarchyLevels";
            this.tableLayoutPanelHierarchyLevels.RowCount = 2;
            this.tableLayoutPanelHierarchyLevels.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 87.5F));
            this.tableLayoutPanelHierarchyLevels.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanelHierarchyLevels.Size = new System.Drawing.Size(752, 273);
            this.tableLayoutPanelHierarchyLevels.TabIndex = 0;
            // 
            // dataGridViewHierarchyLevels
            // 
            this.dataGridViewHierarchyLevels.AllowUserToAddRows = false;
            this.dataGridViewHierarchyLevels.AllowUserToDeleteRows = false;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.AntiqueWhite;
            this.dataGridViewHierarchyLevels.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewHierarchyLevels.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tableLayoutPanelHierarchyLevels.SetColumnSpan(this.dataGridViewHierarchyLevels, 3);
            this.dataGridViewHierarchyLevels.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewHierarchyLevels.Location = new System.Drawing.Point(3, 3);
            this.dataGridViewHierarchyLevels.MultiSelect = false;
            this.dataGridViewHierarchyLevels.Name = "dataGridViewHierarchyLevels";
            this.dataGridViewHierarchyLevels.ReadOnly = true;
            this.dataGridViewHierarchyLevels.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewHierarchyLevels.Size = new System.Drawing.Size(746, 232);
            this.dataGridViewHierarchyLevels.TabIndex = 0;
            // 
            // btnAddToHierarchyLevelList
            // 
            this.btnAddToHierarchyLevelList.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnAddToHierarchyLevelList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnAddToHierarchyLevelList.ForeColor = System.Drawing.Color.White;
            this.btnAddToHierarchyLevelList.Location = new System.Drawing.Point(3, 241);
            this.btnAddToHierarchyLevelList.Name = "btnAddToHierarchyLevelList";
            this.btnAddToHierarchyLevelList.Size = new System.Drawing.Size(244, 29);
            this.btnAddToHierarchyLevelList.TabIndex = 1;
            this.btnAddToHierarchyLevelList.Text = "Добавить уровень иерархии";
            this.btnAddToHierarchyLevelList.UseVisualStyleBackColor = false;
            this.btnAddToHierarchyLevelList.Click += new System.EventHandler(this.btnAddToHierarchyLevelList_Click);
            // 
            // btnChangeInHierarchyLevelList
            // 
            this.btnChangeInHierarchyLevelList.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnChangeInHierarchyLevelList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnChangeInHierarchyLevelList.ForeColor = System.Drawing.Color.White;
            this.btnChangeInHierarchyLevelList.Location = new System.Drawing.Point(253, 241);
            this.btnChangeInHierarchyLevelList.Name = "btnChangeInHierarchyLevelList";
            this.btnChangeInHierarchyLevelList.Size = new System.Drawing.Size(244, 29);
            this.btnChangeInHierarchyLevelList.TabIndex = 2;
            this.btnChangeInHierarchyLevelList.Text = "Редактировать уровень иерархии";
            this.btnChangeInHierarchyLevelList.UseVisualStyleBackColor = false;
            this.btnChangeInHierarchyLevelList.Click += new System.EventHandler(this.btnChangeInHierarchyLevelList_Click);
            // 
            // btnDeleteFromHierarchyLevelList
            // 
            this.btnDeleteFromHierarchyLevelList.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnDeleteFromHierarchyLevelList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnDeleteFromHierarchyLevelList.ForeColor = System.Drawing.Color.White;
            this.btnDeleteFromHierarchyLevelList.Location = new System.Drawing.Point(503, 241);
            this.btnDeleteFromHierarchyLevelList.Name = "btnDeleteFromHierarchyLevelList";
            this.btnDeleteFromHierarchyLevelList.Size = new System.Drawing.Size(246, 29);
            this.btnDeleteFromHierarchyLevelList.TabIndex = 3;
            this.btnDeleteFromHierarchyLevelList.Text = "Удалить уровень иерархии";
            this.btnDeleteFromHierarchyLevelList.UseVisualStyleBackColor = false;
            this.btnDeleteFromHierarchyLevelList.Click += new System.EventHandler(this.btnDeleteFromHierarchyLevelList_Click);
            // 
            // tabPageFunctions
            // 
            this.tabPageFunctions.Controls.Add(this.tableLayoutPanelFunctions);
            this.tabPageFunctions.Location = new System.Drawing.Point(4, 32);
            this.tabPageFunctions.Name = "tabPageFunctions";
            this.tabPageFunctions.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageFunctions.Size = new System.Drawing.Size(758, 279);
            this.tabPageFunctions.TabIndex = 2;
            this.tabPageFunctions.Text = "Должности";
            this.tabPageFunctions.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanelFunctions
            // 
            this.tableLayoutPanelFunctions.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPanelFunctions.ColumnCount = 3;
            this.tableLayoutPanelFunctions.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanelFunctions.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanelFunctions.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanelFunctions.Controls.Add(this.dataGridViewFunctions, 0, 0);
            this.tableLayoutPanelFunctions.Controls.Add(this.btnAddToFunctionsList, 0, 1);
            this.tableLayoutPanelFunctions.Controls.Add(this.btnChangeInFunctionsList, 1, 1);
            this.tableLayoutPanelFunctions.Controls.Add(this.btnDeleteFromFunctionsList, 2, 1);
            this.tableLayoutPanelFunctions.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelFunctions.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanelFunctions.Name = "tableLayoutPanelFunctions";
            this.tableLayoutPanelFunctions.RowCount = 2;
            this.tableLayoutPanelFunctions.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 87.5F));
            this.tableLayoutPanelFunctions.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanelFunctions.Size = new System.Drawing.Size(752, 273);
            this.tableLayoutPanelFunctions.TabIndex = 0;
            // 
            // dataGridViewFunctions
            // 
            this.dataGridViewFunctions.AllowUserToAddRows = false;
            this.dataGridViewFunctions.AllowUserToDeleteRows = false;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.AntiqueWhite;
            this.dataGridViewFunctions.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridViewFunctions.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tableLayoutPanelFunctions.SetColumnSpan(this.dataGridViewFunctions, 3);
            this.dataGridViewFunctions.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewFunctions.Location = new System.Drawing.Point(3, 3);
            this.dataGridViewFunctions.MultiSelect = false;
            this.dataGridViewFunctions.Name = "dataGridViewFunctions";
            this.dataGridViewFunctions.ReadOnly = true;
            this.dataGridViewFunctions.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewFunctions.Size = new System.Drawing.Size(746, 232);
            this.dataGridViewFunctions.TabIndex = 0;
            // 
            // btnAddToFunctionsList
            // 
            this.btnAddToFunctionsList.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnAddToFunctionsList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnAddToFunctionsList.ForeColor = System.Drawing.Color.White;
            this.btnAddToFunctionsList.Location = new System.Drawing.Point(3, 241);
            this.btnAddToFunctionsList.Name = "btnAddToFunctionsList";
            this.btnAddToFunctionsList.Size = new System.Drawing.Size(244, 29);
            this.btnAddToFunctionsList.TabIndex = 1;
            this.btnAddToFunctionsList.Text = "Добавить новую должность";
            this.btnAddToFunctionsList.UseVisualStyleBackColor = false;
            this.btnAddToFunctionsList.Click += new System.EventHandler(this.btnAddToFunctionsList_Click);
            // 
            // btnChangeInFunctionsList
            // 
            this.btnChangeInFunctionsList.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnChangeInFunctionsList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnChangeInFunctionsList.ForeColor = System.Drawing.Color.White;
            this.btnChangeInFunctionsList.Location = new System.Drawing.Point(253, 241);
            this.btnChangeInFunctionsList.Name = "btnChangeInFunctionsList";
            this.btnChangeInFunctionsList.Size = new System.Drawing.Size(244, 29);
            this.btnChangeInFunctionsList.TabIndex = 2;
            this.btnChangeInFunctionsList.Text = "Редактировать должность";
            this.btnChangeInFunctionsList.UseVisualStyleBackColor = false;
            this.btnChangeInFunctionsList.Click += new System.EventHandler(this.btnChangeInFunctionsList_Click);
            // 
            // btnDeleteFromFunctionsList
            // 
            this.btnDeleteFromFunctionsList.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnDeleteFromFunctionsList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnDeleteFromFunctionsList.ForeColor = System.Drawing.Color.White;
            this.btnDeleteFromFunctionsList.Location = new System.Drawing.Point(503, 241);
            this.btnDeleteFromFunctionsList.Name = "btnDeleteFromFunctionsList";
            this.btnDeleteFromFunctionsList.Size = new System.Drawing.Size(246, 29);
            this.btnDeleteFromFunctionsList.TabIndex = 3;
            this.btnDeleteFromFunctionsList.Text = "Удалить должность";
            this.btnDeleteFromFunctionsList.UseVisualStyleBackColor = false;
            this.btnDeleteFromFunctionsList.Click += new System.EventHandler(this.btnDeleteFromFunctionsList_Click);
            // 
            // tabPagePersonnelCategories
            // 
            this.tabPagePersonnelCategories.Controls.Add(this.tableLayoutPanelPersonnelCategories);
            this.tabPagePersonnelCategories.Location = new System.Drawing.Point(4, 32);
            this.tabPagePersonnelCategories.Name = "tabPagePersonnelCategories";
            this.tabPagePersonnelCategories.Padding = new System.Windows.Forms.Padding(3);
            this.tabPagePersonnelCategories.Size = new System.Drawing.Size(758, 279);
            this.tabPagePersonnelCategories.TabIndex = 4;
            this.tabPagePersonnelCategories.Text = "Категории персонала";
            this.tabPagePersonnelCategories.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanelPersonnelCategories
            // 
            this.tableLayoutPanelPersonnelCategories.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPanelPersonnelCategories.ColumnCount = 3;
            this.tableLayoutPanelPersonnelCategories.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanelPersonnelCategories.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanelPersonnelCategories.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanelPersonnelCategories.Controls.Add(this.dataGridViewPersonnelCategories, 0, 0);
            this.tableLayoutPanelPersonnelCategories.Controls.Add(this.btnAddToPersonnelCategoryList, 0, 1);
            this.tableLayoutPanelPersonnelCategories.Controls.Add(this.btnChangeInPersonnelCategoryList, 1, 1);
            this.tableLayoutPanelPersonnelCategories.Controls.Add(this.btnDeleteFromPersonnelCategoryList, 2, 1);
            this.tableLayoutPanelPersonnelCategories.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelPersonnelCategories.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanelPersonnelCategories.Name = "tableLayoutPanelPersonnelCategories";
            this.tableLayoutPanelPersonnelCategories.RowCount = 2;
            this.tableLayoutPanelPersonnelCategories.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 87.5F));
            this.tableLayoutPanelPersonnelCategories.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanelPersonnelCategories.Size = new System.Drawing.Size(752, 273);
            this.tableLayoutPanelPersonnelCategories.TabIndex = 0;
            // 
            // dataGridViewPersonnelCategories
            // 
            this.dataGridViewPersonnelCategories.AllowUserToAddRows = false;
            this.dataGridViewPersonnelCategories.AllowUserToDeleteRows = false;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.AntiqueWhite;
            this.dataGridViewPersonnelCategories.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewPersonnelCategories.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridViewPersonnelCategories.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tableLayoutPanelPersonnelCategories.SetColumnSpan(this.dataGridViewPersonnelCategories, 3);
            this.dataGridViewPersonnelCategories.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewPersonnelCategories.Location = new System.Drawing.Point(3, 3);
            this.dataGridViewPersonnelCategories.MultiSelect = false;
            this.dataGridViewPersonnelCategories.Name = "dataGridViewPersonnelCategories";
            this.dataGridViewPersonnelCategories.ReadOnly = true;
            this.dataGridViewPersonnelCategories.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewPersonnelCategories.Size = new System.Drawing.Size(746, 232);
            this.dataGridViewPersonnelCategories.TabIndex = 0;
            // 
            // btnAddToPersonnelCategoryList
            // 
            this.btnAddToPersonnelCategoryList.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnAddToPersonnelCategoryList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnAddToPersonnelCategoryList.ForeColor = System.Drawing.Color.White;
            this.btnAddToPersonnelCategoryList.Location = new System.Drawing.Point(3, 241);
            this.btnAddToPersonnelCategoryList.Name = "btnAddToPersonnelCategoryList";
            this.btnAddToPersonnelCategoryList.Size = new System.Drawing.Size(244, 29);
            this.btnAddToPersonnelCategoryList.TabIndex = 1;
            this.btnAddToPersonnelCategoryList.Text = "Добавить категорию персонала";
            this.btnAddToPersonnelCategoryList.UseVisualStyleBackColor = false;
            this.btnAddToPersonnelCategoryList.Click += new System.EventHandler(this.btnAddToPersonnelCategoryList_Click);
            // 
            // btnChangeInPersonnelCategoryList
            // 
            this.btnChangeInPersonnelCategoryList.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnChangeInPersonnelCategoryList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnChangeInPersonnelCategoryList.ForeColor = System.Drawing.Color.White;
            this.btnChangeInPersonnelCategoryList.Location = new System.Drawing.Point(253, 241);
            this.btnChangeInPersonnelCategoryList.Name = "btnChangeInPersonnelCategoryList";
            this.btnChangeInPersonnelCategoryList.Size = new System.Drawing.Size(244, 29);
            this.btnChangeInPersonnelCategoryList.TabIndex = 2;
            this.btnChangeInPersonnelCategoryList.Text = "Редактировать категорию персонала";
            this.btnChangeInPersonnelCategoryList.UseVisualStyleBackColor = false;
            this.btnChangeInPersonnelCategoryList.Click += new System.EventHandler(this.btnChangeInPersonnelCategoryList_Click);
            // 
            // btnDeleteFromPersonnelCategoryList
            // 
            this.btnDeleteFromPersonnelCategoryList.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnDeleteFromPersonnelCategoryList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnDeleteFromPersonnelCategoryList.ForeColor = System.Drawing.Color.White;
            this.btnDeleteFromPersonnelCategoryList.Location = new System.Drawing.Point(503, 241);
            this.btnDeleteFromPersonnelCategoryList.Name = "btnDeleteFromPersonnelCategoryList";
            this.btnDeleteFromPersonnelCategoryList.Size = new System.Drawing.Size(246, 29);
            this.btnDeleteFromPersonnelCategoryList.TabIndex = 3;
            this.btnDeleteFromPersonnelCategoryList.Text = "Удалить категорию персонала";
            this.btnDeleteFromPersonnelCategoryList.UseVisualStyleBackColor = false;
            this.btnDeleteFromPersonnelCategoryList.Click += new System.EventHandler(this.btnDeleteFromPersonnelCategoryList_Click);
            // 
            // tabPageStateHolidaysList
            // 
            this.tabPageStateHolidaysList.Controls.Add(this.tableLayoutPanelStateHolidaysList);
            this.tabPageStateHolidaysList.Location = new System.Drawing.Point(4, 32);
            this.tabPageStateHolidaysList.Name = "tabPageStateHolidaysList";
            this.tabPageStateHolidaysList.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageStateHolidaysList.Size = new System.Drawing.Size(758, 279);
            this.tabPageStateHolidaysList.TabIndex = 3;
            this.tabPageStateHolidaysList.Text = "Список выходных праздничных дней";
            this.tabPageStateHolidaysList.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanelStateHolidaysList
            // 
            this.tableLayoutPanelStateHolidaysList.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPanelStateHolidaysList.ColumnCount = 3;
            this.tableLayoutPanelStateHolidaysList.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanelStateHolidaysList.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanelStateHolidaysList.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanelStateHolidaysList.Controls.Add(this.btnAddToStateHolidaysList, 0, 1);
            this.tableLayoutPanelStateHolidaysList.Controls.Add(this.dataGridViewStateHolidaysList, 0, 0);
            this.tableLayoutPanelStateHolidaysList.Controls.Add(this.ChangeInStateHolidaysList, 1, 1);
            this.tableLayoutPanelStateHolidaysList.Controls.Add(this.DeleteFromStateHolidaysList, 2, 1);
            this.tableLayoutPanelStateHolidaysList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelStateHolidaysList.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanelStateHolidaysList.Name = "tableLayoutPanelStateHolidaysList";
            this.tableLayoutPanelStateHolidaysList.RowCount = 2;
            this.tableLayoutPanelStateHolidaysList.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 87.5F));
            this.tableLayoutPanelStateHolidaysList.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanelStateHolidaysList.Size = new System.Drawing.Size(752, 273);
            this.tableLayoutPanelStateHolidaysList.TabIndex = 0;
            // 
            // btnAddToStateHolidaysList
            // 
            this.btnAddToStateHolidaysList.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnAddToStateHolidaysList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnAddToStateHolidaysList.ForeColor = System.Drawing.Color.White;
            this.btnAddToStateHolidaysList.Location = new System.Drawing.Point(3, 241);
            this.btnAddToStateHolidaysList.Name = "btnAddToStateHolidaysList";
            this.btnAddToStateHolidaysList.Size = new System.Drawing.Size(244, 29);
            this.btnAddToStateHolidaysList.TabIndex = 9;
            this.btnAddToStateHolidaysList.Text = "Добавить выходной праздничный день";
            this.btnAddToStateHolidaysList.UseVisualStyleBackColor = false;
            this.btnAddToStateHolidaysList.Click += new System.EventHandler(this.btnAddToStateHolidaysList_Click);
            // 
            // dataGridViewStateHolidaysList
            // 
            this.dataGridViewStateHolidaysList.AllowUserToAddRows = false;
            this.dataGridViewStateHolidaysList.AllowUserToDeleteRows = false;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.AntiqueWhite;
            this.dataGridViewStateHolidaysList.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle6;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewStateHolidaysList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dataGridViewStateHolidaysList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tableLayoutPanelStateHolidaysList.SetColumnSpan(this.dataGridViewStateHolidaysList, 3);
            this.dataGridViewStateHolidaysList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewStateHolidaysList.Location = new System.Drawing.Point(3, 3);
            this.dataGridViewStateHolidaysList.MultiSelect = false;
            this.dataGridViewStateHolidaysList.Name = "dataGridViewStateHolidaysList";
            this.dataGridViewStateHolidaysList.ReadOnly = true;
            this.dataGridViewStateHolidaysList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewStateHolidaysList.Size = new System.Drawing.Size(746, 232);
            this.dataGridViewStateHolidaysList.TabIndex = 2;
            // 
            // ChangeInStateHolidaysList
            // 
            this.ChangeInStateHolidaysList.BackColor = System.Drawing.SystemColors.HotTrack;
            this.ChangeInStateHolidaysList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ChangeInStateHolidaysList.ForeColor = System.Drawing.Color.White;
            this.ChangeInStateHolidaysList.Location = new System.Drawing.Point(253, 241);
            this.ChangeInStateHolidaysList.Name = "ChangeInStateHolidaysList";
            this.ChangeInStateHolidaysList.Size = new System.Drawing.Size(244, 29);
            this.ChangeInStateHolidaysList.TabIndex = 5;
            this.ChangeInStateHolidaysList.Text = "Редактировать сведения о празднике";
            this.ChangeInStateHolidaysList.UseVisualStyleBackColor = false;
            this.ChangeInStateHolidaysList.Click += new System.EventHandler(this.ChangeInStateHolidaysList_Click);
            // 
            // DeleteFromStateHolidaysList
            // 
            this.DeleteFromStateHolidaysList.BackColor = System.Drawing.SystemColors.HotTrack;
            this.DeleteFromStateHolidaysList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DeleteFromStateHolidaysList.ForeColor = System.Drawing.Color.White;
            this.DeleteFromStateHolidaysList.Location = new System.Drawing.Point(503, 241);
            this.DeleteFromStateHolidaysList.Name = "DeleteFromStateHolidaysList";
            this.DeleteFromStateHolidaysList.Size = new System.Drawing.Size(246, 29);
            this.DeleteFromStateHolidaysList.TabIndex = 8;
            this.DeleteFromStateHolidaysList.Text = "Удалить выходной праздничный день";
            this.DeleteFromStateHolidaysList.UseVisualStyleBackColor = false;
            this.DeleteFromStateHolidaysList.Click += new System.EventHandler(this.DeleteFromStateHolidaysList_Click);
            // 
            // tableLayoutPanel_WindowHeader
            // 
            this.tableLayoutPanel_WindowHeader.ColumnCount = 4;
            this.tableLayoutPanel_WindowHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_WindowHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_WindowHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_WindowHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_WindowHeader.Controls.Add(this.lblOrrganizatinSettingsDetail, 0, 0);
            this.tableLayoutPanel_WindowHeader.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_WindowHeader.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel_WindowHeader.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.tableLayoutPanel_WindowHeader.Name = "tableLayoutPanel_WindowHeader";
            this.tableLayoutPanel_WindowHeader.RowCount = 1;
            this.tableLayoutPanel_WindowHeader.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_WindowHeader.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 41F));
            this.tableLayoutPanel_WindowHeader.Size = new System.Drawing.Size(772, 41);
            this.tableLayoutPanel_WindowHeader.TabIndex = 6;
            // 
            // lblOrrganizatinSettingsDetail
            // 
            this.lblOrrganizatinSettingsDetail.AutoSize = true;
            this.tableLayoutPanel_WindowHeader.SetColumnSpan(this.lblOrrganizatinSettingsDetail, 4);
            this.lblOrrganizatinSettingsDetail.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblOrrganizatinSettingsDetail.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblOrrganizatinSettingsDetail.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblOrrganizatinSettingsDetail.Location = new System.Drawing.Point(3, 0);
            this.lblOrrganizatinSettingsDetail.Name = "lblOrrganizatinSettingsDetail";
            this.lblOrrganizatinSettingsDetail.Size = new System.Drawing.Size(766, 41);
            this.lblOrrganizatinSettingsDetail.TabIndex = 19;
            this.lblOrrganizatinSettingsDetail.Text = "ОРГАНИЗАЦИОННЫЕ НАСТРОЙКИ";
            this.lblOrrganizatinSettingsDetail.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel_Programm
            // 
            this.tableLayoutPanel_Programm.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPanel_Programm.ColumnCount = 1;
            this.tableLayoutPanel_Programm.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Programm.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Programm.Controls.Add(this.lblProgramm, 0, 0);
            this.tableLayoutPanel_Programm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Programm.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel_Programm.Name = "tableLayoutPanel_Programm";
            this.tableLayoutPanel_Programm.RowCount = 1;
            this.tableLayoutPanel_Programm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Programm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Programm.Size = new System.Drawing.Size(778, 43);
            this.tableLayoutPanel_Programm.TabIndex = 8;
            // 
            // lblProgramm
            // 
            this.lblProgramm.AutoSize = true;
            this.lblProgramm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblProgramm.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblProgramm.ForeColor = System.Drawing.Color.White;
            this.lblProgramm.Location = new System.Drawing.Point(3, 0);
            this.lblProgramm.Name = "lblProgramm";
            this.lblProgramm.Size = new System.Drawing.Size(772, 43);
            this.lblProgramm.TabIndex = 0;
            this.lblProgramm.Text = "ФОРМИРОВАНИЕ И ВЕДЕНИЕ ГРАФИКА ОТПУСКОВ СОТРУДНИКОВ";
            this.lblProgramm.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // OrganizationSettingsDetailForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 497);
            this.Controls.Add(this.tableLayoutPanel_AllForm);
            this.Name = "OrganizationSettingsDetailForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ФОРМИРОВАНИЕ ОРГАНИЗАЦИОННЫХ НАСТРОЕК";
            this.Load += new System.EventHandler(this.OrganizationSettingsDetailForm_Load);
            this.tableLayoutPanel_AllForm.ResumeLayout(false);
            this.tableLayoutPanel_Company.ResumeLayout(false);
            this.tableLayoutPanel_Company.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCompany)).EndInit();
            this.tableLayoutPanel_OrganizationSettingsDetail.ResumeLayout(false);
            this.tableLayoutPanel_Working_field.ResumeLayout(false);
            this.tabControlOrganizationSettings.ResumeLayout(false);
            this.tabPageCompanyInformation.ResumeLayout(false);
            this.tableLayoutPanelCompanyInformation.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCompanyInformation)).EndInit();
            this.tabPageHierarchyLevels.ResumeLayout(false);
            this.tableLayoutPanelHierarchyLevels.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewHierarchyLevels)).EndInit();
            this.tabPageFunctions.ResumeLayout(false);
            this.tableLayoutPanelFunctions.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewFunctions)).EndInit();
            this.tabPagePersonnelCategories.ResumeLayout(false);
            this.tableLayoutPanelPersonnelCategories.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPersonnelCategories)).EndInit();
            this.tabPageStateHolidaysList.ResumeLayout(false);
            this.tableLayoutPanelStateHolidaysList.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewStateHolidaysList)).EndInit();
            this.tableLayoutPanel_WindowHeader.ResumeLayout(false);
            this.tableLayoutPanel_WindowHeader.PerformLayout();
            this.tableLayoutPanel_Programm.ResumeLayout(false);
            this.tableLayoutPanel_Programm.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_AllForm;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Company;
        private System.Windows.Forms.PictureBox pictureBoxCompany;
        private System.Windows.Forms.Label lblCompany;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_OrganizationSettingsDetail;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Working_field;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_WindowHeader;
        private System.Windows.Forms.Label lblOrrganizatinSettingsDetail;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Programm;
        private System.Windows.Forms.Label lblProgramm;
        private System.Windows.Forms.TabControl tabControlOrganizationSettings;
        private System.Windows.Forms.TabPage tabPageCompanyInformation;
        private System.Windows.Forms.TabPage tabPageHierarchyLevels;
        private System.Windows.Forms.TabPage tabPageFunctions;
        private System.Windows.Forms.TabPage tabPageStateHolidaysList;
        private System.Windows.Forms.TabPage tabPagePersonnelCategories;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelCompanyInformation;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelHierarchyLevels;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelFunctions;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelPersonnelCategories;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelStateHolidaysList;
        private System.Windows.Forms.DataGridView dataGridViewPersonnelCategories;
        private System.Windows.Forms.Button btnAddToPersonnelCategoryList;
        private System.Windows.Forms.Button btnChangeInPersonnelCategoryList;
        private System.Windows.Forms.Button btnDeleteFromPersonnelCategoryList;
        private System.Windows.Forms.DataGridView dataGridViewCompanyInformation;
        private System.Windows.Forms.DataGridView dataGridViewHierarchyLevels;
        private System.Windows.Forms.DataGridView dataGridViewFunctions;
        private System.Windows.Forms.DataGridView dataGridViewStateHolidaysList;
        private System.Windows.Forms.Button btnAddToStateHolidaysList;
        private System.Windows.Forms.Button ChangeInStateHolidaysList;
        private System.Windows.Forms.Button DeleteFromStateHolidaysList;
        private System.Windows.Forms.Button btnAddToFunctionsList;
        private System.Windows.Forms.Button btnChangeInFunctionsList;
        private System.Windows.Forms.Button btnDeleteFromFunctionsList;
        private System.Windows.Forms.Button btnAddToHierarchyLevelList;
        private System.Windows.Forms.Button btnChangeInHierarchyLevelList;
        private System.Windows.Forms.Button btnDeleteFromHierarchyLevelList;
        private System.Windows.Forms.Button btnChangeInCompanyInformationList;
    }
}