﻿namespace VacationScheduleCreator
{
    partial class EmployeesForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EmployeesForm));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tableLayoutPanel_AllForm = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel_Company = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBoxCompany = new System.Windows.Forms.PictureBox();
            this.lblCompany = new System.Windows.Forms.Label();
            this.tableLayoutPanel_Employees = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel_Working_field = new System.Windows.Forms.TableLayoutPanel();
            this.groupBoxEmployeeSickLists = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanelEmployeesAccounts = new System.Windows.Forms.TableLayoutPanel();
            this.dataGridViewEmployeesSickLists = new System.Windows.Forms.DataGridView();
            this.btnEmployeesSickListsDatail = new System.Windows.Forms.Button();
            this.groupBoxEmployees = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanelEmployees = new System.Windows.Forms.TableLayoutPanel();
            this.dataGridViewEmployees = new System.Windows.Forms.DataGridView();
            this.btnEmployeesDetail = new System.Windows.Forms.Button();
            this.groupBoxAlternateList = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanelAlternateList = new System.Windows.Forms.TableLayoutPanel();
            this.dataGridViewAlternateList = new System.Windows.Forms.DataGridView();
            this.btnAlternateListDetail = new System.Windows.Forms.Button();
            this.tableLayoutPanel_WindowHeader = new System.Windows.Forms.TableLayoutPanel();
            this.lblEmployees = new System.Windows.Forms.Label();
            this.tableLayoutPanel_Programm = new System.Windows.Forms.TableLayoutPanel();
            this.lblProgramm = new System.Windows.Forms.Label();
            this.tableLayoutPanel_AllForm.SuspendLayout();
            this.tableLayoutPanel_Company.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCompany)).BeginInit();
            this.tableLayoutPanel_Employees.SuspendLayout();
            this.tableLayoutPanel_Working_field.SuspendLayout();
            this.groupBoxEmployeeSickLists.SuspendLayout();
            this.tableLayoutPanelEmployeesAccounts.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewEmployeesSickLists)).BeginInit();
            this.groupBoxEmployees.SuspendLayout();
            this.tableLayoutPanelEmployees.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewEmployees)).BeginInit();
            this.groupBoxAlternateList.SuspendLayout();
            this.tableLayoutPanelAlternateList.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAlternateList)).BeginInit();
            this.tableLayoutPanel_WindowHeader.SuspendLayout();
            this.tableLayoutPanel_Programm.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel_AllForm
            // 
            this.tableLayoutPanel_AllForm.ColumnCount = 1;
            this.tableLayoutPanel_AllForm.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_AllForm.Controls.Add(this.tableLayoutPanel_Company, 0, 1);
            this.tableLayoutPanel_AllForm.Controls.Add(this.tableLayoutPanel_Employees, 0, 2);
            this.tableLayoutPanel_AllForm.Controls.Add(this.tableLayoutPanel_Programm, 0, 0);
            this.tableLayoutPanel_AllForm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_AllForm.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel_AllForm.Name = "tableLayoutPanel_AllForm";
            this.tableLayoutPanel_AllForm.RowCount = 3;
            this.tableLayoutPanel_AllForm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel_AllForm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tableLayoutPanel_AllForm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 75F));
            this.tableLayoutPanel_AllForm.Size = new System.Drawing.Size(784, 497);
            this.tableLayoutPanel_AllForm.TabIndex = 10;
            // 
            // tableLayoutPanel_Company
            // 
            this.tableLayoutPanel_Company.BackColor = System.Drawing.SystemColors.HotTrack;
            this.tableLayoutPanel_Company.ColumnCount = 2;
            this.tableLayoutPanel_Company.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel_Company.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.tableLayoutPanel_Company.Controls.Add(this.pictureBoxCompany, 0, 1);
            this.tableLayoutPanel_Company.Controls.Add(this.lblCompany, 1, 1);
            this.tableLayoutPanel_Company.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Company.Location = new System.Drawing.Point(3, 52);
            this.tableLayoutPanel_Company.Name = "tableLayoutPanel_Company";
            this.tableLayoutPanel_Company.RowCount = 3;
            this.tableLayoutPanel_Company.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel_Company.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tableLayoutPanel_Company.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel_Company.Size = new System.Drawing.Size(778, 68);
            this.tableLayoutPanel_Company.TabIndex = 7;
            // 
            // pictureBoxCompany
            // 
            this.pictureBoxCompany.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxCompany.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxCompany.Image")));
            this.pictureBoxCompany.Location = new System.Drawing.Point(3, 6);
            this.pictureBoxCompany.Name = "pictureBoxCompany";
            this.pictureBoxCompany.Size = new System.Drawing.Size(227, 55);
            this.pictureBoxCompany.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxCompany.TabIndex = 3;
            this.pictureBoxCompany.TabStop = false;
            // 
            // lblCompany
            // 
            this.lblCompany.AutoSize = true;
            this.lblCompany.BackColor = System.Drawing.SystemColors.HotTrack;
            this.lblCompany.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCompany.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblCompany.ForeColor = System.Drawing.Color.White;
            this.lblCompany.Location = new System.Drawing.Point(236, 3);
            this.lblCompany.Name = "lblCompany";
            this.lblCompany.Size = new System.Drawing.Size(539, 61);
            this.lblCompany.TabIndex = 2;
            this.lblCompany.Text = "МЕЖРЕГИОНАЛЬНАЯ РАСПРЕДЕЛИТЕЛЬНАЯ СЕТЕВАЯ КОМПАНИЯ СЕВЕРО-ЗАПАДА";
            this.lblCompany.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel_Employees
            // 
            this.tableLayoutPanel_Employees.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPanel_Employees.ColumnCount = 1;
            this.tableLayoutPanel_Employees.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_Employees.Controls.Add(this.tableLayoutPanel_Working_field, 0, 1);
            this.tableLayoutPanel_Employees.Controls.Add(this.tableLayoutPanel_WindowHeader, 0, 0);
            this.tableLayoutPanel_Employees.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Employees.Location = new System.Drawing.Point(3, 126);
            this.tableLayoutPanel_Employees.Name = "tableLayoutPanel_Employees";
            this.tableLayoutPanel_Employees.RowCount = 2;
            this.tableLayoutPanel_Employees.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12F));
            this.tableLayoutPanel_Employees.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 88F));
            this.tableLayoutPanel_Employees.Size = new System.Drawing.Size(778, 368);
            this.tableLayoutPanel_Employees.TabIndex = 6;
            // 
            // tableLayoutPanel_Working_field
            // 
            this.tableLayoutPanel_Working_field.ColumnCount = 2;
            this.tableLayoutPanel_Working_field.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel_Working_field.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel_Working_field.Controls.Add(this.groupBoxEmployeeSickLists, 1, 1);
            this.tableLayoutPanel_Working_field.Controls.Add(this.groupBoxEmployees, 0, 0);
            this.tableLayoutPanel_Working_field.Controls.Add(this.groupBoxAlternateList, 0, 1);
            this.tableLayoutPanel_Working_field.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Working_field.Location = new System.Drawing.Point(3, 44);
            this.tableLayoutPanel_Working_field.Margin = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.tableLayoutPanel_Working_field.Name = "tableLayoutPanel_Working_field";
            this.tableLayoutPanel_Working_field.RowCount = 2;
            this.tableLayoutPanel_Working_field.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Working_field.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Working_field.Size = new System.Drawing.Size(772, 321);
            this.tableLayoutPanel_Working_field.TabIndex = 7;
            // 
            // groupBoxEmployeeSickLists
            // 
            this.groupBoxEmployeeSickLists.Controls.Add(this.tableLayoutPanelEmployeesAccounts);
            this.groupBoxEmployeeSickLists.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxEmployeeSickLists.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBoxEmployeeSickLists.ForeColor = System.Drawing.Color.White;
            this.groupBoxEmployeeSickLists.Location = new System.Drawing.Point(311, 163);
            this.groupBoxEmployeeSickLists.Name = "groupBoxEmployeeSickLists";
            this.groupBoxEmployeeSickLists.Size = new System.Drawing.Size(458, 155);
            this.groupBoxEmployeeSickLists.TabIndex = 0;
            this.groupBoxEmployeeSickLists.TabStop = false;
            this.groupBoxEmployeeSickLists.Text = "Больничные листы сотрудников:";
            // 
            // tableLayoutPanelEmployeesAccounts
            // 
            this.tableLayoutPanelEmployeesAccounts.ColumnCount = 1;
            this.tableLayoutPanelEmployeesAccounts.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelEmployeesAccounts.Controls.Add(this.dataGridViewEmployeesSickLists, 0, 0);
            this.tableLayoutPanelEmployeesAccounts.Controls.Add(this.btnEmployeesSickListsDatail, 0, 1);
            this.tableLayoutPanelEmployeesAccounts.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelEmployeesAccounts.Location = new System.Drawing.Point(3, 25);
            this.tableLayoutPanelEmployeesAccounts.Name = "tableLayoutPanelEmployeesAccounts";
            this.tableLayoutPanelEmployeesAccounts.RowCount = 2;
            this.tableLayoutPanelEmployeesAccounts.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 75F));
            this.tableLayoutPanelEmployeesAccounts.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanelEmployeesAccounts.Size = new System.Drawing.Size(452, 127);
            this.tableLayoutPanelEmployeesAccounts.TabIndex = 0;
            // 
            // dataGridViewEmployeesSickLists
            // 
            this.dataGridViewEmployeesSickLists.AllowUserToAddRows = false;
            this.dataGridViewEmployeesSickLists.AllowUserToDeleteRows = false;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.AntiqueWhite;
            this.dataGridViewEmployeesSickLists.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle7;
            this.dataGridViewEmployeesSickLists.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewEmployeesSickLists.DefaultCellStyle = dataGridViewCellStyle8;
            this.dataGridViewEmployeesSickLists.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewEmployeesSickLists.Location = new System.Drawing.Point(3, 3);
            this.dataGridViewEmployeesSickLists.MultiSelect = false;
            this.dataGridViewEmployeesSickLists.Name = "dataGridViewEmployeesSickLists";
            this.dataGridViewEmployeesSickLists.ReadOnly = true;
            this.dataGridViewEmployeesSickLists.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewEmployeesSickLists.Size = new System.Drawing.Size(446, 89);
            this.dataGridViewEmployeesSickLists.TabIndex = 0;
            // 
            // btnEmployeesSickListsDatail
            // 
            this.btnEmployeesSickListsDatail.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnEmployeesSickListsDatail.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnEmployeesSickListsDatail.Location = new System.Drawing.Point(3, 98);
            this.btnEmployeesSickListsDatail.Name = "btnEmployeesSickListsDatail";
            this.btnEmployeesSickListsDatail.Size = new System.Drawing.Size(446, 26);
            this.btnEmployeesSickListsDatail.TabIndex = 1;
            this.btnEmployeesSickListsDatail.Text = "Перейти к больничным листам сотрудников";
            this.btnEmployeesSickListsDatail.UseVisualStyleBackColor = false;
            this.btnEmployeesSickListsDatail.Click += new System.EventHandler(this.btnEmployeesSickListsDatail_Click);
            // 
            // groupBoxEmployees
            // 
            this.tableLayoutPanel_Working_field.SetColumnSpan(this.groupBoxEmployees, 2);
            this.groupBoxEmployees.Controls.Add(this.tableLayoutPanelEmployees);
            this.groupBoxEmployees.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxEmployees.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBoxEmployees.ForeColor = System.Drawing.Color.White;
            this.groupBoxEmployees.Location = new System.Drawing.Point(3, 3);
            this.groupBoxEmployees.Name = "groupBoxEmployees";
            this.groupBoxEmployees.Size = new System.Drawing.Size(766, 154);
            this.groupBoxEmployees.TabIndex = 3;
            this.groupBoxEmployees.TabStop = false;
            this.groupBoxEmployees.Text = "Список сотрудников:";
            // 
            // tableLayoutPanelEmployees
            // 
            this.tableLayoutPanelEmployees.ColumnCount = 1;
            this.tableLayoutPanelEmployees.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelEmployees.Controls.Add(this.dataGridViewEmployees, 0, 0);
            this.tableLayoutPanelEmployees.Controls.Add(this.btnEmployeesDetail, 0, 1);
            this.tableLayoutPanelEmployees.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelEmployees.Location = new System.Drawing.Point(3, 25);
            this.tableLayoutPanelEmployees.Name = "tableLayoutPanelEmployees";
            this.tableLayoutPanelEmployees.RowCount = 2;
            this.tableLayoutPanelEmployees.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 75F));
            this.tableLayoutPanelEmployees.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanelEmployees.Size = new System.Drawing.Size(760, 126);
            this.tableLayoutPanelEmployees.TabIndex = 0;
            // 
            // dataGridViewEmployees
            // 
            this.dataGridViewEmployees.AllowUserToAddRows = false;
            this.dataGridViewEmployees.AllowUserToDeleteRows = false;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.AntiqueWhite;
            this.dataGridViewEmployees.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle9;
            this.dataGridViewEmployees.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewEmployees.DefaultCellStyle = dataGridViewCellStyle10;
            this.dataGridViewEmployees.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewEmployees.Location = new System.Drawing.Point(3, 3);
            this.dataGridViewEmployees.MultiSelect = false;
            this.dataGridViewEmployees.Name = "dataGridViewEmployees";
            this.dataGridViewEmployees.ReadOnly = true;
            this.dataGridViewEmployees.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewEmployees.Size = new System.Drawing.Size(754, 88);
            this.dataGridViewEmployees.TabIndex = 0;
            // 
            // btnEmployeesDetail
            // 
            this.btnEmployeesDetail.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnEmployeesDetail.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnEmployeesDetail.Location = new System.Drawing.Point(3, 97);
            this.btnEmployeesDetail.Name = "btnEmployeesDetail";
            this.btnEmployeesDetail.Size = new System.Drawing.Size(754, 26);
            this.btnEmployeesDetail.TabIndex = 1;
            this.btnEmployeesDetail.Text = "Перейти к списку сотрудников";
            this.btnEmployeesDetail.UseVisualStyleBackColor = false;
            this.btnEmployeesDetail.Click += new System.EventHandler(this.btnEmployeesDetail_Click);
            // 
            // groupBoxAlternateList
            // 
            this.groupBoxAlternateList.Controls.Add(this.tableLayoutPanelAlternateList);
            this.groupBoxAlternateList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxAlternateList.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBoxAlternateList.ForeColor = System.Drawing.Color.White;
            this.groupBoxAlternateList.Location = new System.Drawing.Point(3, 163);
            this.groupBoxAlternateList.Name = "groupBoxAlternateList";
            this.groupBoxAlternateList.Size = new System.Drawing.Size(302, 155);
            this.groupBoxAlternateList.TabIndex = 5;
            this.groupBoxAlternateList.TabStop = false;
            this.groupBoxAlternateList.Text = "Список замещающих лиц:";
            // 
            // tableLayoutPanelAlternateList
            // 
            this.tableLayoutPanelAlternateList.ColumnCount = 1;
            this.tableLayoutPanelAlternateList.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelAlternateList.Controls.Add(this.dataGridViewAlternateList, 0, 0);
            this.tableLayoutPanelAlternateList.Controls.Add(this.btnAlternateListDetail, 0, 1);
            this.tableLayoutPanelAlternateList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelAlternateList.Location = new System.Drawing.Point(3, 25);
            this.tableLayoutPanelAlternateList.Name = "tableLayoutPanelAlternateList";
            this.tableLayoutPanelAlternateList.RowCount = 2;
            this.tableLayoutPanelAlternateList.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 75F));
            this.tableLayoutPanelAlternateList.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanelAlternateList.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanelAlternateList.Size = new System.Drawing.Size(296, 127);
            this.tableLayoutPanelAlternateList.TabIndex = 0;
            // 
            // dataGridViewAlternateList
            // 
            this.dataGridViewAlternateList.AllowUserToAddRows = false;
            this.dataGridViewAlternateList.AllowUserToDeleteRows = false;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.AntiqueWhite;
            this.dataGridViewAlternateList.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle11;
            this.dataGridViewAlternateList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewAlternateList.DefaultCellStyle = dataGridViewCellStyle12;
            this.dataGridViewAlternateList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewAlternateList.Location = new System.Drawing.Point(3, 3);
            this.dataGridViewAlternateList.MultiSelect = false;
            this.dataGridViewAlternateList.Name = "dataGridViewAlternateList";
            this.dataGridViewAlternateList.ReadOnly = true;
            this.dataGridViewAlternateList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewAlternateList.Size = new System.Drawing.Size(290, 89);
            this.dataGridViewAlternateList.TabIndex = 0;
            // 
            // btnAlternateListDetail
            // 
            this.btnAlternateListDetail.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnAlternateListDetail.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnAlternateListDetail.Location = new System.Drawing.Point(3, 98);
            this.btnAlternateListDetail.Name = "btnAlternateListDetail";
            this.btnAlternateListDetail.Size = new System.Drawing.Size(290, 26);
            this.btnAlternateListDetail.TabIndex = 1;
            this.btnAlternateListDetail.Text = "Перейти к списку замешающих лиц";
            this.btnAlternateListDetail.UseVisualStyleBackColor = false;
            this.btnAlternateListDetail.Click += new System.EventHandler(this.btnAlternateListDetail_Click);
            // 
            // tableLayoutPanel_WindowHeader
            // 
            this.tableLayoutPanel_WindowHeader.ColumnCount = 4;
            this.tableLayoutPanel_WindowHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_WindowHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_WindowHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_WindowHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_WindowHeader.Controls.Add(this.lblEmployees, 0, 0);
            this.tableLayoutPanel_WindowHeader.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_WindowHeader.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel_WindowHeader.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.tableLayoutPanel_WindowHeader.Name = "tableLayoutPanel_WindowHeader";
            this.tableLayoutPanel_WindowHeader.RowCount = 1;
            this.tableLayoutPanel_WindowHeader.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_WindowHeader.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 41F));
            this.tableLayoutPanel_WindowHeader.Size = new System.Drawing.Size(772, 41);
            this.tableLayoutPanel_WindowHeader.TabIndex = 6;
            // 
            // lblEmployees
            // 
            this.lblEmployees.AutoSize = true;
            this.tableLayoutPanel_WindowHeader.SetColumnSpan(this.lblEmployees, 4);
            this.lblEmployees.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblEmployees.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblEmployees.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblEmployees.Location = new System.Drawing.Point(3, 0);
            this.lblEmployees.Name = "lblEmployees";
            this.lblEmployees.Size = new System.Drawing.Size(766, 41);
            this.lblEmployees.TabIndex = 19;
            this.lblEmployees.Text = "СВЕДЕНИЯ О СОТРУДНИКАХ";
            this.lblEmployees.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel_Programm
            // 
            this.tableLayoutPanel_Programm.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPanel_Programm.ColumnCount = 1;
            this.tableLayoutPanel_Programm.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Programm.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Programm.Controls.Add(this.lblProgramm, 0, 0);
            this.tableLayoutPanel_Programm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Programm.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel_Programm.Name = "tableLayoutPanel_Programm";
            this.tableLayoutPanel_Programm.RowCount = 1;
            this.tableLayoutPanel_Programm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Programm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Programm.Size = new System.Drawing.Size(778, 43);
            this.tableLayoutPanel_Programm.TabIndex = 8;
            // 
            // lblProgramm
            // 
            this.lblProgramm.AutoSize = true;
            this.lblProgramm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblProgramm.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblProgramm.ForeColor = System.Drawing.Color.White;
            this.lblProgramm.Location = new System.Drawing.Point(3, 0);
            this.lblProgramm.Name = "lblProgramm";
            this.lblProgramm.Size = new System.Drawing.Size(772, 43);
            this.lblProgramm.TabIndex = 0;
            this.lblProgramm.Text = "ФОРМИРОВАНИЕ И ВЕДЕНИЕ ГРАФИКА ОТПУСКОВ СОТРУДНИКОВ";
            this.lblProgramm.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // EmployeesForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 497);
            this.Controls.Add(this.tableLayoutPanel_AllForm);
            this.Name = "EmployeesForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "СОТРУДНИКИ";
            this.Load += new System.EventHandler(this.EmployeesForm_Load);
            this.tableLayoutPanel_AllForm.ResumeLayout(false);
            this.tableLayoutPanel_Company.ResumeLayout(false);
            this.tableLayoutPanel_Company.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCompany)).EndInit();
            this.tableLayoutPanel_Employees.ResumeLayout(false);
            this.tableLayoutPanel_Working_field.ResumeLayout(false);
            this.groupBoxEmployeeSickLists.ResumeLayout(false);
            this.tableLayoutPanelEmployeesAccounts.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewEmployeesSickLists)).EndInit();
            this.groupBoxEmployees.ResumeLayout(false);
            this.tableLayoutPanelEmployees.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewEmployees)).EndInit();
            this.groupBoxAlternateList.ResumeLayout(false);
            this.tableLayoutPanelAlternateList.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAlternateList)).EndInit();
            this.tableLayoutPanel_WindowHeader.ResumeLayout(false);
            this.tableLayoutPanel_WindowHeader.PerformLayout();
            this.tableLayoutPanel_Programm.ResumeLayout(false);
            this.tableLayoutPanel_Programm.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_AllForm;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Company;
        private System.Windows.Forms.PictureBox pictureBoxCompany;
        private System.Windows.Forms.Label lblCompany;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Employees;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Working_field;
        private System.Windows.Forms.GroupBox groupBoxEmployeeSickLists;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelEmployeesAccounts;
        private System.Windows.Forms.DataGridView dataGridViewEmployeesSickLists;
        private System.Windows.Forms.Button btnEmployeesSickListsDatail;
        private System.Windows.Forms.GroupBox groupBoxEmployees;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelEmployees;
        private System.Windows.Forms.DataGridView dataGridViewEmployees;
        private System.Windows.Forms.Button btnEmployeesDetail;
        private System.Windows.Forms.GroupBox groupBoxAlternateList;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelAlternateList;
        private System.Windows.Forms.DataGridView dataGridViewAlternateList;
        private System.Windows.Forms.Button btnAlternateListDetail;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_WindowHeader;
        private System.Windows.Forms.Label lblEmployees;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Programm;
        private System.Windows.Forms.Label lblProgramm;
    }
}