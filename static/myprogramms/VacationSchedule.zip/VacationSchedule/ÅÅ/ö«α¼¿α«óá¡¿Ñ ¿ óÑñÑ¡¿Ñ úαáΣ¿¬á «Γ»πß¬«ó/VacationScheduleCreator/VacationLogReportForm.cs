﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace VacationScheduleCreator
{
    public partial class VacationLogReportForm : Form
    {
        //класс формы для формирования отчета "Журнал ведения отпусков"
        public VacationLogReportForm()
        {
            InitializeComponent();
        }

        //процедура заполнения таблицы "Журнал отпусков" из БД
        private void VacationLogDocumentForm_Load(object sender, EventArgs e)
        {
            DB_Connection.ShowVacationLogReport();
            dataGridViewVacationLog.DataSource = DB_Connection.dtVacationLogReport;
        }

        //процедура формирования отчета "Журнал ведения отпусков"
        private void btnVacationLogReportCreate_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;
            Excel.OpenExcel(Application.StartupPath + @"\VacationLogTemplate.xlsx");
            string Path_to_file = Application.StartupPath + @"\Excel documents\Журнал ведения отпусков от " +
                DateTime.Now.ToString("yyyy-MM-dd_hh-mm-ss") + ".xlsx";
            int k = -1;
            string tab = dataGridViewVacationLog.Rows[0].Cells[0].Value.ToString();
            for (Int32 i = 0; i < dataGridViewVacationLog.RowCount; i++)
            {
                if (tab == dataGridViewVacationLog.Rows[i].Cells[0].Value.ToString())
                    k++;
                else
                {
                    Excel.workSheet.Range[Excel.workSheet.Cells[i - k + 13, 2], Excel.workSheet.Cells[i + 13, 2]].Merge();
                    Excel.workSheet.Range[Excel.workSheet.Cells[i - k + 13, 3], Excel.workSheet.Cells[i + 13, 3]].Merge();
                    Excel.workSheet.Range[Excel.workSheet.Cells[i - k + 13, 3], Excel.workSheet.Cells[i + 13, 3]].HorizontalAlignment = Excel.excelAlign;
                    //Excel.workSheet.Range[Excel.workSheet.Cells[i - k + 13, 4], Excel.workSheet.Cells[i - k + 13, 4]].AutoFit();
                    Excel.workSheet.Range[Excel.workSheet.Cells[i - k + 13, 4], Excel.workSheet.Cells[i + 13, 4]].Merge();
                    k = 0;
                    tab = dataGridViewVacationLog.Rows[i].Cells[0].Value.ToString();
                }
                for (Int32 j = 0; j < dataGridViewVacationLog.ColumnCount; j++)
                {
                    Excel.workSheet.Cells[i + 5, j + 2].Value =
                        dataGridViewVacationLog.Rows[i].Cells[j].Value;
                }
            }
            for (Int32 i = 0; i < dataGridViewVacationLog.RowCount; i++)
                Excel.workSheet.Cells[i + 5, 1].Value = (i + 1).ToString();
            Excel.workBook.SaveAs(Path_to_file);
            MessageBox.Show("Данные успешно сохранены в файл!");
            this.Cursor = Cursors.Default;
        }
    }
}
