﻿namespace VacationScheduleCreator
{
    partial class OrganizationSettingsEditForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(OrganizationSettingsEditForm));
            this.tableLayoutPanel_AllForm = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel_Company = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBoxCompany = new System.Windows.Forms.PictureBox();
            this.lblCompany = new System.Windows.Forms.Label();
            this.tableLayoutPanelWorkingField = new System.Windows.Forms.TableLayoutPanel();
            this.tabControlOrganizationSettingsEdit = new System.Windows.Forms.TabControl();
            this.tabPageCompanyInformation = new System.Windows.Forms.TabPage();
            this.tableLayoutPanelCompanyInformation = new System.Windows.Forms.TableLayoutPanel();
            this.tlpCompanyInformInput = new System.Windows.Forms.TableLayoutPanel();
            this.lblLegaLAddress = new System.Windows.Forms.Label();
            this.lblFullTitle = new System.Windows.Forms.Label();
            this.lblOKPO = new System.Windows.Forms.Label();
            this.lblKPP = new System.Windows.Forms.Label();
            this.lblINN = new System.Windows.Forms.Label();
            this.lblActualAddress = new System.Windows.Forms.Label();
            this.textBoxShortTitle = new System.Windows.Forms.TextBox();
            this.textBoxINN = new System.Windows.Forms.TextBox();
            this.textBoxKPP = new System.Windows.Forms.TextBox();
            this.textBoxOKPO = new System.Windows.Forms.TextBox();
            this.textBoxFullTitle = new System.Windows.Forms.TextBox();
            this.textBoxLegalAddress = new System.Windows.Forms.TextBox();
            this.textBoxActualAddress = new System.Windows.Forms.TextBox();
            this.lblShortTitle = new System.Windows.Forms.Label();
            this.tlpCompanyInformationFunctionalButtons = new System.Windows.Forms.TableLayoutPanel();
            this.btnCompanyInformationPost = new System.Windows.Forms.Button();
            this.btnCompanyInformationCancel = new System.Windows.Forms.Button();
            this.tabPageHierarchyLevels = new System.Windows.Forms.TabPage();
            this.tableLayoutPanelHierarchyLevels = new System.Windows.Forms.TableLayoutPanel();
            this.tlpHierarchyLevelsFunctionalButtons = new System.Windows.Forms.TableLayoutPanel();
            this.btnHierarchyLevelPost = new System.Windows.Forms.Button();
            this.btnHierarchyLevelCancel = new System.Windows.Forms.Button();
            this.tlpHierarhyInput = new System.Windows.Forms.TableLayoutPanel();
            this.textBoxHierarchyName = new System.Windows.Forms.TextBox();
            this.lblHierarchyName = new System.Windows.Forms.Label();
            this.tabPageFunctions = new System.Windows.Forms.TabPage();
            this.tableLayoutPanelFunctions = new System.Windows.Forms.TableLayoutPanel();
            this.tlpFunctionInput = new System.Windows.Forms.TableLayoutPanel();
            this.textBoxFunctionName = new System.Windows.Forms.TextBox();
            this.lblFunctionName = new System.Windows.Forms.Label();
            this.tlpFunctionsFunctionalButtons = new System.Windows.Forms.TableLayoutPanel();
            this.btnFunctionPost = new System.Windows.Forms.Button();
            this.btnFunctionCancel = new System.Windows.Forms.Button();
            this.tabPagePersonnelCategories = new System.Windows.Forms.TabPage();
            this.tableLayoutPanelPersonnelCategories = new System.Windows.Forms.TableLayoutPanel();
            this.tlpPersonnelCategoriesFunctionalButtons = new System.Windows.Forms.TableLayoutPanel();
            this.btnPersonnelCategoryPost = new System.Windows.Forms.Button();
            this.btnPersonnelCategoryCancel = new System.Windows.Forms.Button();
            this.tlpPersonnelCategoryInput = new System.Windows.Forms.TableLayoutPanel();
            this.lblPersonnelCategoryFullName = new System.Windows.Forms.Label();
            this.textBoxPersonnelCategoryFullName = new System.Windows.Forms.TextBox();
            this.textBoxPersonnelCategoryShortName = new System.Windows.Forms.TextBox();
            this.lblPersonnelCategoryShortName = new System.Windows.Forms.Label();
            this.tabPageStateHolidaysList = new System.Windows.Forms.TabPage();
            this.tableLayoutPanelStateHolidaysList = new System.Windows.Forms.TableLayoutPanel();
            this.tlpStateHolidayInput = new System.Windows.Forms.TableLayoutPanel();
            this.lblStateHolidayName = new System.Windows.Forms.Label();
            this.textBoxStateHolidayName = new System.Windows.Forms.TextBox();
            this.lblStateHolidayDate = new System.Windows.Forms.Label();
            this.dtpStateHolidayDate = new System.Windows.Forms.DateTimePicker();
            this.tlpStateHolidaysListFunctionalButtons = new System.Windows.Forms.TableLayoutPanel();
            this.btnStateHolidayPost = new System.Windows.Forms.Button();
            this.btnStateHolidayCancel = new System.Windows.Forms.Button();
            this.tableLayoutPanel_AllForm.SuspendLayout();
            this.tableLayoutPanel_Company.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCompany)).BeginInit();
            this.tableLayoutPanelWorkingField.SuspendLayout();
            this.tabControlOrganizationSettingsEdit.SuspendLayout();
            this.tabPageCompanyInformation.SuspendLayout();
            this.tableLayoutPanelCompanyInformation.SuspendLayout();
            this.tlpCompanyInformInput.SuspendLayout();
            this.tlpCompanyInformationFunctionalButtons.SuspendLayout();
            this.tabPageHierarchyLevels.SuspendLayout();
            this.tableLayoutPanelHierarchyLevels.SuspendLayout();
            this.tlpHierarchyLevelsFunctionalButtons.SuspendLayout();
            this.tlpHierarhyInput.SuspendLayout();
            this.tabPageFunctions.SuspendLayout();
            this.tableLayoutPanelFunctions.SuspendLayout();
            this.tlpFunctionInput.SuspendLayout();
            this.tlpFunctionsFunctionalButtons.SuspendLayout();
            this.tabPagePersonnelCategories.SuspendLayout();
            this.tableLayoutPanelPersonnelCategories.SuspendLayout();
            this.tlpPersonnelCategoriesFunctionalButtons.SuspendLayout();
            this.tlpPersonnelCategoryInput.SuspendLayout();
            this.tabPageStateHolidaysList.SuspendLayout();
            this.tableLayoutPanelStateHolidaysList.SuspendLayout();
            this.tlpStateHolidayInput.SuspendLayout();
            this.tlpStateHolidaysListFunctionalButtons.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel_AllForm
            // 
            this.tableLayoutPanel_AllForm.ColumnCount = 1;
            this.tableLayoutPanel_AllForm.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_AllForm.Controls.Add(this.tableLayoutPanel_Company, 0, 0);
            this.tableLayoutPanel_AllForm.Controls.Add(this.tableLayoutPanelWorkingField, 0, 1);
            this.tableLayoutPanel_AllForm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_AllForm.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel_AllForm.Name = "tableLayoutPanel_AllForm";
            this.tableLayoutPanel_AllForm.RowCount = 2;
            this.tableLayoutPanel_AllForm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel_AllForm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tableLayoutPanel_AllForm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel_AllForm.Size = new System.Drawing.Size(384, 561);
            this.tableLayoutPanel_AllForm.TabIndex = 3;
            // 
            // tableLayoutPanel_Company
            // 
            this.tableLayoutPanel_Company.BackColor = System.Drawing.SystemColors.HotTrack;
            this.tableLayoutPanel_Company.ColumnCount = 3;
            this.tableLayoutPanel_Company.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_Company.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.tableLayoutPanel_Company.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel_Company.Controls.Add(this.pictureBoxCompany, 0, 1);
            this.tableLayoutPanel_Company.Controls.Add(this.lblCompany, 1, 1);
            this.tableLayoutPanel_Company.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Company.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel_Company.Name = "tableLayoutPanel_Company";
            this.tableLayoutPanel_Company.RowCount = 3;
            this.tableLayoutPanel_Company.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel_Company.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tableLayoutPanel_Company.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel_Company.Size = new System.Drawing.Size(378, 50);
            this.tableLayoutPanel_Company.TabIndex = 8;
            // 
            // pictureBoxCompany
            // 
            this.pictureBoxCompany.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxCompany.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxCompany.Image")));
            this.pictureBoxCompany.Location = new System.Drawing.Point(0, 2);
            this.pictureBoxCompany.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBoxCompany.Name = "pictureBoxCompany";
            this.pictureBoxCompany.Size = new System.Drawing.Size(94, 45);
            this.pictureBoxCompany.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxCompany.TabIndex = 3;
            this.pictureBoxCompany.TabStop = false;
            // 
            // lblCompany
            // 
            this.lblCompany.AutoSize = true;
            this.lblCompany.BackColor = System.Drawing.SystemColors.HotTrack;
            this.lblCompany.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCompany.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblCompany.ForeColor = System.Drawing.Color.White;
            this.lblCompany.Location = new System.Drawing.Point(97, 2);
            this.lblCompany.Name = "lblCompany";
            this.lblCompany.Size = new System.Drawing.Size(258, 45);
            this.lblCompany.TabIndex = 2;
            this.lblCompany.Text = "МЕЖРЕГИОНАЛЬНАЯ РАСПРЕДЕЛИТЕЛЬНАЯ СЕТЕВАЯ КОМПАНИЯ СЕВЕРО-ЗАПАДА";
            this.lblCompany.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanelWorkingField
            // 
            this.tableLayoutPanelWorkingField.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPanelWorkingField.ColumnCount = 1;
            this.tableLayoutPanelWorkingField.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelWorkingField.Controls.Add(this.tabControlOrganizationSettingsEdit, 0, 0);
            this.tableLayoutPanelWorkingField.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelWorkingField.Location = new System.Drawing.Point(3, 59);
            this.tableLayoutPanelWorkingField.Name = "tableLayoutPanelWorkingField";
            this.tableLayoutPanelWorkingField.RowCount = 1;
            this.tableLayoutPanelWorkingField.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelWorkingField.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanelWorkingField.Size = new System.Drawing.Size(378, 499);
            this.tableLayoutPanelWorkingField.TabIndex = 9;
            // 
            // tabControlOrganizationSettingsEdit
            // 
            this.tabControlOrganizationSettingsEdit.Controls.Add(this.tabPageCompanyInformation);
            this.tabControlOrganizationSettingsEdit.Controls.Add(this.tabPageHierarchyLevels);
            this.tabControlOrganizationSettingsEdit.Controls.Add(this.tabPageFunctions);
            this.tabControlOrganizationSettingsEdit.Controls.Add(this.tabPagePersonnelCategories);
            this.tabControlOrganizationSettingsEdit.Controls.Add(this.tabPageStateHolidaysList);
            this.tabControlOrganizationSettingsEdit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlOrganizationSettingsEdit.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tabControlOrganizationSettingsEdit.Location = new System.Drawing.Point(3, 3);
            this.tabControlOrganizationSettingsEdit.Name = "tabControlOrganizationSettingsEdit";
            this.tabControlOrganizationSettingsEdit.SelectedIndex = 0;
            this.tabControlOrganizationSettingsEdit.Size = new System.Drawing.Size(372, 493);
            this.tabControlOrganizationSettingsEdit.TabIndex = 10;
            // 
            // tabPageCompanyInformation
            // 
            this.tabPageCompanyInformation.Controls.Add(this.tableLayoutPanelCompanyInformation);
            this.tabPageCompanyInformation.Location = new System.Drawing.Point(4, 29);
            this.tabPageCompanyInformation.Name = "tabPageCompanyInformation";
            this.tabPageCompanyInformation.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageCompanyInformation.Size = new System.Drawing.Size(364, 460);
            this.tabPageCompanyInformation.TabIndex = 0;
            this.tabPageCompanyInformation.Text = "Сведения о предприятии";
            this.tabPageCompanyInformation.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanelCompanyInformation
            // 
            this.tableLayoutPanelCompanyInformation.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPanelCompanyInformation.ColumnCount = 1;
            this.tableLayoutPanelCompanyInformation.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelCompanyInformation.Controls.Add(this.tlpCompanyInformInput, 0, 0);
            this.tableLayoutPanelCompanyInformation.Controls.Add(this.tlpCompanyInformationFunctionalButtons, 0, 1);
            this.tableLayoutPanelCompanyInformation.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelCompanyInformation.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanelCompanyInformation.Name = "tableLayoutPanelCompanyInformation";
            this.tableLayoutPanelCompanyInformation.RowCount = 2;
            this.tableLayoutPanelCompanyInformation.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tableLayoutPanelCompanyInformation.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanelCompanyInformation.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanelCompanyInformation.Size = new System.Drawing.Size(358, 454);
            this.tableLayoutPanelCompanyInformation.TabIndex = 1;
            // 
            // tlpCompanyInformInput
            // 
            this.tlpCompanyInformInput.ColumnCount = 3;
            this.tlpCompanyInformInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36F));
            this.tlpCompanyInformInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 58F));
            this.tlpCompanyInformInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6F));
            this.tlpCompanyInformInput.Controls.Add(this.lblLegaLAddress, 0, 5);
            this.tlpCompanyInformInput.Controls.Add(this.lblFullTitle, 0, 4);
            this.tlpCompanyInformInput.Controls.Add(this.lblOKPO, 0, 3);
            this.tlpCompanyInformInput.Controls.Add(this.lblKPP, 0, 2);
            this.tlpCompanyInformInput.Controls.Add(this.lblINN, 0, 1);
            this.tlpCompanyInformInput.Controls.Add(this.lblActualAddress, 0, 6);
            this.tlpCompanyInformInput.Controls.Add(this.textBoxShortTitle, 1, 0);
            this.tlpCompanyInformInput.Controls.Add(this.textBoxINN, 1, 1);
            this.tlpCompanyInformInput.Controls.Add(this.textBoxKPP, 1, 2);
            this.tlpCompanyInformInput.Controls.Add(this.textBoxOKPO, 1, 3);
            this.tlpCompanyInformInput.Controls.Add(this.textBoxFullTitle, 1, 4);
            this.tlpCompanyInformInput.Controls.Add(this.textBoxLegalAddress, 1, 5);
            this.tlpCompanyInformInput.Controls.Add(this.textBoxActualAddress, 1, 6);
            this.tlpCompanyInformInput.Controls.Add(this.lblShortTitle, 0, 0);
            this.tlpCompanyInformInput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpCompanyInformInput.Location = new System.Drawing.Point(3, 3);
            this.tlpCompanyInformInput.Name = "tlpCompanyInformInput";
            this.tlpCompanyInformInput.RowCount = 8;
            this.tlpCompanyInformInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.5F));
            this.tlpCompanyInformInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpCompanyInformInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpCompanyInformInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpCompanyInformInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpCompanyInformInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpCompanyInformInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpCompanyInformInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 21.5F));
            this.tlpCompanyInformInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tlpCompanyInformInput.Size = new System.Drawing.Size(352, 402);
            this.tlpCompanyInformInput.TabIndex = 9;
            // 
            // lblLegaLAddress
            // 
            this.lblLegaLAddress.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblLegaLAddress.AutoSize = true;
            this.lblLegaLAddress.Location = new System.Drawing.Point(46, 264);
            this.lblLegaLAddress.Name = "lblLegaLAddress";
            this.lblLegaLAddress.Size = new System.Drawing.Size(77, 20);
            this.lblLegaLAddress.TabIndex = 6;
            this.lblLegaLAddress.Text = "Юр. адрес:";
            this.lblLegaLAddress.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblFullTitle
            // 
            this.lblFullTitle.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblFullTitle.AutoSize = true;
            this.lblFullTitle.Location = new System.Drawing.Point(3, 234);
            this.lblFullTitle.Name = "lblFullTitle";
            this.lblFullTitle.Size = new System.Drawing.Size(120, 20);
            this.lblFullTitle.TabIndex = 2;
            this.lblFullTitle.Text = "Полное название:";
            this.lblFullTitle.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblOKPO
            // 
            this.lblOKPO.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblOKPO.AutoSize = true;
            this.lblOKPO.Location = new System.Drawing.Point(73, 204);
            this.lblOKPO.Name = "lblOKPO";
            this.lblOKPO.Size = new System.Drawing.Size(50, 20);
            this.lblOKPO.TabIndex = 5;
            this.lblOKPO.Text = "ОКПО:";
            this.lblOKPO.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblKPP
            // 
            this.lblKPP.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblKPP.AutoSize = true;
            this.lblKPP.Location = new System.Drawing.Point(84, 174);
            this.lblKPP.Name = "lblKPP";
            this.lblKPP.Size = new System.Drawing.Size(39, 20);
            this.lblKPP.TabIndex = 4;
            this.lblKPP.Text = "КПП:";
            this.lblKPP.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblINN
            // 
            this.lblINN.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblINN.AutoSize = true;
            this.lblINN.Location = new System.Drawing.Point(83, 144);
            this.lblINN.Name = "lblINN";
            this.lblINN.Size = new System.Drawing.Size(40, 20);
            this.lblINN.TabIndex = 3;
            this.lblINN.Text = "ИНН:";
            this.lblINN.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblActualAddress
            // 
            this.lblActualAddress.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblActualAddress.AutoSize = true;
            this.lblActualAddress.Location = new System.Drawing.Point(43, 294);
            this.lblActualAddress.Name = "lblActualAddress";
            this.lblActualAddress.Size = new System.Drawing.Size(80, 20);
            this.lblActualAddress.TabIndex = 7;
            this.lblActualAddress.Text = "Физ. адрес:";
            this.lblActualAddress.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // textBoxShortTitle
            // 
            this.textBoxShortTitle.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxShortTitle.Location = new System.Drawing.Point(129, 106);
            this.textBoxShortTitle.MaxLength = 50;
            this.textBoxShortTitle.Name = "textBoxShortTitle";
            this.textBoxShortTitle.Size = new System.Drawing.Size(198, 25);
            this.textBoxShortTitle.TabIndex = 0;
            // 
            // textBoxINN
            // 
            this.textBoxINN.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxINN.Location = new System.Drawing.Point(129, 137);
            this.textBoxINN.MaxLength = 10;
            this.textBoxINN.Name = "textBoxINN";
            this.textBoxINN.Size = new System.Drawing.Size(198, 25);
            this.textBoxINN.TabIndex = 8;
            this.textBoxINN.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxINN_KeyPress);
            // 
            // textBoxKPP
            // 
            this.textBoxKPP.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxKPP.Location = new System.Drawing.Point(129, 167);
            this.textBoxKPP.MaxLength = 9;
            this.textBoxKPP.Name = "textBoxKPP";
            this.textBoxKPP.Size = new System.Drawing.Size(198, 25);
            this.textBoxKPP.TabIndex = 9;
            this.textBoxKPP.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxKPP_KeyPress);
            // 
            // textBoxOKPO
            // 
            this.textBoxOKPO.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxOKPO.Location = new System.Drawing.Point(129, 197);
            this.textBoxOKPO.MaxLength = 8;
            this.textBoxOKPO.Name = "textBoxOKPO";
            this.textBoxOKPO.Size = new System.Drawing.Size(198, 25);
            this.textBoxOKPO.TabIndex = 10;
            this.textBoxOKPO.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxOKPO_KeyPress);
            // 
            // textBoxFullTitle
            // 
            this.textBoxFullTitle.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxFullTitle.Location = new System.Drawing.Point(129, 227);
            this.textBoxFullTitle.MaxLength = 100;
            this.textBoxFullTitle.Name = "textBoxFullTitle";
            this.textBoxFullTitle.Size = new System.Drawing.Size(198, 25);
            this.textBoxFullTitle.TabIndex = 11;
            // 
            // textBoxLegalAddress
            // 
            this.textBoxLegalAddress.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxLegalAddress.Location = new System.Drawing.Point(129, 257);
            this.textBoxLegalAddress.MaxLength = 100;
            this.textBoxLegalAddress.Name = "textBoxLegalAddress";
            this.textBoxLegalAddress.Size = new System.Drawing.Size(198, 25);
            this.textBoxLegalAddress.TabIndex = 12;
            // 
            // textBoxActualAddress
            // 
            this.textBoxActualAddress.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxActualAddress.Location = new System.Drawing.Point(129, 287);
            this.textBoxActualAddress.MaxLength = 100;
            this.textBoxActualAddress.Name = "textBoxActualAddress";
            this.textBoxActualAddress.Size = new System.Drawing.Size(198, 25);
            this.textBoxActualAddress.TabIndex = 13;
            // 
            // lblShortTitle
            // 
            this.lblShortTitle.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblShortTitle.AutoSize = true;
            this.lblShortTitle.Location = new System.Drawing.Point(20, 94);
            this.lblShortTitle.Name = "lblShortTitle";
            this.lblShortTitle.Size = new System.Drawing.Size(103, 40);
            this.lblShortTitle.TabIndex = 1;
            this.lblShortTitle.Text = "Краткое наименование:";
            this.lblShortTitle.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // tlpCompanyInformationFunctionalButtons
            // 
            this.tlpCompanyInformationFunctionalButtons.ColumnCount = 2;
            this.tlpCompanyInformationFunctionalButtons.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpCompanyInformationFunctionalButtons.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpCompanyInformationFunctionalButtons.Controls.Add(this.btnCompanyInformationPost, 1, 0);
            this.tlpCompanyInformationFunctionalButtons.Controls.Add(this.btnCompanyInformationCancel, 0, 0);
            this.tlpCompanyInformationFunctionalButtons.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpCompanyInformationFunctionalButtons.Location = new System.Drawing.Point(3, 411);
            this.tlpCompanyInformationFunctionalButtons.Name = "tlpCompanyInformationFunctionalButtons";
            this.tlpCompanyInformationFunctionalButtons.RowCount = 1;
            this.tlpCompanyInformationFunctionalButtons.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpCompanyInformationFunctionalButtons.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tlpCompanyInformationFunctionalButtons.Size = new System.Drawing.Size(352, 40);
            this.tlpCompanyInformationFunctionalButtons.TabIndex = 0;
            // 
            // btnCompanyInformationPost
            // 
            this.btnCompanyInformationPost.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnCompanyInformationPost.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnCompanyInformationPost.ForeColor = System.Drawing.Color.White;
            this.btnCompanyInformationPost.Location = new System.Drawing.Point(179, 3);
            this.btnCompanyInformationPost.Name = "btnCompanyInformationPost";
            this.btnCompanyInformationPost.Size = new System.Drawing.Size(170, 34);
            this.btnCompanyInformationPost.TabIndex = 0;
            this.btnCompanyInformationPost.Text = "Сохранить данные";
            this.btnCompanyInformationPost.UseVisualStyleBackColor = false;
            this.btnCompanyInformationPost.Click += new System.EventHandler(this.btnCompanyInformationPost_Click);
            // 
            // btnCompanyInformationCancel
            // 
            this.btnCompanyInformationCancel.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnCompanyInformationCancel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnCompanyInformationCancel.ForeColor = System.Drawing.Color.White;
            this.btnCompanyInformationCancel.Location = new System.Drawing.Point(3, 3);
            this.btnCompanyInformationCancel.Name = "btnCompanyInformationCancel";
            this.btnCompanyInformationCancel.Size = new System.Drawing.Size(170, 34);
            this.btnCompanyInformationCancel.TabIndex = 1;
            this.btnCompanyInformationCancel.Text = "Отмена";
            this.btnCompanyInformationCancel.UseVisualStyleBackColor = false;
            this.btnCompanyInformationCancel.Click += new System.EventHandler(this.btnCompanyInformationCancel_Click);
            // 
            // tabPageHierarchyLevels
            // 
            this.tabPageHierarchyLevels.Controls.Add(this.tableLayoutPanelHierarchyLevels);
            this.tabPageHierarchyLevels.Location = new System.Drawing.Point(4, 25);
            this.tabPageHierarchyLevels.Name = "tabPageHierarchyLevels";
            this.tabPageHierarchyLevels.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageHierarchyLevels.Size = new System.Drawing.Size(324, 407);
            this.tabPageHierarchyLevels.TabIndex = 1;
            this.tabPageHierarchyLevels.Text = "Иерархия подразделений";
            this.tabPageHierarchyLevels.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanelHierarchyLevels
            // 
            this.tableLayoutPanelHierarchyLevels.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPanelHierarchyLevels.ColumnCount = 1;
            this.tableLayoutPanelHierarchyLevels.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelHierarchyLevels.Controls.Add(this.tlpHierarchyLevelsFunctionalButtons, 0, 1);
            this.tableLayoutPanelHierarchyLevels.Controls.Add(this.tlpHierarhyInput, 0, 0);
            this.tableLayoutPanelHierarchyLevels.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelHierarchyLevels.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanelHierarchyLevels.Name = "tableLayoutPanelHierarchyLevels";
            this.tableLayoutPanelHierarchyLevels.RowCount = 2;
            this.tableLayoutPanelHierarchyLevels.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tableLayoutPanelHierarchyLevels.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanelHierarchyLevels.Size = new System.Drawing.Size(318, 401);
            this.tableLayoutPanelHierarchyLevels.TabIndex = 0;
            // 
            // tlpHierarchyLevelsFunctionalButtons
            // 
            this.tlpHierarchyLevelsFunctionalButtons.ColumnCount = 2;
            this.tlpHierarchyLevelsFunctionalButtons.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpHierarchyLevelsFunctionalButtons.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpHierarchyLevelsFunctionalButtons.Controls.Add(this.btnHierarchyLevelPost, 1, 0);
            this.tlpHierarchyLevelsFunctionalButtons.Controls.Add(this.btnHierarchyLevelCancel, 0, 0);
            this.tlpHierarchyLevelsFunctionalButtons.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpHierarchyLevelsFunctionalButtons.Location = new System.Drawing.Point(3, 363);
            this.tlpHierarchyLevelsFunctionalButtons.Name = "tlpHierarchyLevelsFunctionalButtons";
            this.tlpHierarchyLevelsFunctionalButtons.RowCount = 1;
            this.tlpHierarchyLevelsFunctionalButtons.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpHierarchyLevelsFunctionalButtons.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tlpHierarchyLevelsFunctionalButtons.Size = new System.Drawing.Size(312, 35);
            this.tlpHierarchyLevelsFunctionalButtons.TabIndex = 0;
            // 
            // btnHierarchyLevelPost
            // 
            this.btnHierarchyLevelPost.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnHierarchyLevelPost.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnHierarchyLevelPost.ForeColor = System.Drawing.Color.White;
            this.btnHierarchyLevelPost.Location = new System.Drawing.Point(159, 3);
            this.btnHierarchyLevelPost.Name = "btnHierarchyLevelPost";
            this.btnHierarchyLevelPost.Size = new System.Drawing.Size(150, 29);
            this.btnHierarchyLevelPost.TabIndex = 0;
            this.btnHierarchyLevelPost.Text = "Сохранить данные";
            this.btnHierarchyLevelPost.UseVisualStyleBackColor = false;
            this.btnHierarchyLevelPost.Click += new System.EventHandler(this.btnHierarchyLevelPost_Click);
            // 
            // btnHierarchyLevelCancel
            // 
            this.btnHierarchyLevelCancel.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnHierarchyLevelCancel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnHierarchyLevelCancel.ForeColor = System.Drawing.Color.White;
            this.btnHierarchyLevelCancel.Location = new System.Drawing.Point(3, 3);
            this.btnHierarchyLevelCancel.Name = "btnHierarchyLevelCancel";
            this.btnHierarchyLevelCancel.Size = new System.Drawing.Size(150, 29);
            this.btnHierarchyLevelCancel.TabIndex = 1;
            this.btnHierarchyLevelCancel.Text = "Отмена";
            this.btnHierarchyLevelCancel.UseVisualStyleBackColor = false;
            this.btnHierarchyLevelCancel.Click += new System.EventHandler(this.btnHierarchyLevelCancel_Click);
            // 
            // tlpHierarhyInput
            // 
            this.tlpHierarhyInput.ColumnCount = 3;
            this.tlpHierarhyInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tlpHierarhyInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tlpHierarhyInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tlpHierarhyInput.Controls.Add(this.textBoxHierarchyName, 1, 1);
            this.tlpHierarhyInput.Controls.Add(this.lblHierarchyName, 1, 0);
            this.tlpHierarhyInput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpHierarhyInput.Location = new System.Drawing.Point(3, 3);
            this.tlpHierarhyInput.Name = "tlpHierarhyInput";
            this.tlpHierarhyInput.RowCount = 3;
            this.tlpHierarhyInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 47.5F));
            this.tlpHierarhyInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpHierarhyInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 45F));
            this.tlpHierarhyInput.Size = new System.Drawing.Size(312, 354);
            this.tlpHierarhyInput.TabIndex = 1;
            // 
            // textBoxHierarchyName
            // 
            this.textBoxHierarchyName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxHierarchyName.Location = new System.Drawing.Point(65, 171);
            this.textBoxHierarchyName.MaxLength = 45;
            this.textBoxHierarchyName.Name = "textBoxHierarchyName";
            this.textBoxHierarchyName.Size = new System.Drawing.Size(181, 25);
            this.textBoxHierarchyName.TabIndex = 0;
            // 
            // lblHierarchyName
            // 
            this.lblHierarchyName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblHierarchyName.AutoSize = true;
            this.lblHierarchyName.Location = new System.Drawing.Point(65, 148);
            this.lblHierarchyName.Name = "lblHierarchyName";
            this.lblHierarchyName.Size = new System.Drawing.Size(130, 20);
            this.lblHierarchyName.TabIndex = 1;
            this.lblHierarchyName.Text = "Уровень иерархии:";
            // 
            // tabPageFunctions
            // 
            this.tabPageFunctions.Controls.Add(this.tableLayoutPanelFunctions);
            this.tabPageFunctions.Location = new System.Drawing.Point(4, 25);
            this.tabPageFunctions.Name = "tabPageFunctions";
            this.tabPageFunctions.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageFunctions.Size = new System.Drawing.Size(324, 407);
            this.tabPageFunctions.TabIndex = 2;
            this.tabPageFunctions.Text = "Должности";
            this.tabPageFunctions.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanelFunctions
            // 
            this.tableLayoutPanelFunctions.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPanelFunctions.ColumnCount = 1;
            this.tableLayoutPanelFunctions.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelFunctions.Controls.Add(this.tlpFunctionInput, 0, 0);
            this.tableLayoutPanelFunctions.Controls.Add(this.tlpFunctionsFunctionalButtons, 0, 1);
            this.tableLayoutPanelFunctions.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelFunctions.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanelFunctions.Name = "tableLayoutPanelFunctions";
            this.tableLayoutPanelFunctions.RowCount = 2;
            this.tableLayoutPanelFunctions.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tableLayoutPanelFunctions.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanelFunctions.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanelFunctions.Size = new System.Drawing.Size(318, 401);
            this.tableLayoutPanelFunctions.TabIndex = 0;
            // 
            // tlpFunctionInput
            // 
            this.tlpFunctionInput.ColumnCount = 3;
            this.tlpFunctionInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tlpFunctionInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tlpFunctionInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tlpFunctionInput.Controls.Add(this.textBoxFunctionName, 1, 1);
            this.tlpFunctionInput.Controls.Add(this.lblFunctionName, 1, 0);
            this.tlpFunctionInput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpFunctionInput.Location = new System.Drawing.Point(3, 3);
            this.tlpFunctionInput.Name = "tlpFunctionInput";
            this.tlpFunctionInput.RowCount = 3;
            this.tlpFunctionInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 47.5F));
            this.tlpFunctionInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpFunctionInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 45F));
            this.tlpFunctionInput.Size = new System.Drawing.Size(312, 354);
            this.tlpFunctionInput.TabIndex = 3;
            // 
            // textBoxFunctionName
            // 
            this.textBoxFunctionName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxFunctionName.Location = new System.Drawing.Point(65, 171);
            this.textBoxFunctionName.MaxLength = 45;
            this.textBoxFunctionName.Name = "textBoxFunctionName";
            this.textBoxFunctionName.Size = new System.Drawing.Size(181, 25);
            this.textBoxFunctionName.TabIndex = 0;
            // 
            // lblFunctionName
            // 
            this.lblFunctionName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblFunctionName.AutoSize = true;
            this.lblFunctionName.Location = new System.Drawing.Point(65, 148);
            this.lblFunctionName.Name = "lblFunctionName";
            this.lblFunctionName.Size = new System.Drawing.Size(144, 20);
            this.lblFunctionName.TabIndex = 1;
            this.lblFunctionName.Text = "Название должности:";
            // 
            // tlpFunctionsFunctionalButtons
            // 
            this.tlpFunctionsFunctionalButtons.ColumnCount = 2;
            this.tlpFunctionsFunctionalButtons.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpFunctionsFunctionalButtons.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpFunctionsFunctionalButtons.Controls.Add(this.btnFunctionPost, 1, 0);
            this.tlpFunctionsFunctionalButtons.Controls.Add(this.btnFunctionCancel, 0, 0);
            this.tlpFunctionsFunctionalButtons.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpFunctionsFunctionalButtons.Location = new System.Drawing.Point(3, 363);
            this.tlpFunctionsFunctionalButtons.Name = "tlpFunctionsFunctionalButtons";
            this.tlpFunctionsFunctionalButtons.RowCount = 1;
            this.tlpFunctionsFunctionalButtons.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpFunctionsFunctionalButtons.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tlpFunctionsFunctionalButtons.Size = new System.Drawing.Size(312, 35);
            this.tlpFunctionsFunctionalButtons.TabIndex = 0;
            // 
            // btnFunctionPost
            // 
            this.btnFunctionPost.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnFunctionPost.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnFunctionPost.ForeColor = System.Drawing.Color.White;
            this.btnFunctionPost.Location = new System.Drawing.Point(159, 3);
            this.btnFunctionPost.Name = "btnFunctionPost";
            this.btnFunctionPost.Size = new System.Drawing.Size(150, 29);
            this.btnFunctionPost.TabIndex = 0;
            this.btnFunctionPost.Text = "Сохранить данные";
            this.btnFunctionPost.UseVisualStyleBackColor = false;
            this.btnFunctionPost.Click += new System.EventHandler(this.btnFunctionPost_Click);
            // 
            // btnFunctionCancel
            // 
            this.btnFunctionCancel.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnFunctionCancel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnFunctionCancel.ForeColor = System.Drawing.Color.White;
            this.btnFunctionCancel.Location = new System.Drawing.Point(3, 3);
            this.btnFunctionCancel.Name = "btnFunctionCancel";
            this.btnFunctionCancel.Size = new System.Drawing.Size(150, 29);
            this.btnFunctionCancel.TabIndex = 1;
            this.btnFunctionCancel.Text = "Отмена";
            this.btnFunctionCancel.UseVisualStyleBackColor = false;
            this.btnFunctionCancel.Click += new System.EventHandler(this.btnFunctionCancel_Click);
            // 
            // tabPagePersonnelCategories
            // 
            this.tabPagePersonnelCategories.Controls.Add(this.tableLayoutPanelPersonnelCategories);
            this.tabPagePersonnelCategories.Location = new System.Drawing.Point(4, 25);
            this.tabPagePersonnelCategories.Name = "tabPagePersonnelCategories";
            this.tabPagePersonnelCategories.Padding = new System.Windows.Forms.Padding(3);
            this.tabPagePersonnelCategories.Size = new System.Drawing.Size(324, 407);
            this.tabPagePersonnelCategories.TabIndex = 4;
            this.tabPagePersonnelCategories.Text = "Категории персонала";
            this.tabPagePersonnelCategories.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanelPersonnelCategories
            // 
            this.tableLayoutPanelPersonnelCategories.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPanelPersonnelCategories.ColumnCount = 1;
            this.tableLayoutPanelPersonnelCategories.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelPersonnelCategories.Controls.Add(this.tlpPersonnelCategoriesFunctionalButtons, 0, 1);
            this.tableLayoutPanelPersonnelCategories.Controls.Add(this.tlpPersonnelCategoryInput, 0, 0);
            this.tableLayoutPanelPersonnelCategories.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelPersonnelCategories.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanelPersonnelCategories.Name = "tableLayoutPanelPersonnelCategories";
            this.tableLayoutPanelPersonnelCategories.RowCount = 2;
            this.tableLayoutPanelPersonnelCategories.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tableLayoutPanelPersonnelCategories.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanelPersonnelCategories.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanelPersonnelCategories.Size = new System.Drawing.Size(318, 401);
            this.tableLayoutPanelPersonnelCategories.TabIndex = 0;
            // 
            // tlpPersonnelCategoriesFunctionalButtons
            // 
            this.tlpPersonnelCategoriesFunctionalButtons.ColumnCount = 2;
            this.tlpPersonnelCategoriesFunctionalButtons.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpPersonnelCategoriesFunctionalButtons.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpPersonnelCategoriesFunctionalButtons.Controls.Add(this.btnPersonnelCategoryPost, 1, 0);
            this.tlpPersonnelCategoriesFunctionalButtons.Controls.Add(this.btnPersonnelCategoryCancel, 0, 0);
            this.tlpPersonnelCategoriesFunctionalButtons.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpPersonnelCategoriesFunctionalButtons.Location = new System.Drawing.Point(3, 363);
            this.tlpPersonnelCategoriesFunctionalButtons.Name = "tlpPersonnelCategoriesFunctionalButtons";
            this.tlpPersonnelCategoriesFunctionalButtons.RowCount = 1;
            this.tlpPersonnelCategoriesFunctionalButtons.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpPersonnelCategoriesFunctionalButtons.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tlpPersonnelCategoriesFunctionalButtons.Size = new System.Drawing.Size(312, 35);
            this.tlpPersonnelCategoriesFunctionalButtons.TabIndex = 0;
            // 
            // btnPersonnelCategoryPost
            // 
            this.btnPersonnelCategoryPost.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnPersonnelCategoryPost.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnPersonnelCategoryPost.ForeColor = System.Drawing.Color.White;
            this.btnPersonnelCategoryPost.Location = new System.Drawing.Point(159, 3);
            this.btnPersonnelCategoryPost.Name = "btnPersonnelCategoryPost";
            this.btnPersonnelCategoryPost.Size = new System.Drawing.Size(150, 29);
            this.btnPersonnelCategoryPost.TabIndex = 0;
            this.btnPersonnelCategoryPost.Text = "Сохранить данные";
            this.btnPersonnelCategoryPost.UseVisualStyleBackColor = false;
            this.btnPersonnelCategoryPost.Click += new System.EventHandler(this.btnPersonnelCategoryPost_Click);
            // 
            // btnPersonnelCategoryCancel
            // 
            this.btnPersonnelCategoryCancel.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnPersonnelCategoryCancel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnPersonnelCategoryCancel.ForeColor = System.Drawing.Color.White;
            this.btnPersonnelCategoryCancel.Location = new System.Drawing.Point(3, 3);
            this.btnPersonnelCategoryCancel.Name = "btnPersonnelCategoryCancel";
            this.btnPersonnelCategoryCancel.Size = new System.Drawing.Size(150, 29);
            this.btnPersonnelCategoryCancel.TabIndex = 1;
            this.btnPersonnelCategoryCancel.Text = "Отмена";
            this.btnPersonnelCategoryCancel.UseVisualStyleBackColor = false;
            this.btnPersonnelCategoryCancel.Click += new System.EventHandler(this.btnPersonnelCategoryCancel_Click);
            // 
            // tlpPersonnelCategoryInput
            // 
            this.tlpPersonnelCategoryInput.ColumnCount = 3;
            this.tlpPersonnelCategoryInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tlpPersonnelCategoryInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tlpPersonnelCategoryInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tlpPersonnelCategoryInput.Controls.Add(this.lblPersonnelCategoryFullName, 1, 0);
            this.tlpPersonnelCategoryInput.Controls.Add(this.textBoxPersonnelCategoryFullName, 1, 1);
            this.tlpPersonnelCategoryInput.Controls.Add(this.textBoxPersonnelCategoryShortName, 1, 3);
            this.tlpPersonnelCategoryInput.Controls.Add(this.lblPersonnelCategoryShortName, 1, 2);
            this.tlpPersonnelCategoryInput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpPersonnelCategoryInput.Location = new System.Drawing.Point(3, 3);
            this.tlpPersonnelCategoryInput.Name = "tlpPersonnelCategoryInput";
            this.tlpPersonnelCategoryInput.RowCount = 5;
            this.tlpPersonnelCategoryInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tlpPersonnelCategoryInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpPersonnelCategoryInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpPersonnelCategoryInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpPersonnelCategoryInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 37.5F));
            this.tlpPersonnelCategoryInput.Size = new System.Drawing.Size(312, 354);
            this.tlpPersonnelCategoryInput.TabIndex = 4;
            // 
            // lblPersonnelCategoryFullName
            // 
            this.lblPersonnelCategoryFullName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblPersonnelCategoryFullName.AutoSize = true;
            this.lblPersonnelCategoryFullName.Location = new System.Drawing.Point(65, 121);
            this.lblPersonnelCategoryFullName.Name = "lblPersonnelCategoryFullName";
            this.lblPersonnelCategoryFullName.Size = new System.Drawing.Size(153, 20);
            this.lblPersonnelCategoryFullName.TabIndex = 1;
            this.lblPersonnelCategoryFullName.Text = "Полное наименование:";
            // 
            // textBoxPersonnelCategoryFullName
            // 
            this.textBoxPersonnelCategoryFullName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxPersonnelCategoryFullName.Location = new System.Drawing.Point(65, 144);
            this.textBoxPersonnelCategoryFullName.MaxLength = 45;
            this.textBoxPersonnelCategoryFullName.Name = "textBoxPersonnelCategoryFullName";
            this.textBoxPersonnelCategoryFullName.Size = new System.Drawing.Size(181, 25);
            this.textBoxPersonnelCategoryFullName.TabIndex = 0;
            // 
            // textBoxPersonnelCategoryShortName
            // 
            this.textBoxPersonnelCategoryShortName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxPersonnelCategoryShortName.Location = new System.Drawing.Point(65, 196);
            this.textBoxPersonnelCategoryShortName.MaxLength = 15;
            this.textBoxPersonnelCategoryShortName.Name = "textBoxPersonnelCategoryShortName";
            this.textBoxPersonnelCategoryShortName.Size = new System.Drawing.Size(181, 25);
            this.textBoxPersonnelCategoryShortName.TabIndex = 2;
            // 
            // lblPersonnelCategoryShortName
            // 
            this.lblPersonnelCategoryShortName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblPersonnelCategoryShortName.AutoSize = true;
            this.lblPersonnelCategoryShortName.Location = new System.Drawing.Point(65, 173);
            this.lblPersonnelCategoryShortName.Name = "lblPersonnelCategoryShortName";
            this.lblPersonnelCategoryShortName.Size = new System.Drawing.Size(156, 20);
            this.lblPersonnelCategoryShortName.TabIndex = 3;
            this.lblPersonnelCategoryShortName.Text = "Краткое наименование:";
            // 
            // tabPageStateHolidaysList
            // 
            this.tabPageStateHolidaysList.Controls.Add(this.tableLayoutPanelStateHolidaysList);
            this.tabPageStateHolidaysList.Location = new System.Drawing.Point(4, 25);
            this.tabPageStateHolidaysList.Name = "tabPageStateHolidaysList";
            this.tabPageStateHolidaysList.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageStateHolidaysList.Size = new System.Drawing.Size(324, 407);
            this.tabPageStateHolidaysList.TabIndex = 3;
            this.tabPageStateHolidaysList.Text = "Список выходных и празднечных дней";
            this.tabPageStateHolidaysList.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanelStateHolidaysList
            // 
            this.tableLayoutPanelStateHolidaysList.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPanelStateHolidaysList.ColumnCount = 1;
            this.tableLayoutPanelStateHolidaysList.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelStateHolidaysList.Controls.Add(this.tlpStateHolidayInput, 0, 0);
            this.tableLayoutPanelStateHolidaysList.Controls.Add(this.tlpStateHolidaysListFunctionalButtons, 0, 1);
            this.tableLayoutPanelStateHolidaysList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelStateHolidaysList.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanelStateHolidaysList.Name = "tableLayoutPanelStateHolidaysList";
            this.tableLayoutPanelStateHolidaysList.RowCount = 2;
            this.tableLayoutPanelStateHolidaysList.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tableLayoutPanelStateHolidaysList.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanelStateHolidaysList.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanelStateHolidaysList.Size = new System.Drawing.Size(318, 401);
            this.tableLayoutPanelStateHolidaysList.TabIndex = 0;
            // 
            // tlpStateHolidayInput
            // 
            this.tlpStateHolidayInput.ColumnCount = 3;
            this.tlpStateHolidayInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tlpStateHolidayInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tlpStateHolidayInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tlpStateHolidayInput.Controls.Add(this.lblStateHolidayName, 1, 0);
            this.tlpStateHolidayInput.Controls.Add(this.textBoxStateHolidayName, 1, 1);
            this.tlpStateHolidayInput.Controls.Add(this.lblStateHolidayDate, 1, 2);
            this.tlpStateHolidayInput.Controls.Add(this.dtpStateHolidayDate, 1, 3);
            this.tlpStateHolidayInput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpStateHolidayInput.Location = new System.Drawing.Point(3, 3);
            this.tlpStateHolidayInput.Name = "tlpStateHolidayInput";
            this.tlpStateHolidayInput.RowCount = 5;
            this.tlpStateHolidayInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tlpStateHolidayInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpStateHolidayInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpStateHolidayInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpStateHolidayInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 37.5F));
            this.tlpStateHolidayInput.Size = new System.Drawing.Size(312, 354);
            this.tlpStateHolidayInput.TabIndex = 5;
            // 
            // lblStateHolidayName
            // 
            this.lblStateHolidayName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblStateHolidayName.AutoSize = true;
            this.lblStateHolidayName.Location = new System.Drawing.Point(65, 121);
            this.lblStateHolidayName.Name = "lblStateHolidayName";
            this.lblStateHolidayName.Size = new System.Drawing.Size(139, 20);
            this.lblStateHolidayName.TabIndex = 1;
            this.lblStateHolidayName.Text = "Название праздника:";
            // 
            // textBoxStateHolidayName
            // 
            this.textBoxStateHolidayName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxStateHolidayName.Location = new System.Drawing.Point(65, 144);
            this.textBoxStateHolidayName.MaxLength = 45;
            this.textBoxStateHolidayName.Name = "textBoxStateHolidayName";
            this.textBoxStateHolidayName.Size = new System.Drawing.Size(181, 25);
            this.textBoxStateHolidayName.TabIndex = 0;
            // 
            // lblStateHolidayDate
            // 
            this.lblStateHolidayDate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblStateHolidayDate.AutoSize = true;
            this.lblStateHolidayDate.Location = new System.Drawing.Point(65, 173);
            this.lblStateHolidayDate.Name = "lblStateHolidayDate";
            this.lblStateHolidayDate.Size = new System.Drawing.Size(133, 20);
            this.lblStateHolidayDate.TabIndex = 2;
            this.lblStateHolidayDate.Text = "Дата празднования:";
            // 
            // dtpStateHolidayDate
            // 
            this.dtpStateHolidayDate.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dtpStateHolidayDate.Location = new System.Drawing.Point(65, 196);
            this.dtpStateHolidayDate.Name = "dtpStateHolidayDate";
            this.dtpStateHolidayDate.Size = new System.Drawing.Size(181, 25);
            this.dtpStateHolidayDate.TabIndex = 3;
            // 
            // tlpStateHolidaysListFunctionalButtons
            // 
            this.tlpStateHolidaysListFunctionalButtons.ColumnCount = 2;
            this.tlpStateHolidaysListFunctionalButtons.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpStateHolidaysListFunctionalButtons.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpStateHolidaysListFunctionalButtons.Controls.Add(this.btnStateHolidayPost, 1, 0);
            this.tlpStateHolidaysListFunctionalButtons.Controls.Add(this.btnStateHolidayCancel, 0, 0);
            this.tlpStateHolidaysListFunctionalButtons.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpStateHolidaysListFunctionalButtons.Location = new System.Drawing.Point(3, 363);
            this.tlpStateHolidaysListFunctionalButtons.Name = "tlpStateHolidaysListFunctionalButtons";
            this.tlpStateHolidaysListFunctionalButtons.RowCount = 1;
            this.tlpStateHolidaysListFunctionalButtons.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpStateHolidaysListFunctionalButtons.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tlpStateHolidaysListFunctionalButtons.Size = new System.Drawing.Size(312, 35);
            this.tlpStateHolidaysListFunctionalButtons.TabIndex = 0;
            // 
            // btnStateHolidayPost
            // 
            this.btnStateHolidayPost.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnStateHolidayPost.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnStateHolidayPost.ForeColor = System.Drawing.Color.White;
            this.btnStateHolidayPost.Location = new System.Drawing.Point(159, 3);
            this.btnStateHolidayPost.Name = "btnStateHolidayPost";
            this.btnStateHolidayPost.Size = new System.Drawing.Size(150, 29);
            this.btnStateHolidayPost.TabIndex = 0;
            this.btnStateHolidayPost.Text = "Сохранить данные";
            this.btnStateHolidayPost.UseVisualStyleBackColor = false;
            this.btnStateHolidayPost.Click += new System.EventHandler(this.btnStateHolidayPost_Click);
            // 
            // btnStateHolidayCancel
            // 
            this.btnStateHolidayCancel.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnStateHolidayCancel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnStateHolidayCancel.ForeColor = System.Drawing.Color.White;
            this.btnStateHolidayCancel.Location = new System.Drawing.Point(3, 3);
            this.btnStateHolidayCancel.Name = "btnStateHolidayCancel";
            this.btnStateHolidayCancel.Size = new System.Drawing.Size(150, 29);
            this.btnStateHolidayCancel.TabIndex = 1;
            this.btnStateHolidayCancel.Text = "Отмена";
            this.btnStateHolidayCancel.UseVisualStyleBackColor = false;
            this.btnStateHolidayCancel.Click += new System.EventHandler(this.btnStateHolidayCancel_Click);
            // 
            // OrganizationSettingsEditForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(384, 561);
            this.Controls.Add(this.tableLayoutPanel_AllForm);
            this.Name = "OrganizationSettingsEditForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "РЕДАКТОР ОРГАНИЗАЦ. НАСТРОЕК";
            this.tableLayoutPanel_AllForm.ResumeLayout(false);
            this.tableLayoutPanel_Company.ResumeLayout(false);
            this.tableLayoutPanel_Company.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCompany)).EndInit();
            this.tableLayoutPanelWorkingField.ResumeLayout(false);
            this.tabControlOrganizationSettingsEdit.ResumeLayout(false);
            this.tabPageCompanyInformation.ResumeLayout(false);
            this.tableLayoutPanelCompanyInformation.ResumeLayout(false);
            this.tlpCompanyInformInput.ResumeLayout(false);
            this.tlpCompanyInformInput.PerformLayout();
            this.tlpCompanyInformationFunctionalButtons.ResumeLayout(false);
            this.tabPageHierarchyLevels.ResumeLayout(false);
            this.tableLayoutPanelHierarchyLevels.ResumeLayout(false);
            this.tlpHierarchyLevelsFunctionalButtons.ResumeLayout(false);
            this.tlpHierarhyInput.ResumeLayout(false);
            this.tlpHierarhyInput.PerformLayout();
            this.tabPageFunctions.ResumeLayout(false);
            this.tableLayoutPanelFunctions.ResumeLayout(false);
            this.tlpFunctionInput.ResumeLayout(false);
            this.tlpFunctionInput.PerformLayout();
            this.tlpFunctionsFunctionalButtons.ResumeLayout(false);
            this.tabPagePersonnelCategories.ResumeLayout(false);
            this.tableLayoutPanelPersonnelCategories.ResumeLayout(false);
            this.tlpPersonnelCategoriesFunctionalButtons.ResumeLayout(false);
            this.tlpPersonnelCategoryInput.ResumeLayout(false);
            this.tlpPersonnelCategoryInput.PerformLayout();
            this.tabPageStateHolidaysList.ResumeLayout(false);
            this.tableLayoutPanelStateHolidaysList.ResumeLayout(false);
            this.tlpStateHolidayInput.ResumeLayout(false);
            this.tlpStateHolidayInput.PerformLayout();
            this.tlpStateHolidaysListFunctionalButtons.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_AllForm;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Company;
        private System.Windows.Forms.PictureBox pictureBoxCompany;
        private System.Windows.Forms.Label lblCompany;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelWorkingField;
        private System.Windows.Forms.TabControl tabControlOrganizationSettingsEdit;
        private System.Windows.Forms.TabPage tabPageCompanyInformation;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelCompanyInformation;
        private System.Windows.Forms.TabPage tabPageHierarchyLevels;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelHierarchyLevels;
        private System.Windows.Forms.TabPage tabPageFunctions;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelFunctions;
        private System.Windows.Forms.TabPage tabPagePersonnelCategories;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelPersonnelCategories;
        private System.Windows.Forms.TabPage tabPageStateHolidaysList;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelStateHolidaysList;
        private System.Windows.Forms.TableLayoutPanel tlpCompanyInformationFunctionalButtons;
        private System.Windows.Forms.Button btnCompanyInformationPost;
        private System.Windows.Forms.Button btnCompanyInformationCancel;
        private System.Windows.Forms.TableLayoutPanel tlpHierarchyLevelsFunctionalButtons;
        private System.Windows.Forms.Button btnHierarchyLevelPost;
        private System.Windows.Forms.Button btnHierarchyLevelCancel;
        private System.Windows.Forms.TableLayoutPanel tlpFunctionsFunctionalButtons;
        private System.Windows.Forms.Button btnFunctionPost;
        private System.Windows.Forms.Button btnFunctionCancel;
        private System.Windows.Forms.TableLayoutPanel tlpPersonnelCategoriesFunctionalButtons;
        private System.Windows.Forms.Button btnPersonnelCategoryPost;
        private System.Windows.Forms.Button btnPersonnelCategoryCancel;
        private System.Windows.Forms.TableLayoutPanel tlpStateHolidaysListFunctionalButtons;
        private System.Windows.Forms.Button btnStateHolidayPost;
        private System.Windows.Forms.Button btnStateHolidayCancel;
        private System.Windows.Forms.TableLayoutPanel tlpHierarhyInput;
        private System.Windows.Forms.TextBox textBoxHierarchyName;
        private System.Windows.Forms.Label lblHierarchyName;
        private System.Windows.Forms.TableLayoutPanel tlpFunctionInput;
        private System.Windows.Forms.TextBox textBoxFunctionName;
        private System.Windows.Forms.Label lblFunctionName;
        private System.Windows.Forms.TableLayoutPanel tlpPersonnelCategoryInput;
        private System.Windows.Forms.TextBox textBoxPersonnelCategoryFullName;
        private System.Windows.Forms.Label lblPersonnelCategoryFullName;
        private System.Windows.Forms.TableLayoutPanel tlpStateHolidayInput;
        private System.Windows.Forms.Label lblStateHolidayName;
        private System.Windows.Forms.TextBox textBoxStateHolidayName;
        private System.Windows.Forms.Label lblStateHolidayDate;
        private System.Windows.Forms.DateTimePicker dtpStateHolidayDate;
        private System.Windows.Forms.TableLayoutPanel tlpCompanyInformInput;
        private System.Windows.Forms.TextBox textBoxShortTitle;
        private System.Windows.Forms.TextBox textBoxPersonnelCategoryShortName;
        private System.Windows.Forms.Label lblPersonnelCategoryShortName;
        private System.Windows.Forms.Label lblLegaLAddress;
        private System.Windows.Forms.Label lblFullTitle;
        private System.Windows.Forms.Label lblOKPO;
        private System.Windows.Forms.Label lblKPP;
        private System.Windows.Forms.Label lblINN;
        private System.Windows.Forms.Label lblActualAddress;
        private System.Windows.Forms.Label lblShortTitle;
        private System.Windows.Forms.TextBox textBoxINN;
        private System.Windows.Forms.TextBox textBoxKPP;
        private System.Windows.Forms.TextBox textBoxOKPO;
        private System.Windows.Forms.TextBox textBoxFullTitle;
        private System.Windows.Forms.TextBox textBoxLegalAddress;
        private System.Windows.Forms.TextBox textBoxActualAddress;
    }
}