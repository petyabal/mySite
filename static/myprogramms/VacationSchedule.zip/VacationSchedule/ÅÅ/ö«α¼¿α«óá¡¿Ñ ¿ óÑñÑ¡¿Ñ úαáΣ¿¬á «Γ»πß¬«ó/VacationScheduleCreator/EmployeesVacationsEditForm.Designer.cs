﻿namespace VacationScheduleCreator
{
    partial class EmployeesVacationsEditForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EmployeesVacationsEditForm));
            this.tableLayoutPanel_AllForm = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel_EditField = new System.Windows.Forms.TableLayoutPanel();
            this.tabControlEmployeesVacationsEdit = new System.Windows.Forms.TabControl();
            this.tabPageEmployeesVacation = new System.Windows.Forms.TabPage();
            this.tlpEmployeesVacations = new System.Windows.Forms.TableLayoutPanel();
            this.tlpStaffingTableFunctionalButtons = new System.Windows.Forms.TableLayoutPanel();
            this.btnEmployeesVacationsCancel = new System.Windows.Forms.Button();
            this.btnEmployeesVacationsPost = new System.Windows.Forms.Button();
            this.tlpEmployeesVacationsInput = new System.Windows.Forms.TableLayoutPanel();
            this.lBlPersonnel = new System.Windows.Forms.Label();
            this.lblVacationStart = new System.Windows.Forms.Label();
            this.lblVacationFinish = new System.Windows.Forms.Label();
            this.lblDaysQuantity = new System.Windows.Forms.Label();
            this.lblDaysRemain = new System.Windows.Forms.Label();
            this.lblTypeOfVacation = new System.Windows.Forms.Label();
            this.textBoxDaysRamain = new System.Windows.Forms.TextBox();
            this.comboBoxPersonnel = new System.Windows.Forms.ComboBox();
            this.comboBoxVacationType = new System.Windows.Forms.ComboBox();
            this.textBoxDaysQuantity = new System.Windows.Forms.TextBox();
            this.dtpVacationStart = new System.Windows.Forms.DateTimePicker();
            this.dtpVacationFinish = new System.Windows.Forms.DateTimePicker();
            this.tabPageVacationSchedulesList = new System.Windows.Forms.TabPage();
            this.tlpStaffingTables = new System.Windows.Forms.TableLayoutPanel();
            this.tlpVacationSchedulesInput = new System.Windows.Forms.TableLayoutPanel();
            this.lblStructuralUnit = new System.Windows.Forms.Label();
            this.comboBoxStructuralUnit = new System.Windows.Forms.ComboBox();
            this.dtpApprovementDate = new System.Windows.Forms.DateTimePicker();
            this.lblApprovementDate = new System.Windows.Forms.Label();
            this.comboBoxApprovedBy = new System.Windows.Forms.ComboBox();
            this.lblApprovedBy = new System.Windows.Forms.Label();
            this.comboBoxApproved = new System.Windows.Forms.ComboBox();
            this.lblApproved = new System.Windows.Forms.Label();
            this.lblYear = new System.Windows.Forms.Label();
            this.textBoxYear = new System.Windows.Forms.TextBox();
            this.lblTitleVacationSchedule = new System.Windows.Forms.Label();
            this.textBoxVacationScheduleTitle = new System.Windows.Forms.TextBox();
            this.labelCreated = new System.Windows.Forms.Label();
            this.dtpCreated = new System.Windows.Forms.DateTimePicker();
            this.btnYearMinus = new System.Windows.Forms.Button();
            this.btnYearPlus = new System.Windows.Forms.Button();
            this.tlpStaffingTablesButtons = new System.Windows.Forms.TableLayoutPanel();
            this.btnVacationSchedulesPost = new System.Windows.Forms.Button();
            this.btnVacationSchedulesCancel = new System.Windows.Forms.Button();
            this.tabPageVacationType = new System.Windows.Forms.TabPage();
            this.tlpVacationTypes = new System.Windows.Forms.TableLayoutPanel();
            this.tlpVacationTypesInput = new System.Windows.Forms.TableLayoutPanel();
            this.btnUnpaidDaysPlus = new System.Windows.Forms.Button();
            this.btnUnpaidDaysMinus = new System.Windows.Forms.Button();
            this.btnPaidDaysPlus = new System.Windows.Forms.Button();
            this.lblVacationType = new System.Windows.Forms.Label();
            this.textBoxVacationType = new System.Windows.Forms.TextBox();
            this.lblPaidDays = new System.Windows.Forms.Label();
            this.lblUnpaidDays = new System.Windows.Forms.Label();
            this.textBoxPaidDays = new System.Windows.Forms.TextBox();
            this.textBoxUnpaidDays = new System.Windows.Forms.TextBox();
            this.btnPaidDaysMinus = new System.Windows.Forms.Button();
            this.tlpStructuralUnitsFunctionalButtons = new System.Windows.Forms.TableLayoutPanel();
            this.btnVacationTypePost = new System.Windows.Forms.Button();
            this.btnVacationTypeCancel = new System.Windows.Forms.Button();
            this.tabPageSpendingOfVacations = new System.Windows.Forms.TabPage();
            this.tlpSpendingOfVacations = new System.Windows.Forms.TableLayoutPanel();
            this.tlpSpendingOfVacationsFunctionalButtons = new System.Windows.Forms.TableLayoutPanel();
            this.btnSpendingOfVacationPost = new System.Windows.Forms.Button();
            this.btnSpendingOfVacationCancel = new System.Windows.Forms.Button();
            this.tlpSpendingOfVacationsInput = new System.Windows.Forms.TableLayoutPanel();
            this.buttonVacationMinus = new System.Windows.Forms.Button();
            this.buttonVacationPlus = new System.Windows.Forms.Button();
            this.buttonPlus = new System.Windows.Forms.Button();
            this.buttonYearMinus = new System.Windows.Forms.Button();
            this.lblVacationict = new System.Windows.Forms.Label();
            this.comboBoxVacationist = new System.Windows.Forms.ComboBox();
            this.lblTipeOfVacation = new System.Windows.Forms.Label();
            this.comboBoxTypeOfVacation = new System.Windows.Forms.ComboBox();
            this.textBoxVacationYear = new System.Windows.Forms.TextBox();
            this.lblVacationYear = new System.Windows.Forms.Label();
            this.labelVacationDays = new System.Windows.Forms.Label();
            this.textBoxVacationDays = new System.Windows.Forms.TextBox();
            this.tabPageEmployeesPaidTravel = new System.Windows.Forms.TabPage();
            this.tableLayoutPanelEmployeesPaidDays = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanelEmployeesPaidTravelInput = new System.Windows.Forms.TableLayoutPanel();
            this.lblTraveler = new System.Windows.Forms.Label();
            this.lblTransitStart = new System.Windows.Forms.Label();
            this.lblTransitFinish = new System.Windows.Forms.Label();
            this.comboBoxTraveler = new System.Windows.Forms.ComboBox();
            this.dtpTransitStart = new System.Windows.Forms.DateTimePicker();
            this.dtpTransitFinish = new System.Windows.Forms.DateTimePicker();
            this.tableLayoutPanelEmployeesPaidTravelFunctionalButtons = new System.Windows.Forms.TableLayoutPanel();
            this.btnEmployeesPaidTravelPost = new System.Windows.Forms.Button();
            this.btnEmployeesPaidTravelCancel = new System.Windows.Forms.Button();
            this.tabPageVacationLog = new System.Windows.Forms.TabPage();
            this.tableLayoutPanelVacationLog = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanelVacationLogFunctionalButtons = new System.Windows.Forms.TableLayoutPanel();
            this.btnVacationLogCancel = new System.Windows.Forms.Button();
            this.btnVacationLogPost = new System.Windows.Forms.Button();
            this.tableLayoutPanelVacationLogInput = new System.Windows.Forms.TableLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxRealDaysRemain = new System.Windows.Forms.TextBox();
            this.comboBoxRealPersonnel = new System.Windows.Forms.ComboBox();
            this.comboBoxRealVacationType = new System.Windows.Forms.ComboBox();
            this.textBoxRealDaysQuantity = new System.Windows.Forms.TextBox();
            this.dtpRealVacationStart = new System.Windows.Forms.DateTimePicker();
            this.dtpRealVacationFinish = new System.Windows.Forms.DateTimePicker();
            this.tableLayoutPanel_Company = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBoxCompany = new System.Windows.Forms.PictureBox();
            this.lblCompany = new System.Windows.Forms.Label();
            this.tableLayoutPanel_AllForm.SuspendLayout();
            this.tableLayoutPanel_EditField.SuspendLayout();
            this.tabControlEmployeesVacationsEdit.SuspendLayout();
            this.tabPageEmployeesVacation.SuspendLayout();
            this.tlpEmployeesVacations.SuspendLayout();
            this.tlpStaffingTableFunctionalButtons.SuspendLayout();
            this.tlpEmployeesVacationsInput.SuspendLayout();
            this.tabPageVacationSchedulesList.SuspendLayout();
            this.tlpStaffingTables.SuspendLayout();
            this.tlpVacationSchedulesInput.SuspendLayout();
            this.tlpStaffingTablesButtons.SuspendLayout();
            this.tabPageVacationType.SuspendLayout();
            this.tlpVacationTypes.SuspendLayout();
            this.tlpVacationTypesInput.SuspendLayout();
            this.tlpStructuralUnitsFunctionalButtons.SuspendLayout();
            this.tabPageSpendingOfVacations.SuspendLayout();
            this.tlpSpendingOfVacations.SuspendLayout();
            this.tlpSpendingOfVacationsFunctionalButtons.SuspendLayout();
            this.tlpSpendingOfVacationsInput.SuspendLayout();
            this.tabPageEmployeesPaidTravel.SuspendLayout();
            this.tableLayoutPanelEmployeesPaidDays.SuspendLayout();
            this.tableLayoutPanelEmployeesPaidTravelInput.SuspendLayout();
            this.tableLayoutPanelEmployeesPaidTravelFunctionalButtons.SuspendLayout();
            this.tabPageVacationLog.SuspendLayout();
            this.tableLayoutPanelVacationLog.SuspendLayout();
            this.tableLayoutPanelVacationLogFunctionalButtons.SuspendLayout();
            this.tableLayoutPanelVacationLogInput.SuspendLayout();
            this.tableLayoutPanel_Company.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCompany)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel_AllForm
            // 
            this.tableLayoutPanel_AllForm.ColumnCount = 1;
            this.tableLayoutPanel_AllForm.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_AllForm.Controls.Add(this.tableLayoutPanel_EditField, 0, 1);
            this.tableLayoutPanel_AllForm.Controls.Add(this.tableLayoutPanel_Company, 0, 0);
            this.tableLayoutPanel_AllForm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_AllForm.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel_AllForm.Name = "tableLayoutPanel_AllForm";
            this.tableLayoutPanel_AllForm.RowCount = 2;
            this.tableLayoutPanel_AllForm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel_AllForm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tableLayoutPanel_AllForm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel_AllForm.Size = new System.Drawing.Size(384, 561);
            this.tableLayoutPanel_AllForm.TabIndex = 4;
            // 
            // tableLayoutPanel_EditField
            // 
            this.tableLayoutPanel_EditField.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPanel_EditField.ColumnCount = 1;
            this.tableLayoutPanel_EditField.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_EditField.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel_EditField.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel_EditField.Controls.Add(this.tabControlEmployeesVacationsEdit, 0, 0);
            this.tableLayoutPanel_EditField.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_EditField.Location = new System.Drawing.Point(3, 59);
            this.tableLayoutPanel_EditField.Name = "tableLayoutPanel_EditField";
            this.tableLayoutPanel_EditField.RowCount = 1;
            this.tableLayoutPanel_EditField.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tableLayoutPanel_EditField.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel_EditField.Size = new System.Drawing.Size(378, 499);
            this.tableLayoutPanel_EditField.TabIndex = 9;
            // 
            // tabControlEmployeesVacationsEdit
            // 
            this.tabControlEmployeesVacationsEdit.Controls.Add(this.tabPageEmployeesVacation);
            this.tabControlEmployeesVacationsEdit.Controls.Add(this.tabPageVacationSchedulesList);
            this.tabControlEmployeesVacationsEdit.Controls.Add(this.tabPageVacationType);
            this.tabControlEmployeesVacationsEdit.Controls.Add(this.tabPageSpendingOfVacations);
            this.tabControlEmployeesVacationsEdit.Controls.Add(this.tabPageEmployeesPaidTravel);
            this.tabControlEmployeesVacationsEdit.Controls.Add(this.tabPageVacationLog);
            this.tabControlEmployeesVacationsEdit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlEmployeesVacationsEdit.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tabControlEmployeesVacationsEdit.Location = new System.Drawing.Point(3, 3);
            this.tabControlEmployeesVacationsEdit.Name = "tabControlEmployeesVacationsEdit";
            this.tabControlEmployeesVacationsEdit.SelectedIndex = 0;
            this.tabControlEmployeesVacationsEdit.Size = new System.Drawing.Size(372, 493);
            this.tabControlEmployeesVacationsEdit.TabIndex = 0;
            // 
            // tabPageEmployeesVacation
            // 
            this.tabPageEmployeesVacation.Controls.Add(this.tlpEmployeesVacations);
            this.tabPageEmployeesVacation.Location = new System.Drawing.Point(4, 29);
            this.tabPageEmployeesVacation.Name = "tabPageEmployeesVacation";
            this.tabPageEmployeesVacation.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageEmployeesVacation.Size = new System.Drawing.Size(364, 460);
            this.tabPageEmployeesVacation.TabIndex = 0;
            this.tabPageEmployeesVacation.Text = "Отпуска сотрудников";
            this.tabPageEmployeesVacation.UseVisualStyleBackColor = true;
            // 
            // tlpEmployeesVacations
            // 
            this.tlpEmployeesVacations.BackColor = System.Drawing.Color.Tan;
            this.tlpEmployeesVacations.ColumnCount = 1;
            this.tlpEmployeesVacations.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpEmployeesVacations.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tlpEmployeesVacations.Controls.Add(this.tlpStaffingTableFunctionalButtons, 0, 1);
            this.tlpEmployeesVacations.Controls.Add(this.tlpEmployeesVacationsInput, 0, 0);
            this.tlpEmployeesVacations.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpEmployeesVacations.Location = new System.Drawing.Point(3, 3);
            this.tlpEmployeesVacations.Name = "tlpEmployeesVacations";
            this.tlpEmployeesVacations.RowCount = 2;
            this.tlpEmployeesVacations.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tlpEmployeesVacations.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tlpEmployeesVacations.Size = new System.Drawing.Size(358, 454);
            this.tlpEmployeesVacations.TabIndex = 2;
            // 
            // tlpStaffingTableFunctionalButtons
            // 
            this.tlpStaffingTableFunctionalButtons.ColumnCount = 2;
            this.tlpStaffingTableFunctionalButtons.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpStaffingTableFunctionalButtons.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpStaffingTableFunctionalButtons.Controls.Add(this.btnEmployeesVacationsCancel, 0, 0);
            this.tlpStaffingTableFunctionalButtons.Controls.Add(this.btnEmployeesVacationsPost, 1, 0);
            this.tlpStaffingTableFunctionalButtons.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpStaffingTableFunctionalButtons.Location = new System.Drawing.Point(3, 411);
            this.tlpStaffingTableFunctionalButtons.Name = "tlpStaffingTableFunctionalButtons";
            this.tlpStaffingTableFunctionalButtons.RowCount = 1;
            this.tlpStaffingTableFunctionalButtons.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpStaffingTableFunctionalButtons.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tlpStaffingTableFunctionalButtons.Size = new System.Drawing.Size(352, 40);
            this.tlpStaffingTableFunctionalButtons.TabIndex = 17;
            // 
            // btnEmployeesVacationsCancel
            // 
            this.btnEmployeesVacationsCancel.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnEmployeesVacationsCancel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnEmployeesVacationsCancel.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnEmployeesVacationsCancel.ForeColor = System.Drawing.Color.White;
            this.btnEmployeesVacationsCancel.Location = new System.Drawing.Point(3, 3);
            this.btnEmployeesVacationsCancel.Name = "btnEmployeesVacationsCancel";
            this.btnEmployeesVacationsCancel.Size = new System.Drawing.Size(170, 34);
            this.btnEmployeesVacationsCancel.TabIndex = 13;
            this.btnEmployeesVacationsCancel.Text = "Отмена";
            this.btnEmployeesVacationsCancel.UseVisualStyleBackColor = false;
            this.btnEmployeesVacationsCancel.Click += new System.EventHandler(this.btnEmployeesVacationsCancel_Click);
            // 
            // btnEmployeesVacationsPost
            // 
            this.btnEmployeesVacationsPost.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnEmployeesVacationsPost.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnEmployeesVacationsPost.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnEmployeesVacationsPost.ForeColor = System.Drawing.Color.White;
            this.btnEmployeesVacationsPost.Location = new System.Drawing.Point(179, 3);
            this.btnEmployeesVacationsPost.Name = "btnEmployeesVacationsPost";
            this.btnEmployeesVacationsPost.Size = new System.Drawing.Size(170, 34);
            this.btnEmployeesVacationsPost.TabIndex = 15;
            this.btnEmployeesVacationsPost.Text = "Сохранить данные";
            this.btnEmployeesVacationsPost.UseVisualStyleBackColor = false;
            this.btnEmployeesVacationsPost.Click += new System.EventHandler(this.btnEmployeesVacationsPost_Click);
            // 
            // tlpEmployeesVacationsInput
            // 
            this.tlpEmployeesVacationsInput.BackColor = System.Drawing.Color.Tan;
            this.tlpEmployeesVacationsInput.ColumnCount = 3;
            this.tlpEmployeesVacationsInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36F));
            this.tlpEmployeesVacationsInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 58F));
            this.tlpEmployeesVacationsInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6F));
            this.tlpEmployeesVacationsInput.Controls.Add(this.lBlPersonnel, 0, 1);
            this.tlpEmployeesVacationsInput.Controls.Add(this.lblVacationStart, 0, 3);
            this.tlpEmployeesVacationsInput.Controls.Add(this.lblVacationFinish, 0, 4);
            this.tlpEmployeesVacationsInput.Controls.Add(this.lblDaysQuantity, 0, 5);
            this.tlpEmployeesVacationsInput.Controls.Add(this.lblDaysRemain, 0, 6);
            this.tlpEmployeesVacationsInput.Controls.Add(this.lblTypeOfVacation, 0, 2);
            this.tlpEmployeesVacationsInput.Controls.Add(this.textBoxDaysRamain, 1, 6);
            this.tlpEmployeesVacationsInput.Controls.Add(this.comboBoxPersonnel, 1, 1);
            this.tlpEmployeesVacationsInput.Controls.Add(this.comboBoxVacationType, 1, 2);
            this.tlpEmployeesVacationsInput.Controls.Add(this.textBoxDaysQuantity, 1, 5);
            this.tlpEmployeesVacationsInput.Controls.Add(this.dtpVacationStart, 1, 3);
            this.tlpEmployeesVacationsInput.Controls.Add(this.dtpVacationFinish, 1, 4);
            this.tlpEmployeesVacationsInput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpEmployeesVacationsInput.Location = new System.Drawing.Point(3, 3);
            this.tlpEmployeesVacationsInput.Name = "tlpEmployeesVacationsInput";
            this.tlpEmployeesVacationsInput.RowCount = 8;
            this.tlpEmployeesVacationsInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tlpEmployeesVacationsInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tlpEmployeesVacationsInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tlpEmployeesVacationsInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tlpEmployeesVacationsInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tlpEmployeesVacationsInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tlpEmployeesVacationsInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tlpEmployeesVacationsInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tlpEmployeesVacationsInput.Size = new System.Drawing.Size(352, 402);
            this.tlpEmployeesVacationsInput.TabIndex = 2;
            // 
            // lBlPersonnel
            // 
            this.lBlPersonnel.AutoSize = true;
            this.lBlPersonnel.BackColor = System.Drawing.Color.Transparent;
            this.lBlPersonnel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lBlPersonnel.ForeColor = System.Drawing.Color.Black;
            this.lBlPersonnel.Location = new System.Drawing.Point(3, 80);
            this.lBlPersonnel.Name = "lBlPersonnel";
            this.lBlPersonnel.Size = new System.Drawing.Size(120, 40);
            this.lBlPersonnel.TabIndex = 0;
            this.lBlPersonnel.Text = "Сотрудник:";
            this.lBlPersonnel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblVacationStart
            // 
            this.lblVacationStart.AutoSize = true;
            this.lblVacationStart.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblVacationStart.ForeColor = System.Drawing.Color.Black;
            this.lblVacationStart.Location = new System.Drawing.Point(3, 160);
            this.lblVacationStart.Name = "lblVacationStart";
            this.lblVacationStart.Size = new System.Drawing.Size(120, 40);
            this.lblVacationStart.TabIndex = 3;
            this.lblVacationStart.Text = "Начало отпуска:";
            this.lblVacationStart.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblVacationFinish
            // 
            this.lblVacationFinish.AutoSize = true;
            this.lblVacationFinish.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblVacationFinish.ForeColor = System.Drawing.Color.Black;
            this.lblVacationFinish.Location = new System.Drawing.Point(3, 200);
            this.lblVacationFinish.Name = "lblVacationFinish";
            this.lblVacationFinish.Size = new System.Drawing.Size(120, 40);
            this.lblVacationFinish.TabIndex = 4;
            this.lblVacationFinish.Text = "Конец отпуска:";
            this.lblVacationFinish.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblDaysQuantity
            // 
            this.lblDaysQuantity.AutoSize = true;
            this.lblDaysQuantity.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblDaysQuantity.ForeColor = System.Drawing.Color.Black;
            this.lblDaysQuantity.Location = new System.Drawing.Point(3, 240);
            this.lblDaysQuantity.Name = "lblDaysQuantity";
            this.lblDaysQuantity.Size = new System.Drawing.Size(120, 40);
            this.lblDaysQuantity.TabIndex = 6;
            this.lblDaysQuantity.Text = "Число дней:";
            this.lblDaysQuantity.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblDaysRemain
            // 
            this.lblDaysRemain.AutoSize = true;
            this.lblDaysRemain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblDaysRemain.ForeColor = System.Drawing.Color.Black;
            this.lblDaysRemain.Location = new System.Drawing.Point(3, 280);
            this.lblDaysRemain.Name = "lblDaysRemain";
            this.lblDaysRemain.Size = new System.Drawing.Size(120, 40);
            this.lblDaysRemain.TabIndex = 5;
            this.lblDaysRemain.Text = "Осталось дней:";
            this.lblDaysRemain.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblTypeOfVacation
            // 
            this.lblTypeOfVacation.AutoSize = true;
            this.lblTypeOfVacation.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTypeOfVacation.ForeColor = System.Drawing.Color.Black;
            this.lblTypeOfVacation.Location = new System.Drawing.Point(3, 120);
            this.lblTypeOfVacation.Name = "lblTypeOfVacation";
            this.lblTypeOfVacation.Size = new System.Drawing.Size(120, 40);
            this.lblTypeOfVacation.TabIndex = 14;
            this.lblTypeOfVacation.Text = "Вид отпуска:";
            this.lblTypeOfVacation.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBoxDaysRamain
            // 
            this.textBoxDaysRamain.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxDaysRamain.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxDaysRamain.Location = new System.Drawing.Point(129, 287);
            this.textBoxDaysRamain.Name = "textBoxDaysRamain";
            this.textBoxDaysRamain.ReadOnly = true;
            this.textBoxDaysRamain.Size = new System.Drawing.Size(198, 25);
            this.textBoxDaysRamain.TabIndex = 25;
            this.textBoxDaysRamain.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // comboBoxPersonnel
            // 
            this.comboBoxPersonnel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBoxPersonnel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxPersonnel.Enabled = false;
            this.comboBoxPersonnel.FormattingEnabled = true;
            this.comboBoxPersonnel.Location = new System.Drawing.Point(129, 89);
            this.comboBoxPersonnel.Name = "comboBoxPersonnel";
            this.comboBoxPersonnel.Size = new System.Drawing.Size(198, 28);
            this.comboBoxPersonnel.TabIndex = 28;
            // 
            // comboBoxVacationType
            // 
            this.comboBoxVacationType.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBoxVacationType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxVacationType.Enabled = false;
            this.comboBoxVacationType.FormattingEnabled = true;
            this.comboBoxVacationType.Location = new System.Drawing.Point(129, 129);
            this.comboBoxVacationType.Name = "comboBoxVacationType";
            this.comboBoxVacationType.Size = new System.Drawing.Size(198, 28);
            this.comboBoxVacationType.TabIndex = 19;
            // 
            // textBoxDaysQuantity
            // 
            this.textBoxDaysQuantity.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxDaysQuantity.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxDaysQuantity.Location = new System.Drawing.Point(129, 247);
            this.textBoxDaysQuantity.Name = "textBoxDaysQuantity";
            this.textBoxDaysQuantity.ReadOnly = true;
            this.textBoxDaysQuantity.Size = new System.Drawing.Size(198, 25);
            this.textBoxDaysQuantity.TabIndex = 29;
            this.textBoxDaysQuantity.Text = "1";
            this.textBoxDaysQuantity.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // dtpVacationStart
            // 
            this.dtpVacationStart.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.dtpVacationStart.Location = new System.Drawing.Point(129, 167);
            this.dtpVacationStart.Name = "dtpVacationStart";
            this.dtpVacationStart.Size = new System.Drawing.Size(198, 25);
            this.dtpVacationStart.TabIndex = 21;
            this.dtpVacationStart.ValueChanged += new System.EventHandler(this.dtpVacationStart_ValueChanged);
            // 
            // dtpVacationFinish
            // 
            this.dtpVacationFinish.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.dtpVacationFinish.Location = new System.Drawing.Point(129, 207);
            this.dtpVacationFinish.Name = "dtpVacationFinish";
            this.dtpVacationFinish.Size = new System.Drawing.Size(198, 25);
            this.dtpVacationFinish.TabIndex = 20;
            this.dtpVacationFinish.ValueChanged += new System.EventHandler(this.dtpVacationFinish_ValueChanged);
            // 
            // tabPageVacationSchedulesList
            // 
            this.tabPageVacationSchedulesList.Controls.Add(this.tlpStaffingTables);
            this.tabPageVacationSchedulesList.Location = new System.Drawing.Point(4, 29);
            this.tabPageVacationSchedulesList.Name = "tabPageVacationSchedulesList";
            this.tabPageVacationSchedulesList.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageVacationSchedulesList.Size = new System.Drawing.Size(364, 460);
            this.tabPageVacationSchedulesList.TabIndex = 1;
            this.tabPageVacationSchedulesList.Text = "Графики отпусков";
            this.tabPageVacationSchedulesList.UseVisualStyleBackColor = true;
            // 
            // tlpStaffingTables
            // 
            this.tlpStaffingTables.BackColor = System.Drawing.Color.Tan;
            this.tlpStaffingTables.ColumnCount = 1;
            this.tlpStaffingTables.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpStaffingTables.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tlpStaffingTables.Controls.Add(this.tlpVacationSchedulesInput, 0, 0);
            this.tlpStaffingTables.Controls.Add(this.tlpStaffingTablesButtons, 0, 1);
            this.tlpStaffingTables.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpStaffingTables.Location = new System.Drawing.Point(3, 3);
            this.tlpStaffingTables.Name = "tlpStaffingTables";
            this.tlpStaffingTables.RowCount = 2;
            this.tlpStaffingTables.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tlpStaffingTables.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tlpStaffingTables.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tlpStaffingTables.Size = new System.Drawing.Size(358, 454);
            this.tlpStaffingTables.TabIndex = 0;
            // 
            // tlpVacationSchedulesInput
            // 
            this.tlpVacationSchedulesInput.ColumnCount = 5;
            this.tlpVacationSchedulesInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36F));
            this.tlpVacationSchedulesInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tlpVacationSchedulesInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 38F));
            this.tlpVacationSchedulesInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tlpVacationSchedulesInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6F));
            this.tlpVacationSchedulesInput.Controls.Add(this.lblStructuralUnit, 0, 7);
            this.tlpVacationSchedulesInput.Controls.Add(this.comboBoxStructuralUnit, 1, 7);
            this.tlpVacationSchedulesInput.Controls.Add(this.dtpApprovementDate, 1, 6);
            this.tlpVacationSchedulesInput.Controls.Add(this.lblApprovementDate, 0, 6);
            this.tlpVacationSchedulesInput.Controls.Add(this.comboBoxApprovedBy, 1, 5);
            this.tlpVacationSchedulesInput.Controls.Add(this.lblApprovedBy, 0, 5);
            this.tlpVacationSchedulesInput.Controls.Add(this.comboBoxApproved, 1, 4);
            this.tlpVacationSchedulesInput.Controls.Add(this.lblApproved, 0, 4);
            this.tlpVacationSchedulesInput.Controls.Add(this.lblYear, 0, 3);
            this.tlpVacationSchedulesInput.Controls.Add(this.textBoxYear, 2, 3);
            this.tlpVacationSchedulesInput.Controls.Add(this.lblTitleVacationSchedule, 0, 2);
            this.tlpVacationSchedulesInput.Controls.Add(this.textBoxVacationScheduleTitle, 1, 2);
            this.tlpVacationSchedulesInput.Controls.Add(this.labelCreated, 0, 1);
            this.tlpVacationSchedulesInput.Controls.Add(this.dtpCreated, 1, 1);
            this.tlpVacationSchedulesInput.Controls.Add(this.btnYearMinus, 1, 3);
            this.tlpVacationSchedulesInput.Controls.Add(this.btnYearPlus, 3, 3);
            this.tlpVacationSchedulesInput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpVacationSchedulesInput.Location = new System.Drawing.Point(3, 3);
            this.tlpVacationSchedulesInput.Name = "tlpVacationSchedulesInput";
            this.tlpVacationSchedulesInput.RowCount = 9;
            this.tlpVacationSchedulesInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tlpVacationSchedulesInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpVacationSchedulesInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpVacationSchedulesInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpVacationSchedulesInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpVacationSchedulesInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpVacationSchedulesInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpVacationSchedulesInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpVacationSchedulesInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 22.5F));
            this.tlpVacationSchedulesInput.Size = new System.Drawing.Size(352, 402);
            this.tlpVacationSchedulesInput.TabIndex = 10;
            // 
            // lblStructuralUnit
            // 
            this.lblStructuralUnit.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblStructuralUnit.AutoSize = true;
            this.lblStructuralUnit.Location = new System.Drawing.Point(12, 285);
            this.lblStructuralUnit.Name = "lblStructuralUnit";
            this.lblStructuralUnit.Size = new System.Drawing.Size(111, 20);
            this.lblStructuralUnit.TabIndex = 13;
            this.lblStructuralUnit.Text = "Подразделение:";
            this.lblStructuralUnit.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // comboBoxStructuralUnit
            // 
            this.comboBoxStructuralUnit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.tlpVacationSchedulesInput.SetColumnSpan(this.comboBoxStructuralUnit, 3);
            this.comboBoxStructuralUnit.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxStructuralUnit.FormattingEnabled = true;
            this.comboBoxStructuralUnit.Location = new System.Drawing.Point(129, 281);
            this.comboBoxStructuralUnit.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.comboBoxStructuralUnit.Name = "comboBoxStructuralUnit";
            this.comboBoxStructuralUnit.Size = new System.Drawing.Size(197, 28);
            this.comboBoxStructuralUnit.TabIndex = 14;
            // 
            // dtpApprovementDate
            // 
            this.dtpApprovementDate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.tlpVacationSchedulesInput.SetColumnSpan(this.dtpApprovementDate, 3);
            this.dtpApprovementDate.Location = new System.Drawing.Point(129, 253);
            this.dtpApprovementDate.Name = "dtpApprovementDate";
            this.dtpApprovementDate.Size = new System.Drawing.Size(197, 25);
            this.dtpApprovementDate.TabIndex = 11;
            // 
            // lblApprovementDate
            // 
            this.lblApprovementDate.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblApprovementDate.AutoSize = true;
            this.lblApprovementDate.Location = new System.Drawing.Point(24, 255);
            this.lblApprovementDate.Name = "lblApprovementDate";
            this.lblApprovementDate.Size = new System.Drawing.Size(99, 20);
            this.lblApprovementDate.TabIndex = 12;
            this.lblApprovementDate.Text = "Дата решения:";
            this.lblApprovementDate.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // comboBoxApprovedBy
            // 
            this.comboBoxApprovedBy.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.tlpVacationSchedulesInput.SetColumnSpan(this.comboBoxApprovedBy, 3);
            this.comboBoxApprovedBy.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxApprovedBy.FormattingEnabled = true;
            this.comboBoxApprovedBy.Location = new System.Drawing.Point(129, 224);
            this.comboBoxApprovedBy.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.comboBoxApprovedBy.Name = "comboBoxApprovedBy";
            this.comboBoxApprovedBy.Size = new System.Drawing.Size(197, 28);
            this.comboBoxApprovedBy.TabIndex = 10;
            // 
            // lblApprovedBy
            // 
            this.lblApprovedBy.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblApprovedBy.AutoSize = true;
            this.lblApprovedBy.Location = new System.Drawing.Point(49, 225);
            this.lblApprovedBy.Name = "lblApprovedBy";
            this.lblApprovedBy.Size = new System.Drawing.Size(74, 20);
            this.lblApprovedBy.TabIndex = 9;
            this.lblApprovedBy.Text = "Утвердил:";
            this.lblApprovedBy.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // comboBoxApproved
            // 
            this.comboBoxApproved.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.tlpVacationSchedulesInput.SetColumnSpan(this.comboBoxApproved, 3);
            this.comboBoxApproved.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxApproved.FormattingEnabled = true;
            this.comboBoxApproved.Items.AddRange(new object[] {
            "Не утвержден",
            "Утвержден"});
            this.comboBoxApproved.Location = new System.Drawing.Point(129, 194);
            this.comboBoxApproved.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.comboBoxApproved.Name = "comboBoxApproved";
            this.comboBoxApproved.Size = new System.Drawing.Size(197, 28);
            this.comboBoxApproved.TabIndex = 4;
            this.comboBoxApproved.SelectedIndexChanged += new System.EventHandler(this.comboBoxApproved_SelectedIndexChanged);
            // 
            // lblApproved
            // 
            this.lblApproved.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblApproved.AutoSize = true;
            this.lblApproved.Location = new System.Drawing.Point(68, 195);
            this.lblApproved.Name = "lblApproved";
            this.lblApproved.Size = new System.Drawing.Size(55, 20);
            this.lblApproved.TabIndex = 2;
            this.lblApproved.Text = "Статус:";
            this.lblApproved.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblYear
            // 
            this.lblYear.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblYear.AutoSize = true;
            this.lblYear.Location = new System.Drawing.Point(70, 165);
            this.lblYear.Name = "lblYear";
            this.lblYear.Size = new System.Drawing.Size(53, 20);
            this.lblYear.TabIndex = 6;
            this.lblYear.Text = "На год:";
            this.lblYear.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBoxYear
            // 
            this.textBoxYear.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxYear.Location = new System.Drawing.Point(164, 163);
            this.textBoxYear.MaxLength = 4;
            this.textBoxYear.Name = "textBoxYear";
            this.textBoxYear.ReadOnly = true;
            this.textBoxYear.Size = new System.Drawing.Size(127, 25);
            this.textBoxYear.TabIndex = 8;
            this.textBoxYear.Text = "2018";
            this.textBoxYear.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblTitleVacationSchedule
            // 
            this.lblTitleVacationSchedule.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblTitleVacationSchedule.AutoSize = true;
            this.lblTitleVacationSchedule.Location = new System.Drawing.Point(18, 135);
            this.lblTitleVacationSchedule.Name = "lblTitleVacationSchedule";
            this.lblTitleVacationSchedule.Size = new System.Drawing.Size(105, 20);
            this.lblTitleVacationSchedule.TabIndex = 5;
            this.lblTitleVacationSchedule.Text = "Наименование:";
            this.lblTitleVacationSchedule.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBoxVacationScheduleTitle
            // 
            this.textBoxVacationScheduleTitle.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.tlpVacationSchedulesInput.SetColumnSpan(this.textBoxVacationScheduleTitle, 3);
            this.textBoxVacationScheduleTitle.Location = new System.Drawing.Point(129, 133);
            this.textBoxVacationScheduleTitle.Name = "textBoxVacationScheduleTitle";
            this.textBoxVacationScheduleTitle.Size = new System.Drawing.Size(197, 25);
            this.textBoxVacationScheduleTitle.TabIndex = 7;
            // 
            // labelCreated
            // 
            this.labelCreated.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.labelCreated.AutoSize = true;
            this.labelCreated.Location = new System.Drawing.Point(43, 105);
            this.labelCreated.Name = "labelCreated";
            this.labelCreated.Size = new System.Drawing.Size(80, 20);
            this.labelCreated.TabIndex = 1;
            this.labelCreated.Text = "Составлен:";
            this.labelCreated.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // dtpCreated
            // 
            this.dtpCreated.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.tlpVacationSchedulesInput.SetColumnSpan(this.dtpCreated, 3);
            this.dtpCreated.Location = new System.Drawing.Point(129, 103);
            this.dtpCreated.Name = "dtpCreated";
            this.dtpCreated.Size = new System.Drawing.Size(197, 25);
            this.dtpCreated.TabIndex = 15;
            // 
            // btnYearMinus
            // 
            this.btnYearMinus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnYearMinus.Location = new System.Drawing.Point(129, 160);
            this.btnYearMinus.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.btnYearMinus.Name = "btnYearMinus";
            this.btnYearMinus.Size = new System.Drawing.Size(29, 30);
            this.btnYearMinus.TabIndex = 16;
            this.btnYearMinus.Text = "<";
            this.btnYearMinus.UseVisualStyleBackColor = true;
            this.btnYearMinus.Click += new System.EventHandler(this.btnYearMinus_Click);
            // 
            // btnYearPlus
            // 
            this.btnYearPlus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnYearPlus.Location = new System.Drawing.Point(297, 160);
            this.btnYearPlus.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.btnYearPlus.Name = "btnYearPlus";
            this.btnYearPlus.Size = new System.Drawing.Size(29, 30);
            this.btnYearPlus.TabIndex = 17;
            this.btnYearPlus.Text = ">";
            this.btnYearPlus.UseVisualStyleBackColor = true;
            this.btnYearPlus.Click += new System.EventHandler(this.btnYearPlus_Click);
            // 
            // tlpStaffingTablesButtons
            // 
            this.tlpStaffingTablesButtons.ColumnCount = 2;
            this.tlpStaffingTablesButtons.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpStaffingTablesButtons.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpStaffingTablesButtons.Controls.Add(this.btnVacationSchedulesPost, 1, 0);
            this.tlpStaffingTablesButtons.Controls.Add(this.btnVacationSchedulesCancel, 0, 0);
            this.tlpStaffingTablesButtons.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpStaffingTablesButtons.Location = new System.Drawing.Point(3, 411);
            this.tlpStaffingTablesButtons.Name = "tlpStaffingTablesButtons";
            this.tlpStaffingTablesButtons.RowCount = 1;
            this.tlpStaffingTablesButtons.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpStaffingTablesButtons.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tlpStaffingTablesButtons.Size = new System.Drawing.Size(352, 40);
            this.tlpStaffingTablesButtons.TabIndex = 1;
            // 
            // btnVacationSchedulesPost
            // 
            this.btnVacationSchedulesPost.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnVacationSchedulesPost.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnVacationSchedulesPost.ForeColor = System.Drawing.Color.White;
            this.btnVacationSchedulesPost.Location = new System.Drawing.Point(179, 3);
            this.btnVacationSchedulesPost.Name = "btnVacationSchedulesPost";
            this.btnVacationSchedulesPost.Size = new System.Drawing.Size(170, 34);
            this.btnVacationSchedulesPost.TabIndex = 0;
            this.btnVacationSchedulesPost.Text = "Сохранить данные";
            this.btnVacationSchedulesPost.UseVisualStyleBackColor = false;
            this.btnVacationSchedulesPost.Click += new System.EventHandler(this.btnVacationSchedulesPost_Click);
            // 
            // btnVacationSchedulesCancel
            // 
            this.btnVacationSchedulesCancel.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnVacationSchedulesCancel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnVacationSchedulesCancel.ForeColor = System.Drawing.Color.White;
            this.btnVacationSchedulesCancel.Location = new System.Drawing.Point(3, 3);
            this.btnVacationSchedulesCancel.Name = "btnVacationSchedulesCancel";
            this.btnVacationSchedulesCancel.Size = new System.Drawing.Size(170, 34);
            this.btnVacationSchedulesCancel.TabIndex = 1;
            this.btnVacationSchedulesCancel.Text = "Отмена";
            this.btnVacationSchedulesCancel.UseVisualStyleBackColor = false;
            this.btnVacationSchedulesCancel.Click += new System.EventHandler(this.btnVacationSchedulesCancel_Click);
            // 
            // tabPageVacationType
            // 
            this.tabPageVacationType.Controls.Add(this.tlpVacationTypes);
            this.tabPageVacationType.Location = new System.Drawing.Point(4, 29);
            this.tabPageVacationType.Name = "tabPageVacationType";
            this.tabPageVacationType.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageVacationType.Size = new System.Drawing.Size(364, 460);
            this.tabPageVacationType.TabIndex = 2;
            this.tabPageVacationType.Text = "Виды отпусков";
            this.tabPageVacationType.UseVisualStyleBackColor = true;
            // 
            // tlpVacationTypes
            // 
            this.tlpVacationTypes.BackColor = System.Drawing.Color.Tan;
            this.tlpVacationTypes.ColumnCount = 1;
            this.tlpVacationTypes.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpVacationTypes.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tlpVacationTypes.Controls.Add(this.tlpVacationTypesInput, 0, 0);
            this.tlpVacationTypes.Controls.Add(this.tlpStructuralUnitsFunctionalButtons, 0, 1);
            this.tlpVacationTypes.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpVacationTypes.Location = new System.Drawing.Point(3, 3);
            this.tlpVacationTypes.Name = "tlpVacationTypes";
            this.tlpVacationTypes.RowCount = 2;
            this.tlpVacationTypes.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tlpVacationTypes.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tlpVacationTypes.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tlpVacationTypes.Size = new System.Drawing.Size(358, 454);
            this.tlpVacationTypes.TabIndex = 0;
            // 
            // tlpVacationTypesInput
            // 
            this.tlpVacationTypesInput.ColumnCount = 5;
            this.tlpVacationTypesInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tlpVacationTypesInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tlpVacationTypesInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tlpVacationTypesInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tlpVacationTypesInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tlpVacationTypesInput.Controls.Add(this.btnUnpaidDaysPlus, 3, 5);
            this.tlpVacationTypesInput.Controls.Add(this.btnUnpaidDaysMinus, 1, 5);
            this.tlpVacationTypesInput.Controls.Add(this.btnPaidDaysPlus, 3, 3);
            this.tlpVacationTypesInput.Controls.Add(this.lblVacationType, 1, 0);
            this.tlpVacationTypesInput.Controls.Add(this.textBoxVacationType, 1, 1);
            this.tlpVacationTypesInput.Controls.Add(this.lblPaidDays, 1, 2);
            this.tlpVacationTypesInput.Controls.Add(this.lblUnpaidDays, 1, 4);
            this.tlpVacationTypesInput.Controls.Add(this.textBoxPaidDays, 2, 3);
            this.tlpVacationTypesInput.Controls.Add(this.textBoxUnpaidDays, 2, 5);
            this.tlpVacationTypesInput.Controls.Add(this.btnPaidDaysMinus, 1, 3);
            this.tlpVacationTypesInput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpVacationTypesInput.Location = new System.Drawing.Point(3, 3);
            this.tlpVacationTypesInput.Name = "tlpVacationTypesInput";
            this.tlpVacationTypesInput.RowCount = 7;
            this.tlpVacationTypesInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 32.5F));
            this.tlpVacationTypesInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpVacationTypesInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpVacationTypesInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpVacationTypesInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpVacationTypesInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpVacationTypesInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tlpVacationTypesInput.Size = new System.Drawing.Size(352, 402);
            this.tlpVacationTypesInput.TabIndex = 9;
            // 
            // btnUnpaidDaysPlus
            // 
            this.btnUnpaidDaysPlus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnUnpaidDaysPlus.Location = new System.Drawing.Point(248, 250);
            this.btnUnpaidDaysPlus.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.btnUnpaidDaysPlus.Name = "btnUnpaidDaysPlus";
            this.btnUnpaidDaysPlus.Size = new System.Drawing.Size(29, 30);
            this.btnUnpaidDaysPlus.TabIndex = 15;
            this.btnUnpaidDaysPlus.Text = ">";
            this.btnUnpaidDaysPlus.UseVisualStyleBackColor = true;
            this.btnUnpaidDaysPlus.Click += new System.EventHandler(this.btnUnpaidDaysPlus_Click);
            // 
            // btnUnpaidDaysMinus
            // 
            this.btnUnpaidDaysMinus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnUnpaidDaysMinus.Location = new System.Drawing.Point(73, 250);
            this.btnUnpaidDaysMinus.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.btnUnpaidDaysMinus.Name = "btnUnpaidDaysMinus";
            this.btnUnpaidDaysMinus.Size = new System.Drawing.Size(29, 30);
            this.btnUnpaidDaysMinus.TabIndex = 14;
            this.btnUnpaidDaysMinus.Text = "<";
            this.btnUnpaidDaysMinus.UseVisualStyleBackColor = true;
            this.btnUnpaidDaysMinus.Click += new System.EventHandler(this.btnUnpaidDaysMinus_Click);
            // 
            // btnPaidDaysPlus
            // 
            this.btnPaidDaysPlus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnPaidDaysPlus.Location = new System.Drawing.Point(248, 190);
            this.btnPaidDaysPlus.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.btnPaidDaysPlus.Name = "btnPaidDaysPlus";
            this.btnPaidDaysPlus.Size = new System.Drawing.Size(29, 30);
            this.btnPaidDaysPlus.TabIndex = 13;
            this.btnPaidDaysPlus.Text = ">";
            this.btnPaidDaysPlus.UseVisualStyleBackColor = true;
            this.btnPaidDaysPlus.Click += new System.EventHandler(this.btnPaidDaysPlus_Click);
            // 
            // lblVacationType
            // 
            this.lblVacationType.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblVacationType.AutoSize = true;
            this.tlpVacationTypesInput.SetColumnSpan(this.lblVacationType, 3);
            this.lblVacationType.Location = new System.Drawing.Point(73, 110);
            this.lblVacationType.Name = "lblVacationType";
            this.lblVacationType.Size = new System.Drawing.Size(156, 20);
            this.lblVacationType.TabIndex = 1;
            this.lblVacationType.Text = "Наименование отпуска:";
            // 
            // textBoxVacationType
            // 
            this.textBoxVacationType.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tlpVacationTypesInput.SetColumnSpan(this.textBoxVacationType, 3);
            this.textBoxVacationType.Location = new System.Drawing.Point(73, 133);
            this.textBoxVacationType.Name = "textBoxVacationType";
            this.textBoxVacationType.Size = new System.Drawing.Size(204, 25);
            this.textBoxVacationType.TabIndex = 8;
            // 
            // lblPaidDays
            // 
            this.lblPaidDays.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblPaidDays.AutoSize = true;
            this.tlpVacationTypesInput.SetColumnSpan(this.lblPaidDays, 3);
            this.lblPaidDays.Location = new System.Drawing.Point(73, 170);
            this.lblPaidDays.Name = "lblPaidDays";
            this.lblPaidDays.Size = new System.Drawing.Size(182, 20);
            this.lblPaidDays.TabIndex = 2;
            this.lblPaidDays.Text = "Число оплачиваемых дней:";
            // 
            // lblUnpaidDays
            // 
            this.lblUnpaidDays.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblUnpaidDays.AutoSize = true;
            this.tlpVacationTypesInput.SetColumnSpan(this.lblUnpaidDays, 3);
            this.lblUnpaidDays.Location = new System.Drawing.Point(73, 230);
            this.lblUnpaidDays.Name = "lblUnpaidDays";
            this.lblUnpaidDays.Size = new System.Drawing.Size(196, 20);
            this.lblUnpaidDays.TabIndex = 9;
            this.lblUnpaidDays.Text = "Число неоплачиваемых дней:";
            // 
            // textBoxPaidDays
            // 
            this.textBoxPaidDays.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxPaidDays.Location = new System.Drawing.Point(108, 193);
            this.textBoxPaidDays.Name = "textBoxPaidDays";
            this.textBoxPaidDays.Size = new System.Drawing.Size(134, 25);
            this.textBoxPaidDays.TabIndex = 10;
            this.textBoxPaidDays.Text = "0";
            this.textBoxPaidDays.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxPaidDays.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxPaidDays_KeyPress);
            // 
            // textBoxUnpaidDays
            // 
            this.textBoxUnpaidDays.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxUnpaidDays.Location = new System.Drawing.Point(108, 253);
            this.textBoxUnpaidDays.Name = "textBoxUnpaidDays";
            this.textBoxUnpaidDays.Size = new System.Drawing.Size(134, 25);
            this.textBoxUnpaidDays.TabIndex = 11;
            this.textBoxUnpaidDays.Text = "0";
            this.textBoxUnpaidDays.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxUnpaidDays.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxUnpaidDays_KeyPress);
            // 
            // btnPaidDaysMinus
            // 
            this.btnPaidDaysMinus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnPaidDaysMinus.Location = new System.Drawing.Point(73, 190);
            this.btnPaidDaysMinus.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.btnPaidDaysMinus.Name = "btnPaidDaysMinus";
            this.btnPaidDaysMinus.Size = new System.Drawing.Size(29, 30);
            this.btnPaidDaysMinus.TabIndex = 12;
            this.btnPaidDaysMinus.Text = "<";
            this.btnPaidDaysMinus.UseVisualStyleBackColor = true;
            this.btnPaidDaysMinus.Click += new System.EventHandler(this.btnPaidDaysMinus_Click);
            // 
            // tlpStructuralUnitsFunctionalButtons
            // 
            this.tlpStructuralUnitsFunctionalButtons.ColumnCount = 2;
            this.tlpStructuralUnitsFunctionalButtons.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpStructuralUnitsFunctionalButtons.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpStructuralUnitsFunctionalButtons.Controls.Add(this.btnVacationTypePost, 1, 0);
            this.tlpStructuralUnitsFunctionalButtons.Controls.Add(this.btnVacationTypeCancel, 0, 0);
            this.tlpStructuralUnitsFunctionalButtons.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpStructuralUnitsFunctionalButtons.Location = new System.Drawing.Point(3, 411);
            this.tlpStructuralUnitsFunctionalButtons.Name = "tlpStructuralUnitsFunctionalButtons";
            this.tlpStructuralUnitsFunctionalButtons.RowCount = 1;
            this.tlpStructuralUnitsFunctionalButtons.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpStructuralUnitsFunctionalButtons.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tlpStructuralUnitsFunctionalButtons.Size = new System.Drawing.Size(352, 40);
            this.tlpStructuralUnitsFunctionalButtons.TabIndex = 1;
            // 
            // btnVacationTypePost
            // 
            this.btnVacationTypePost.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnVacationTypePost.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnVacationTypePost.ForeColor = System.Drawing.Color.White;
            this.btnVacationTypePost.Location = new System.Drawing.Point(179, 3);
            this.btnVacationTypePost.Name = "btnVacationTypePost";
            this.btnVacationTypePost.Size = new System.Drawing.Size(170, 34);
            this.btnVacationTypePost.TabIndex = 0;
            this.btnVacationTypePost.Text = "Сохранить данные";
            this.btnVacationTypePost.UseVisualStyleBackColor = false;
            this.btnVacationTypePost.Click += new System.EventHandler(this.btnVacationTypePost_Click);
            // 
            // btnVacationTypeCancel
            // 
            this.btnVacationTypeCancel.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnVacationTypeCancel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnVacationTypeCancel.ForeColor = System.Drawing.Color.White;
            this.btnVacationTypeCancel.Location = new System.Drawing.Point(3, 3);
            this.btnVacationTypeCancel.Name = "btnVacationTypeCancel";
            this.btnVacationTypeCancel.Size = new System.Drawing.Size(170, 34);
            this.btnVacationTypeCancel.TabIndex = 1;
            this.btnVacationTypeCancel.Text = "Отмена";
            this.btnVacationTypeCancel.UseVisualStyleBackColor = false;
            this.btnVacationTypeCancel.Click += new System.EventHandler(this.btnVacationTypeCancel_Click);
            // 
            // tabPageSpendingOfVacations
            // 
            this.tabPageSpendingOfVacations.Controls.Add(this.tlpSpendingOfVacations);
            this.tabPageSpendingOfVacations.Location = new System.Drawing.Point(4, 29);
            this.tabPageSpendingOfVacations.Name = "tabPageSpendingOfVacations";
            this.tabPageSpendingOfVacations.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageSpendingOfVacations.Size = new System.Drawing.Size(364, 460);
            this.tabPageSpendingOfVacations.TabIndex = 3;
            this.tabPageSpendingOfVacations.Text = "Расходование отпусков:";
            this.tabPageSpendingOfVacations.UseVisualStyleBackColor = true;
            // 
            // tlpSpendingOfVacations
            // 
            this.tlpSpendingOfVacations.BackColor = System.Drawing.Color.Tan;
            this.tlpSpendingOfVacations.ColumnCount = 1;
            this.tlpSpendingOfVacations.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpSpendingOfVacations.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tlpSpendingOfVacations.Controls.Add(this.tlpSpendingOfVacationsFunctionalButtons, 0, 1);
            this.tlpSpendingOfVacations.Controls.Add(this.tlpSpendingOfVacationsInput, 0, 0);
            this.tlpSpendingOfVacations.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpSpendingOfVacations.Location = new System.Drawing.Point(3, 3);
            this.tlpSpendingOfVacations.Name = "tlpSpendingOfVacations";
            this.tlpSpendingOfVacations.RowCount = 2;
            this.tlpSpendingOfVacations.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tlpSpendingOfVacations.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tlpSpendingOfVacations.Size = new System.Drawing.Size(358, 454);
            this.tlpSpendingOfVacations.TabIndex = 0;
            // 
            // tlpSpendingOfVacationsFunctionalButtons
            // 
            this.tlpSpendingOfVacationsFunctionalButtons.ColumnCount = 2;
            this.tlpSpendingOfVacationsFunctionalButtons.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpSpendingOfVacationsFunctionalButtons.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpSpendingOfVacationsFunctionalButtons.Controls.Add(this.btnSpendingOfVacationPost, 1, 0);
            this.tlpSpendingOfVacationsFunctionalButtons.Controls.Add(this.btnSpendingOfVacationCancel, 0, 0);
            this.tlpSpendingOfVacationsFunctionalButtons.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpSpendingOfVacationsFunctionalButtons.Location = new System.Drawing.Point(3, 411);
            this.tlpSpendingOfVacationsFunctionalButtons.Name = "tlpSpendingOfVacationsFunctionalButtons";
            this.tlpSpendingOfVacationsFunctionalButtons.RowCount = 1;
            this.tlpSpendingOfVacationsFunctionalButtons.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpSpendingOfVacationsFunctionalButtons.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tlpSpendingOfVacationsFunctionalButtons.Size = new System.Drawing.Size(352, 40);
            this.tlpSpendingOfVacationsFunctionalButtons.TabIndex = 2;
            // 
            // btnSpendingOfVacationPost
            // 
            this.btnSpendingOfVacationPost.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnSpendingOfVacationPost.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnSpendingOfVacationPost.ForeColor = System.Drawing.Color.White;
            this.btnSpendingOfVacationPost.Location = new System.Drawing.Point(179, 3);
            this.btnSpendingOfVacationPost.Name = "btnSpendingOfVacationPost";
            this.btnSpendingOfVacationPost.Size = new System.Drawing.Size(170, 34);
            this.btnSpendingOfVacationPost.TabIndex = 0;
            this.btnSpendingOfVacationPost.Text = "Сохранить данные";
            this.btnSpendingOfVacationPost.UseVisualStyleBackColor = false;
            this.btnSpendingOfVacationPost.Click += new System.EventHandler(this.btnSpendingOfVacationPost_Click);
            // 
            // btnSpendingOfVacationCancel
            // 
            this.btnSpendingOfVacationCancel.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnSpendingOfVacationCancel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnSpendingOfVacationCancel.ForeColor = System.Drawing.Color.White;
            this.btnSpendingOfVacationCancel.Location = new System.Drawing.Point(3, 3);
            this.btnSpendingOfVacationCancel.Name = "btnSpendingOfVacationCancel";
            this.btnSpendingOfVacationCancel.Size = new System.Drawing.Size(170, 34);
            this.btnSpendingOfVacationCancel.TabIndex = 1;
            this.btnSpendingOfVacationCancel.Text = "Отмена";
            this.btnSpendingOfVacationCancel.UseVisualStyleBackColor = false;
            this.btnSpendingOfVacationCancel.Click += new System.EventHandler(this.btnSpendingOfVacationCancel_Click);
            // 
            // tlpSpendingOfVacationsInput
            // 
            this.tlpSpendingOfVacationsInput.ColumnCount = 5;
            this.tlpSpendingOfVacationsInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tlpSpendingOfVacationsInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tlpSpendingOfVacationsInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tlpSpendingOfVacationsInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tlpSpendingOfVacationsInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tlpSpendingOfVacationsInput.Controls.Add(this.buttonVacationMinus, 1, 5);
            this.tlpSpendingOfVacationsInput.Controls.Add(this.buttonVacationPlus, 3, 5);
            this.tlpSpendingOfVacationsInput.Controls.Add(this.buttonPlus, 3, 7);
            this.tlpSpendingOfVacationsInput.Controls.Add(this.buttonYearMinus, 1, 7);
            this.tlpSpendingOfVacationsInput.Controls.Add(this.lblVacationict, 1, 0);
            this.tlpSpendingOfVacationsInput.Controls.Add(this.comboBoxVacationist, 1, 1);
            this.tlpSpendingOfVacationsInput.Controls.Add(this.lblTipeOfVacation, 1, 2);
            this.tlpSpendingOfVacationsInput.Controls.Add(this.comboBoxTypeOfVacation, 1, 3);
            this.tlpSpendingOfVacationsInput.Controls.Add(this.textBoxVacationYear, 2, 7);
            this.tlpSpendingOfVacationsInput.Controls.Add(this.lblVacationYear, 1, 6);
            this.tlpSpendingOfVacationsInput.Controls.Add(this.labelVacationDays, 1, 4);
            this.tlpSpendingOfVacationsInput.Controls.Add(this.textBoxVacationDays, 2, 5);
            this.tlpSpendingOfVacationsInput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpSpendingOfVacationsInput.Location = new System.Drawing.Point(3, 3);
            this.tlpSpendingOfVacationsInput.Name = "tlpSpendingOfVacationsInput";
            this.tlpSpendingOfVacationsInput.RowCount = 9;
            this.tlpSpendingOfVacationsInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tlpSpendingOfVacationsInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpSpendingOfVacationsInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpSpendingOfVacationsInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpSpendingOfVacationsInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpSpendingOfVacationsInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpSpendingOfVacationsInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpSpendingOfVacationsInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tlpSpendingOfVacationsInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 22.5F));
            this.tlpSpendingOfVacationsInput.Size = new System.Drawing.Size(352, 402);
            this.tlpSpendingOfVacationsInput.TabIndex = 3;
            // 
            // buttonVacationMinus
            // 
            this.buttonVacationMinus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonVacationMinus.Location = new System.Drawing.Point(73, 220);
            this.buttonVacationMinus.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.buttonVacationMinus.Name = "buttonVacationMinus";
            this.buttonVacationMinus.Size = new System.Drawing.Size(29, 30);
            this.buttonVacationMinus.TabIndex = 12;
            this.buttonVacationMinus.Text = "<";
            this.buttonVacationMinus.UseVisualStyleBackColor = true;
            this.buttonVacationMinus.Click += new System.EventHandler(this.buttonVacationMinus_Click);
            // 
            // buttonVacationPlus
            // 
            this.buttonVacationPlus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonVacationPlus.Location = new System.Drawing.Point(248, 220);
            this.buttonVacationPlus.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.buttonVacationPlus.Name = "buttonVacationPlus";
            this.buttonVacationPlus.Size = new System.Drawing.Size(29, 30);
            this.buttonVacationPlus.TabIndex = 11;
            this.buttonVacationPlus.Text = ">";
            this.buttonVacationPlus.UseVisualStyleBackColor = true;
            this.buttonVacationPlus.Click += new System.EventHandler(this.buttonVacationPlus_Click);
            // 
            // buttonPlus
            // 
            this.buttonPlus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonPlus.Location = new System.Drawing.Point(248, 280);
            this.buttonPlus.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.buttonPlus.Name = "buttonPlus";
            this.buttonPlus.Size = new System.Drawing.Size(29, 30);
            this.buttonPlus.TabIndex = 8;
            this.buttonPlus.Text = ">";
            this.buttonPlus.UseVisualStyleBackColor = true;
            this.buttonPlus.Click += new System.EventHandler(this.buttonPlus_Click);
            // 
            // buttonYearMinus
            // 
            this.buttonYearMinus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonYearMinus.Location = new System.Drawing.Point(73, 280);
            this.buttonYearMinus.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.buttonYearMinus.Name = "buttonYearMinus";
            this.buttonYearMinus.Size = new System.Drawing.Size(29, 30);
            this.buttonYearMinus.TabIndex = 7;
            this.buttonYearMinus.Text = "<";
            this.buttonYearMinus.UseVisualStyleBackColor = true;
            this.buttonYearMinus.Click += new System.EventHandler(this.buttonYearMinus_Click);
            // 
            // lblVacationict
            // 
            this.lblVacationict.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblVacationict.AutoSize = true;
            this.tlpSpendingOfVacationsInput.SetColumnSpan(this.lblVacationict, 3);
            this.lblVacationict.Location = new System.Drawing.Point(73, 80);
            this.lblVacationict.Name = "lblVacationict";
            this.lblVacationict.Size = new System.Drawing.Size(80, 20);
            this.lblVacationict.TabIndex = 3;
            this.lblVacationict.Text = "Сотрудник:";
            // 
            // comboBoxVacationist
            // 
            this.comboBoxVacationist.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.tlpSpendingOfVacationsInput.SetColumnSpan(this.comboBoxVacationist, 3);
            this.comboBoxVacationist.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxVacationist.FormattingEnabled = true;
            this.comboBoxVacationist.Location = new System.Drawing.Point(73, 103);
            this.comboBoxVacationist.Name = "comboBoxVacationist";
            this.comboBoxVacationist.Size = new System.Drawing.Size(204, 28);
            this.comboBoxVacationist.TabIndex = 1;
            // 
            // lblTipeOfVacation
            // 
            this.lblTipeOfVacation.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblTipeOfVacation.AutoSize = true;
            this.tlpSpendingOfVacationsInput.SetColumnSpan(this.lblTipeOfVacation, 3);
            this.lblTipeOfVacation.Location = new System.Drawing.Point(73, 140);
            this.lblTipeOfVacation.Name = "lblTipeOfVacation";
            this.lblTipeOfVacation.Size = new System.Drawing.Size(89, 20);
            this.lblTipeOfVacation.TabIndex = 4;
            this.lblTipeOfVacation.Text = "Вид отпуска:";
            // 
            // comboBoxTypeOfVacation
            // 
            this.comboBoxTypeOfVacation.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.tlpSpendingOfVacationsInput.SetColumnSpan(this.comboBoxTypeOfVacation, 3);
            this.comboBoxTypeOfVacation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxTypeOfVacation.FormattingEnabled = true;
            this.comboBoxTypeOfVacation.Location = new System.Drawing.Point(73, 163);
            this.comboBoxTypeOfVacation.Name = "comboBoxTypeOfVacation";
            this.comboBoxTypeOfVacation.Size = new System.Drawing.Size(204, 28);
            this.comboBoxTypeOfVacation.Sorted = true;
            this.comboBoxTypeOfVacation.TabIndex = 5;
            this.comboBoxTypeOfVacation.SelectedValueChanged += new System.EventHandler(this.comboBoxTypeOfVacation_SelectedValueChanged);
            // 
            // textBoxVacationYear
            // 
            this.textBoxVacationYear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxVacationYear.Location = new System.Drawing.Point(108, 283);
            this.textBoxVacationYear.Name = "textBoxVacationYear";
            this.textBoxVacationYear.ReadOnly = true;
            this.textBoxVacationYear.Size = new System.Drawing.Size(134, 25);
            this.textBoxVacationYear.TabIndex = 6;
            this.textBoxVacationYear.Text = "2018";
            this.textBoxVacationYear.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblVacationYear
            // 
            this.lblVacationYear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblVacationYear.AutoSize = true;
            this.tlpSpendingOfVacationsInput.SetColumnSpan(this.lblVacationYear, 3);
            this.lblVacationYear.Location = new System.Drawing.Point(73, 260);
            this.lblVacationYear.Name = "lblVacationYear";
            this.lblVacationYear.Size = new System.Drawing.Size(139, 20);
            this.lblVacationYear.TabIndex = 2;
            this.lblVacationYear.Text = "За календарный год:";
            // 
            // labelVacationDays
            // 
            this.labelVacationDays.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.labelVacationDays.AutoSize = true;
            this.tlpSpendingOfVacationsInput.SetColumnSpan(this.labelVacationDays, 3);
            this.labelVacationDays.Location = new System.Drawing.Point(73, 200);
            this.labelVacationDays.Name = "labelVacationDays";
            this.labelVacationDays.Size = new System.Drawing.Size(137, 20);
            this.labelVacationDays.TabIndex = 9;
            this.labelVacationDays.Text = "Число дней отпуска:";
            // 
            // textBoxVacationDays
            // 
            this.textBoxVacationDays.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxVacationDays.Location = new System.Drawing.Point(108, 223);
            this.textBoxVacationDays.Name = "textBoxVacationDays";
            this.textBoxVacationDays.ReadOnly = true;
            this.textBoxVacationDays.Size = new System.Drawing.Size(134, 25);
            this.textBoxVacationDays.TabIndex = 10;
            this.textBoxVacationDays.Text = "0";
            this.textBoxVacationDays.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tabPageEmployeesPaidTravel
            // 
            this.tabPageEmployeesPaidTravel.Controls.Add(this.tableLayoutPanelEmployeesPaidDays);
            this.tabPageEmployeesPaidTravel.Location = new System.Drawing.Point(4, 29);
            this.tabPageEmployeesPaidTravel.Name = "tabPageEmployeesPaidTravel";
            this.tabPageEmployeesPaidTravel.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageEmployeesPaidTravel.Size = new System.Drawing.Size(364, 460);
            this.tabPageEmployeesPaidTravel.TabIndex = 4;
            this.tabPageEmployeesPaidTravel.Text = "Дорожные";
            this.tabPageEmployeesPaidTravel.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanelEmployeesPaidDays
            // 
            this.tableLayoutPanelEmployeesPaidDays.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPanelEmployeesPaidDays.ColumnCount = 1;
            this.tableLayoutPanelEmployeesPaidDays.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelEmployeesPaidDays.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanelEmployeesPaidDays.Controls.Add(this.tableLayoutPanelEmployeesPaidTravelInput, 0, 0);
            this.tableLayoutPanelEmployeesPaidDays.Controls.Add(this.tableLayoutPanelEmployeesPaidTravelFunctionalButtons, 0, 1);
            this.tableLayoutPanelEmployeesPaidDays.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelEmployeesPaidDays.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanelEmployeesPaidDays.Name = "tableLayoutPanelEmployeesPaidDays";
            this.tableLayoutPanelEmployeesPaidDays.RowCount = 2;
            this.tableLayoutPanelEmployeesPaidDays.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tableLayoutPanelEmployeesPaidDays.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanelEmployeesPaidDays.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanelEmployeesPaidDays.Size = new System.Drawing.Size(358, 454);
            this.tableLayoutPanelEmployeesPaidDays.TabIndex = 1;
            // 
            // tableLayoutPanelEmployeesPaidTravelInput
            // 
            this.tableLayoutPanelEmployeesPaidTravelInput.ColumnCount = 3;
            this.tableLayoutPanelEmployeesPaidTravelInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanelEmployeesPaidTravelInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanelEmployeesPaidTravelInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanelEmployeesPaidTravelInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanelEmployeesPaidTravelInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanelEmployeesPaidTravelInput.Controls.Add(this.lblTraveler, 1, 0);
            this.tableLayoutPanelEmployeesPaidTravelInput.Controls.Add(this.lblTransitStart, 1, 2);
            this.tableLayoutPanelEmployeesPaidTravelInput.Controls.Add(this.lblTransitFinish, 1, 4);
            this.tableLayoutPanelEmployeesPaidTravelInput.Controls.Add(this.comboBoxTraveler, 1, 1);
            this.tableLayoutPanelEmployeesPaidTravelInput.Controls.Add(this.dtpTransitStart, 1, 3);
            this.tableLayoutPanelEmployeesPaidTravelInput.Controls.Add(this.dtpTransitFinish, 1, 5);
            this.tableLayoutPanelEmployeesPaidTravelInput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelEmployeesPaidTravelInput.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanelEmployeesPaidTravelInput.Name = "tableLayoutPanelEmployeesPaidTravelInput";
            this.tableLayoutPanelEmployeesPaidTravelInput.RowCount = 7;
            this.tableLayoutPanelEmployeesPaidTravelInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 32.5F));
            this.tableLayoutPanelEmployeesPaidTravelInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tableLayoutPanelEmployeesPaidTravelInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tableLayoutPanelEmployeesPaidTravelInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tableLayoutPanelEmployeesPaidTravelInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tableLayoutPanelEmployeesPaidTravelInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5F));
            this.tableLayoutPanelEmployeesPaidTravelInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanelEmployeesPaidTravelInput.Size = new System.Drawing.Size(352, 402);
            this.tableLayoutPanelEmployeesPaidTravelInput.TabIndex = 9;
            // 
            // lblTraveler
            // 
            this.lblTraveler.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblTraveler.AutoSize = true;
            this.lblTraveler.ForeColor = System.Drawing.Color.Black;
            this.lblTraveler.Location = new System.Drawing.Point(73, 110);
            this.lblTraveler.Name = "lblTraveler";
            this.lblTraveler.Size = new System.Drawing.Size(80, 20);
            this.lblTraveler.TabIndex = 34;
            this.lblTraveler.Text = "Сотрудник:";
            this.lblTraveler.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblTransitStart
            // 
            this.lblTransitStart.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblTransitStart.AutoSize = true;
            this.lblTransitStart.ForeColor = System.Drawing.Color.Black;
            this.lblTransitStart.Location = new System.Drawing.Point(73, 170);
            this.lblTransitStart.Name = "lblTransitStart";
            this.lblTransitStart.Size = new System.Drawing.Size(90, 20);
            this.lblTransitStart.TabIndex = 32;
            this.lblTransitStart.Text = "Дорожные с:";
            this.lblTransitStart.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblTransitFinish
            // 
            this.lblTransitFinish.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblTransitFinish.AutoSize = true;
            this.lblTransitFinish.ForeColor = System.Drawing.Color.Black;
            this.lblTransitFinish.Location = new System.Drawing.Point(73, 230);
            this.lblTransitFinish.Name = "lblTransitFinish";
            this.lblTransitFinish.Size = new System.Drawing.Size(98, 20);
            this.lblTransitFinish.TabIndex = 33;
            this.lblTransitFinish.Text = "Дорожные по:";
            this.lblTransitFinish.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // comboBoxTraveler
            // 
            this.comboBoxTraveler.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBoxTraveler.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxTraveler.FormattingEnabled = true;
            this.comboBoxTraveler.Location = new System.Drawing.Point(73, 133);
            this.comboBoxTraveler.Name = "comboBoxTraveler";
            this.comboBoxTraveler.Size = new System.Drawing.Size(205, 28);
            this.comboBoxTraveler.TabIndex = 29;
            // 
            // dtpTransitStart
            // 
            this.dtpTransitStart.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.dtpTransitStart.Location = new System.Drawing.Point(73, 193);
            this.dtpTransitStart.Name = "dtpTransitStart";
            this.dtpTransitStart.Size = new System.Drawing.Size(205, 25);
            this.dtpTransitStart.TabIndex = 31;
            // 
            // dtpTransitFinish
            // 
            this.dtpTransitFinish.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.dtpTransitFinish.Location = new System.Drawing.Point(73, 253);
            this.dtpTransitFinish.Name = "dtpTransitFinish";
            this.dtpTransitFinish.Size = new System.Drawing.Size(205, 25);
            this.dtpTransitFinish.TabIndex = 30;
            // 
            // tableLayoutPanelEmployeesPaidTravelFunctionalButtons
            // 
            this.tableLayoutPanelEmployeesPaidTravelFunctionalButtons.ColumnCount = 2;
            this.tableLayoutPanelEmployeesPaidTravelFunctionalButtons.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelEmployeesPaidTravelFunctionalButtons.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelEmployeesPaidTravelFunctionalButtons.Controls.Add(this.btnEmployeesPaidTravelPost, 1, 0);
            this.tableLayoutPanelEmployeesPaidTravelFunctionalButtons.Controls.Add(this.btnEmployeesPaidTravelCancel, 0, 0);
            this.tableLayoutPanelEmployeesPaidTravelFunctionalButtons.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelEmployeesPaidTravelFunctionalButtons.Location = new System.Drawing.Point(3, 411);
            this.tableLayoutPanelEmployeesPaidTravelFunctionalButtons.Name = "tableLayoutPanelEmployeesPaidTravelFunctionalButtons";
            this.tableLayoutPanelEmployeesPaidTravelFunctionalButtons.RowCount = 1;
            this.tableLayoutPanelEmployeesPaidTravelFunctionalButtons.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelEmployeesPaidTravelFunctionalButtons.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanelEmployeesPaidTravelFunctionalButtons.Size = new System.Drawing.Size(352, 40);
            this.tableLayoutPanelEmployeesPaidTravelFunctionalButtons.TabIndex = 1;
            // 
            // btnEmployeesPaidTravelPost
            // 
            this.btnEmployeesPaidTravelPost.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnEmployeesPaidTravelPost.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnEmployeesPaidTravelPost.ForeColor = System.Drawing.Color.White;
            this.btnEmployeesPaidTravelPost.Location = new System.Drawing.Point(179, 3);
            this.btnEmployeesPaidTravelPost.Name = "btnEmployeesPaidTravelPost";
            this.btnEmployeesPaidTravelPost.Size = new System.Drawing.Size(170, 34);
            this.btnEmployeesPaidTravelPost.TabIndex = 0;
            this.btnEmployeesPaidTravelPost.Text = "Сохранить данные";
            this.btnEmployeesPaidTravelPost.UseVisualStyleBackColor = false;
            this.btnEmployeesPaidTravelPost.Click += new System.EventHandler(this.btnEmployeesPaidTravelPost_Click);
            // 
            // btnEmployeesPaidTravelCancel
            // 
            this.btnEmployeesPaidTravelCancel.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnEmployeesPaidTravelCancel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnEmployeesPaidTravelCancel.ForeColor = System.Drawing.Color.White;
            this.btnEmployeesPaidTravelCancel.Location = new System.Drawing.Point(3, 3);
            this.btnEmployeesPaidTravelCancel.Name = "btnEmployeesPaidTravelCancel";
            this.btnEmployeesPaidTravelCancel.Size = new System.Drawing.Size(170, 34);
            this.btnEmployeesPaidTravelCancel.TabIndex = 1;
            this.btnEmployeesPaidTravelCancel.Text = "Отмена";
            this.btnEmployeesPaidTravelCancel.UseVisualStyleBackColor = false;
            this.btnEmployeesPaidTravelCancel.Click += new System.EventHandler(this.btnEmployeesPaidTravelCancel_Click);
            // 
            // tabPageVacationLog
            // 
            this.tabPageVacationLog.Controls.Add(this.tableLayoutPanelVacationLog);
            this.tabPageVacationLog.Location = new System.Drawing.Point(4, 29);
            this.tabPageVacationLog.Name = "tabPageVacationLog";
            this.tabPageVacationLog.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageVacationLog.Size = new System.Drawing.Size(364, 460);
            this.tabPageVacationLog.TabIndex = 5;
            this.tabPageVacationLog.Text = "Журнал ведения отпусков";
            this.tabPageVacationLog.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanelVacationLog
            // 
            this.tableLayoutPanelVacationLog.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPanelVacationLog.ColumnCount = 1;
            this.tableLayoutPanelVacationLog.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelVacationLog.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanelVacationLog.Controls.Add(this.tableLayoutPanelVacationLogFunctionalButtons, 0, 1);
            this.tableLayoutPanelVacationLog.Controls.Add(this.tableLayoutPanelVacationLogInput, 0, 0);
            this.tableLayoutPanelVacationLog.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelVacationLog.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanelVacationLog.Name = "tableLayoutPanelVacationLog";
            this.tableLayoutPanelVacationLog.RowCount = 2;
            this.tableLayoutPanelVacationLog.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tableLayoutPanelVacationLog.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanelVacationLog.Size = new System.Drawing.Size(358, 454);
            this.tableLayoutPanelVacationLog.TabIndex = 3;
            // 
            // tableLayoutPanelVacationLogFunctionalButtons
            // 
            this.tableLayoutPanelVacationLogFunctionalButtons.ColumnCount = 2;
            this.tableLayoutPanelVacationLogFunctionalButtons.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelVacationLogFunctionalButtons.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelVacationLogFunctionalButtons.Controls.Add(this.btnVacationLogCancel, 0, 0);
            this.tableLayoutPanelVacationLogFunctionalButtons.Controls.Add(this.btnVacationLogPost, 1, 0);
            this.tableLayoutPanelVacationLogFunctionalButtons.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelVacationLogFunctionalButtons.Location = new System.Drawing.Point(3, 411);
            this.tableLayoutPanelVacationLogFunctionalButtons.Name = "tableLayoutPanelVacationLogFunctionalButtons";
            this.tableLayoutPanelVacationLogFunctionalButtons.RowCount = 1;
            this.tableLayoutPanelVacationLogFunctionalButtons.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelVacationLogFunctionalButtons.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanelVacationLogFunctionalButtons.Size = new System.Drawing.Size(352, 40);
            this.tableLayoutPanelVacationLogFunctionalButtons.TabIndex = 17;
            // 
            // btnVacationLogCancel
            // 
            this.btnVacationLogCancel.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnVacationLogCancel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnVacationLogCancel.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnVacationLogCancel.ForeColor = System.Drawing.Color.White;
            this.btnVacationLogCancel.Location = new System.Drawing.Point(3, 3);
            this.btnVacationLogCancel.Name = "btnVacationLogCancel";
            this.btnVacationLogCancel.Size = new System.Drawing.Size(170, 34);
            this.btnVacationLogCancel.TabIndex = 13;
            this.btnVacationLogCancel.Text = "Отмена";
            this.btnVacationLogCancel.UseVisualStyleBackColor = false;
            this.btnVacationLogCancel.Click += new System.EventHandler(this.btnVacationLogCancel_Click);
            // 
            // btnVacationLogPost
            // 
            this.btnVacationLogPost.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnVacationLogPost.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnVacationLogPost.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnVacationLogPost.ForeColor = System.Drawing.Color.White;
            this.btnVacationLogPost.Location = new System.Drawing.Point(179, 3);
            this.btnVacationLogPost.Name = "btnVacationLogPost";
            this.btnVacationLogPost.Size = new System.Drawing.Size(170, 34);
            this.btnVacationLogPost.TabIndex = 15;
            this.btnVacationLogPost.Text = "Сохранить данные";
            this.btnVacationLogPost.UseVisualStyleBackColor = false;
            this.btnVacationLogPost.Click += new System.EventHandler(this.btnVacationLogPost_Click);
            // 
            // tableLayoutPanelVacationLogInput
            // 
            this.tableLayoutPanelVacationLogInput.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPanelVacationLogInput.ColumnCount = 3;
            this.tableLayoutPanelVacationLogInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36F));
            this.tableLayoutPanelVacationLogInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 58F));
            this.tableLayoutPanelVacationLogInput.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6F));
            this.tableLayoutPanelVacationLogInput.Controls.Add(this.label1, 0, 1);
            this.tableLayoutPanelVacationLogInput.Controls.Add(this.label2, 0, 3);
            this.tableLayoutPanelVacationLogInput.Controls.Add(this.label3, 0, 4);
            this.tableLayoutPanelVacationLogInput.Controls.Add(this.label4, 0, 5);
            this.tableLayoutPanelVacationLogInput.Controls.Add(this.label5, 0, 6);
            this.tableLayoutPanelVacationLogInput.Controls.Add(this.label6, 0, 2);
            this.tableLayoutPanelVacationLogInput.Controls.Add(this.textBoxRealDaysRemain, 1, 6);
            this.tableLayoutPanelVacationLogInput.Controls.Add(this.comboBoxRealPersonnel, 1, 1);
            this.tableLayoutPanelVacationLogInput.Controls.Add(this.comboBoxRealVacationType, 1, 2);
            this.tableLayoutPanelVacationLogInput.Controls.Add(this.textBoxRealDaysQuantity, 1, 5);
            this.tableLayoutPanelVacationLogInput.Controls.Add(this.dtpRealVacationStart, 1, 3);
            this.tableLayoutPanelVacationLogInput.Controls.Add(this.dtpRealVacationFinish, 1, 4);
            this.tableLayoutPanelVacationLogInput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelVacationLogInput.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanelVacationLogInput.Name = "tableLayoutPanelVacationLogInput";
            this.tableLayoutPanelVacationLogInput.RowCount = 8;
            this.tableLayoutPanelVacationLogInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanelVacationLogInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanelVacationLogInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanelVacationLogInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanelVacationLogInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanelVacationLogInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanelVacationLogInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanelVacationLogInput.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanelVacationLogInput.Size = new System.Drawing.Size(352, 402);
            this.tableLayoutPanelVacationLogInput.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(3, 80);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 40);
            this.label1.TabIndex = 0;
            this.label1.Text = "Сотрудник:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(3, 160);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(120, 40);
            this.label2.TabIndex = 3;
            this.label2.Text = "Начало отпуска:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(3, 200);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(120, 40);
            this.label3.TabIndex = 4;
            this.label3.Text = "Конец отпуска:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(3, 240);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(120, 40);
            this.label4.TabIndex = 6;
            this.label4.Text = "Число дней:";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(3, 280);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(120, 40);
            this.label5.TabIndex = 5;
            this.label5.Text = "Осталось дней:";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(3, 120);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(120, 40);
            this.label6.TabIndex = 14;
            this.label6.Text = "Вид отпуска:";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBoxRealDaysRemain
            // 
            this.textBoxRealDaysRemain.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxRealDaysRemain.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxRealDaysRemain.Location = new System.Drawing.Point(129, 287);
            this.textBoxRealDaysRemain.Name = "textBoxRealDaysRemain";
            this.textBoxRealDaysRemain.ReadOnly = true;
            this.textBoxRealDaysRemain.Size = new System.Drawing.Size(198, 25);
            this.textBoxRealDaysRemain.TabIndex = 25;
            this.textBoxRealDaysRemain.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // comboBoxRealPersonnel
            // 
            this.comboBoxRealPersonnel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBoxRealPersonnel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxRealPersonnel.Enabled = false;
            this.comboBoxRealPersonnel.FormattingEnabled = true;
            this.comboBoxRealPersonnel.Location = new System.Drawing.Point(129, 86);
            this.comboBoxRealPersonnel.Name = "comboBoxRealPersonnel";
            this.comboBoxRealPersonnel.Size = new System.Drawing.Size(198, 28);
            this.comboBoxRealPersonnel.TabIndex = 28;
            // 
            // comboBoxRealVacationType
            // 
            this.comboBoxRealVacationType.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBoxRealVacationType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxRealVacationType.Enabled = false;
            this.comboBoxRealVacationType.FormattingEnabled = true;
            this.comboBoxRealVacationType.Location = new System.Drawing.Point(129, 126);
            this.comboBoxRealVacationType.Name = "comboBoxRealVacationType";
            this.comboBoxRealVacationType.Size = new System.Drawing.Size(198, 28);
            this.comboBoxRealVacationType.TabIndex = 19;
            // 
            // textBoxRealDaysQuantity
            // 
            this.textBoxRealDaysQuantity.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxRealDaysQuantity.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxRealDaysQuantity.Location = new System.Drawing.Point(129, 247);
            this.textBoxRealDaysQuantity.Name = "textBoxRealDaysQuantity";
            this.textBoxRealDaysQuantity.ReadOnly = true;
            this.textBoxRealDaysQuantity.Size = new System.Drawing.Size(198, 25);
            this.textBoxRealDaysQuantity.TabIndex = 29;
            this.textBoxRealDaysQuantity.Text = "1";
            this.textBoxRealDaysQuantity.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // dtpRealVacationStart
            // 
            this.dtpRealVacationStart.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.dtpRealVacationStart.Location = new System.Drawing.Point(129, 167);
            this.dtpRealVacationStart.Name = "dtpRealVacationStart";
            this.dtpRealVacationStart.Size = new System.Drawing.Size(198, 25);
            this.dtpRealVacationStart.TabIndex = 21;
            this.dtpRealVacationStart.ValueChanged += new System.EventHandler(this.dtpRealVacationStart_ValueChanged);
            // 
            // dtpRealVacationFinish
            // 
            this.dtpRealVacationFinish.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.dtpRealVacationFinish.Location = new System.Drawing.Point(129, 207);
            this.dtpRealVacationFinish.Name = "dtpRealVacationFinish";
            this.dtpRealVacationFinish.Size = new System.Drawing.Size(198, 25);
            this.dtpRealVacationFinish.TabIndex = 20;
            this.dtpRealVacationFinish.ValueChanged += new System.EventHandler(this.dtpRealVacationFinish_ValueChanged);
            // 
            // tableLayoutPanel_Company
            // 
            this.tableLayoutPanel_Company.BackColor = System.Drawing.SystemColors.HotTrack;
            this.tableLayoutPanel_Company.ColumnCount = 3;
            this.tableLayoutPanel_Company.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_Company.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.tableLayoutPanel_Company.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel_Company.Controls.Add(this.pictureBoxCompany, 0, 1);
            this.tableLayoutPanel_Company.Controls.Add(this.lblCompany, 1, 1);
            this.tableLayoutPanel_Company.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Company.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel_Company.Name = "tableLayoutPanel_Company";
            this.tableLayoutPanel_Company.RowCount = 3;
            this.tableLayoutPanel_Company.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel_Company.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tableLayoutPanel_Company.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel_Company.Size = new System.Drawing.Size(378, 50);
            this.tableLayoutPanel_Company.TabIndex = 8;
            // 
            // pictureBoxCompany
            // 
            this.pictureBoxCompany.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxCompany.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxCompany.Image")));
            this.pictureBoxCompany.Location = new System.Drawing.Point(0, 2);
            this.pictureBoxCompany.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBoxCompany.Name = "pictureBoxCompany";
            this.pictureBoxCompany.Size = new System.Drawing.Size(94, 45);
            this.pictureBoxCompany.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxCompany.TabIndex = 3;
            this.pictureBoxCompany.TabStop = false;
            // 
            // lblCompany
            // 
            this.lblCompany.AutoSize = true;
            this.lblCompany.BackColor = System.Drawing.SystemColors.HotTrack;
            this.lblCompany.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCompany.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblCompany.ForeColor = System.Drawing.Color.White;
            this.lblCompany.Location = new System.Drawing.Point(97, 2);
            this.lblCompany.Name = "lblCompany";
            this.lblCompany.Size = new System.Drawing.Size(258, 45);
            this.lblCompany.TabIndex = 2;
            this.lblCompany.Text = "МЕЖРЕГИОНАЛЬНАЯ РАСПРЕДЕЛИТЕЛЬНАЯ СЕТЕВАЯ КОМПАНИЯ СЕВЕРО-ЗАПАДА";
            this.lblCompany.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // EmployeesVacationsEditForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(384, 561);
            this.Controls.Add(this.tableLayoutPanel_AllForm);
            this.Name = "EmployeesVacationsEditForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "РЕДАКТОР СВЕДЕНИЙ ОБ ОТПУСКАХ";
            this.Load += new System.EventHandler(this.EmployeesVacationsEditForm_Load);
            this.Shown += new System.EventHandler(this.EmployeesVacationsEditForm_Shown);
            this.tableLayoutPanel_AllForm.ResumeLayout(false);
            this.tableLayoutPanel_EditField.ResumeLayout(false);
            this.tabControlEmployeesVacationsEdit.ResumeLayout(false);
            this.tabPageEmployeesVacation.ResumeLayout(false);
            this.tlpEmployeesVacations.ResumeLayout(false);
            this.tlpStaffingTableFunctionalButtons.ResumeLayout(false);
            this.tlpEmployeesVacationsInput.ResumeLayout(false);
            this.tlpEmployeesVacationsInput.PerformLayout();
            this.tabPageVacationSchedulesList.ResumeLayout(false);
            this.tlpStaffingTables.ResumeLayout(false);
            this.tlpVacationSchedulesInput.ResumeLayout(false);
            this.tlpVacationSchedulesInput.PerformLayout();
            this.tlpStaffingTablesButtons.ResumeLayout(false);
            this.tabPageVacationType.ResumeLayout(false);
            this.tlpVacationTypes.ResumeLayout(false);
            this.tlpVacationTypesInput.ResumeLayout(false);
            this.tlpVacationTypesInput.PerformLayout();
            this.tlpStructuralUnitsFunctionalButtons.ResumeLayout(false);
            this.tabPageSpendingOfVacations.ResumeLayout(false);
            this.tlpSpendingOfVacations.ResumeLayout(false);
            this.tlpSpendingOfVacationsFunctionalButtons.ResumeLayout(false);
            this.tlpSpendingOfVacationsInput.ResumeLayout(false);
            this.tlpSpendingOfVacationsInput.PerformLayout();
            this.tabPageEmployeesPaidTravel.ResumeLayout(false);
            this.tableLayoutPanelEmployeesPaidDays.ResumeLayout(false);
            this.tableLayoutPanelEmployeesPaidTravelInput.ResumeLayout(false);
            this.tableLayoutPanelEmployeesPaidTravelInput.PerformLayout();
            this.tableLayoutPanelEmployeesPaidTravelFunctionalButtons.ResumeLayout(false);
            this.tabPageVacationLog.ResumeLayout(false);
            this.tableLayoutPanelVacationLog.ResumeLayout(false);
            this.tableLayoutPanelVacationLogFunctionalButtons.ResumeLayout(false);
            this.tableLayoutPanelVacationLogInput.ResumeLayout(false);
            this.tableLayoutPanelVacationLogInput.PerformLayout();
            this.tableLayoutPanel_Company.ResumeLayout(false);
            this.tableLayoutPanel_Company.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCompany)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_AllForm;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_EditField;
        private System.Windows.Forms.TabControl tabControlEmployeesVacationsEdit;
        private System.Windows.Forms.TabPage tabPageEmployeesVacation;
        private System.Windows.Forms.TableLayoutPanel tlpEmployeesVacations;
        private System.Windows.Forms.TableLayoutPanel tlpStaffingTableFunctionalButtons;
        private System.Windows.Forms.Button btnEmployeesVacationsCancel;
        private System.Windows.Forms.Button btnEmployeesVacationsPost;
        private System.Windows.Forms.TableLayoutPanel tlpEmployeesVacationsInput;
        private System.Windows.Forms.Label lBlPersonnel;
        private System.Windows.Forms.TextBox textBoxDaysRamain;
        private System.Windows.Forms.DateTimePicker dtpVacationFinish;
        private System.Windows.Forms.DateTimePicker dtpVacationStart;
        private System.Windows.Forms.Label lblVacationStart;
        private System.Windows.Forms.Label lblVacationFinish;
        private System.Windows.Forms.Label lblDaysQuantity;
        private System.Windows.Forms.Label lblDaysRemain;
        private System.Windows.Forms.ComboBox comboBoxVacationType;
        private System.Windows.Forms.Label lblTypeOfVacation;
        private System.Windows.Forms.TabPage tabPageVacationSchedulesList;
        private System.Windows.Forms.TableLayoutPanel tlpStaffingTables;
        private System.Windows.Forms.TableLayoutPanel tlpVacationSchedulesInput;
        private System.Windows.Forms.Label labelCreated;
        private System.Windows.Forms.Label lblTitleVacationSchedule;
        private System.Windows.Forms.TextBox textBoxVacationScheduleTitle;
        private System.Windows.Forms.Label lblYear;
        private System.Windows.Forms.TextBox textBoxYear;
        private System.Windows.Forms.Label lblApproved;
        private System.Windows.Forms.ComboBox comboBoxApproved;
        private System.Windows.Forms.Label lblApprovedBy;
        private System.Windows.Forms.ComboBox comboBoxApprovedBy;
        private System.Windows.Forms.TableLayoutPanel tlpStaffingTablesButtons;
        private System.Windows.Forms.Button btnVacationSchedulesPost;
        private System.Windows.Forms.Button btnVacationSchedulesCancel;
        private System.Windows.Forms.TabPage tabPageVacationType;
        private System.Windows.Forms.TableLayoutPanel tlpVacationTypes;
        private System.Windows.Forms.TableLayoutPanel tlpVacationTypesInput;
        private System.Windows.Forms.Label lblVacationType;
        private System.Windows.Forms.Label lblPaidDays;
        private System.Windows.Forms.TableLayoutPanel tlpStructuralUnitsFunctionalButtons;
        private System.Windows.Forms.Button btnVacationTypePost;
        private System.Windows.Forms.Button btnVacationTypeCancel;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Company;
        private System.Windows.Forms.PictureBox pictureBoxCompany;
        private System.Windows.Forms.Label lblCompany;
        private System.Windows.Forms.TextBox textBoxVacationType;
        private System.Windows.Forms.Label lblUnpaidDays;
        private System.Windows.Forms.TextBox textBoxPaidDays;
        private System.Windows.Forms.TextBox textBoxUnpaidDays;
        private System.Windows.Forms.Label lblStructuralUnit;
        private System.Windows.Forms.ComboBox comboBoxStructuralUnit;
        private System.Windows.Forms.DateTimePicker dtpApprovementDate;
        private System.Windows.Forms.Label lblApprovementDate;
        private System.Windows.Forms.DateTimePicker dtpCreated;
        private System.Windows.Forms.ComboBox comboBoxPersonnel;
        private System.Windows.Forms.Button btnUnpaidDaysPlus;
        private System.Windows.Forms.Button btnUnpaidDaysMinus;
        private System.Windows.Forms.Button btnPaidDaysPlus;
        private System.Windows.Forms.Button btnPaidDaysMinus;
        private System.Windows.Forms.TabPage tabPageSpendingOfVacations;
        private System.Windows.Forms.TableLayoutPanel tlpSpendingOfVacations;
        private System.Windows.Forms.TableLayoutPanel tlpSpendingOfVacationsFunctionalButtons;
        private System.Windows.Forms.Button btnSpendingOfVacationPost;
        private System.Windows.Forms.Button btnSpendingOfVacationCancel;
        private System.Windows.Forms.TableLayoutPanel tlpSpendingOfVacationsInput;
        private System.Windows.Forms.ComboBox comboBoxVacationist;
        private System.Windows.Forms.Button btnYearMinus;
        private System.Windows.Forms.Button btnYearPlus;
        private System.Windows.Forms.Label lblVacationYear;
        private System.Windows.Forms.Label lblVacationict;
        private System.Windows.Forms.Label lblTipeOfVacation;
        private System.Windows.Forms.ComboBox comboBoxTypeOfVacation;
        private System.Windows.Forms.Button buttonPlus;
        private System.Windows.Forms.TextBox textBoxVacationYear;
        private System.Windows.Forms.Button buttonYearMinus;
        private System.Windows.Forms.Button buttonVacationMinus;
        private System.Windows.Forms.Button buttonVacationPlus;
        private System.Windows.Forms.Label labelVacationDays;
        private System.Windows.Forms.TextBox textBoxVacationDays;
        private System.Windows.Forms.TextBox textBoxDaysQuantity;
        private System.Windows.Forms.TabPage tabPageEmployeesPaidTravel;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelEmployeesPaidDays;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelEmployeesPaidTravelInput;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelEmployeesPaidTravelFunctionalButtons;
        private System.Windows.Forms.Button btnEmployeesPaidTravelPost;
        private System.Windows.Forms.Button btnEmployeesPaidTravelCancel;
        private System.Windows.Forms.Label lblTransitStart;
        private System.Windows.Forms.Label lblTransitFinish;
        private System.Windows.Forms.ComboBox comboBoxTraveler;
        private System.Windows.Forms.DateTimePicker dtpTransitStart;
        private System.Windows.Forms.DateTimePicker dtpTransitFinish;
        private System.Windows.Forms.Label lblTraveler;
        private System.Windows.Forms.TabPage tabPageVacationLog;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelVacationLog;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelVacationLogFunctionalButtons;
        private System.Windows.Forms.Button btnVacationLogCancel;
        private System.Windows.Forms.Button btnVacationLogPost;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelVacationLogInput;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBoxRealDaysRemain;
        private System.Windows.Forms.ComboBox comboBoxRealPersonnel;
        private System.Windows.Forms.ComboBox comboBoxRealVacationType;
        private System.Windows.Forms.TextBox textBoxRealDaysQuantity;
        private System.Windows.Forms.DateTimePicker dtpRealVacationStart;
        private System.Windows.Forms.DateTimePicker dtpRealVacationFinish;
    }
}