﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace VacationScheduleCreator
{
    //класс главной формы
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        //процедура скрытия кнопок главного меню
        void HideAllFunctionButtons()
        {
            foreach (Control a in Controls)
            {
                if (a.GetType() == typeof(TableLayoutPanel) && ((TableLayoutPanel)a).Name == "tableLayoutPanel_AllForm")
                {
                    foreach (Control b in a.Controls)
                    {
                        if (b.GetType() == typeof(TableLayoutPanel) && ((TableLayoutPanel)b).Name == "tableLayoutPanel_MainMenu")
                        {
                            foreach (Control c in b.Controls)
                            {
                                if (c.GetType() == typeof(TableLayoutPanel) && ((TableLayoutPanel)c).Name == "tableLayoutPanel_MenuOptions")
                                {
                                    foreach (Control d in c.Controls)
                                    {
                                        if (d.GetType() == typeof(Button) && ((Button)d).FlatStyle == FlatStyle.Popup)
                                            ((Button)d).Hide();
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        //процедура показа пунктов меню раздела "Информационная база"
        private void btnInformation_Click(object sender, EventArgs e)
        {
            HideAllFunctionButtons();
            btnEmployees.Show();
            btnEmployeesVacations.Show();
            btnStaffingTable.Show();
            btnOrganizationSettings.Show();
        }

        //процедура показа формы с организационными настройками
        private void btnOrganizationSettings_Click(object sender, EventArgs e)
        {
            OrganizationSettingsForm OrganizationSettings = new OrganizationSettingsForm();
            OrganizationSettings.WindowState = FormWindowState.Maximized;
            OrganizationSettings.ShowDialog();
            HideAllFunctionButtons();
        }

        //процедура показа формы с информацией о сотрудниках
        private void btnEmployees_Click(object sender, EventArgs e)
        {
            EmployeesForm Employees = new EmployeesForm();
            Employees.WindowState = FormWindowState.Maximized;
            Employees.ShowDialog();
            HideAllFunctionButtons();
        }

        //процедура показа формы с информацией об отпусках
        private void btnVacationSchedules_Click(object sender, EventArgs e)
        {
            EmployeesVacationsForm EmployeesVacations = new EmployeesVacationsForm();
            EmployeesVacations.WindowState = FormWindowState.Maximized;
            EmployeesVacations.ShowDialog();
            HideAllFunctionButtons();
        }

        //процедура показа формы с информацией о штатных расписаниях
        private void btnStaffingTable_Click(object sender, EventArgs e)
        {
            StaffingTableForm StaffingTable = new StaffingTableForm();
            StaffingTable.WindowState = FormWindowState.Maximized;
            StaffingTable.ShowDialog();
            HideAllFunctionButtons();
        }

        //процедура показа пунктов меню раздела "Отчеты"
        private void btnReports_Click(object sender, EventArgs e)
        {
            HideAllFunctionButtons();
            //btnDaysCreditReport.Show();
            btnDaysRemainReport.Show();
            btnVacationScheduleOfUnit.Show();
            btnAllCompanyVacationSchedule.Show();
            btnVacationLogReport.Show();
        }

        //процедура открытия формы для формирования графика отпусков всего предприятия
        private void btnAllCompanyVacationSchedule_Click(object sender, EventArgs e)
        {
            VacationScheduleOfAllCompanyDocumentForm
            VacationScheduleOfAllCompanyDocument = new
            VacationScheduleOfAllCompanyDocumentForm();

            VacationScheduleOfAllCompanyDocument.WindowState = FormWindowState.Maximized;
            VacationScheduleOfAllCompanyDocument.ShowDialog();
            HideAllFunctionButtons();
        }

        //процедура показа формы для формирования документа 
        //"График отпусков структурного подразделения"
        private void btnVacationScheduleOfUnit_Click(object sender, EventArgs e)
        {
            VacationScheduleOfUnitDocumentForm VacationScheduleOfUnitDocument
                = new VacationScheduleOfUnitDocumentForm();
            VacationScheduleOfUnitDocument.WindowState = FormWindowState.Maximized;
            VacationScheduleOfUnitDocument.ShowDialog();
            HideAllFunctionButtons();
        }

        //процедура показа формы для формирования отчета
        //"Журнал фактических отпусков"
        private void btnVacationLogReport_Click(object sender, EventArgs e)
        {
            VacationLogReportForm VacationLogReport = new VacationLogReportForm();
            VacationLogReport.WindowState = FormWindowState.Maximized;
            VacationLogReport.ShowDialog();
            HideAllFunctionButtons();
        }

        //процедура показа формы для формирования отчета "Список сотрудников,
        //неизрасходовавших дни отпуска"
        private void btnDaysRemainReport_Click(object sender, EventArgs e)
        {
            DaysRemainReportForm DaysRemainReport = new DaysRemainReportForm();
            DaysRemainReport.WindowState = FormWindowState.Maximized;
            DaysRemainReport.ShowDialog();
            HideAllFunctionButtons();
        }

        //процедура показа формы для формирования отчета "Список сотрудников,
        //бравших дни в счет будущего отпуска
        private void btnDaysCreditReport_Click(object sender, EventArgs e)
        {
            DaysCreditReportForm DaysCreditForm = new DaysCreditReportForm();
            DaysCreditForm.WindowState = FormWindowState.Maximized;
            DaysCreditForm.ShowDialog();
            HideAllFunctionButtons();
        }

        //процедура показа пунктов меню раздела "Профиль"
        private void btnUserProfile_Click(object sender, EventArgs e)
        {
            HideAllFunctionButtons();
            btnUserProfile.Show();
        }

        //процедура показа пунктов меню раздела "Завершение работы"
        private void btnPause_Click(object sender, EventArgs e)
        {
            HideAllFunctionButtons();
            btnUserChange.Show();
            btnCloseApplication.Show();
        }

        //процедура смены пользователя
        private void btnUserChange_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = new DialogResult();
            dialogResult = MessageBox.Show("Сменить пользователя?",
                "Смена пользователя!", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
                this.Close();
            else HideAllFunctionButtons();
        }

        //процедура завершения работы приложения
        private void btnCloseApplication_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = new DialogResult();
            dialogResult = MessageBox.Show("Вы действительно хотите выйти из приложения?",
                "Завершение работы!", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                this.Close();
                InitialForm.ExitConfirm = true;
            }
            else HideAllFunctionButtons();
        }
        
        //процедура заполнения строки статуса информацией об авторизованном пользователе
        public void ImportUserInformation()
        {
            statusStripActiveUser.Items[1].Text = DB_Connection.ActiveUser;
            statusStripActiveUser.Items[4].Text = DB_Connection.ActiveRole;
        }

        private void MainForm_Activated(object sender, EventArgs e)
        {
            //this.WindowState(maximiza;
                /*double xRange = this.Height/(double)SystemInformation.PrimaryMonitorSize.Width;
            double yRange = this.Height/(double)SystemInformation.PrimaryMonitorSize.Height;
            
            if (xRange > yRange)
            {
                this.Height = SystemInformation.PrimaryMonitorSize.Height - 50;
                this.Width = (int)(this.Height / InitialForm.Proportion);
            }
            if (xRange < yRange)
            {
                this.Width = SystemInformation.PrimaryMonitorSize.Width - 50;
                this.Height = (int)(this.Width * InitialForm.Proportion);
            }
            if (xRange == yRange)
            {
                this.Width = SystemInformation.PrimaryMonitorSize.Width;
                this.Height = SystemInformation.PrimaryMonitorSize.Height;
            }
            this.Left = (SystemInformation.PrimaryMonitorSize.Width - this.Width) / 2;
            this.Top = (SystemInformation.PrimaryMonitorSize.Height - this.Height) / 2;
            //this.StartPosition = FormStartPosition.CenterScreen;*/
            /*
            this.Top = 0;
            this.Left = 0;
            this.Size = SystemInformation.WorkingArea.Size;
             * */
                //PrimaryMonitorSize.; //размер всего монитора
            //this.Size = SystemInformation.VirtualScreen.Size; //размер всего монитора
            //this.Size = System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Size;
        }       
    }
}
