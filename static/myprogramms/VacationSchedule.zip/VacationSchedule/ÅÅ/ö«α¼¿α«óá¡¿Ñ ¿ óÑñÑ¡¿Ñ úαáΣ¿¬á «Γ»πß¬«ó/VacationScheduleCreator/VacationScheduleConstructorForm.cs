﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace VacationScheduleCreator
{
    public partial class VacationScheduleConstructorForm : Form
    {
        public VacationScheduleConstructorForm()
        {
            InitializeComponent();
        }
        //строка хранит идентификатор назначенного отпуска
        static public string TheVacation;
        //строка хранит идентификатор нужного графика отпусков
        static public string TheVacationSchedule;

        //строка хранит идентификатор редактируемого отдела
        static public string CurrentUnit;
        //строка хранит идентификатор вида отпуска для активной записи
        static public string CurrentEmployee;

        //переменные для удаления записи из другого модуля
        static public string OldChangingRecord;
        static public int OldChangingDaysBalance;
        static public string OldChangingEmployeesVacation;

        //процедура загрузки даных из таблиц БД
        private void VacationScheduleConstructorForm_Load(object sender, EventArgs e)
        {
            //выпадающий список "Подразделение"
            DB_Connection.ShowStructuralUnits();
            comboBoxStructuralUnit.DataSource = DB_Connection.dtStructuralUnits;
            comboBoxStructuralUnit.DisplayMember = "Сокращенное наименование";
            comboBoxStructuralUnit.ValueMember = "su.Unit_id";
            //выпадающий список "Сотрудник
            DB_Connection.ShowUnitEmployees(comboBoxStructuralUnit.SelectedValue.ToString());
            comboBoxEmployee.DataSource = DB_Connection.dtUnitEmployees;
            comboBoxEmployee.DisplayMember = "Surname_NF";
            comboBoxEmployee.ValueMember = "Personnel_number";
            //таблица "Расходование отпусков"
            DB_Connection.ShowEmployeeVacationsBalance(comboBoxEmployee.SelectedValue.ToString());
            dataGridViewSpendingOfVacation.DataSource = DB_Connection.dtEmployeesVacationsBalance;
            dataGridViewSpendingOfVacation.Columns["Position_id"].Visible = false;
            dataGridViewSpendingOfVacation.Columns["Personnel_number"].Visible = false;
            if (dataGridViewSpendingOfVacation.RowCount != 0)                
                dataGridViewSpendingOfVacation.Rows[0].Cells["За календарный год"].Selected = true;
            //таблица "Статус графика отпусков"
            DB_Connection.ShowActualVacationScheduleStatus
                (comboBoxStructuralUnit.SelectedValue.ToString());
            dataGridViewVacationStatus.DataSource = DB_Connection.dtActualVacationScheduleStatus;
            dataGridViewVacationStatus.Columns["Vacation_schedule_id"].Visible = false;
            dataGridViewVacationStatus.Columns["Утвердившее лицо"].Visible = false;
            if (dataGridViewVacationStatus.RowCount != 0)                
                dataGridViewVacationStatus.Rows[0].Cells["Дата составления"].Selected = true;
            //таблица "График отпусков"
            DB_Connection.ShowUnitEmployeesVacations(comboBoxStructuralUnit.SelectedValue.ToString());
            dataGridViewVacationSchedule.DataSource = DB_Connection.dtUnitEmployeesVacations;
            dataGridViewVacationSchedule.Columns["Vacation_schedule_id"].Visible = false;
            dataGridViewVacationSchedule.Columns["Structural_unit_id"].Visible = false;
            dataGridViewVacationSchedule.Columns["Position_id"].Visible = false;
            if (dataGridViewVacationSchedule.RowCount != 0)
                dataGridViewVacationSchedule.Rows[0].Cells["Табельный номер"].Selected = true;
        }

        //процедура занесения сотрудников подразделения 
        //в выпадающий список при выборе подразделения
        private void comboBoxStructuralUnit_SelectedValueChanged(object sender, EventArgs e)
        {
            if (comboBoxStructuralUnit.SelectedValue != null)
            {
                //обновить список сотрудников
                DB_Connection.ShowUnitEmployees(comboBoxStructuralUnit.SelectedValue.ToString());
                //обновить график отпусков
                DB_Connection.ShowUnitEmployeesVacations
                    (comboBoxStructuralUnit.SelectedValue.ToString());
                //обновить статус графика отпусков
                DB_Connection.ShowActualVacationScheduleStatus
                    (comboBoxStructuralUnit.SelectedValue.ToString());
                if (comboBoxEmployee.SelectedValue != null)
                {
                    //обновить список отпусков сотрудника
                    DB_Connection.ShowEmployeeVacationsBalance(comboBoxEmployee.SelectedValue.ToString());
                }
                else DB_Connection.dtEmployeesVacationsBalance.Clear();
            }
            else DB_Connection.dtEmployeesVacationsBalance.Clear();
        }

        //процедура вывода списка назначенных отпусков для выбранного сотрудника
        private void comboBoxEmployee_SelectedValueChanged(object sender, EventArgs e)
        {
            if (comboBoxEmployee.SelectedValue != null)
            {
                DB_Connection.ShowEmployeeVacationsBalance(comboBoxEmployee.SelectedValue.ToString());
                dataGridViewSpendingOfVacation.DataSource = DB_Connection.dtEmployeesVacationsBalance;
            }
            else DB_Connection.dtEmployeesVacationsBalance.Clear();
        }

        //процедура выбора подразделения и сотрудника в 
        //выпадающих списках для обновления данных в таблице
        private void VacationScheduleConstructorForm_Activated(object sender, EventArgs e)
        {
            if (CurrentUnit != null)
                comboBoxStructuralUnit.SelectedItem = CurrentUnit;
            if (CurrentEmployee != null)
                comboBoxEmployee.SelectedItem = CurrentEmployee;
        }

        //процедура проверки утверждения графика отпусков
        bool VacationScheduleIsApproved()
        {
            if (dataGridViewVacationStatus.CurrentRow.Cells["Утвержден"].Value.ToString() == "Утвержден")
                return true;
            else return false;
        }

        //процедура открытия формы с полями ввода для добавления отпуска в график
        private void btnAddVacation_Click(object sender, EventArgs e)
        {
            if (dataGridViewVacationStatus.RowCount != 0)
            {
                if (!VacationScheduleIsApproved())
                {
                    if (dataGridViewSpendingOfVacation.RowCount != 0)
                    {
                        TheVacation = dataGridViewSpendingOfVacation.CurrentRow.Cells["Position_id"].Value.ToString();
                        TheVacationSchedule = dataGridViewVacationStatus.
                            CurrentRow.Cells["Vacation_schedule_id"].Value.ToString();
                        EmployeesVacationsEditForm EmployeesVacationsEdit = new EmployeesVacationsEditForm();
                        EmployeesVacationsEdit.ShowEmployeesVacationsTabToAdd();
                        EmployeesVacationsEdit.DaysBalanceImport(dataGridViewSpendingOfVacation.CurrentRow.
                            Cells["Осталось оплачиваемых дней"].Value.ToString());
                        EmployeesVacationsEdit.ImportEmployee = comboBoxEmployee.SelectedValue.ToString();
                        EmployeesVacationsEdit.ImportVacationType = dataGridViewSpendingOfVacation.
                            CurrentRow.Cells["Вид отпуска"].Value.ToString();
                        EmployeesVacationsEdit.ShowDialog();
                        int temp1 = Convert.ToInt16(comboBoxStructuralUnit.SelectedValue.ToString());
                        int temp2 = Convert.ToInt16(comboBoxEmployee.SelectedValue.ToString());
                        DB_Connection.ShowStructuralUnits();
                        comboBoxStructuralUnit.SelectedValue = temp1;
                        comboBoxEmployee.SelectedValue = temp2;
                    }
                    else MessageBox.Show("Этому сотруднику не назначен отпуск!");
                }
                else MessageBox.Show("Нельзя изменять утвержденный график отпусков!");
            }
            else MessageBox.Show("Для подразделения, к которому относится этот сотрудник не создан график отпусков!");
        }

        //процедура изменения отпуска сотрудника
        private void btnChangeVacation_Click(object sender, EventArgs e)
        {
            if (!VacationScheduleIsApproved())
            {
                if (dataGridViewVacationSchedule.RowCount == 0)
                {
                    MessageBox.Show("Нет записей для редактирования!");
                    return;
                }
                if (dataGridViewSpendingOfVacation.RowCount != 0)
                {
                    string TheRecord = DB_Connection.GetSpendingOfVacationRecordId(
                            dataGridViewVacationSchedule.CurrentRow.Cells["Сотрудник"].Value.ToString(),
                            dataGridViewVacationSchedule.CurrentRow.Cells["Вид отпуска"].Value.ToString());
                    if (TheRecord != "NULL")
                    {
                        OldChangingRecord = TheRecord;
                        OldChangingDaysBalance = DB_Connection.ImportDayRemainValue(TheRecord) +
                            Convert.ToInt16(dataGridViewVacationSchedule.CurrentRow.
                            Cells["Итого дней отпуска"].Value.ToString());
                        OldChangingEmployeesVacation = dataGridViewVacationSchedule.
                            CurrentRow.Cells["Position_id"].Value.ToString();

                        TheVacation = dataGridViewSpendingOfVacation.CurrentRow.Cells["Position_id"].Value.ToString();
                        TheVacationSchedule = dataGridViewVacationStatus.
                            CurrentRow.Cells["Vacation_schedule_id"].Value.ToString();
                        EmployeesVacationsEditForm EmployeesVacationsEdit = new EmployeesVacationsEditForm();
                        EmployeesVacationsEdit.ShowEmployeesVacationsTabToChange();
                        EmployeesVacationsEdit.DaysBalanceImport(dataGridViewSpendingOfVacation.CurrentRow.
                            Cells["Осталось оплачиваемых дней"].Value.ToString());
                        EmployeesVacationsEdit.CorrectiongDaysBalanceImport(
                            dataGridViewVacationSchedule.CurrentRow.Cells["Итого дней отпуска"].Value.ToString());
                        EmployeesVacationsEdit.ImportEmployee = comboBoxEmployee.SelectedValue.ToString(); ;
                        EmployeesVacationsEdit.ImportVacationType = dataGridViewSpendingOfVacation.
                            CurrentRow.Cells["Вид отпуска"].Value.ToString();
                        EmployeesVacationsEdit.ShowDialog();
                        int temp1 = Convert.ToInt16(comboBoxStructuralUnit.SelectedValue.ToString());
                        int temp2 = Convert.ToInt16(comboBoxEmployee.SelectedValue.ToString());
                        DB_Connection.ShowStructuralUnits();
                        comboBoxStructuralUnit.SelectedValue = temp1;
                        comboBoxEmployee.SelectedValue = temp2;
                    }
                    else MessageBox.Show("Нет сведений о назначенном сутруднику отпуске!");
                }
                else MessageBox.Show("Этому сотруднику не назначался отпуск!");
            }
            else MessageBox.Show("Нельзя изменять утвержденный график отпусков!");
        }

        //процедура удаления выбранного отпуска из графика отпусков
        private void btnDeleteVacation_Click(object sender, EventArgs e)
        {
            if (!VacationScheduleIsApproved())
            {
                if (dataGridViewVacationSchedule.RowCount == 0)
                {
                    MessageBox.Show("Нет записей для удаления!");
                    return;
                }
                DialogResult dialogResult = new DialogResult();
                dialogResult = MessageBox.Show("Вы действительно хотите удалить выбраный отпуск из графика?"
                    , "Удаление отпуска!", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    string TheRecord = DB_Connection.GetSpendingOfVacationRecordId(
                    dataGridViewVacationSchedule.CurrentRow.Cells["Сотрудник"].Value.ToString(),
                    dataGridViewVacationSchedule.CurrentRow.Cells["Вид отпуска"].Value.ToString());
                    if (TheRecord != "NULL")
                    {
                        int DaysBalance = DB_Connection.ImportDayRemainValue(TheRecord) +
                            Convert.ToInt16(dataGridViewVacationSchedule.CurrentRow.
                            Cells["Итого дней отпуска"].Value.ToString());
                        DB_Connection.CorrectingSpendingOfVacations(TheRecord, DaysBalance.ToString());
                        DB_Connection.DeleteEmployeesVacation(dataGridViewVacationSchedule.
                            CurrentRow.Cells["Position_id"].Value.ToString());
                        MessageBox.Show("Отпуск удален из графика отпусков!");
                        int temp1 = Convert.ToInt16(comboBoxStructuralUnit.SelectedValue.ToString());
                        int temp2 = Convert.ToInt16(comboBoxEmployee.SelectedValue.ToString());
                        DB_Connection.ShowStructuralUnits();
                        comboBoxStructuralUnit.SelectedValue = temp1;
                        comboBoxEmployee.SelectedValue = temp2;
                    }
                    else MessageBox.Show("Нет сведений о назначенном сутруднику отпуске!");
                }
            }
            else MessageBox.Show("Нельзя изменять утвержденный график отпусков!");
        }
    }
}
