﻿namespace VacationScheduleCreator
{
    partial class OrganizationSettingsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(OrganizationSettingsForm));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tableLayoutPanel_AllForm = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel_Company = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBoxCompany = new System.Windows.Forms.PictureBox();
            this.lblCompany = new System.Windows.Forms.Label();
            this.tableLayoutPanel_OrganizationSettings = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel_Working_field = new System.Windows.Forms.TableLayoutPanel();
            this.groupBoxCompanyInformation = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanelCompanyInformation = new System.Windows.Forms.TableLayoutPanel();
            this.dataGridViewCompanyInformation = new System.Windows.Forms.DataGridView();
            this.btnCompanyInformation = new System.Windows.Forms.Button();
            this.groupBoxFunctions = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanelFunctions = new System.Windows.Forms.TableLayoutPanel();
            this.dataGridViewFunctions = new System.Windows.Forms.DataGridView();
            this.должность = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnFunctionsDetail = new System.Windows.Forms.Button();
            this.groupBoxPersonnelCategories = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanelPersonnelCategories = new System.Windows.Forms.TableLayoutPanel();
            this.dataGridViewPersonnelCategories = new System.Windows.Forms.DataGridView();
            this.btnPersonnelCategoriesDetail = new System.Windows.Forms.Button();
            this.groupBoxStateHolidaysList = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanelStateHolidaysList = new System.Windows.Forms.TableLayoutPanel();
            this.dataGridViewStateHolidaysList = new System.Windows.Forms.DataGridView();
            this.btnStateHolidaysList = new System.Windows.Forms.Button();
            this.groupBoxHierarchyLevels = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanelHierarchyLevels = new System.Windows.Forms.TableLayoutPanel();
            this.dataGridViewHierarchyLevels = new System.Windows.Forms.DataGridView();
            this.btnHierarchyLevelsDetail = new System.Windows.Forms.Button();
            this.tableLayoutPanel_WindowHeader = new System.Windows.Forms.TableLayoutPanel();
            this.lblOrganizationSettings = new System.Windows.Forms.Label();
            this.tableLayoutPanel_Programm = new System.Windows.Forms.TableLayoutPanel();
            this.lblProgramm = new System.Windows.Forms.Label();
            this.Название_праздника = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Дата = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Полное_наименование = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Сокращенное_наименование = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Уровень_иерархии = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Сокр_наим = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ИНН = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.КПП = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ОКПО = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Полн_наим = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Юридический_адрес = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Фактический_адрес = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tableLayoutPanel_AllForm.SuspendLayout();
            this.tableLayoutPanel_Company.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCompany)).BeginInit();
            this.tableLayoutPanel_OrganizationSettings.SuspendLayout();
            this.tableLayoutPanel_Working_field.SuspendLayout();
            this.groupBoxCompanyInformation.SuspendLayout();
            this.tableLayoutPanelCompanyInformation.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCompanyInformation)).BeginInit();
            this.groupBoxFunctions.SuspendLayout();
            this.tableLayoutPanelFunctions.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewFunctions)).BeginInit();
            this.groupBoxPersonnelCategories.SuspendLayout();
            this.tableLayoutPanelPersonnelCategories.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPersonnelCategories)).BeginInit();
            this.groupBoxStateHolidaysList.SuspendLayout();
            this.tableLayoutPanelStateHolidaysList.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewStateHolidaysList)).BeginInit();
            this.groupBoxHierarchyLevels.SuspendLayout();
            this.tableLayoutPanelHierarchyLevels.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewHierarchyLevels)).BeginInit();
            this.tableLayoutPanel_WindowHeader.SuspendLayout();
            this.tableLayoutPanel_Programm.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel_AllForm
            // 
            this.tableLayoutPanel_AllForm.ColumnCount = 1;
            this.tableLayoutPanel_AllForm.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_AllForm.Controls.Add(this.tableLayoutPanel_Company, 0, 1);
            this.tableLayoutPanel_AllForm.Controls.Add(this.tableLayoutPanel_OrganizationSettings, 0, 2);
            this.tableLayoutPanel_AllForm.Controls.Add(this.tableLayoutPanel_Programm, 0, 0);
            this.tableLayoutPanel_AllForm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_AllForm.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel_AllForm.Name = "tableLayoutPanel_AllForm";
            this.tableLayoutPanel_AllForm.RowCount = 3;
            this.tableLayoutPanel_AllForm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel_AllForm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tableLayoutPanel_AllForm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 75F));
            this.tableLayoutPanel_AllForm.Size = new System.Drawing.Size(784, 497);
            this.tableLayoutPanel_AllForm.TabIndex = 10;
            // 
            // tableLayoutPanel_Company
            // 
            this.tableLayoutPanel_Company.BackColor = System.Drawing.SystemColors.HotTrack;
            this.tableLayoutPanel_Company.ColumnCount = 2;
            this.tableLayoutPanel_Company.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel_Company.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.tableLayoutPanel_Company.Controls.Add(this.pictureBoxCompany, 0, 1);
            this.tableLayoutPanel_Company.Controls.Add(this.lblCompany, 1, 1);
            this.tableLayoutPanel_Company.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Company.Location = new System.Drawing.Point(3, 52);
            this.tableLayoutPanel_Company.Name = "tableLayoutPanel_Company";
            this.tableLayoutPanel_Company.RowCount = 3;
            this.tableLayoutPanel_Company.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel_Company.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tableLayoutPanel_Company.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel_Company.Size = new System.Drawing.Size(778, 68);
            this.tableLayoutPanel_Company.TabIndex = 7;
            // 
            // pictureBoxCompany
            // 
            this.pictureBoxCompany.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxCompany.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxCompany.Image")));
            this.pictureBoxCompany.Location = new System.Drawing.Point(3, 6);
            this.pictureBoxCompany.Name = "pictureBoxCompany";
            this.pictureBoxCompany.Size = new System.Drawing.Size(227, 55);
            this.pictureBoxCompany.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxCompany.TabIndex = 3;
            this.pictureBoxCompany.TabStop = false;
            // 
            // lblCompany
            // 
            this.lblCompany.AutoSize = true;
            this.lblCompany.BackColor = System.Drawing.SystemColors.HotTrack;
            this.lblCompany.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCompany.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblCompany.ForeColor = System.Drawing.Color.White;
            this.lblCompany.Location = new System.Drawing.Point(236, 3);
            this.lblCompany.Name = "lblCompany";
            this.lblCompany.Size = new System.Drawing.Size(539, 61);
            this.lblCompany.TabIndex = 2;
            this.lblCompany.Text = "МЕЖРЕГИОНАЛЬНАЯ РАСПРЕДЕЛИТЕЛЬНАЯ СЕТЕВАЯ КОМПАНИЯ СЕВЕРО-ЗАПАДА";
            this.lblCompany.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel_OrganizationSettings
            // 
            this.tableLayoutPanel_OrganizationSettings.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPanel_OrganizationSettings.ColumnCount = 1;
            this.tableLayoutPanel_OrganizationSettings.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_OrganizationSettings.Controls.Add(this.tableLayoutPanel_Working_field, 0, 1);
            this.tableLayoutPanel_OrganizationSettings.Controls.Add(this.tableLayoutPanel_WindowHeader, 0, 0);
            this.tableLayoutPanel_OrganizationSettings.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_OrganizationSettings.Location = new System.Drawing.Point(3, 126);
            this.tableLayoutPanel_OrganizationSettings.Name = "tableLayoutPanel_OrganizationSettings";
            this.tableLayoutPanel_OrganizationSettings.RowCount = 2;
            this.tableLayoutPanel_OrganizationSettings.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12F));
            this.tableLayoutPanel_OrganizationSettings.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 88F));
            this.tableLayoutPanel_OrganizationSettings.Size = new System.Drawing.Size(778, 368);
            this.tableLayoutPanel_OrganizationSettings.TabIndex = 6;
            // 
            // tableLayoutPanel_Working_field
            // 
            this.tableLayoutPanel_Working_field.ColumnCount = 4;
            this.tableLayoutPanel_Working_field.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_Working_field.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_Working_field.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_Working_field.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_Working_field.Controls.Add(this.groupBoxCompanyInformation, 0, 1);
            this.tableLayoutPanel_Working_field.Controls.Add(this.groupBoxFunctions, 1, 0);
            this.tableLayoutPanel_Working_field.Controls.Add(this.groupBoxPersonnelCategories, 2, 0);
            this.tableLayoutPanel_Working_field.Controls.Add(this.groupBoxStateHolidaysList, 0, 0);
            this.tableLayoutPanel_Working_field.Controls.Add(this.groupBoxHierarchyLevels, 3, 0);
            this.tableLayoutPanel_Working_field.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Working_field.Location = new System.Drawing.Point(3, 44);
            this.tableLayoutPanel_Working_field.Margin = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.tableLayoutPanel_Working_field.Name = "tableLayoutPanel_Working_field";
            this.tableLayoutPanel_Working_field.RowCount = 2;
            this.tableLayoutPanel_Working_field.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Working_field.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Working_field.Size = new System.Drawing.Size(772, 321);
            this.tableLayoutPanel_Working_field.TabIndex = 7;
            // 
            // groupBoxCompanyInformation
            // 
            this.tableLayoutPanel_Working_field.SetColumnSpan(this.groupBoxCompanyInformation, 4);
            this.groupBoxCompanyInformation.Controls.Add(this.tableLayoutPanelCompanyInformation);
            this.groupBoxCompanyInformation.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxCompanyInformation.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBoxCompanyInformation.ForeColor = System.Drawing.Color.White;
            this.groupBoxCompanyInformation.Location = new System.Drawing.Point(3, 163);
            this.groupBoxCompanyInformation.Name = "groupBoxCompanyInformation";
            this.groupBoxCompanyInformation.Size = new System.Drawing.Size(766, 155);
            this.groupBoxCompanyInformation.TabIndex = 6;
            this.groupBoxCompanyInformation.TabStop = false;
            this.groupBoxCompanyInformation.Text = "Сведения о предприятии:";
            // 
            // tableLayoutPanelCompanyInformation
            // 
            this.tableLayoutPanelCompanyInformation.ColumnCount = 1;
            this.tableLayoutPanelCompanyInformation.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelCompanyInformation.Controls.Add(this.dataGridViewCompanyInformation, 0, 0);
            this.tableLayoutPanelCompanyInformation.Controls.Add(this.btnCompanyInformation, 0, 1);
            this.tableLayoutPanelCompanyInformation.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelCompanyInformation.Location = new System.Drawing.Point(3, 25);
            this.tableLayoutPanelCompanyInformation.Name = "tableLayoutPanelCompanyInformation";
            this.tableLayoutPanelCompanyInformation.RowCount = 2;
            this.tableLayoutPanelCompanyInformation.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 75F));
            this.tableLayoutPanelCompanyInformation.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanelCompanyInformation.Size = new System.Drawing.Size(760, 127);
            this.tableLayoutPanelCompanyInformation.TabIndex = 0;
            // 
            // dataGridViewCompanyInformation
            // 
            this.dataGridViewCompanyInformation.AllowUserToAddRows = false;
            this.dataGridViewCompanyInformation.AllowUserToDeleteRows = false;
            this.dataGridViewCompanyInformation.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewCompanyInformation.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Сокр_наим,
            this.ИНН,
            this.КПП,
            this.ОКПО,
            this.Полн_наим,
            this.Юридический_адрес,
            this.Фактический_адрес});
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewCompanyInformation.DefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewCompanyInformation.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewCompanyInformation.Location = new System.Drawing.Point(3, 3);
            this.dataGridViewCompanyInformation.MultiSelect = false;
            this.dataGridViewCompanyInformation.Name = "dataGridViewCompanyInformation";
            this.dataGridViewCompanyInformation.ReadOnly = true;
            this.dataGridViewCompanyInformation.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewCompanyInformation.Size = new System.Drawing.Size(754, 89);
            this.dataGridViewCompanyInformation.TabIndex = 0;
            // 
            // btnCompanyInformation
            // 
            this.btnCompanyInformation.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnCompanyInformation.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnCompanyInformation.Location = new System.Drawing.Point(3, 98);
            this.btnCompanyInformation.Name = "btnCompanyInformation";
            this.btnCompanyInformation.Size = new System.Drawing.Size(754, 26);
            this.btnCompanyInformation.TabIndex = 1;
            this.btnCompanyInformation.Text = "Перейти к сведениям о предприятии";
            this.btnCompanyInformation.UseVisualStyleBackColor = false;
            this.btnCompanyInformation.Click += new System.EventHandler(this.btnCompanyInformation_Click);
            // 
            // groupBoxFunctions
            // 
            this.groupBoxFunctions.Controls.Add(this.tableLayoutPanelFunctions);
            this.groupBoxFunctions.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxFunctions.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBoxFunctions.ForeColor = System.Drawing.Color.White;
            this.groupBoxFunctions.Location = new System.Drawing.Point(196, 3);
            this.groupBoxFunctions.Name = "groupBoxFunctions";
            this.groupBoxFunctions.Size = new System.Drawing.Size(187, 154);
            this.groupBoxFunctions.TabIndex = 1;
            this.groupBoxFunctions.TabStop = false;
            this.groupBoxFunctions.Text = "Должности:";
            // 
            // tableLayoutPanelFunctions
            // 
            this.tableLayoutPanelFunctions.ColumnCount = 1;
            this.tableLayoutPanelFunctions.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelFunctions.Controls.Add(this.dataGridViewFunctions, 0, 0);
            this.tableLayoutPanelFunctions.Controls.Add(this.btnFunctionsDetail, 0, 1);
            this.tableLayoutPanelFunctions.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelFunctions.Location = new System.Drawing.Point(3, 25);
            this.tableLayoutPanelFunctions.Name = "tableLayoutPanelFunctions";
            this.tableLayoutPanelFunctions.RowCount = 2;
            this.tableLayoutPanelFunctions.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 75F));
            this.tableLayoutPanelFunctions.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanelFunctions.Size = new System.Drawing.Size(181, 126);
            this.tableLayoutPanelFunctions.TabIndex = 0;
            // 
            // dataGridViewFunctions
            // 
            this.dataGridViewFunctions.AllowUserToAddRows = false;
            this.dataGridViewFunctions.AllowUserToDeleteRows = false;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.AntiqueWhite;
            this.dataGridViewFunctions.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewFunctions.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewFunctions.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.должность});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewFunctions.DefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridViewFunctions.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewFunctions.Location = new System.Drawing.Point(3, 3);
            this.dataGridViewFunctions.MultiSelect = false;
            this.dataGridViewFunctions.Name = "dataGridViewFunctions";
            this.dataGridViewFunctions.ReadOnly = true;
            this.dataGridViewFunctions.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewFunctions.Size = new System.Drawing.Size(175, 88);
            this.dataGridViewFunctions.TabIndex = 0;
            // 
            // должность
            // 
            this.должность.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.должность.DataPropertyName = "Должность";
            this.должность.HeaderText = "Должность сотрудника";
            this.должность.Name = "должность";
            this.должность.ReadOnly = true;
            // 
            // btnFunctionsDetail
            // 
            this.btnFunctionsDetail.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnFunctionsDetail.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnFunctionsDetail.Location = new System.Drawing.Point(3, 97);
            this.btnFunctionsDetail.Name = "btnFunctionsDetail";
            this.btnFunctionsDetail.Size = new System.Drawing.Size(175, 26);
            this.btnFunctionsDetail.TabIndex = 1;
            this.btnFunctionsDetail.Text = "Перейти к списку";
            this.btnFunctionsDetail.UseVisualStyleBackColor = false;
            this.btnFunctionsDetail.Click += new System.EventHandler(this.btnFunctionsDetail_Click);
            // 
            // groupBoxPersonnelCategories
            // 
            this.groupBoxPersonnelCategories.Controls.Add(this.tableLayoutPanelPersonnelCategories);
            this.groupBoxPersonnelCategories.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxPersonnelCategories.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBoxPersonnelCategories.ForeColor = System.Drawing.Color.White;
            this.groupBoxPersonnelCategories.Location = new System.Drawing.Point(389, 3);
            this.groupBoxPersonnelCategories.Name = "groupBoxPersonnelCategories";
            this.groupBoxPersonnelCategories.Size = new System.Drawing.Size(187, 154);
            this.groupBoxPersonnelCategories.TabIndex = 2;
            this.groupBoxPersonnelCategories.TabStop = false;
            this.groupBoxPersonnelCategories.Text = "Категории персонала:";
            // 
            // tableLayoutPanelPersonnelCategories
            // 
            this.tableLayoutPanelPersonnelCategories.ColumnCount = 1;
            this.tableLayoutPanelPersonnelCategories.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelPersonnelCategories.Controls.Add(this.dataGridViewPersonnelCategories, 0, 0);
            this.tableLayoutPanelPersonnelCategories.Controls.Add(this.btnPersonnelCategoriesDetail, 0, 1);
            this.tableLayoutPanelPersonnelCategories.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelPersonnelCategories.Location = new System.Drawing.Point(3, 25);
            this.tableLayoutPanelPersonnelCategories.Name = "tableLayoutPanelPersonnelCategories";
            this.tableLayoutPanelPersonnelCategories.RowCount = 2;
            this.tableLayoutPanelPersonnelCategories.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 75F));
            this.tableLayoutPanelPersonnelCategories.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanelPersonnelCategories.Size = new System.Drawing.Size(181, 126);
            this.tableLayoutPanelPersonnelCategories.TabIndex = 0;
            // 
            // dataGridViewPersonnelCategories
            // 
            this.dataGridViewPersonnelCategories.AllowUserToAddRows = false;
            this.dataGridViewPersonnelCategories.AllowUserToDeleteRows = false;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.AntiqueWhite;
            this.dataGridViewPersonnelCategories.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridViewPersonnelCategories.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewPersonnelCategories.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Полное_наименование,
            this.Сокращенное_наименование});
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewPersonnelCategories.DefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridViewPersonnelCategories.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewPersonnelCategories.Location = new System.Drawing.Point(3, 3);
            this.dataGridViewPersonnelCategories.MultiSelect = false;
            this.dataGridViewPersonnelCategories.Name = "dataGridViewPersonnelCategories";
            this.dataGridViewPersonnelCategories.ReadOnly = true;
            this.dataGridViewPersonnelCategories.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewPersonnelCategories.Size = new System.Drawing.Size(175, 88);
            this.dataGridViewPersonnelCategories.TabIndex = 0;
            // 
            // btnPersonnelCategoriesDetail
            // 
            this.btnPersonnelCategoriesDetail.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnPersonnelCategoriesDetail.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnPersonnelCategoriesDetail.Location = new System.Drawing.Point(3, 97);
            this.btnPersonnelCategoriesDetail.Name = "btnPersonnelCategoriesDetail";
            this.btnPersonnelCategoriesDetail.Size = new System.Drawing.Size(175, 26);
            this.btnPersonnelCategoriesDetail.TabIndex = 1;
            this.btnPersonnelCategoriesDetail.Text = "Перейти к списку";
            this.btnPersonnelCategoriesDetail.UseVisualStyleBackColor = false;
            this.btnPersonnelCategoriesDetail.Click += new System.EventHandler(this.btnPersonnelCategoriesDetail_Click);
            // 
            // groupBoxStateHolidaysList
            // 
            this.groupBoxStateHolidaysList.Controls.Add(this.tableLayoutPanelStateHolidaysList);
            this.groupBoxStateHolidaysList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxStateHolidaysList.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBoxStateHolidaysList.ForeColor = System.Drawing.Color.White;
            this.groupBoxStateHolidaysList.Location = new System.Drawing.Point(3, 3);
            this.groupBoxStateHolidaysList.Name = "groupBoxStateHolidaysList";
            this.groupBoxStateHolidaysList.Size = new System.Drawing.Size(187, 154);
            this.groupBoxStateHolidaysList.TabIndex = 4;
            this.groupBoxStateHolidaysList.TabStop = false;
            this.groupBoxStateHolidaysList.Text = "Государственные праздники:";
            // 
            // tableLayoutPanelStateHolidaysList
            // 
            this.tableLayoutPanelStateHolidaysList.ColumnCount = 1;
            this.tableLayoutPanelStateHolidaysList.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelStateHolidaysList.Controls.Add(this.dataGridViewStateHolidaysList, 0, 0);
            this.tableLayoutPanelStateHolidaysList.Controls.Add(this.btnStateHolidaysList, 0, 1);
            this.tableLayoutPanelStateHolidaysList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelStateHolidaysList.Location = new System.Drawing.Point(3, 25);
            this.tableLayoutPanelStateHolidaysList.Name = "tableLayoutPanelStateHolidaysList";
            this.tableLayoutPanelStateHolidaysList.RowCount = 2;
            this.tableLayoutPanelStateHolidaysList.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 75F));
            this.tableLayoutPanelStateHolidaysList.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanelStateHolidaysList.Size = new System.Drawing.Size(181, 126);
            this.tableLayoutPanelStateHolidaysList.TabIndex = 0;
            // 
            // dataGridViewStateHolidaysList
            // 
            this.dataGridViewStateHolidaysList.AllowUserToAddRows = false;
            this.dataGridViewStateHolidaysList.AllowUserToDeleteRows = false;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.AntiqueWhite;
            this.dataGridViewStateHolidaysList.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridViewStateHolidaysList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewStateHolidaysList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Название_праздника,
            this.Дата});
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewStateHolidaysList.DefaultCellStyle = dataGridViewCellStyle7;
            this.dataGridViewStateHolidaysList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewStateHolidaysList.Location = new System.Drawing.Point(3, 3);
            this.dataGridViewStateHolidaysList.MultiSelect = false;
            this.dataGridViewStateHolidaysList.Name = "dataGridViewStateHolidaysList";
            this.dataGridViewStateHolidaysList.ReadOnly = true;
            this.dataGridViewStateHolidaysList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewStateHolidaysList.Size = new System.Drawing.Size(175, 88);
            this.dataGridViewStateHolidaysList.TabIndex = 0;
            // 
            // btnStateHolidaysList
            // 
            this.btnStateHolidaysList.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnStateHolidaysList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnStateHolidaysList.Location = new System.Drawing.Point(3, 97);
            this.btnStateHolidaysList.Name = "btnStateHolidaysList";
            this.btnStateHolidaysList.Size = new System.Drawing.Size(175, 26);
            this.btnStateHolidaysList.TabIndex = 1;
            this.btnStateHolidaysList.Text = "Перейти к списку";
            this.btnStateHolidaysList.UseVisualStyleBackColor = false;
            this.btnStateHolidaysList.Click += new System.EventHandler(this.btnStateHolidaysList_Click);
            // 
            // groupBoxHierarchyLevels
            // 
            this.groupBoxHierarchyLevels.Controls.Add(this.tableLayoutPanelHierarchyLevels);
            this.groupBoxHierarchyLevels.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxHierarchyLevels.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBoxHierarchyLevels.ForeColor = System.Drawing.Color.White;
            this.groupBoxHierarchyLevels.Location = new System.Drawing.Point(582, 3);
            this.groupBoxHierarchyLevels.Name = "groupBoxHierarchyLevels";
            this.groupBoxHierarchyLevels.Size = new System.Drawing.Size(187, 154);
            this.groupBoxHierarchyLevels.TabIndex = 5;
            this.groupBoxHierarchyLevels.TabStop = false;
            this.groupBoxHierarchyLevels.Text = "Иерархия подразделений:";
            // 
            // tableLayoutPanelHierarchyLevels
            // 
            this.tableLayoutPanelHierarchyLevels.ColumnCount = 1;
            this.tableLayoutPanelHierarchyLevels.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelHierarchyLevels.Controls.Add(this.dataGridViewHierarchyLevels, 0, 0);
            this.tableLayoutPanelHierarchyLevels.Controls.Add(this.btnHierarchyLevelsDetail, 0, 1);
            this.tableLayoutPanelHierarchyLevels.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelHierarchyLevels.Location = new System.Drawing.Point(3, 25);
            this.tableLayoutPanelHierarchyLevels.Name = "tableLayoutPanelHierarchyLevels";
            this.tableLayoutPanelHierarchyLevels.RowCount = 2;
            this.tableLayoutPanelHierarchyLevels.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 75F));
            this.tableLayoutPanelHierarchyLevels.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanelHierarchyLevels.Size = new System.Drawing.Size(181, 126);
            this.tableLayoutPanelHierarchyLevels.TabIndex = 0;
            // 
            // dataGridViewHierarchyLevels
            // 
            this.dataGridViewHierarchyLevels.AllowUserToAddRows = false;
            this.dataGridViewHierarchyLevels.AllowUserToDeleteRows = false;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.AntiqueWhite;
            this.dataGridViewHierarchyLevels.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle8;
            this.dataGridViewHierarchyLevels.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewHierarchyLevels.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Уровень_иерархии});
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewHierarchyLevels.DefaultCellStyle = dataGridViewCellStyle9;
            this.dataGridViewHierarchyLevels.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewHierarchyLevels.Location = new System.Drawing.Point(3, 3);
            this.dataGridViewHierarchyLevels.MultiSelect = false;
            this.dataGridViewHierarchyLevels.Name = "dataGridViewHierarchyLevels";
            this.dataGridViewHierarchyLevels.ReadOnly = true;
            this.dataGridViewHierarchyLevels.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewHierarchyLevels.Size = new System.Drawing.Size(175, 88);
            this.dataGridViewHierarchyLevels.TabIndex = 0;
            // 
            // btnHierarchyLevelsDetail
            // 
            this.btnHierarchyLevelsDetail.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnHierarchyLevelsDetail.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnHierarchyLevelsDetail.Location = new System.Drawing.Point(3, 97);
            this.btnHierarchyLevelsDetail.Name = "btnHierarchyLevelsDetail";
            this.btnHierarchyLevelsDetail.Size = new System.Drawing.Size(175, 26);
            this.btnHierarchyLevelsDetail.TabIndex = 1;
            this.btnHierarchyLevelsDetail.Text = "Перейти к списку";
            this.btnHierarchyLevelsDetail.UseVisualStyleBackColor = false;
            this.btnHierarchyLevelsDetail.Click += new System.EventHandler(this.btnHierarchyLevelsDetail_Click);
            // 
            // tableLayoutPanel_WindowHeader
            // 
            this.tableLayoutPanel_WindowHeader.ColumnCount = 4;
            this.tableLayoutPanel_WindowHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_WindowHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_WindowHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_WindowHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_WindowHeader.Controls.Add(this.lblOrganizationSettings, 0, 0);
            this.tableLayoutPanel_WindowHeader.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_WindowHeader.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel_WindowHeader.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.tableLayoutPanel_WindowHeader.Name = "tableLayoutPanel_WindowHeader";
            this.tableLayoutPanel_WindowHeader.RowCount = 1;
            this.tableLayoutPanel_WindowHeader.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_WindowHeader.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 41F));
            this.tableLayoutPanel_WindowHeader.Size = new System.Drawing.Size(772, 41);
            this.tableLayoutPanel_WindowHeader.TabIndex = 6;
            // 
            // lblOrganizationSettings
            // 
            this.lblOrganizationSettings.AutoSize = true;
            this.tableLayoutPanel_WindowHeader.SetColumnSpan(this.lblOrganizationSettings, 4);
            this.lblOrganizationSettings.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblOrganizationSettings.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblOrganizationSettings.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblOrganizationSettings.Location = new System.Drawing.Point(3, 0);
            this.lblOrganizationSettings.Name = "lblOrganizationSettings";
            this.lblOrganizationSettings.Size = new System.Drawing.Size(766, 41);
            this.lblOrganizationSettings.TabIndex = 19;
            this.lblOrganizationSettings.Text = "ОРГАНИЗАЦИОННЫЕ НАСТРОЙКИ";
            this.lblOrganizationSettings.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel_Programm
            // 
            this.tableLayoutPanel_Programm.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPanel_Programm.ColumnCount = 1;
            this.tableLayoutPanel_Programm.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Programm.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Programm.Controls.Add(this.lblProgramm, 0, 0);
            this.tableLayoutPanel_Programm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Programm.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel_Programm.Name = "tableLayoutPanel_Programm";
            this.tableLayoutPanel_Programm.RowCount = 1;
            this.tableLayoutPanel_Programm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Programm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Programm.Size = new System.Drawing.Size(778, 43);
            this.tableLayoutPanel_Programm.TabIndex = 8;
            // 
            // lblProgramm
            // 
            this.lblProgramm.AutoSize = true;
            this.lblProgramm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblProgramm.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblProgramm.ForeColor = System.Drawing.Color.White;
            this.lblProgramm.Location = new System.Drawing.Point(3, 0);
            this.lblProgramm.Name = "lblProgramm";
            this.lblProgramm.Size = new System.Drawing.Size(772, 43);
            this.lblProgramm.TabIndex = 0;
            this.lblProgramm.Text = "ФОРМИРОВАНИЕ И ВЕДЕНИЕ ГРАФИКА ОТПУСКОВ СОТРУДНИКОВ";
            this.lblProgramm.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // Название_праздника
            // 
            this.Название_праздника.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Название_праздника.DataPropertyName = "Название праздника";
            this.Название_праздника.HeaderText = "Название праздника";
            this.Название_праздника.Name = "Название_праздника";
            this.Название_праздника.ReadOnly = true;
            // 
            // Дата
            // 
            this.Дата.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Дата.DataPropertyName = "Дата";
            this.Дата.HeaderText = "Дата";
            this.Дата.Name = "Дата";
            this.Дата.ReadOnly = true;
            // 
            // Полное_наименование
            // 
            this.Полное_наименование.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Полное_наименование.DataPropertyName = "Полное наименование";
            this.Полное_наименование.HeaderText = "Полное наименование";
            this.Полное_наименование.Name = "Полное_наименование";
            this.Полное_наименование.ReadOnly = true;
            // 
            // Сокращенное_наименование
            // 
            this.Сокращенное_наименование.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Сокращенное_наименование.DataPropertyName = "Сокращенное наименование";
            this.Сокращенное_наименование.HeaderText = "Сокращенное наименование";
            this.Сокращенное_наименование.Name = "Сокращенное_наименование";
            this.Сокращенное_наименование.ReadOnly = true;
            // 
            // Уровень_иерархии
            // 
            this.Уровень_иерархии.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Уровень_иерархии.DataPropertyName = "Уровень иерархии";
            this.Уровень_иерархии.HeaderText = "Уровень иерархии";
            this.Уровень_иерархии.Name = "Уровень_иерархии";
            this.Уровень_иерархии.ReadOnly = true;
            // 
            // Сокр_наим
            // 
            this.Сокр_наим.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Сокр_наим.DataPropertyName = "Сокращенное наименование";
            this.Сокр_наим.HeaderText = "Сокращенное наименование";
            this.Сокр_наим.Name = "Сокр_наим";
            this.Сокр_наим.ReadOnly = true;
            // 
            // ИНН
            // 
            this.ИНН.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ИНН.DataPropertyName = "ИНН";
            this.ИНН.HeaderText = "ИНН";
            this.ИНН.Name = "ИНН";
            this.ИНН.ReadOnly = true;
            // 
            // КПП
            // 
            this.КПП.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.КПП.DataPropertyName = "КПП";
            this.КПП.HeaderText = "КПП";
            this.КПП.Name = "КПП";
            this.КПП.ReadOnly = true;
            // 
            // ОКПО
            // 
            this.ОКПО.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ОКПО.DataPropertyName = "ОКПО";
            this.ОКПО.HeaderText = "ОКПО";
            this.ОКПО.Name = "ОКПО";
            this.ОКПО.ReadOnly = true;
            // 
            // Полн_наим
            // 
            this.Полн_наим.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Полн_наим.DataPropertyName = "Полное наименование";
            this.Полн_наим.HeaderText = "Полное наименование";
            this.Полн_наим.Name = "Полн_наим";
            this.Полн_наим.ReadOnly = true;
            // 
            // Юридический_адрес
            // 
            this.Юридический_адрес.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Юридический_адрес.DataPropertyName = "Юридический адрес";
            this.Юридический_адрес.HeaderText = "Юридический адрес";
            this.Юридический_адрес.Name = "Юридический_адрес";
            this.Юридический_адрес.ReadOnly = true;
            // 
            // Фактический_адрес
            // 
            this.Фактический_адрес.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Фактический_адрес.DataPropertyName = "Фактический адрес";
            this.Фактический_адрес.HeaderText = "Фактический_адрес";
            this.Фактический_адрес.Name = "Фактический_адрес";
            this.Фактический_адрес.ReadOnly = true;
            // 
            // OrganizationSettingsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 497);
            this.Controls.Add(this.tableLayoutPanel_AllForm);
            this.Name = "OrganizationSettingsForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ОРГАНИЗАЦИОННЫЕ НАСТРОЙКИ";
            this.Load += new System.EventHandler(this.OrganizationSettingsForm_Load);
            this.tableLayoutPanel_AllForm.ResumeLayout(false);
            this.tableLayoutPanel_Company.ResumeLayout(false);
            this.tableLayoutPanel_Company.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCompany)).EndInit();
            this.tableLayoutPanel_OrganizationSettings.ResumeLayout(false);
            this.tableLayoutPanel_Working_field.ResumeLayout(false);
            this.groupBoxCompanyInformation.ResumeLayout(false);
            this.tableLayoutPanelCompanyInformation.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCompanyInformation)).EndInit();
            this.groupBoxFunctions.ResumeLayout(false);
            this.tableLayoutPanelFunctions.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewFunctions)).EndInit();
            this.groupBoxPersonnelCategories.ResumeLayout(false);
            this.tableLayoutPanelPersonnelCategories.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPersonnelCategories)).EndInit();
            this.groupBoxStateHolidaysList.ResumeLayout(false);
            this.tableLayoutPanelStateHolidaysList.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewStateHolidaysList)).EndInit();
            this.groupBoxHierarchyLevels.ResumeLayout(false);
            this.tableLayoutPanelHierarchyLevels.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewHierarchyLevels)).EndInit();
            this.tableLayoutPanel_WindowHeader.ResumeLayout(false);
            this.tableLayoutPanel_WindowHeader.PerformLayout();
            this.tableLayoutPanel_Programm.ResumeLayout(false);
            this.tableLayoutPanel_Programm.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_AllForm;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Company;
        private System.Windows.Forms.PictureBox pictureBoxCompany;
        private System.Windows.Forms.Label lblCompany;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_OrganizationSettings;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Working_field;
        private System.Windows.Forms.GroupBox groupBoxFunctions;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelFunctions;
        private System.Windows.Forms.DataGridView dataGridViewFunctions;
        private System.Windows.Forms.Button btnFunctionsDetail;
        private System.Windows.Forms.GroupBox groupBoxPersonnelCategories;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelPersonnelCategories;
        private System.Windows.Forms.DataGridView dataGridViewPersonnelCategories;
        private System.Windows.Forms.Button btnPersonnelCategoriesDetail;
        private System.Windows.Forms.GroupBox groupBoxHierarchyLevels;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelHierarchyLevels;
        private System.Windows.Forms.DataGridView dataGridViewHierarchyLevels;
        private System.Windows.Forms.Button btnHierarchyLevelsDetail;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_WindowHeader;
        private System.Windows.Forms.Label lblOrganizationSettings;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Programm;
        private System.Windows.Forms.Label lblProgramm;
        private System.Windows.Forms.GroupBox groupBoxStateHolidaysList;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelStateHolidaysList;
        private System.Windows.Forms.DataGridView dataGridViewStateHolidaysList;
        private System.Windows.Forms.Button btnStateHolidaysList;
        private System.Windows.Forms.GroupBox groupBoxCompanyInformation;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelCompanyInformation;
        private System.Windows.Forms.DataGridView dataGridViewCompanyInformation;
        private System.Windows.Forms.Button btnCompanyInformation;
        private System.Windows.Forms.DataGridViewTextBoxColumn должность;
        private System.Windows.Forms.DataGridViewTextBoxColumn Название_праздника;
        private System.Windows.Forms.DataGridViewTextBoxColumn Дата;
        private System.Windows.Forms.DataGridViewTextBoxColumn Полное_наименование;
        private System.Windows.Forms.DataGridViewTextBoxColumn Сокращенное_наименование;
        private System.Windows.Forms.DataGridViewTextBoxColumn Уровень_иерархии;
        private System.Windows.Forms.DataGridViewTextBoxColumn Сокр_наим;
        private System.Windows.Forms.DataGridViewTextBoxColumn ИНН;
        private System.Windows.Forms.DataGridViewTextBoxColumn КПП;
        private System.Windows.Forms.DataGridViewTextBoxColumn ОКПО;
        private System.Windows.Forms.DataGridViewTextBoxColumn Полн_наим;
        private System.Windows.Forms.DataGridViewTextBoxColumn Юридический_адрес;
        private System.Windows.Forms.DataGridViewTextBoxColumn Фактический_адрес;
    }
}