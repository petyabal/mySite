﻿namespace VacationScheduleCreator
{
    partial class EmployeesVacationsDetailForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EmployeesVacationsDetailForm));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tableLayoutPanel_AllForm = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel_Company = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBoxCompany = new System.Windows.Forms.PictureBox();
            this.lblCompany = new System.Windows.Forms.Label();
            this.tableLayoutPanel_Employees = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel_Working_field = new System.Windows.Forms.TableLayoutPanel();
            this.tabControlEmployeesVacations = new System.Windows.Forms.TabControl();
            this.tabPageEmployeesVacations = new System.Windows.Forms.TabPage();
            this.tableLayoutPanelEmployeesVacations = new System.Windows.Forms.TableLayoutPanel();
            this.btnOpenVacationLogConstructor = new System.Windows.Forms.Button();
            this.dataGridViewVacationLog = new System.Windows.Forms.DataGridView();
            this.dataGridViewVacationsSchedulesList = new System.Windows.Forms.DataGridView();
            this.lblVacationScheduleList = new System.Windows.Forms.Label();
            this.btnOpenVacationScheduleConstructior = new System.Windows.Forms.Button();
            this.dataGridViewEmployeesVacations = new System.Windows.Forms.DataGridView();
            this.lblVacationSchedule = new System.Windows.Forms.Label();
            this.lblVacationLog = new System.Windows.Forms.Label();
            this.tabPageVacationSchedules = new System.Windows.Forms.TabPage();
            this.tableLayoutPanelVacationSchedules = new System.Windows.Forms.TableLayoutPanel();
            this.btnAddVacationSchedule = new System.Windows.Forms.Button();
            this.DeleteVacationSchedule = new System.Windows.Forms.Button();
            this.btnChangeVacationSchedule = new System.Windows.Forms.Button();
            this.dataGridViewVacationSchedules = new System.Windows.Forms.DataGridView();
            this.tabPageVacationTypes = new System.Windows.Forms.TabPage();
            this.tableLayoutPanelVacationTypes = new System.Windows.Forms.TableLayoutPanel();
            this.btnAddVacationType = new System.Windows.Forms.Button();
            this.btnDeleteVacationType = new System.Windows.Forms.Button();
            this.btnChangeVacationType = new System.Windows.Forms.Button();
            this.dataGridViewVacationTypes = new System.Windows.Forms.DataGridView();
            this.tabPageSpendingOfVacations = new System.Windows.Forms.TabPage();
            this.tableLayoutPanelSpendingOfVacations = new System.Windows.Forms.TableLayoutPanel();
            this.btnAddSpendingOfVacationInformation = new System.Windows.Forms.Button();
            this.btnChangeSpendingOfVacationInformation = new System.Windows.Forms.Button();
            this.btnDeleteSpendingOfVacationInformation = new System.Windows.Forms.Button();
            this.dataGridViewSpendingOfVacations = new System.Windows.Forms.DataGridView();
            this.tabPageEmployeesPaidTravel = new System.Windows.Forms.TabPage();
            this.tableLayoutPanelEmployeesPaidTravel = new System.Windows.Forms.TableLayoutPanel();
            this.btnAddEmployeesPaidTravel = new System.Windows.Forms.Button();
            this.btnChangeEmployeesPaidTravel = new System.Windows.Forms.Button();
            this.btnDeleteEmployeesPaidTravel = new System.Windows.Forms.Button();
            this.dataGridViewEmployeesPaidTravel = new System.Windows.Forms.DataGridView();
            this.tableLayoutPanel_WindowHeader = new System.Windows.Forms.TableLayoutPanel();
            this.lblEmployeesVacations = new System.Windows.Forms.Label();
            this.tableLayoutPanel_Programm = new System.Windows.Forms.TableLayoutPanel();
            this.lblProgramm = new System.Windows.Forms.Label();
            this.tableLayoutPanel_AllForm.SuspendLayout();
            this.tableLayoutPanel_Company.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCompany)).BeginInit();
            this.tableLayoutPanel_Employees.SuspendLayout();
            this.tableLayoutPanel_Working_field.SuspendLayout();
            this.tabControlEmployeesVacations.SuspendLayout();
            this.tabPageEmployeesVacations.SuspendLayout();
            this.tableLayoutPanelEmployeesVacations.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVacationLog)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVacationsSchedulesList)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewEmployeesVacations)).BeginInit();
            this.tabPageVacationSchedules.SuspendLayout();
            this.tableLayoutPanelVacationSchedules.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVacationSchedules)).BeginInit();
            this.tabPageVacationTypes.SuspendLayout();
            this.tableLayoutPanelVacationTypes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVacationTypes)).BeginInit();
            this.tabPageSpendingOfVacations.SuspendLayout();
            this.tableLayoutPanelSpendingOfVacations.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSpendingOfVacations)).BeginInit();
            this.tabPageEmployeesPaidTravel.SuspendLayout();
            this.tableLayoutPanelEmployeesPaidTravel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewEmployeesPaidTravel)).BeginInit();
            this.tableLayoutPanel_WindowHeader.SuspendLayout();
            this.tableLayoutPanel_Programm.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel_AllForm
            // 
            this.tableLayoutPanel_AllForm.ColumnCount = 1;
            this.tableLayoutPanel_AllForm.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_AllForm.Controls.Add(this.tableLayoutPanel_Company, 0, 1);
            this.tableLayoutPanel_AllForm.Controls.Add(this.tableLayoutPanel_Employees, 0, 2);
            this.tableLayoutPanel_AllForm.Controls.Add(this.tableLayoutPanel_Programm, 0, 0);
            this.tableLayoutPanel_AllForm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_AllForm.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel_AllForm.Name = "tableLayoutPanel_AllForm";
            this.tableLayoutPanel_AllForm.RowCount = 3;
            this.tableLayoutPanel_AllForm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel_AllForm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tableLayoutPanel_AllForm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 75F));
            this.tableLayoutPanel_AllForm.Size = new System.Drawing.Size(784, 497);
            this.tableLayoutPanel_AllForm.TabIndex = 8;
            // 
            // tableLayoutPanel_Company
            // 
            this.tableLayoutPanel_Company.BackColor = System.Drawing.SystemColors.HotTrack;
            this.tableLayoutPanel_Company.ColumnCount = 2;
            this.tableLayoutPanel_Company.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel_Company.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.tableLayoutPanel_Company.Controls.Add(this.pictureBoxCompany, 0, 1);
            this.tableLayoutPanel_Company.Controls.Add(this.lblCompany, 1, 1);
            this.tableLayoutPanel_Company.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Company.Location = new System.Drawing.Point(3, 52);
            this.tableLayoutPanel_Company.Name = "tableLayoutPanel_Company";
            this.tableLayoutPanel_Company.RowCount = 3;
            this.tableLayoutPanel_Company.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel_Company.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tableLayoutPanel_Company.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel_Company.Size = new System.Drawing.Size(778, 68);
            this.tableLayoutPanel_Company.TabIndex = 7;
            // 
            // pictureBoxCompany
            // 
            this.pictureBoxCompany.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxCompany.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxCompany.Image")));
            this.pictureBoxCompany.Location = new System.Drawing.Point(3, 6);
            this.pictureBoxCompany.Name = "pictureBoxCompany";
            this.pictureBoxCompany.Size = new System.Drawing.Size(227, 55);
            this.pictureBoxCompany.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxCompany.TabIndex = 3;
            this.pictureBoxCompany.TabStop = false;
            // 
            // lblCompany
            // 
            this.lblCompany.AutoSize = true;
            this.lblCompany.BackColor = System.Drawing.SystemColors.HotTrack;
            this.lblCompany.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCompany.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblCompany.ForeColor = System.Drawing.Color.White;
            this.lblCompany.Location = new System.Drawing.Point(236, 3);
            this.lblCompany.Name = "lblCompany";
            this.lblCompany.Size = new System.Drawing.Size(539, 61);
            this.lblCompany.TabIndex = 2;
            this.lblCompany.Text = "МЕЖРЕГИОНАЛЬНАЯ РАСПРЕДЕЛИТЕЛЬНАЯ СЕТЕВАЯ КОМПАНИЯ СЕВЕРО-ЗАПАДА";
            this.lblCompany.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel_Employees
            // 
            this.tableLayoutPanel_Employees.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPanel_Employees.ColumnCount = 1;
            this.tableLayoutPanel_Employees.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_Employees.Controls.Add(this.tableLayoutPanel_Working_field, 0, 1);
            this.tableLayoutPanel_Employees.Controls.Add(this.tableLayoutPanel_WindowHeader, 0, 0);
            this.tableLayoutPanel_Employees.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Employees.Location = new System.Drawing.Point(3, 126);
            this.tableLayoutPanel_Employees.Name = "tableLayoutPanel_Employees";
            this.tableLayoutPanel_Employees.RowCount = 2;
            this.tableLayoutPanel_Employees.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12F));
            this.tableLayoutPanel_Employees.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 88F));
            this.tableLayoutPanel_Employees.Size = new System.Drawing.Size(778, 368);
            this.tableLayoutPanel_Employees.TabIndex = 6;
            // 
            // tableLayoutPanel_Working_field
            // 
            this.tableLayoutPanel_Working_field.ColumnCount = 1;
            this.tableLayoutPanel_Working_field.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_Working_field.Controls.Add(this.tabControlEmployeesVacations, 0, 0);
            this.tableLayoutPanel_Working_field.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Working_field.Location = new System.Drawing.Point(3, 44);
            this.tableLayoutPanel_Working_field.Margin = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.tableLayoutPanel_Working_field.Name = "tableLayoutPanel_Working_field";
            this.tableLayoutPanel_Working_field.RowCount = 1;
            this.tableLayoutPanel_Working_field.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_Working_field.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 321F));
            this.tableLayoutPanel_Working_field.Size = new System.Drawing.Size(772, 321);
            this.tableLayoutPanel_Working_field.TabIndex = 7;
            // 
            // tabControlEmployeesVacations
            // 
            this.tabControlEmployeesVacations.Controls.Add(this.tabPageEmployeesVacations);
            this.tabControlEmployeesVacations.Controls.Add(this.tabPageVacationSchedules);
            this.tabControlEmployeesVacations.Controls.Add(this.tabPageVacationTypes);
            this.tabControlEmployeesVacations.Controls.Add(this.tabPageSpendingOfVacations);
            this.tabControlEmployeesVacations.Controls.Add(this.tabPageEmployeesPaidTravel);
            this.tabControlEmployeesVacations.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlEmployeesVacations.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tabControlEmployeesVacations.Location = new System.Drawing.Point(3, 3);
            this.tabControlEmployeesVacations.Name = "tabControlEmployeesVacations";
            this.tabControlEmployeesVacations.SelectedIndex = 0;
            this.tabControlEmployeesVacations.Size = new System.Drawing.Size(766, 315);
            this.tabControlEmployeesVacations.TabIndex = 2;
            // 
            // tabPageEmployeesVacations
            // 
            this.tabPageEmployeesVacations.Controls.Add(this.tableLayoutPanelEmployeesVacations);
            this.tabPageEmployeesVacations.Location = new System.Drawing.Point(4, 32);
            this.tabPageEmployeesVacations.Name = "tabPageEmployeesVacations";
            this.tabPageEmployeesVacations.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageEmployeesVacations.Size = new System.Drawing.Size(758, 279);
            this.tabPageEmployeesVacations.TabIndex = 0;
            this.tabPageEmployeesVacations.Text = "Графики отпусков";
            this.tabPageEmployeesVacations.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanelEmployeesVacations
            // 
            this.tableLayoutPanelEmployeesVacations.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPanelEmployeesVacations.ColumnCount = 2;
            this.tableLayoutPanelEmployeesVacations.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanelEmployeesVacations.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanelEmployeesVacations.Controls.Add(this.btnOpenVacationLogConstructor, 1, 4);
            this.tableLayoutPanelEmployeesVacations.Controls.Add(this.dataGridViewVacationLog, 1, 3);
            this.tableLayoutPanelEmployeesVacations.Controls.Add(this.dataGridViewVacationsSchedulesList, 0, 1);
            this.tableLayoutPanelEmployeesVacations.Controls.Add(this.lblVacationScheduleList, 0, 0);
            this.tableLayoutPanelEmployeesVacations.Controls.Add(this.btnOpenVacationScheduleConstructior, 0, 4);
            this.tableLayoutPanelEmployeesVacations.Controls.Add(this.dataGridViewEmployeesVacations, 0, 3);
            this.tableLayoutPanelEmployeesVacations.Controls.Add(this.lblVacationSchedule, 0, 2);
            this.tableLayoutPanelEmployeesVacations.Controls.Add(this.lblVacationLog, 1, 2);
            this.tableLayoutPanelEmployeesVacations.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelEmployeesVacations.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanelEmployeesVacations.Name = "tableLayoutPanelEmployeesVacations";
            this.tableLayoutPanelEmployeesVacations.RowCount = 5;
            this.tableLayoutPanelEmployeesVacations.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanelEmployeesVacations.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanelEmployeesVacations.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanelEmployeesVacations.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 48F));
            this.tableLayoutPanelEmployeesVacations.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12F));
            this.tableLayoutPanelEmployeesVacations.Size = new System.Drawing.Size(752, 273);
            this.tableLayoutPanelEmployeesVacations.TabIndex = 0;
            // 
            // btnOpenVacationLogConstructor
            // 
            this.btnOpenVacationLogConstructor.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnOpenVacationLogConstructor.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnOpenVacationLogConstructor.ForeColor = System.Drawing.Color.White;
            this.btnOpenVacationLogConstructor.Location = new System.Drawing.Point(454, 242);
            this.btnOpenVacationLogConstructor.Name = "btnOpenVacationLogConstructor";
            this.btnOpenVacationLogConstructor.Size = new System.Drawing.Size(295, 28);
            this.btnOpenVacationLogConstructor.TabIndex = 12;
            this.btnOpenVacationLogConstructor.Text = "Открыть конструктор журнала ведения отпусков";
            this.btnOpenVacationLogConstructor.UseVisualStyleBackColor = false;
            this.btnOpenVacationLogConstructor.Click += new System.EventHandler(this.btnOpenVacationLogConstructor_Click);
            // 
            // dataGridViewVacationLog
            // 
            this.dataGridViewVacationLog.AllowUserToAddRows = false;
            this.dataGridViewVacationLog.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.AntiqueWhite;
            this.dataGridViewVacationLog.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewVacationLog.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewVacationLog.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewVacationLog.Location = new System.Drawing.Point(454, 111);
            this.dataGridViewVacationLog.MultiSelect = false;
            this.dataGridViewVacationLog.Name = "dataGridViewVacationLog";
            this.dataGridViewVacationLog.ReadOnly = true;
            this.dataGridViewVacationLog.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewVacationLog.Size = new System.Drawing.Size(295, 125);
            this.dataGridViewVacationLog.TabIndex = 11;
            // 
            // dataGridViewVacationsSchedulesList
            // 
            this.dataGridViewVacationsSchedulesList.AllowUserToAddRows = false;
            this.dataGridViewVacationsSchedulesList.AllowUserToDeleteRows = false;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.AntiqueWhite;
            this.dataGridViewVacationsSchedulesList.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewVacationsSchedulesList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tableLayoutPanelEmployeesVacations.SetColumnSpan(this.dataGridViewVacationsSchedulesList, 2);
            this.dataGridViewVacationsSchedulesList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewVacationsSchedulesList.Location = new System.Drawing.Point(3, 30);
            this.dataGridViewVacationsSchedulesList.MultiSelect = false;
            this.dataGridViewVacationsSchedulesList.Name = "dataGridViewVacationsSchedulesList";
            this.dataGridViewVacationsSchedulesList.ReadOnly = true;
            this.dataGridViewVacationsSchedulesList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewVacationsSchedulesList.Size = new System.Drawing.Size(746, 48);
            this.dataGridViewVacationsSchedulesList.TabIndex = 9;
            this.dataGridViewVacationsSchedulesList.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewVacationsSchedulesList_CellClick);
            // 
            // lblVacationScheduleList
            // 
            this.lblVacationScheduleList.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblVacationScheduleList.AutoSize = true;
            this.lblVacationScheduleList.Location = new System.Drawing.Point(3, 4);
            this.lblVacationScheduleList.Name = "lblVacationScheduleList";
            this.lblVacationScheduleList.Size = new System.Drawing.Size(227, 23);
            this.lblVacationScheduleList.TabIndex = 8;
            this.lblVacationScheduleList.Text = "Перечень графиков отпусков:";
            // 
            // btnOpenVacationScheduleConstructior
            // 
            this.btnOpenVacationScheduleConstructior.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnOpenVacationScheduleConstructior.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnOpenVacationScheduleConstructior.ForeColor = System.Drawing.Color.White;
            this.btnOpenVacationScheduleConstructior.Location = new System.Drawing.Point(3, 242);
            this.btnOpenVacationScheduleConstructior.Name = "btnOpenVacationScheduleConstructior";
            this.btnOpenVacationScheduleConstructior.Size = new System.Drawing.Size(445, 28);
            this.btnOpenVacationScheduleConstructior.TabIndex = 6;
            this.btnOpenVacationScheduleConstructior.Text = "Открыть конструктор графика отпусков";
            this.btnOpenVacationScheduleConstructior.UseVisualStyleBackColor = false;
            this.btnOpenVacationScheduleConstructior.Click += new System.EventHandler(this.btnOpenVacationScheduleConstructior_Click);
            // 
            // dataGridViewEmployeesVacations
            // 
            this.dataGridViewEmployeesVacations.AllowUserToAddRows = false;
            this.dataGridViewEmployeesVacations.AllowUserToDeleteRows = false;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.AntiqueWhite;
            this.dataGridViewEmployeesVacations.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridViewEmployeesVacations.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewEmployeesVacations.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewEmployeesVacations.Location = new System.Drawing.Point(3, 111);
            this.dataGridViewEmployeesVacations.MultiSelect = false;
            this.dataGridViewEmployeesVacations.Name = "dataGridViewEmployeesVacations";
            this.dataGridViewEmployeesVacations.ReadOnly = true;
            this.dataGridViewEmployeesVacations.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewEmployeesVacations.Size = new System.Drawing.Size(445, 125);
            this.dataGridViewEmployeesVacations.TabIndex = 4;
            // 
            // lblVacationSchedule
            // 
            this.lblVacationSchedule.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblVacationSchedule.AutoSize = true;
            this.lblVacationSchedule.Location = new System.Drawing.Point(3, 85);
            this.lblVacationSchedule.Name = "lblVacationSchedule";
            this.lblVacationSchedule.Size = new System.Drawing.Size(136, 23);
            this.lblVacationSchedule.TabIndex = 7;
            this.lblVacationSchedule.Text = "График отпусков:";
            // 
            // lblVacationLog
            // 
            this.lblVacationLog.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblVacationLog.AutoSize = true;
            this.lblVacationLog.Location = new System.Drawing.Point(454, 85);
            this.lblVacationLog.Name = "lblVacationLog";
            this.lblVacationLog.Size = new System.Drawing.Size(203, 23);
            this.lblVacationLog.TabIndex = 10;
            this.lblVacationLog.Text = "Журнал ведения отпусков:";
            // 
            // tabPageVacationSchedules
            // 
            this.tabPageVacationSchedules.Controls.Add(this.tableLayoutPanelVacationSchedules);
            this.tabPageVacationSchedules.Location = new System.Drawing.Point(4, 32);
            this.tabPageVacationSchedules.Name = "tabPageVacationSchedules";
            this.tabPageVacationSchedules.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageVacationSchedules.Size = new System.Drawing.Size(758, 279);
            this.tabPageVacationSchedules.TabIndex = 1;
            this.tabPageVacationSchedules.Text = "Перечень графиков отпусков";
            this.tabPageVacationSchedules.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanelVacationSchedules
            // 
            this.tableLayoutPanelVacationSchedules.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPanelVacationSchedules.ColumnCount = 3;
            this.tableLayoutPanelVacationSchedules.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanelVacationSchedules.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanelVacationSchedules.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanelVacationSchedules.Controls.Add(this.btnAddVacationSchedule, 0, 1);
            this.tableLayoutPanelVacationSchedules.Controls.Add(this.DeleteVacationSchedule, 0, 1);
            this.tableLayoutPanelVacationSchedules.Controls.Add(this.btnChangeVacationSchedule, 0, 1);
            this.tableLayoutPanelVacationSchedules.Controls.Add(this.dataGridViewVacationSchedules, 0, 0);
            this.tableLayoutPanelVacationSchedules.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelVacationSchedules.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanelVacationSchedules.Name = "tableLayoutPanelVacationSchedules";
            this.tableLayoutPanelVacationSchedules.RowCount = 2;
            this.tableLayoutPanelVacationSchedules.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 88F));
            this.tableLayoutPanelVacationSchedules.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12F));
            this.tableLayoutPanelVacationSchedules.Size = new System.Drawing.Size(752, 273);
            this.tableLayoutPanelVacationSchedules.TabIndex = 0;
            // 
            // btnAddVacationSchedule
            // 
            this.btnAddVacationSchedule.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnAddVacationSchedule.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnAddVacationSchedule.ForeColor = System.Drawing.Color.White;
            this.btnAddVacationSchedule.Location = new System.Drawing.Point(3, 243);
            this.btnAddVacationSchedule.Name = "btnAddVacationSchedule";
            this.btnAddVacationSchedule.Size = new System.Drawing.Size(244, 27);
            this.btnAddVacationSchedule.TabIndex = 9;
            this.btnAddVacationSchedule.Text = "Добавить график отпусков";
            this.btnAddVacationSchedule.UseVisualStyleBackColor = false;
            this.btnAddVacationSchedule.Click += new System.EventHandler(this.btnAddVacationSchedule_Click);
            // 
            // DeleteVacationSchedule
            // 
            this.DeleteVacationSchedule.BackColor = System.Drawing.SystemColors.HotTrack;
            this.DeleteVacationSchedule.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DeleteVacationSchedule.ForeColor = System.Drawing.Color.White;
            this.DeleteVacationSchedule.Location = new System.Drawing.Point(503, 243);
            this.DeleteVacationSchedule.Name = "DeleteVacationSchedule";
            this.DeleteVacationSchedule.Size = new System.Drawing.Size(246, 27);
            this.DeleteVacationSchedule.TabIndex = 8;
            this.DeleteVacationSchedule.Text = "Удалить график отпусков";
            this.DeleteVacationSchedule.UseVisualStyleBackColor = false;
            this.DeleteVacationSchedule.Click += new System.EventHandler(this.DeleteVacationSchedule_Click);
            // 
            // btnChangeVacationSchedule
            // 
            this.btnChangeVacationSchedule.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnChangeVacationSchedule.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnChangeVacationSchedule.ForeColor = System.Drawing.Color.White;
            this.btnChangeVacationSchedule.Location = new System.Drawing.Point(253, 243);
            this.btnChangeVacationSchedule.Name = "btnChangeVacationSchedule";
            this.btnChangeVacationSchedule.Size = new System.Drawing.Size(244, 27);
            this.btnChangeVacationSchedule.TabIndex = 7;
            this.btnChangeVacationSchedule.Text = "Редактировать сведения о графике";
            this.btnChangeVacationSchedule.UseVisualStyleBackColor = false;
            this.btnChangeVacationSchedule.Click += new System.EventHandler(this.btnChangeVacationSchedule_Click);
            // 
            // dataGridViewVacationSchedules
            // 
            this.dataGridViewVacationSchedules.AllowUserToAddRows = false;
            this.dataGridViewVacationSchedules.AllowUserToDeleteRows = false;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.AntiqueWhite;
            this.dataGridViewVacationSchedules.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridViewVacationSchedules.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tableLayoutPanelVacationSchedules.SetColumnSpan(this.dataGridViewVacationSchedules, 3);
            this.dataGridViewVacationSchedules.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewVacationSchedules.Location = new System.Drawing.Point(3, 3);
            this.dataGridViewVacationSchedules.MultiSelect = false;
            this.dataGridViewVacationSchedules.Name = "dataGridViewVacationSchedules";
            this.dataGridViewVacationSchedules.ReadOnly = true;
            this.dataGridViewVacationSchedules.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewVacationSchedules.Size = new System.Drawing.Size(746, 234);
            this.dataGridViewVacationSchedules.TabIndex = 5;
            // 
            // tabPageVacationTypes
            // 
            this.tabPageVacationTypes.Controls.Add(this.tableLayoutPanelVacationTypes);
            this.tabPageVacationTypes.Location = new System.Drawing.Point(4, 32);
            this.tabPageVacationTypes.Name = "tabPageVacationTypes";
            this.tabPageVacationTypes.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageVacationTypes.Size = new System.Drawing.Size(758, 279);
            this.tabPageVacationTypes.TabIndex = 2;
            this.tabPageVacationTypes.Text = "Виды отпусков";
            this.tabPageVacationTypes.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanelVacationTypes
            // 
            this.tableLayoutPanelVacationTypes.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPanelVacationTypes.ColumnCount = 3;
            this.tableLayoutPanelVacationTypes.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanelVacationTypes.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanelVacationTypes.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanelVacationTypes.Controls.Add(this.btnAddVacationType, 0, 1);
            this.tableLayoutPanelVacationTypes.Controls.Add(this.btnDeleteVacationType, 0, 1);
            this.tableLayoutPanelVacationTypes.Controls.Add(this.btnChangeVacationType, 0, 1);
            this.tableLayoutPanelVacationTypes.Controls.Add(this.dataGridViewVacationTypes, 0, 0);
            this.tableLayoutPanelVacationTypes.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelVacationTypes.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanelVacationTypes.Name = "tableLayoutPanelVacationTypes";
            this.tableLayoutPanelVacationTypes.RowCount = 2;
            this.tableLayoutPanelVacationTypes.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 88F));
            this.tableLayoutPanelVacationTypes.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12F));
            this.tableLayoutPanelVacationTypes.Size = new System.Drawing.Size(752, 273);
            this.tableLayoutPanelVacationTypes.TabIndex = 0;
            // 
            // btnAddVacationType
            // 
            this.btnAddVacationType.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnAddVacationType.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnAddVacationType.ForeColor = System.Drawing.Color.White;
            this.btnAddVacationType.Location = new System.Drawing.Point(3, 243);
            this.btnAddVacationType.Name = "btnAddVacationType";
            this.btnAddVacationType.Size = new System.Drawing.Size(244, 27);
            this.btnAddVacationType.TabIndex = 12;
            this.btnAddVacationType.Text = "Добавить вид отпуска";
            this.btnAddVacationType.UseVisualStyleBackColor = false;
            this.btnAddVacationType.Click += new System.EventHandler(this.btnAddVacationType_Click);
            // 
            // btnDeleteVacationType
            // 
            this.btnDeleteVacationType.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnDeleteVacationType.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnDeleteVacationType.ForeColor = System.Drawing.Color.White;
            this.btnDeleteVacationType.Location = new System.Drawing.Point(503, 243);
            this.btnDeleteVacationType.Name = "btnDeleteVacationType";
            this.btnDeleteVacationType.Size = new System.Drawing.Size(246, 27);
            this.btnDeleteVacationType.TabIndex = 11;
            this.btnDeleteVacationType.Text = "Удалить вид отпуска";
            this.btnDeleteVacationType.UseVisualStyleBackColor = false;
            this.btnDeleteVacationType.Click += new System.EventHandler(this.btnDeleteVacationType_Click);
            // 
            // btnChangeVacationType
            // 
            this.btnChangeVacationType.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnChangeVacationType.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnChangeVacationType.ForeColor = System.Drawing.Color.White;
            this.btnChangeVacationType.Location = new System.Drawing.Point(253, 243);
            this.btnChangeVacationType.Name = "btnChangeVacationType";
            this.btnChangeVacationType.Size = new System.Drawing.Size(244, 27);
            this.btnChangeVacationType.TabIndex = 10;
            this.btnChangeVacationType.Text = "Редактировать вид отпуска";
            this.btnChangeVacationType.UseVisualStyleBackColor = false;
            this.btnChangeVacationType.Click += new System.EventHandler(this.btnChangeVacationType_Click);
            // 
            // dataGridViewVacationTypes
            // 
            this.dataGridViewVacationTypes.AllowUserToAddRows = false;
            this.dataGridViewVacationTypes.AllowUserToDeleteRows = false;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.AntiqueWhite;
            this.dataGridViewVacationTypes.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridViewVacationTypes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tableLayoutPanelVacationTypes.SetColumnSpan(this.dataGridViewVacationTypes, 3);
            this.dataGridViewVacationTypes.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewVacationTypes.Location = new System.Drawing.Point(3, 3);
            this.dataGridViewVacationTypes.MultiSelect = false;
            this.dataGridViewVacationTypes.Name = "dataGridViewVacationTypes";
            this.dataGridViewVacationTypes.ReadOnly = true;
            this.dataGridViewVacationTypes.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewVacationTypes.Size = new System.Drawing.Size(746, 234);
            this.dataGridViewVacationTypes.TabIndex = 6;
            // 
            // tabPageSpendingOfVacations
            // 
            this.tabPageSpendingOfVacations.Controls.Add(this.tableLayoutPanelSpendingOfVacations);
            this.tabPageSpendingOfVacations.Location = new System.Drawing.Point(4, 32);
            this.tabPageSpendingOfVacations.Name = "tabPageSpendingOfVacations";
            this.tabPageSpendingOfVacations.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageSpendingOfVacations.Size = new System.Drawing.Size(758, 279);
            this.tabPageSpendingOfVacations.TabIndex = 3;
            this.tabPageSpendingOfVacations.Text = "Расходование отпусков ";
            this.tabPageSpendingOfVacations.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanelSpendingOfVacations
            // 
            this.tableLayoutPanelSpendingOfVacations.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPanelSpendingOfVacations.ColumnCount = 3;
            this.tableLayoutPanelSpendingOfVacations.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanelSpendingOfVacations.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanelSpendingOfVacations.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanelSpendingOfVacations.Controls.Add(this.btnAddSpendingOfVacationInformation, 0, 1);
            this.tableLayoutPanelSpendingOfVacations.Controls.Add(this.btnChangeSpendingOfVacationInformation, 1, 1);
            this.tableLayoutPanelSpendingOfVacations.Controls.Add(this.btnDeleteSpendingOfVacationInformation, 2, 1);
            this.tableLayoutPanelSpendingOfVacations.Controls.Add(this.dataGridViewSpendingOfVacations, 0, 0);
            this.tableLayoutPanelSpendingOfVacations.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelSpendingOfVacations.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanelSpendingOfVacations.Name = "tableLayoutPanelSpendingOfVacations";
            this.tableLayoutPanelSpendingOfVacations.RowCount = 2;
            this.tableLayoutPanelSpendingOfVacations.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 88F));
            this.tableLayoutPanelSpendingOfVacations.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12F));
            this.tableLayoutPanelSpendingOfVacations.Size = new System.Drawing.Size(752, 273);
            this.tableLayoutPanelSpendingOfVacations.TabIndex = 0;
            // 
            // btnAddSpendingOfVacationInformation
            // 
            this.btnAddSpendingOfVacationInformation.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnAddSpendingOfVacationInformation.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnAddSpendingOfVacationInformation.ForeColor = System.Drawing.Color.White;
            this.btnAddSpendingOfVacationInformation.Location = new System.Drawing.Point(3, 243);
            this.btnAddSpendingOfVacationInformation.Name = "btnAddSpendingOfVacationInformation";
            this.btnAddSpendingOfVacationInformation.Size = new System.Drawing.Size(244, 27);
            this.btnAddSpendingOfVacationInformation.TabIndex = 14;
            this.btnAddSpendingOfVacationInformation.Text = "Назначить отпуск сотруднику";
            this.btnAddSpendingOfVacationInformation.UseVisualStyleBackColor = false;
            this.btnAddSpendingOfVacationInformation.Click += new System.EventHandler(this.btnAddSpendingOfVacationInformation_Click);
            // 
            // btnChangeSpendingOfVacationInformation
            // 
            this.btnChangeSpendingOfVacationInformation.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnChangeSpendingOfVacationInformation.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnChangeSpendingOfVacationInformation.ForeColor = System.Drawing.Color.White;
            this.btnChangeSpendingOfVacationInformation.Location = new System.Drawing.Point(253, 243);
            this.btnChangeSpendingOfVacationInformation.Name = "btnChangeSpendingOfVacationInformation";
            this.btnChangeSpendingOfVacationInformation.Size = new System.Drawing.Size(244, 27);
            this.btnChangeSpendingOfVacationInformation.TabIndex = 13;
            this.btnChangeSpendingOfVacationInformation.Text = "Редактировать назначенный отпуск";
            this.btnChangeSpendingOfVacationInformation.UseVisualStyleBackColor = false;
            this.btnChangeSpendingOfVacationInformation.Click += new System.EventHandler(this.btnChangeSpendingOfVacationInformation_Click);
            // 
            // btnDeleteSpendingOfVacationInformation
            // 
            this.btnDeleteSpendingOfVacationInformation.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnDeleteSpendingOfVacationInformation.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnDeleteSpendingOfVacationInformation.ForeColor = System.Drawing.Color.White;
            this.btnDeleteSpendingOfVacationInformation.Location = new System.Drawing.Point(503, 243);
            this.btnDeleteSpendingOfVacationInformation.Name = "btnDeleteSpendingOfVacationInformation";
            this.btnDeleteSpendingOfVacationInformation.Size = new System.Drawing.Size(246, 27);
            this.btnDeleteSpendingOfVacationInformation.TabIndex = 12;
            this.btnDeleteSpendingOfVacationInformation.Text = "Удалить назначенный отпуск";
            this.btnDeleteSpendingOfVacationInformation.UseVisualStyleBackColor = false;
            this.btnDeleteSpendingOfVacationInformation.Click += new System.EventHandler(this.btnDeleteSpendingOfVacationInformation_Click);
            // 
            // dataGridViewSpendingOfVacations
            // 
            this.dataGridViewSpendingOfVacations.AllowUserToAddRows = false;
            this.dataGridViewSpendingOfVacations.AllowUserToDeleteRows = false;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.AntiqueWhite;
            this.dataGridViewSpendingOfVacations.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridViewSpendingOfVacations.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tableLayoutPanelSpendingOfVacations.SetColumnSpan(this.dataGridViewSpendingOfVacations, 3);
            this.dataGridViewSpendingOfVacations.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewSpendingOfVacations.Location = new System.Drawing.Point(3, 3);
            this.dataGridViewSpendingOfVacations.MultiSelect = false;
            this.dataGridViewSpendingOfVacations.Name = "dataGridViewSpendingOfVacations";
            this.dataGridViewSpendingOfVacations.ReadOnly = true;
            this.dataGridViewSpendingOfVacations.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewSpendingOfVacations.Size = new System.Drawing.Size(746, 234);
            this.dataGridViewSpendingOfVacations.TabIndex = 7;
            // 
            // tabPageEmployeesPaidTravel
            // 
            this.tabPageEmployeesPaidTravel.Controls.Add(this.tableLayoutPanelEmployeesPaidTravel);
            this.tabPageEmployeesPaidTravel.Location = new System.Drawing.Point(4, 32);
            this.tabPageEmployeesPaidTravel.Name = "tabPageEmployeesPaidTravel";
            this.tabPageEmployeesPaidTravel.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageEmployeesPaidTravel.Size = new System.Drawing.Size(758, 279);
            this.tabPageEmployeesPaidTravel.TabIndex = 4;
            this.tabPageEmployeesPaidTravel.Text = "Дорожные";
            this.tabPageEmployeesPaidTravel.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanelEmployeesPaidTravel
            // 
            this.tableLayoutPanelEmployeesPaidTravel.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPanelEmployeesPaidTravel.ColumnCount = 3;
            this.tableLayoutPanelEmployeesPaidTravel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanelEmployeesPaidTravel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanelEmployeesPaidTravel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanelEmployeesPaidTravel.Controls.Add(this.btnAddEmployeesPaidTravel, 0, 1);
            this.tableLayoutPanelEmployeesPaidTravel.Controls.Add(this.btnChangeEmployeesPaidTravel, 1, 1);
            this.tableLayoutPanelEmployeesPaidTravel.Controls.Add(this.btnDeleteEmployeesPaidTravel, 2, 1);
            this.tableLayoutPanelEmployeesPaidTravel.Controls.Add(this.dataGridViewEmployeesPaidTravel, 0, 0);
            this.tableLayoutPanelEmployeesPaidTravel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelEmployeesPaidTravel.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanelEmployeesPaidTravel.Name = "tableLayoutPanelEmployeesPaidTravel";
            this.tableLayoutPanelEmployeesPaidTravel.RowCount = 2;
            this.tableLayoutPanelEmployeesPaidTravel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 88F));
            this.tableLayoutPanelEmployeesPaidTravel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12F));
            this.tableLayoutPanelEmployeesPaidTravel.Size = new System.Drawing.Size(752, 273);
            this.tableLayoutPanelEmployeesPaidTravel.TabIndex = 1;
            // 
            // btnAddEmployeesPaidTravel
            // 
            this.btnAddEmployeesPaidTravel.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnAddEmployeesPaidTravel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnAddEmployeesPaidTravel.ForeColor = System.Drawing.Color.White;
            this.btnAddEmployeesPaidTravel.Location = new System.Drawing.Point(3, 243);
            this.btnAddEmployeesPaidTravel.Name = "btnAddEmployeesPaidTravel";
            this.btnAddEmployeesPaidTravel.Size = new System.Drawing.Size(244, 27);
            this.btnAddEmployeesPaidTravel.TabIndex = 14;
            this.btnAddEmployeesPaidTravel.Text = "Добавить период";
            this.btnAddEmployeesPaidTravel.UseVisualStyleBackColor = false;
            this.btnAddEmployeesPaidTravel.Click += new System.EventHandler(this.btnAddEmployeesPaidTravel_Click);
            // 
            // btnChangeEmployeesPaidTravel
            // 
            this.btnChangeEmployeesPaidTravel.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnChangeEmployeesPaidTravel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnChangeEmployeesPaidTravel.ForeColor = System.Drawing.Color.White;
            this.btnChangeEmployeesPaidTravel.Location = new System.Drawing.Point(253, 243);
            this.btnChangeEmployeesPaidTravel.Name = "btnChangeEmployeesPaidTravel";
            this.btnChangeEmployeesPaidTravel.Size = new System.Drawing.Size(244, 27);
            this.btnChangeEmployeesPaidTravel.TabIndex = 13;
            this.btnChangeEmployeesPaidTravel.Text = "Редактировать период";
            this.btnChangeEmployeesPaidTravel.UseVisualStyleBackColor = false;
            this.btnChangeEmployeesPaidTravel.Click += new System.EventHandler(this.btnChangeEmployeesPaidTravel_Click);
            // 
            // btnDeleteEmployeesPaidTravel
            // 
            this.btnDeleteEmployeesPaidTravel.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnDeleteEmployeesPaidTravel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnDeleteEmployeesPaidTravel.ForeColor = System.Drawing.Color.White;
            this.btnDeleteEmployeesPaidTravel.Location = new System.Drawing.Point(503, 243);
            this.btnDeleteEmployeesPaidTravel.Name = "btnDeleteEmployeesPaidTravel";
            this.btnDeleteEmployeesPaidTravel.Size = new System.Drawing.Size(246, 27);
            this.btnDeleteEmployeesPaidTravel.TabIndex = 12;
            this.btnDeleteEmployeesPaidTravel.Text = "Удалить период";
            this.btnDeleteEmployeesPaidTravel.UseVisualStyleBackColor = false;
            this.btnDeleteEmployeesPaidTravel.Click += new System.EventHandler(this.btnDeleteEmployeesPaidTravel_Click);
            // 
            // dataGridViewEmployeesPaidTravel
            // 
            this.dataGridViewEmployeesPaidTravel.AllowUserToAddRows = false;
            this.dataGridViewEmployeesPaidTravel.AllowUserToDeleteRows = false;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.AntiqueWhite;
            this.dataGridViewEmployeesPaidTravel.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle7;
            this.dataGridViewEmployeesPaidTravel.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tableLayoutPanelEmployeesPaidTravel.SetColumnSpan(this.dataGridViewEmployeesPaidTravel, 3);
            this.dataGridViewEmployeesPaidTravel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewEmployeesPaidTravel.Location = new System.Drawing.Point(3, 3);
            this.dataGridViewEmployeesPaidTravel.MultiSelect = false;
            this.dataGridViewEmployeesPaidTravel.Name = "dataGridViewEmployeesPaidTravel";
            this.dataGridViewEmployeesPaidTravel.ReadOnly = true;
            this.dataGridViewEmployeesPaidTravel.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewEmployeesPaidTravel.Size = new System.Drawing.Size(746, 234);
            this.dataGridViewEmployeesPaidTravel.TabIndex = 7;
            // 
            // tableLayoutPanel_WindowHeader
            // 
            this.tableLayoutPanel_WindowHeader.ColumnCount = 4;
            this.tableLayoutPanel_WindowHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_WindowHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_WindowHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_WindowHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel_WindowHeader.Controls.Add(this.lblEmployeesVacations, 0, 0);
            this.tableLayoutPanel_WindowHeader.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_WindowHeader.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel_WindowHeader.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.tableLayoutPanel_WindowHeader.Name = "tableLayoutPanel_WindowHeader";
            this.tableLayoutPanel_WindowHeader.RowCount = 1;
            this.tableLayoutPanel_WindowHeader.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_WindowHeader.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 41F));
            this.tableLayoutPanel_WindowHeader.Size = new System.Drawing.Size(772, 41);
            this.tableLayoutPanel_WindowHeader.TabIndex = 6;
            // 
            // lblEmployeesVacations
            // 
            this.lblEmployeesVacations.AutoSize = true;
            this.tableLayoutPanel_WindowHeader.SetColumnSpan(this.lblEmployeesVacations, 4);
            this.lblEmployeesVacations.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblEmployeesVacations.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblEmployeesVacations.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblEmployeesVacations.Location = new System.Drawing.Point(3, 0);
            this.lblEmployeesVacations.Name = "lblEmployeesVacations";
            this.lblEmployeesVacations.Size = new System.Drawing.Size(766, 41);
            this.lblEmployeesVacations.TabIndex = 19;
            this.lblEmployeesVacations.Text = "ОТПУСКА СОТРУДНИКОВ";
            this.lblEmployeesVacations.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel_Programm
            // 
            this.tableLayoutPanel_Programm.BackColor = System.Drawing.Color.Tan;
            this.tableLayoutPanel_Programm.ColumnCount = 1;
            this.tableLayoutPanel_Programm.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Programm.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Programm.Controls.Add(this.lblProgramm, 0, 0);
            this.tableLayoutPanel_Programm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Programm.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel_Programm.Name = "tableLayoutPanel_Programm";
            this.tableLayoutPanel_Programm.RowCount = 1;
            this.tableLayoutPanel_Programm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Programm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel_Programm.Size = new System.Drawing.Size(778, 43);
            this.tableLayoutPanel_Programm.TabIndex = 8;
            // 
            // lblProgramm
            // 
            this.lblProgramm.AutoSize = true;
            this.lblProgramm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblProgramm.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblProgramm.ForeColor = System.Drawing.Color.White;
            this.lblProgramm.Location = new System.Drawing.Point(3, 0);
            this.lblProgramm.Name = "lblProgramm";
            this.lblProgramm.Size = new System.Drawing.Size(772, 43);
            this.lblProgramm.TabIndex = 0;
            this.lblProgramm.Text = "ФОРМИРОВАНИЕ И ВЕДЕНИЕ ГРАФИКА ОТПУСКОВ СОТРУДНИКОВ";
            this.lblProgramm.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // EmployeesVacationsDetailForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 497);
            this.Controls.Add(this.tableLayoutPanel_AllForm);
            this.Name = "EmployeesVacationsDetailForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ОТПУСКА СОТРУДНИКОВ";
            this.Load += new System.EventHandler(this.EmployeesVacationsDetailForm_Load);
            this.tableLayoutPanel_AllForm.ResumeLayout(false);
            this.tableLayoutPanel_Company.ResumeLayout(false);
            this.tableLayoutPanel_Company.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCompany)).EndInit();
            this.tableLayoutPanel_Employees.ResumeLayout(false);
            this.tableLayoutPanel_Working_field.ResumeLayout(false);
            this.tabControlEmployeesVacations.ResumeLayout(false);
            this.tabPageEmployeesVacations.ResumeLayout(false);
            this.tableLayoutPanelEmployeesVacations.ResumeLayout(false);
            this.tableLayoutPanelEmployeesVacations.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVacationLog)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVacationsSchedulesList)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewEmployeesVacations)).EndInit();
            this.tabPageVacationSchedules.ResumeLayout(false);
            this.tableLayoutPanelVacationSchedules.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVacationSchedules)).EndInit();
            this.tabPageVacationTypes.ResumeLayout(false);
            this.tableLayoutPanelVacationTypes.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVacationTypes)).EndInit();
            this.tabPageSpendingOfVacations.ResumeLayout(false);
            this.tableLayoutPanelSpendingOfVacations.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSpendingOfVacations)).EndInit();
            this.tabPageEmployeesPaidTravel.ResumeLayout(false);
            this.tableLayoutPanelEmployeesPaidTravel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewEmployeesPaidTravel)).EndInit();
            this.tableLayoutPanel_WindowHeader.ResumeLayout(false);
            this.tableLayoutPanel_WindowHeader.PerformLayout();
            this.tableLayoutPanel_Programm.ResumeLayout(false);
            this.tableLayoutPanel_Programm.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_AllForm;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Company;
        private System.Windows.Forms.PictureBox pictureBoxCompany;
        private System.Windows.Forms.Label lblCompany;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Employees;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Working_field;
        private System.Windows.Forms.TabControl tabControlEmployeesVacations;
        private System.Windows.Forms.TabPage tabPageEmployeesVacations;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelEmployeesVacations;
        private System.Windows.Forms.Button btnOpenVacationScheduleConstructior;
        private System.Windows.Forms.DataGridView dataGridViewEmployeesVacations;
        private System.Windows.Forms.TabPage tabPageVacationSchedules;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelVacationSchedules;
        private System.Windows.Forms.Button btnAddVacationSchedule;
        private System.Windows.Forms.Button DeleteVacationSchedule;
        private System.Windows.Forms.Button btnChangeVacationSchedule;
        private System.Windows.Forms.DataGridView dataGridViewVacationSchedules;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_WindowHeader;
        private System.Windows.Forms.Label lblEmployeesVacations;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Programm;
        private System.Windows.Forms.Label lblProgramm;
        private System.Windows.Forms.TabPage tabPageVacationTypes;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelVacationTypes;
        private System.Windows.Forms.Button btnAddVacationType;
        private System.Windows.Forms.Button btnDeleteVacationType;
        private System.Windows.Forms.Button btnChangeVacationType;
        private System.Windows.Forms.DataGridView dataGridViewVacationTypes;
        private System.Windows.Forms.TabPage tabPageSpendingOfVacations;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelSpendingOfVacations;
        private System.Windows.Forms.DataGridView dataGridViewSpendingOfVacations;
        private System.Windows.Forms.Button btnAddSpendingOfVacationInformation;
        private System.Windows.Forms.Button btnChangeSpendingOfVacationInformation;
        private System.Windows.Forms.Button btnDeleteSpendingOfVacationInformation;
        private System.Windows.Forms.DataGridView dataGridViewVacationsSchedulesList;
        private System.Windows.Forms.Label lblVacationScheduleList;
        private System.Windows.Forms.Label lblVacationSchedule;
        private System.Windows.Forms.TabPage tabPageEmployeesPaidTravel;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelEmployeesPaidTravel;
        private System.Windows.Forms.Button btnAddEmployeesPaidTravel;
        private System.Windows.Forms.Button btnChangeEmployeesPaidTravel;
        private System.Windows.Forms.Button btnDeleteEmployeesPaidTravel;
        private System.Windows.Forms.DataGridView dataGridViewEmployeesPaidTravel;
        private System.Windows.Forms.Button btnOpenVacationLogConstructor;
        private System.Windows.Forms.DataGridView dataGridViewVacationLog;
        private System.Windows.Forms.Label lblVacationLog;
    }
}