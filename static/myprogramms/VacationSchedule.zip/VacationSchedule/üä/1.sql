-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: vacation_schedule
-- ------------------------------------------------------
-- Server version	5.7.21-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `alternate_list`
--

DROP TABLE IF EXISTS `alternate_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alternate_list` (
  `Position_id` int(11) NOT NULL AUTO_INCREMENT,
  `Vacationist_personnel_number` int(11) NOT NULL,
  `Alternate_personnel_number` int(11) NOT NULL,
  PRIMARY KEY (`Position_id`),
  KEY `Alternate_employe_idx` (`Vacationist_personnel_number`),
  CONSTRAINT `Alternate_employe` FOREIGN KEY (`Vacationist_personnel_number`) REFERENCES `employees` (`Personnel_number`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alternate_list`
--

LOCK TABLES `alternate_list` WRITE;
/*!40000 ALTER TABLE `alternate_list` DISABLE KEYS */;
INSERT INTO `alternate_list` VALUES (1,2,1),(2,3,2),(3,1,2),(4,1,3),(5,4,3),(7,1,7),(8,3,11),(9,16,13),(11,18,13);
/*!40000 ALTER TABLE `alternate_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `company_information`
--

DROP TABLE IF EXISTS `company_information`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `company_information` (
  `Short_title` varchar(50) NOT NULL,
  `INN` varchar(10) DEFAULT NULL,
  `KPP` varchar(9) DEFAULT NULL,
  `OKPO` varchar(8) DEFAULT NULL,
  `Full_title` varchar(100) DEFAULT NULL,
  `Legal_address` varchar(100) DEFAULT NULL,
  `Actual_address` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Short_title`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `company_information`
--

LOCK TABLES `company_information` WRITE;
/*!40000 ALTER TABLE `company_information` DISABLE KEYS */;
INSERT INTO `company_information` VALUES ('Филиал ПАО \"МРСК Северо-Запада\" (\"Колэнерго\")','7802312751','510501001','81078024','Филиал ПАО \"Межрегиональная распределительная сетевая компания Северо-Запада\" (\"Колэнерго\")','184355 Россия, Мурманская обл., пгт  Мурмаши, ул. Кирова д. 2','Мурманск, ул. Шмидта 10');
/*!40000 ALTER TABLE `company_information` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employees` (
  `Personnel_number` int(11) NOT NULL AUTO_INCREMENT,
  `Surname` varchar(45) DEFAULT NULL,
  `Name` varchar(45) DEFAULT NULL,
  `Fathers_name` varchar(45) DEFAULT NULL,
  `Surname_NF` varchar(50) DEFAULT NULL,
  `Birthday` date DEFAULT NULL,
  `Gender` varchar(7) DEFAULT NULL,
  `Passport_series` varchar(4) DEFAULT NULL,
  `Passport_number` varchar(6) DEFAULT NULL,
  `SNILS` varchar(14) DEFAULT NULL,
  `INN` varchar(12) DEFAULT NULL,
  `Registration_place` varchar(100) DEFAULT NULL,
  `Employment_date` date DEFAULT NULL,
  PRIMARY KEY (`Personnel_number`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees`
--

LOCK TABLES `employees` WRITE;
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
INSERT INTO `employees` VALUES (1,'Птенцов','Александр','Иванович','Птенцов А.И.','1958-06-30','Мужской','4703','439203','012-945-459 13','143514549514','184929 г. Северовморск, ул. Мира д.58, кв. 42','2015-09-10'),(2,'Тыквин','Сергей','Николаевич','Тыквин С.Н.','1993-05-17','Мужской','4709','485245','234-032-034 23','359123495439','183042 г. Мурманск, ул Гаджиева, д.24, кв.12','2016-03-03'),(3,'Лосев','Михаил','Васильевич','Лосев М.В.','1973-03-20','Мужской','4787','482948','140-581-043 85','145810485134','183040 г. Мурманск, ул. Халатина д.15, кв. 89','2010-12-23'),(4,'Дёмин','Федор','Михайлович','Дёмин Ф.М.','1989-03-25','Мужской','4703','635256','145-081-485 18','134510340851','184029 п. Гаджиево, ул. Ленина д.17, кв. 5','2012-04-02'),(7,'Герасимов','Алексей','Максимович','Герасимов А.М.','1989-08-21','Мужской','4703','245934','048-510-834 35','143058103485','183433 г. Мурманск, ул. Комсомольская, д.15 кв. 37','2015-03-24'),(8,'Бобров','Александр','Александрович','Бобров А.А.','1975-11-26','Мужской','4329','345094','233-402-342 93','234592935243','183041 г.Мурманск, ул Александрова, д.8, кв14','2011-03-02'),(9,'Сорокин','Kонстантин','Петрович','Сорокин K.П.','1983-04-21','Мужской','4630','234864','134-058-140 38','134058010348','183042 г. Мурманск, ул Хлобыстова, д.12, кв.25','2008-01-08'),(10,'Фролов','Максим','Афанасевич','Фролов М.А.','1973-05-01','Мужской','4705','445233','434-095-134 05','234512893494','183025 г. Мурманск, ул Лобова д.25, кв.17','2014-03-02'),(11,'Денисова','Анна','Васильевна','Денисова А.В.','1991-06-20','Женский','4712','123333','877-697-580 85','234514541346','182934 ЗАТО Гаджиево, ул. Советская д.7, кв. 18','2009-09-15'),(12,'Цветкова','Наталья','Ивановна','Цветкова Н.И.','1974-06-20','Женский','4394','239402','293-482-310 48','234123492387','183038 пос. Гаджиево, ул Советская, д.9, кв.14','2014-03-01'),(13,'Чесноков','Василий','Павлович','Чесноков В.П.','1984-12-15','Мужской','4710','203232','321-732-841 23','134084018464','183221 п.Мурмаши, ул.Мира, д.24, кв.15','2011-06-23'),(14,'Марков','Владимир','Владимирович','Марков В.В.','1995-03-02','Мужской','4712','234123','234-523-485 34','197235823740','183022 г. Мурманск ул.Профсоюзов д.8, кв.17','2014-07-31'),(15,'Голованов','Николай','Васильевич','Голованов Н.В.','1979-06-27','Мужской','4715','032851','129-571-235 21','423952935923','183029 г.Мурманск, ул. Челюскинцев, д.17, кв.4','2017-12-13'),(16,'Крапивин','Иван','Андреевич','Крапивин И.А.','1983-11-25','Мужской','4729','122394','123-450-823 54','023859273543','182434 п. Мурмаши, ул Ленина д.5, кв.18','2015-09-30'),(17,'Татаринов','Иван','Анатльевич','Татаринов И.А.','1979-06-28','Мужской','4912','132001','108-234-508 12','151802345293','183455 п.Ревда, ул.Правды, д.11, кв.7','2009-01-02'),(18,'Шведов','Михаил','Тарасович','Шведов М.Т.','1969-12-22','Мужской','4429','954018','103-405-104 38','102385194359','183054 п. Африканда, ул. Красноармейская, д.4, кв.5','2015-03-19');
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employees_accounts`
--

DROP TABLE IF EXISTS `employees_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employees_accounts` (
  `Personnel_number` int(11) NOT NULL,
  `Login` varchar(15) DEFAULT NULL,
  `Password` varchar(20) DEFAULT NULL,
  `Role` varchar(45) DEFAULT NULL,
  `Attempts_quantity` int(11) DEFAULT NULL,
  PRIMARY KEY (`Personnel_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees_accounts`
--

LOCK TABLES `employees_accounts` WRITE;
/*!40000 ALTER TABLE `employees_accounts` DISABLE KEYS */;
INSERT INTO `employees_accounts` VALUES (1,'абвг','абвг','Руководитель',3),(7,'ЭЮЯ','ЭЮЯ','Кадровик',3),(8,'aBc','aBc','Кадровик',3),(9,'АБВ','АБВ','Руководитель',3),(10,'АДМИН','АДМИН1','Администратор',3);
/*!40000 ALTER TABLE `employees_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employees_paid_travel`
--

DROP TABLE IF EXISTS `employees_paid_travel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employees_paid_travel` (
  `Position_id` int(11) NOT NULL AUTO_INCREMENT,
  `Personnel_number` int(11) NOT NULL,
  `Start_date` date DEFAULT NULL,
  `Finish_date` date DEFAULT NULL,
  PRIMARY KEY (`Position_id`),
  KEY `employees_paid_travel_idx` (`Personnel_number`),
  CONSTRAINT `employees_paid_travel` FOREIGN KEY (`Personnel_number`) REFERENCES `employees` (`Personnel_number`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees_paid_travel`
--

LOCK TABLES `employees_paid_travel` WRITE;
/*!40000 ALTER TABLE `employees_paid_travel` DISABLE KEYS */;
INSERT INTO `employees_paid_travel` VALUES (1,1,'2017-07-11','2019-07-10'),(2,15,'2016-08-05','2018-08-04'),(3,10,'2018-03-09','2020-03-08'),(4,3,'2018-02-08','2020-02-07'),(5,8,'2016-06-27','2018-06-26'),(6,13,'2017-05-15','2019-05-14'),(7,9,'2016-11-21','2018-11-20'),(8,8,'2016-05-28','2018-05-28');
/*!40000 ALTER TABLE `employees_paid_travel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employees_sick_lists`
--

DROP TABLE IF EXISTS `employees_sick_lists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employees_sick_lists` (
  `Sick_list_id` int(11) NOT NULL AUTO_INCREMENT,
  `Personnel_number` int(11) DEFAULT NULL,
  `Beginning_of_period` date DEFAULT NULL,
  `End_of_period` date DEFAULT NULL,
  PRIMARY KEY (`Sick_list_id`),
  KEY `employees_sick_list_idx` (`Personnel_number`),
  CONSTRAINT `employees_sick_list` FOREIGN KEY (`Personnel_number`) REFERENCES `employees` (`Personnel_number`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees_sick_lists`
--

LOCK TABLES `employees_sick_lists` WRITE;
/*!40000 ALTER TABLE `employees_sick_lists` DISABLE KEYS */;
INSERT INTO `employees_sick_lists` VALUES (2,8,'2018-05-02','2018-05-11'),(4,8,'2018-05-09','2018-05-14'),(5,10,'2018-04-02','2018-04-15'),(6,11,'2018-05-19','2018-05-22');
/*!40000 ALTER TABLE `employees_sick_lists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employees_vacations`
--

DROP TABLE IF EXISTS `employees_vacations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employees_vacations` (
  `Position_id` int(11) NOT NULL AUTO_INCREMENT,
  `Personnel_number` int(11) NOT NULL,
  `Vacation_schedule_id` int(11) NOT NULL,
  `Vacation_start_date` date DEFAULT NULL,
  `Vacation_finish_date` date DEFAULT NULL,
  `Days_quantity` int(11) DEFAULT NULL,
  `Vacation_type_id` int(11) NOT NULL,
  PRIMARY KEY (`Position_id`),
  UNIQUE KEY `Position_id_UNIQUE` (`Position_id`),
  KEY `Vacation_schedule_id_idx` (`Vacation_schedule_id`),
  KEY `Vacation_type_idx` (`Vacation_type_id`),
  KEY `Personnel_number_idx` (`Personnel_number`),
  CONSTRAINT `Personnel_number` FOREIGN KEY (`Personnel_number`) REFERENCES `employees` (`Personnel_number`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `Vacation_schedule` FOREIGN KEY (`Vacation_schedule_id`) REFERENCES `vacation_schedules` (`Vacation_schedule_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `Vacation_type` FOREIGN KEY (`Vacation_type_id`) REFERENCES `vacation_types` (`Vacation_type_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees_vacations`
--

LOCK TABLES `employees_vacations` WRITE;
/*!40000 ALTER TABLE `employees_vacations` DISABLE KEYS */;
INSERT INTO `employees_vacations` VALUES (9,15,4,'2018-03-11','2018-03-25',15,1),(10,10,4,'2018-07-16','2018-08-25',10,1),(11,3,8,'2018-05-11','2018-05-20',10,1),(12,8,8,'2018-04-20','2018-04-30',11,1),(13,13,8,'2018-08-01','2018-08-14',14,1),(14,9,3,'2018-07-03','2018-07-22',20,1),(22,2,7,'2018-05-11','2018-05-15',5,1),(23,2,7,'2018-06-11','2018-06-17',7,1),(25,18,7,'2018-06-01','2018-06-10',10,1),(26,18,7,'2018-04-30','2018-05-27',26,1),(27,2,7,'2018-06-01','2018-06-15',15,1),(28,18,7,'2018-06-01','2018-06-16',16,1),(29,1,4,'2018-04-02','2018-04-30',29,1),(30,2,7,'2018-03-01','2018-03-21',20,1),(43,11,5,'2018-06-08','2018-06-15',7,1);
/*!40000 ALTER TABLE `employees_vacations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `functions`
--

DROP TABLE IF EXISTS `functions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `functions` (
  `Function_id` int(11) NOT NULL AUTO_INCREMENT,
  `Function` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`Function_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `functions`
--

LOCK TABLES `functions` WRITE;
/*!40000 ALTER TABLE `functions` DISABLE KEYS */;
INSERT INTO `functions` VALUES (1,'Спецалист по обслуживанию высоковольтной сети'),(2,'Инспектор отдела кадров'),(3,'Главный бухгалтер');
/*!40000 ALTER TABLE `functions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hierarchy_levels`
--

DROP TABLE IF EXISTS `hierarchy_levels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hierarchy_levels` (
  `Hierarchy_level_id` int(11) NOT NULL AUTO_INCREMENT,
  `Hierarchy_level` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`Hierarchy_level_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hierarchy_levels`
--

LOCK TABLES `hierarchy_levels` WRITE;
/*!40000 ALTER TABLE `hierarchy_levels` DISABLE KEYS */;
INSERT INTO `hierarchy_levels` VALUES (1,'Производственное отделение'),(2,'Управление'),(3,'Производственная служба'),(4,'Отдел'),(6,'Группа');
/*!40000 ALTER TABLE `hierarchy_levels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `paid_travel`
--

DROP TABLE IF EXISTS `paid_travel`;
/*!50001 DROP VIEW IF EXISTS `paid_travel`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `paid_travel` AS SELECT 
 1 AS `Personnel_number`,
 1 AS `Дорожные: начало периода`,
 1 AS `Дорожные: конец периода`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `parent_units`
--

DROP TABLE IF EXISTS `parent_units`;
/*!50001 DROP VIEW IF EXISTS `parent_units`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `parent_units` AS SELECT 
 1 AS `Unit_id`,
 1 AS `Unit_full_title`,
 1 AS `Unit_short_title`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `personnel_categories`
--

DROP TABLE IF EXISTS `personnel_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personnel_categories` (
  `Category_id` int(11) NOT NULL AUTO_INCREMENT,
  `Category` varchar(45) DEFAULT NULL,
  `Category_short_name` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`Category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personnel_categories`
--

LOCK TABLES `personnel_categories` WRITE;
/*!40000 ALTER TABLE `personnel_categories` DISABLE KEYS */;
INSERT INTO `personnel_categories` VALUES (1,'Руководители','Рук.'),(2,'Специалисты','Спец.'),(5,'Ведущие специалисты','В. Спец.');
/*!40000 ALTER TABLE `personnel_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `real_vacation_spending`
--

DROP TABLE IF EXISTS `real_vacation_spending`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `real_vacation_spending` (
  `Position_id` int(11) NOT NULL AUTO_INCREMENT,
  `Personnel_number` int(11) NOT NULL,
  `Year` varchar(4) DEFAULT NULL,
  `Vacation_type_id` int(11) DEFAULT NULL,
  `Paid_days` int(11) DEFAULT NULL,
  `Paid_days_balance` int(11) DEFAULT NULL,
  PRIMARY KEY (`Position_id`),
  KEY `Real_days_balance_idx` (`Personnel_number`),
  CONSTRAINT `Real_days_balance` FOREIGN KEY (`Personnel_number`) REFERENCES `employees` (`Personnel_number`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `real_vacation_spending`
--

LOCK TABLES `real_vacation_spending` WRITE;
/*!40000 ALTER TABLE `real_vacation_spending` DISABLE KEYS */;
INSERT INTO `real_vacation_spending` VALUES (3,4,'2018',1,52,25),(7,11,'2018',1,52,52),(8,8,'2018',1,52,22),(10,18,'2018',1,52,0),(12,1,'2018',1,52,52),(13,15,'2018',1,52,38),(14,10,'2018',1,52,52),(15,3,'2018',1,52,52),(16,13,'2018',1,52,52),(17,9,'2018',1,52,38),(18,2,'2018',1,52,0),(19,16,'2018',1,52,50);
/*!40000 ALTER TABLE `real_vacation_spending` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `spending_of_vacations`
--

DROP TABLE IF EXISTS `spending_of_vacations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `spending_of_vacations` (
  `Position_id` int(11) NOT NULL AUTO_INCREMENT,
  `Personnel_number` int(11) NOT NULL,
  `Year` varchar(4) DEFAULT NULL,
  `Vacation_type_id` int(11) DEFAULT NULL,
  `Paid_days` int(11) DEFAULT NULL,
  `Paid_days_balance` int(11) DEFAULT NULL,
  PRIMARY KEY (`Position_id`),
  KEY `VacationBalance_idx` (`Personnel_number`),
  CONSTRAINT `VacationBalance` FOREIGN KEY (`Personnel_number`) REFERENCES `employees` (`Personnel_number`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `spending_of_vacations`
--

LOCK TABLES `spending_of_vacations` WRITE;
/*!40000 ALTER TABLE `spending_of_vacations` DISABLE KEYS */;
INSERT INTO `spending_of_vacations` VALUES (3,4,'2018',1,52,25),(7,11,'2018',1,52,45),(8,8,'2018',1,52,41),(10,18,'2018',1,52,0),(12,1,'2018',1,52,23),(13,15,'2018',1,52,37),(14,10,'2018',1,52,42),(15,3,'2018',1,52,42),(16,13,'2018',1,52,38),(17,9,'2018',1,52,32),(18,2,'2018',1,52,5),(19,16,'2018',1,52,50);
/*!40000 ALTER TABLE `spending_of_vacations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staffing_table`
--

DROP TABLE IF EXISTS `staffing_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staffing_table` (
  `Position_id` int(11) NOT NULL AUTO_INCREMENT,
  `Function_id` int(11) NOT NULL,
  `Category_id` int(11) NOT NULL,
  `Personnel_number` int(11) NOT NULL,
  `Add_to_vacation` int(11) DEFAULT NULL,
  `Unit_id` int(11) NOT NULL,
  `staffing_table_id` int(11) NOT NULL,
  PRIMARY KEY (`Position_id`),
  KEY `Personnel_category_idx` (`Category_id`),
  KEY `Function_idx` (`Function_id`),
  KEY `Structural_unit_idx` (`Unit_id`),
  KEY `Employe_idx` (`Personnel_number`),
  KEY `Staffing_table_idx` (`staffing_table_id`),
  CONSTRAINT `Employee` FOREIGN KEY (`Personnel_number`) REFERENCES `employees` (`Personnel_number`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `Function` FOREIGN KEY (`Function_id`) REFERENCES `functions` (`Function_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `Personnel_category` FOREIGN KEY (`Category_id`) REFERENCES `personnel_categories` (`Category_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `Staffing_table` FOREIGN KEY (`staffing_table_id`) REFERENCES `staffing_table_status` (`Staffing_table_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `Structural_unit` FOREIGN KEY (`Unit_id`) REFERENCES `structural_units` (`Unit_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staffing_table`
--

LOCK TABLES `staffing_table` WRITE;
/*!40000 ALTER TABLE `staffing_table` DISABLE KEYS */;
INSERT INTO `staffing_table` VALUES (2,1,1,3,8,3,1),(3,1,1,4,5,8,1),(4,1,1,1,16,1,1),(5,2,5,7,0,4,1),(6,1,5,10,3,1,1),(7,2,1,9,9,4,1),(14,1,5,8,3,3,1),(15,3,1,11,3,6,1),(16,1,1,2,0,2,1),(17,1,2,15,0,1,1),(18,1,5,16,0,8,1),(19,1,2,13,0,3,1),(20,1,2,14,0,3,1),(21,1,5,12,0,2,1),(22,1,2,18,0,2,1),(23,3,5,17,0,6,1);
/*!40000 ALTER TABLE `staffing_table` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staffing_table_status`
--

DROP TABLE IF EXISTS `staffing_table_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staffing_table_status` (
  `Staffing_table_id` int(11) NOT NULL AUTO_INCREMENT,
  `Year` varchar(4) DEFAULT NULL,
  `Staffing_table_status` varchar(45) DEFAULT NULL,
  `Comment` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Staffing_table_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staffing_table_status`
--

LOCK TABLES `staffing_table_status` WRITE;
/*!40000 ALTER TABLE `staffing_table_status` DISABLE KEYS */;
INSERT INTO `staffing_table_status` VALUES (1,'2018','Не утверждено','на 2018');
/*!40000 ALTER TABLE `staffing_table_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `state_holidays_list`
--

DROP TABLE IF EXISTS `state_holidays_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `state_holidays_list` (
  `State_holiday` varchar(45) DEFAULT NULL,
  `State_holiday_date` date NOT NULL,
  PRIMARY KEY (`State_holiday_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `state_holidays_list`
--

LOCK TABLES `state_holidays_list` WRITE;
/*!40000 ALTER TABLE `state_holidays_list` DISABLE KEYS */;
INSERT INTO `state_holidays_list` VALUES ('Новый год','2018-01-01'),('Новый год','2018-01-02'),('Рождество','2018-01-07'),('День защитника отечества','2018-02-23'),('Международный женский день','2018-03-08'),('Праздник весны и труда','2018-05-01'),('День Победы','2018-05-09'),('День России','2018-06-12'),('День народного единства','2018-11-04');
/*!40000 ALTER TABLE `state_holidays_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `structural_units`
--

DROP TABLE IF EXISTS `structural_units`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `structural_units` (
  `Unit_id` int(11) NOT NULL AUTO_INCREMENT,
  `Hierarchy_level_id` int(11) NOT NULL,
  `Unit_full_title` varchar(80) DEFAULT NULL,
  `Unit_short_title` varchar(20) DEFAULT NULL,
  `Unit_chief` int(11) DEFAULT NULL,
  `Parent_unit` int(11) DEFAULT NULL,
  PRIMARY KEY (`Unit_id`),
  KEY `Hierarchy_level_idx` (`Hierarchy_level_id`),
  CONSTRAINT `Hierarchy_level` FOREIGN KEY (`Hierarchy_level_id`) REFERENCES `hierarchy_levels` (`Hierarchy_level_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `structural_units`
--

LOCK TABLES `structural_units` WRITE;
/*!40000 ALTER TABLE `structural_units` DISABLE KEYS */;
INSERT INTO `structural_units` VALUES (1,4,'Отдел эксплуатации силовых установок','ОЭСУ',1,1),(2,2,'Управление по контролю эксплуатации высоковольтного оборудования','УПКЭВО',2,3),(3,1,'Производственое отделение по проведению и обслуживанию высоковольтных сетей','ПОПОВС',3,3),(4,4,'Отдел кадров','ОК',9,2),(6,2,'Управление по закупкам','Управление закупок',11,3),(8,6,'Группа контроля качества выполнения работ','ГККВР',4,1);
/*!40000 ALTER TABLE `structural_units` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `vacation_data`
--

DROP TABLE IF EXISTS `vacation_data`;
/*!50001 DROP VIEW IF EXISTS `vacation_data`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vacation_data` AS SELECT 
 1 AS `Vacation_schedule_id`,
 1 AS `Табельный номер`,
 1 AS `Фамилия, имя, отчество`,
 1 AS `Подразделение`,
 1 AS `Должность`,
 1 AS `Категория персонала`,
 1 AS `Продолжительность отпуска`,
 1 AS `Начало отпуска`,
 1 AS `Окончание отпуска`,
 1 AS `Дни`,
 1 AS `Вид отпуска`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `vacation_log`
--

DROP TABLE IF EXISTS `vacation_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vacation_log` (
  `Position_id` int(11) NOT NULL AUTO_INCREMENT,
  `Personnel_number` int(11) NOT NULL,
  `Vacation_schedule_id` int(11) DEFAULT NULL,
  `Vacation_start_date` date DEFAULT NULL,
  `Vacation_finish_date` date DEFAULT NULL,
  `Days_quantity` int(11) DEFAULT NULL,
  `Vacation_type_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`Position_id`),
  KEY `EmployeesRealVacations_idx` (`Personnel_number`),
  CONSTRAINT `EmployeesRealVacations` FOREIGN KEY (`Personnel_number`) REFERENCES `employees` (`Personnel_number`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vacation_log`
--

LOCK TABLES `vacation_log` WRITE;
/*!40000 ALTER TABLE `vacation_log` DISABLE KEYS */;
INSERT INTO `vacation_log` VALUES (3,2,7,'2018-03-01','2018-03-17',16,1),(4,2,7,'2018-07-05','2018-08-09',36,1),(5,18,7,'2018-02-11','2018-02-25',14,1),(6,18,7,'2018-06-10','2018-07-02',22,1),(7,8,8,'2018-03-01','2018-03-17',16,1),(8,8,8,'2018-05-17','2018-05-30',14,1),(9,9,3,'2018-04-30','2018-05-15',14,1);
/*!40000 ALTER TABLE `vacation_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `vacation_schedule`
--

DROP TABLE IF EXISTS `vacation_schedule`;
/*!50001 DROP VIEW IF EXISTS `vacation_schedule`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vacation_schedule` AS SELECT 
 1 AS `Vacation_schedule_id`,
 1 AS `Structural_unit_id`,
 1 AS `Position_id`,
 1 AS `Табельный номер`,
 1 AS `Сотрудник`,
 1 AS `Вид отпуска`,
 1 AS `Начало отпуска`,
 1 AS `Конец отпуска`,
 1 AS `Итого дней отпуска`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `vacation_schedules`
--

DROP TABLE IF EXISTS `vacation_schedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vacation_schedules` (
  `Vacation_schedule_id` int(11) NOT NULL AUTO_INCREMENT,
  `Created` date DEFAULT NULL,
  `Title_vacation_schedule` varchar(45) DEFAULT NULL,
  `Vacation_schedule_year` varchar(4) DEFAULT NULL,
  `Status` varchar(12) DEFAULT NULL,
  `Approved_by` int(11) DEFAULT NULL,
  `Approvement_date` date DEFAULT NULL,
  `Structural_unit_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`Vacation_schedule_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vacation_schedules`
--

LOCK TABLES `vacation_schedules` WRITE;
/*!40000 ALTER TABLE `vacation_schedules` DISABLE KEYS */;
INSERT INTO `vacation_schedules` VALUES (1,'2017-12-15','Основной','2018','Не утвержден',NULL,NULL,8),(3,'2017-12-15','Основной','2018','Утвержден',9,'2017-12-17',4),(4,'2017-12-15','Основной','2018','Не утвержден',NULL,NULL,1),(5,'2017-12-15','Основной','2018','Не утвержден',NULL,NULL,6),(7,'2017-12-15','Основной','2018','Не утвержден',NULL,NULL,2),(8,'2017-12-15','Основной','2018','Утвержден',8,'2017-12-17',3);
/*!40000 ALTER TABLE `vacation_schedules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `vacation_schedules_list`
--

DROP TABLE IF EXISTS `vacation_schedules_list`;
/*!50001 DROP VIEW IF EXISTS `vacation_schedules_list`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vacation_schedules_list` AS SELECT 
 1 AS `Vacation_schedule_id`,
 1 AS `Дата составления`,
 1 AS `Название графика отпусков`,
 1 AS `Структурное подразделение`,
 1 AS `На год`,
 1 AS `Утвержден`,
 1 AS `Утвердившее лицо`,
 1 AS `Дата утверждения`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `vacation_types`
--

DROP TABLE IF EXISTS `vacation_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vacation_types` (
  `Vacation_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `Vacation_type` varchar(45) DEFAULT NULL,
  `Paid_days` int(11) DEFAULT NULL,
  `Unpaid_days` int(11) DEFAULT NULL,
  PRIMARY KEY (`Vacation_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vacation_types`
--

LOCK TABLES `vacation_types` WRITE;
/*!40000 ALTER TABLE `vacation_types` DISABLE KEYS */;
INSERT INTO `vacation_types` VALUES (1,'основной оплачиваемый',52,0),(4,'премиальный',8,0);
/*!40000 ALTER TABLE `vacation_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `vacationists`
--

DROP TABLE IF EXISTS `vacationists`;
/*!50001 DROP VIEW IF EXISTS `vacationists`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vacationists` AS SELECT 
 1 AS `Position_id`,
 1 AS `Surname_NF`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `paid_travel`
--

/*!50001 DROP VIEW IF EXISTS `paid_travel`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `paid_travel` AS select `employees_paid_travel`.`Personnel_number` AS `Personnel_number`,`employees_paid_travel`.`Start_date` AS `Дорожные: начало периода`,`employees_paid_travel`.`Finish_date` AS `Дорожные: конец периода` from `employees_paid_travel` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `parent_units`
--

/*!50001 DROP VIEW IF EXISTS `parent_units`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `parent_units` AS select `structural_units`.`Unit_id` AS `Unit_id`,`structural_units`.`Unit_full_title` AS `Unit_full_title`,`structural_units`.`Unit_short_title` AS `Unit_short_title` from `structural_units` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vacation_data`
--

/*!50001 DROP VIEW IF EXISTS `vacation_data`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vacation_data` AS select `ev`.`Vacation_schedule_id` AS `Vacation_schedule_id`,`e`.`Personnel_number` AS `Табельный номер`,concat(`e`.`Surname`,' ',`e`.`Name`,' ',`e`.`Fathers_name`) AS `Фамилия, имя, отчество`,`su`.`Unit_short_title` AS `Подразделение`,`f`.`Function` AS `Должность`,`pc`.`Category_short_name` AS `Категория персонала`,`ev`.`Days_quantity` AS `Продолжительность отпуска`,`ev`.`Vacation_start_date` AS `Начало отпуска`,`ev`.`Vacation_finish_date` AS `Окончание отпуска`,`ev`.`Days_quantity` AS `Дни`,`vt`.`Vacation_type` AS `Вид отпуска` from (((((((`employees` `e` join `staffing_table` `st`) join `personnel_categories` `pc`) join `functions` `f`) join `employees_vacations` `ev`) join `vacation_schedules` `vs`) join `structural_units` `su`) join `vacation_types` `vt`) where ((`e`.`Personnel_number` = `st`.`Personnel_number`) and (`st`.`Function_id` = `f`.`Function_id`) and (`st`.`Category_id` = `pc`.`Category_id`) and (`e`.`Personnel_number` = `ev`.`Personnel_number`) and (`ev`.`Vacation_schedule_id` = `vs`.`Vacation_schedule_id`) and (`su`.`Unit_id` = `st`.`Unit_id`) and (`vt`.`Vacation_type_id` = `ev`.`Vacation_type_id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vacation_schedule`
--

/*!50001 DROP VIEW IF EXISTS `vacation_schedule`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vacation_schedule` AS select `ev`.`Vacation_schedule_id` AS `Vacation_schedule_id`,`vs`.`Structural_unit_id` AS `Structural_unit_id`,`ev`.`Position_id` AS `Position_id`,`e`.`Personnel_number` AS `Табельный номер`,`e`.`Surname_NF` AS `Сотрудник`,`vt`.`Vacation_type` AS `Вид отпуска`,`ev`.`Vacation_start_date` AS `Начало отпуска`,`ev`.`Vacation_finish_date` AS `Конец отпуска`,`ev`.`Days_quantity` AS `Итого дней отпуска` from (((`employees` `e` join `vacation_schedules` `vs`) join `vacation_types` `vt`) join `employees_vacations` `ev`) where ((`e`.`Personnel_number` = `ev`.`Personnel_number`) and (`vs`.`Vacation_schedule_id` = `ev`.`Vacation_schedule_id`) and (`vt`.`Vacation_type_id` = `ev`.`Vacation_type_id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vacation_schedules_list`
--

/*!50001 DROP VIEW IF EXISTS `vacation_schedules_list`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vacation_schedules_list` AS select `vs`.`Vacation_schedule_id` AS `Vacation_schedule_id`,`vs`.`Created` AS `Дата составления`,`vs`.`Title_vacation_schedule` AS `Название графика отпусков`,`su`.`Unit_short_title` AS `Структурное подразделение`,`vs`.`Vacation_schedule_year` AS `На год`,`vs`.`Status` AS `Утвержден`,`vs`.`Approved_by` AS `Утвердившее лицо`,`vs`.`Approvement_date` AS `Дата утверждения` from (`vacation_schedules` `vs` join `structural_units` `su`) where (`vs`.`Structural_unit_id` = `su`.`Unit_id`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vacationists`
--

/*!50001 DROP VIEW IF EXISTS `vacationists`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vacationists` AS select `al`.`Position_id` AS `Position_id`,`e`.`Surname_NF` AS `Surname_NF` from (`alternate_list` `al` join `employees` `e`) where (`al`.`Vacationist_personnel_number` = `e`.`Personnel_number`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-06-15 16:28:34
