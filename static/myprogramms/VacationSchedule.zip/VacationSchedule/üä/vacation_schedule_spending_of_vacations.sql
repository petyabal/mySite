-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: vacation_schedule
-- ------------------------------------------------------
-- Server version	5.7.21-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `spending_of_vacations`
--

DROP TABLE IF EXISTS `spending_of_vacations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `spending_of_vacations` (
  `Position_id` int(11) NOT NULL AUTO_INCREMENT,
  `Personnel_number` int(11) NOT NULL,
  `Year` varchar(4) DEFAULT NULL,
  `Vacation_type_id` int(11) DEFAULT NULL,
  `Paid_days` int(11) DEFAULT NULL,
  `Paid_days_balance` int(11) DEFAULT NULL,
  PRIMARY KEY (`Position_id`),
  KEY `VacationBalance_idx` (`Personnel_number`),
  CONSTRAINT `VacationBalance` FOREIGN KEY (`Personnel_number`) REFERENCES `employees` (`Personnel_number`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `spending_of_vacations`
--

LOCK TABLES `spending_of_vacations` WRITE;
/*!40000 ALTER TABLE `spending_of_vacations` DISABLE KEYS */;
INSERT INTO `spending_of_vacations` VALUES (3,4,'2018',1,52,25),(7,11,'2018',1,52,45),(8,8,'2018',1,52,41),(10,18,'2018',1,52,0),(12,1,'2018',1,52,23),(13,15,'2018',1,52,37),(14,10,'2018',1,52,42),(15,3,'2018',1,52,42),(16,13,'2018',1,52,38),(17,9,'2018',1,52,32),(18,2,'2018',1,52,5),(19,16,'2018',1,52,50);
/*!40000 ALTER TABLE `spending_of_vacations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-06-15 16:29:12
