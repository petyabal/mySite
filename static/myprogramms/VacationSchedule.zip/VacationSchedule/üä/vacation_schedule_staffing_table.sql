-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: vacation_schedule
-- ------------------------------------------------------
-- Server version	5.7.21-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `staffing_table`
--

DROP TABLE IF EXISTS `staffing_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staffing_table` (
  `Position_id` int(11) NOT NULL AUTO_INCREMENT,
  `Function_id` int(11) NOT NULL,
  `Category_id` int(11) NOT NULL,
  `Personnel_number` int(11) NOT NULL,
  `Add_to_vacation` int(11) DEFAULT NULL,
  `Unit_id` int(11) NOT NULL,
  `staffing_table_id` int(11) NOT NULL,
  PRIMARY KEY (`Position_id`),
  KEY `Personnel_category_idx` (`Category_id`),
  KEY `Function_idx` (`Function_id`),
  KEY `Structural_unit_idx` (`Unit_id`),
  KEY `Employe_idx` (`Personnel_number`),
  KEY `Staffing_table_idx` (`staffing_table_id`),
  CONSTRAINT `Employee` FOREIGN KEY (`Personnel_number`) REFERENCES `employees` (`Personnel_number`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `Function` FOREIGN KEY (`Function_id`) REFERENCES `functions` (`Function_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `Personnel_category` FOREIGN KEY (`Category_id`) REFERENCES `personnel_categories` (`Category_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `Staffing_table` FOREIGN KEY (`staffing_table_id`) REFERENCES `staffing_table_status` (`Staffing_table_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `Structural_unit` FOREIGN KEY (`Unit_id`) REFERENCES `structural_units` (`Unit_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staffing_table`
--

LOCK TABLES `staffing_table` WRITE;
/*!40000 ALTER TABLE `staffing_table` DISABLE KEYS */;
INSERT INTO `staffing_table` VALUES (2,1,1,3,8,3,1),(3,1,1,4,5,8,1),(4,1,1,1,16,1,1),(5,2,5,7,0,4,1),(6,1,5,10,3,1,1),(7,2,1,9,9,4,1),(14,1,5,8,3,3,1),(15,3,1,11,3,6,1),(16,1,1,2,0,2,1),(17,1,2,15,0,1,1),(18,1,5,16,0,8,1),(19,1,2,13,0,3,1),(20,1,2,14,0,3,1),(21,1,5,12,0,2,1),(22,1,2,18,0,2,1),(23,3,5,17,0,6,1);
/*!40000 ALTER TABLE `staffing_table` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-06-15 16:29:12
