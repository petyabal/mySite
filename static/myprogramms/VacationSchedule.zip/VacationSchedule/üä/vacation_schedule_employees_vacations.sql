-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: vacation_schedule
-- ------------------------------------------------------
-- Server version	5.7.21-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `employees_vacations`
--

DROP TABLE IF EXISTS `employees_vacations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employees_vacations` (
  `Position_id` int(11) NOT NULL AUTO_INCREMENT,
  `Personnel_number` int(11) NOT NULL,
  `Vacation_schedule_id` int(11) NOT NULL,
  `Vacation_start_date` date DEFAULT NULL,
  `Vacation_finish_date` date DEFAULT NULL,
  `Days_quantity` int(11) DEFAULT NULL,
  `Vacation_type_id` int(11) NOT NULL,
  PRIMARY KEY (`Position_id`),
  UNIQUE KEY `Position_id_UNIQUE` (`Position_id`),
  KEY `Vacation_schedule_id_idx` (`Vacation_schedule_id`),
  KEY `Vacation_type_idx` (`Vacation_type_id`),
  KEY `Personnel_number_idx` (`Personnel_number`),
  CONSTRAINT `Personnel_number` FOREIGN KEY (`Personnel_number`) REFERENCES `employees` (`Personnel_number`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `Vacation_schedule` FOREIGN KEY (`Vacation_schedule_id`) REFERENCES `vacation_schedules` (`Vacation_schedule_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `Vacation_type` FOREIGN KEY (`Vacation_type_id`) REFERENCES `vacation_types` (`Vacation_type_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees_vacations`
--

LOCK TABLES `employees_vacations` WRITE;
/*!40000 ALTER TABLE `employees_vacations` DISABLE KEYS */;
INSERT INTO `employees_vacations` VALUES (9,15,4,'2018-03-11','2018-03-25',15,1),(10,10,4,'2018-07-16','2018-08-25',10,1),(11,3,8,'2018-05-11','2018-05-20',10,1),(12,8,8,'2018-04-20','2018-04-30',11,1),(13,13,8,'2018-08-01','2018-08-14',14,1),(14,9,3,'2018-07-03','2018-07-22',20,1),(22,2,7,'2018-05-11','2018-05-15',5,1),(23,2,7,'2018-06-11','2018-06-17',7,1),(25,18,7,'2018-06-01','2018-06-10',10,1),(26,18,7,'2018-04-30','2018-05-27',26,1),(27,2,7,'2018-06-01','2018-06-15',15,1),(28,18,7,'2018-06-01','2018-06-16',16,1),(29,1,4,'2018-04-02','2018-04-30',29,1),(30,2,7,'2018-03-01','2018-03-21',20,1),(43,11,5,'2018-06-08','2018-06-15',7,1);
/*!40000 ALTER TABLE `employees_vacations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-06-15 16:29:11
