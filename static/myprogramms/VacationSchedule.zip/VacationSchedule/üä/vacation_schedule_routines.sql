-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: vacation_schedule
-- ------------------------------------------------------
-- Server version	5.7.21-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `vacationists`
--

DROP TABLE IF EXISTS `vacationists`;
/*!50001 DROP VIEW IF EXISTS `vacationists`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vacationists` AS SELECT 
 1 AS `Position_id`,
 1 AS `Surname_NF`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vacation_data`
--

DROP TABLE IF EXISTS `vacation_data`;
/*!50001 DROP VIEW IF EXISTS `vacation_data`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vacation_data` AS SELECT 
 1 AS `Vacation_schedule_id`,
 1 AS `Табельный номер`,
 1 AS `Фамилия, имя, отчество`,
 1 AS `Подразделение`,
 1 AS `Должность`,
 1 AS `Категория персонала`,
 1 AS `Продолжительность отпуска`,
 1 AS `Начало отпуска`,
 1 AS `Окончание отпуска`,
 1 AS `Дни`,
 1 AS `Вид отпуска`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `parent_units`
--

DROP TABLE IF EXISTS `parent_units`;
/*!50001 DROP VIEW IF EXISTS `parent_units`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `parent_units` AS SELECT 
 1 AS `Unit_id`,
 1 AS `Unit_full_title`,
 1 AS `Unit_short_title`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `paid_travel`
--

DROP TABLE IF EXISTS `paid_travel`;
/*!50001 DROP VIEW IF EXISTS `paid_travel`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `paid_travel` AS SELECT 
 1 AS `Personnel_number`,
 1 AS `Дорожные: начало периода`,
 1 AS `Дорожные: конец периода`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vacation_schedule`
--

DROP TABLE IF EXISTS `vacation_schedule`;
/*!50001 DROP VIEW IF EXISTS `vacation_schedule`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vacation_schedule` AS SELECT 
 1 AS `Vacation_schedule_id`,
 1 AS `Structural_unit_id`,
 1 AS `Position_id`,
 1 AS `Табельный номер`,
 1 AS `Сотрудник`,
 1 AS `Вид отпуска`,
 1 AS `Начало отпуска`,
 1 AS `Конец отпуска`,
 1 AS `Итого дней отпуска`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vacation_schedules_list`
--

DROP TABLE IF EXISTS `vacation_schedules_list`;
/*!50001 DROP VIEW IF EXISTS `vacation_schedules_list`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vacation_schedules_list` AS SELECT 
 1 AS `Vacation_schedule_id`,
 1 AS `Дата составления`,
 1 AS `Название графика отпусков`,
 1 AS `Структурное подразделение`,
 1 AS `На год`,
 1 AS `Утвержден`,
 1 AS `Утвердившее лицо`,
 1 AS `Дата утверждения`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `vacationists`
--

/*!50001 DROP VIEW IF EXISTS `vacationists`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vacationists` AS select `al`.`Position_id` AS `Position_id`,`e`.`Surname_NF` AS `Surname_NF` from (`alternate_list` `al` join `employees` `e`) where (`al`.`Vacationist_personnel_number` = `e`.`Personnel_number`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vacation_data`
--

/*!50001 DROP VIEW IF EXISTS `vacation_data`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vacation_data` AS select `ev`.`Vacation_schedule_id` AS `Vacation_schedule_id`,`e`.`Personnel_number` AS `Табельный номер`,concat(`e`.`Surname`,' ',`e`.`Name`,' ',`e`.`Fathers_name`) AS `Фамилия, имя, отчество`,`su`.`Unit_short_title` AS `Подразделение`,`f`.`Function` AS `Должность`,`pc`.`Category_short_name` AS `Категория персонала`,`ev`.`Days_quantity` AS `Продолжительность отпуска`,`ev`.`Vacation_start_date` AS `Начало отпуска`,`ev`.`Vacation_finish_date` AS `Окончание отпуска`,`ev`.`Days_quantity` AS `Дни`,`vt`.`Vacation_type` AS `Вид отпуска` from (((((((`employees` `e` join `staffing_table` `st`) join `personnel_categories` `pc`) join `functions` `f`) join `employees_vacations` `ev`) join `vacation_schedules` `vs`) join `structural_units` `su`) join `vacation_types` `vt`) where ((`e`.`Personnel_number` = `st`.`Personnel_number`) and (`st`.`Function_id` = `f`.`Function_id`) and (`st`.`Category_id` = `pc`.`Category_id`) and (`e`.`Personnel_number` = `ev`.`Personnel_number`) and (`ev`.`Vacation_schedule_id` = `vs`.`Vacation_schedule_id`) and (`su`.`Unit_id` = `st`.`Unit_id`) and (`vt`.`Vacation_type_id` = `ev`.`Vacation_type_id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `parent_units`
--

/*!50001 DROP VIEW IF EXISTS `parent_units`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `parent_units` AS select `structural_units`.`Unit_id` AS `Unit_id`,`structural_units`.`Unit_full_title` AS `Unit_full_title`,`structural_units`.`Unit_short_title` AS `Unit_short_title` from `structural_units` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `paid_travel`
--

/*!50001 DROP VIEW IF EXISTS `paid_travel`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `paid_travel` AS select `employees_paid_travel`.`Personnel_number` AS `Personnel_number`,`employees_paid_travel`.`Start_date` AS `Дорожные: начало периода`,`employees_paid_travel`.`Finish_date` AS `Дорожные: конец периода` from `employees_paid_travel` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vacation_schedule`
--

/*!50001 DROP VIEW IF EXISTS `vacation_schedule`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vacation_schedule` AS select `ev`.`Vacation_schedule_id` AS `Vacation_schedule_id`,`vs`.`Structural_unit_id` AS `Structural_unit_id`,`ev`.`Position_id` AS `Position_id`,`e`.`Personnel_number` AS `Табельный номер`,`e`.`Surname_NF` AS `Сотрудник`,`vt`.`Vacation_type` AS `Вид отпуска`,`ev`.`Vacation_start_date` AS `Начало отпуска`,`ev`.`Vacation_finish_date` AS `Конец отпуска`,`ev`.`Days_quantity` AS `Итого дней отпуска` from (((`employees` `e` join `vacation_schedules` `vs`) join `vacation_types` `vt`) join `employees_vacations` `ev`) where ((`e`.`Personnel_number` = `ev`.`Personnel_number`) and (`vs`.`Vacation_schedule_id` = `ev`.`Vacation_schedule_id`) and (`vt`.`Vacation_type_id` = `ev`.`Vacation_type_id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vacation_schedules_list`
--

/*!50001 DROP VIEW IF EXISTS `vacation_schedules_list`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vacation_schedules_list` AS select `vs`.`Vacation_schedule_id` AS `Vacation_schedule_id`,`vs`.`Created` AS `Дата составления`,`vs`.`Title_vacation_schedule` AS `Название графика отпусков`,`su`.`Unit_short_title` AS `Структурное подразделение`,`vs`.`Vacation_schedule_year` AS `На год`,`vs`.`Status` AS `Утвержден`,`vs`.`Approved_by` AS `Утвердившее лицо`,`vs`.`Approvement_date` AS `Дата утверждения` from (`vacation_schedules` `vs` join `structural_units` `su`) where (`vs`.`Structural_unit_id` = `su`.`Unit_id`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-06-15 16:29:13
