-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: inventory_accounting
-- ------------------------------------------------------
-- Server version	5.7.21-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `company_details`
--

DROP TABLE IF EXISTS `company_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `company_details` (
  `Short_title` varchar(50) DEFAULT NULL,
  `Full_title` varchar(100) DEFAULT NULL,
  `INN` varchar(10) DEFAULT NULL,
  `KPP` varchar(9) DEFAULT NULL,
  `OKPO` varchar(10) NOT NULL,
  `Legal_address` varchar(100) DEFAULT NULL,
  `Actual_address` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`OKPO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `company_details`
--

LOCK TABLES `company_details` WRITE;
/*!40000 ALTER TABLE `company_details` DISABLE KEYS */;
INSERT INTO `company_details` VALUES ('краткое наименование','полное наименование','инн','кпп','окпо','г. Мураманск, ул. Челюскинцев, д.18','физический адресс');
/*!40000 ALTER TABLE `company_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `counterparties`
--

DROP TABLE IF EXISTS `counterparties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `counterparties` (
  `Line_id` int(11) NOT NULL AUTO_INCREMENT,
  `Counterparty` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`Line_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `counterparties`
--

LOCK TABLES `counterparties` WRITE;
/*!40000 ALTER TABLE `counterparties` DISABLE KEYS */;
INSERT INTO `counterparties` VALUES (1,'ООО \"Ромашка\"'),(2,'ООО \"Выгода\"'),(3,'ПАО \"МММ\"');
/*!40000 ALTER TABLE `counterparties` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory`
--

DROP TABLE IF EXISTS `inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory` (
  `Line_id` int(11) NOT NULL AUTO_INCREMENT,
  `Inventory_number` varchar(20) DEFAULT NULL,
  `Repository_id` int(11) NOT NULL,
  `Model_id` int(11) NOT NULL,
  `Waybill_note_id` int(11) NOT NULL,
  `Status_id` int(11) NOT NULL,
  `Price` int(11) DEFAULT NULL,
  PRIMARY KEY (`Line_id`),
  KEY `Inventory_status_idx` (`Status_id`),
  KEY `Repository_idx` (`Repository_id`),
  KEY `Waybill_note_idx` (`Waybill_note_id`),
  KEY `Model_id_idx` (`Model_id`),
  CONSTRAINT `Inventory_status` FOREIGN KEY (`Status_id`) REFERENCES `inventory_statuses` (`Line_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `Model` FOREIGN KEY (`Model_id`) REFERENCES `models` (`Line_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `Repository` FOREIGN KEY (`Repository_id`) REFERENCES `repositories` (`Line_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `Waybill_note` FOREIGN KEY (`Waybill_note_id`) REFERENCES `waybill_notes` (`Line_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory`
--

LOCK TABLES `inventory` WRITE;
/*!40000 ALTER TABLE `inventory` DISABLE KEYS */;
INSERT INTO `inventory` VALUES (1,'тест',4,1,3,1,15000),(2,'тест1',4,3,3,1,10800),(4,'зщш',4,1,3,1,18000),(5,'фкрке23у',1,5,1,1,515),(6,'ыкнлг',2,6,1,2,400),(7,'КМ-2018-02-кд',4,7,3,1,15990);
/*!40000 ALTER TABLE `inventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_acts`
--

DROP TABLE IF EXISTS `inventory_acts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory_acts` (
  `Line_id` int(11) NOT NULL AUTO_INCREMENT,
  `Date` date NOT NULL,
  `Number` varchar(20) NOT NULL,
  PRIMARY KEY (`Line_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_acts`
--

LOCK TABLES `inventory_acts` WRITE;
/*!40000 ALTER TABLE `inventory_acts` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory_acts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_categories`
--

DROP TABLE IF EXISTS `inventory_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory_categories` (
  `Line_id` int(11) NOT NULL AUTO_INCREMENT,
  `Inventory_category` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`Line_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_categories`
--

LOCK TABLES `inventory_categories` WRITE;
/*!40000 ALTER TABLE `inventory_categories` DISABLE KEYS */;
INSERT INTO `inventory_categories` VALUES (1,'Технические устройства'),(2,'Мебель'),(3,'Аксессуары'),(4,'Предметы декора'),(6,'Фигня');
/*!40000 ALTER TABLE `inventory_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_checking`
--

DROP TABLE IF EXISTS `inventory_checking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory_checking` (
  `Line_id` int(11) NOT NULL AUTO_INCREMENT,
  `Inventory_act_id` int(11) NOT NULL,
  `Inventory_id` int(11) NOT NULL,
  `Result` enum('нет','да') NOT NULL DEFAULT 'нет',
  PRIMARY KEY (`Line_id`),
  KEY `Inventory_id_idx` (`Inventory_id`),
  KEY `Inventory_act_idx` (`Inventory_act_id`),
  CONSTRAINT `Inventory_act` FOREIGN KEY (`Inventory_act_id`) REFERENCES `inventory_acts` (`Line_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `Inventory_id` FOREIGN KEY (`Inventory_id`) REFERENCES `inventory` (`Line_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_checking`
--

LOCK TABLES `inventory_checking` WRITE;
/*!40000 ALTER TABLE `inventory_checking` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory_checking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_statuses`
--

DROP TABLE IF EXISTS `inventory_statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory_statuses` (
  `Line_id` int(11) NOT NULL AUTO_INCREMENT,
  `Status` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`Line_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_statuses`
--

LOCK TABLES `inventory_statuses` WRITE;
/*!40000 ALTER TABLE `inventory_statuses` DISABLE KEYS */;
INSERT INTO `inventory_statuses` VALUES (1,'В наличии'),(2,'Списано'),(3,'Пропажа');
/*!40000 ALTER TABLE `inventory_statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_subcategories`
--

DROP TABLE IF EXISTS `inventory_subcategories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory_subcategories` (
  `Line_id` int(11) NOT NULL AUTO_INCREMENT,
  `Inventory_category_id` int(11) NOT NULL,
  `Inventory_subcategory` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`Line_id`),
  KEY `Inventory_category_idx` (`Inventory_category_id`),
  CONSTRAINT `Inventory_category` FOREIGN KEY (`Inventory_category_id`) REFERENCES `inventory_categories` (`Line_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_subcategories`
--

LOCK TABLES `inventory_subcategories` WRITE;
/*!40000 ALTER TABLE `inventory_subcategories` DISABLE KEYS */;
INSERT INTO `inventory_subcategories` VALUES (1,1,'Электронно-вычислительная техника'),(2,1,'Электронно-бытовая техника'),(3,2,'Офисная мебель'),(4,3,'Аксессуры для рабочей станции'),(5,2,'Кухонная мебель');
/*!40000 ALTER TABLE `inventory_subcategories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `models`
--

DROP TABLE IF EXISTS `models`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `models` (
  `Line_id` int(11) NOT NULL AUTO_INCREMENT,
  `Model` varchar(45) NOT NULL,
  `Ware_type_id` int(11) NOT NULL,
  PRIMARY KEY (`Line_id`),
  KEY `Ware_type_idx` (`Ware_type_id`),
  CONSTRAINT `Ware_type` FOREIGN KEY (`Ware_type_id`) REFERENCES `ware_types` (`Line_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `models`
--

LOCK TABLES `models` WRITE;
/*!40000 ALTER TABLE `models` DISABLE KEYS */;
INSERT INTO `models` VALUES (1,'Aser FP-1100-GeForce86-03',2),(2,'Саратовский МЗ К-09 Металлик  ',1),(3,'Диван угловой Ярославская МФ Д-62-2',4),(5,'Ведро с гвоздями',1),(6,'Пластиковый, с надписью \"Обама - козёл\"',5),(7,'Philips Grind & Brew HD7769',6);
/*!40000 ALTER TABLE `models` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personnel`
--

DROP TABLE IF EXISTS `personnel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personnel` (
  `Line_id` int(11) NOT NULL AUTO_INCREMENT,
  `Personnel_number` varchar(5) NOT NULL,
  `Surname` varchar(20) NOT NULL,
  `Name` varchar(15) NOT NULL,
  `Fathers_name` varchar(15) NOT NULL,
  `Surname_NF` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`Line_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personnel`
--

LOCK TABLES `personnel` WRITE;
/*!40000 ALTER TABLE `personnel` DISABLE KEYS */;
INSERT INTO `personnel` VALUES (1,'ИИИ01','Иванов','Иван','Иванович','Иванов И.И.'),(2,'ФВН01','Федорович','Василий','Николаевич','Федорович В.Н.'),(3,'ДМИ01','Денисов','Максим','Иванович','Денисов М.И.'),(4,'МАД01','Максимова','Анна','Дмитриевна','Максимова А.Д.'),(5,'СГВ01','Сидоров','Георгий','Владимирович','Сидоров Г.В.'),(6,'НАК01','Николаев','Александр','Константинович','Николаев А.К.'),(7,'ЛВИ01','Лосев','Василий','Иванович','Лосев В.И.'),(8,'СГВ02','Седов','Геннадий','Витальевич','Седов Г.В.');
/*!40000 ALTER TABLE `personnel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personnel_accounts`
--

DROP TABLE IF EXISTS `personnel_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personnel_accounts` (
  `Personnel_id` int(11) NOT NULL,
  `Login` varchar(10) NOT NULL,
  `Password` varchar(10) NOT NULL,
  `Role` enum('Администратор','Пользователь') NOT NULL DEFAULT 'Пользователь',
  `Attempts_quantity` tinyint(4) NOT NULL DEFAULT '3',
  PRIMARY KEY (`Personnel_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personnel_accounts`
--

LOCK TABLES `personnel_accounts` WRITE;
/*!40000 ALTER TABLE `personnel_accounts` DISABLE KEYS */;
INSERT INTO `personnel_accounts` VALUES (3,'3','3','Пользователь',3),(4,'1','1','Администратор',3),(5,'2','2','Администратор',3),(7,'5','5','Пользователь',3);
/*!40000 ALTER TABLE `personnel_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `repositories`
--

DROP TABLE IF EXISTS `repositories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `repositories` (
  `Line_id` int(11) NOT NULL AUTO_INCREMENT,
  `Repository` varchar(25) DEFAULT NULL,
  `Surety_person` int(11) NOT NULL,
  `Address` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`Line_id`),
  KEY `Surety_personl_idx` (`Surety_person`),
  CONSTRAINT `Surety_person` FOREIGN KEY (`Surety_person`) REFERENCES `personnel` (`Line_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repositories`
--

LOCK TABLES `repositories` WRITE;
/*!40000 ALTER TABLE `repositories` DISABLE KEYS */;
INSERT INTO `repositories` VALUES (1,'Основной склад',1,'Нижнеростинское шоссе, д.9, стр.5'),(2,'Кабинет гл. бухгалтера',7,'ул. Профсоюзов, д.18, каб. 415'),(3,'Розничный склад',3,'ул. Лобова, д.18, корп. 1'),(4,'Кабинет директора',2,'ул. Профсоюзов, д.18, каб. 417');
/*!40000 ALTER TABLE `repositories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ware_types`
--

DROP TABLE IF EXISTS `ware_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ware_types` (
  `Line_id` int(11) NOT NULL AUTO_INCREMENT,
  `Inventory_subcategory_id` int(11) NOT NULL,
  `Ware_type` varchar(25) NOT NULL,
  PRIMARY KEY (`Line_id`),
  KEY `Inventory_subcategory_idx` (`Inventory_subcategory_id`),
  CONSTRAINT `Inventory_subcategory` FOREIGN KEY (`Inventory_subcategory_id`) REFERENCES `inventory_subcategories` (`Line_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ware_types`
--

LOCK TABLES `ware_types` WRITE;
/*!40000 ALTER TABLE `ware_types` DISABLE KEYS */;
INSERT INTO `ware_types` VALUES (1,3,'Компьютерное кресло'),(2,1,'Ноутбук'),(3,3,'Компьютерный стол'),(4,3,'Офисный диван'),(5,4,'Коврик для мыши'),(6,2,'Кофемашина');
/*!40000 ALTER TABLE `ware_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `waybill_notes`
--

DROP TABLE IF EXISTS `waybill_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `waybill_notes` (
  `Line_id` int(11) NOT NULL AUTO_INCREMENT,
  `Date` date NOT NULL,
  `Number` varchar(20) NOT NULL,
  `Repository_id` int(11) NOT NULL,
  `Provider_id` int(11) NOT NULL,
  PRIMARY KEY (`Line_id`),
  KEY `Provider_idx` (`Provider_id`),
  CONSTRAINT `Provider` FOREIGN KEY (`Provider_id`) REFERENCES `counterparties` (`Line_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `waybill_notes`
--

LOCK TABLES `waybill_notes` WRITE;
/*!40000 ALTER TABLE `waybill_notes` DISABLE KEYS */;
INSERT INTO `waybill_notes` VALUES (1,'2019-02-04','ПН-2019-02-04-ДОП',2,1),(2,'2019-02-17','ПН-2019-02-17-ОСН',3,1),(3,'2019-02-22','ПН-2019-02-22-ДОП',4,1);
/*!40000 ALTER TABLE `waybill_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `write-off_acts`
--

DROP TABLE IF EXISTS `write-off_acts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `write-off_acts` (
  `Line_id` int(11) NOT NULL AUTO_INCREMENT,
  `Date` date NOT NULL,
  `Number` varchar(20) NOT NULL,
  PRIMARY KEY (`Line_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `write-off_acts`
--

LOCK TABLES `write-off_acts` WRITE;
/*!40000 ALTER TABLE `write-off_acts` DISABLE KEYS */;
INSERT INTO `write-off_acts` VALUES (3,'2019-04-26','АС-2019-04-26-ОСН'),(4,'2019-04-27','АС-2019-04-27-ОСН'),(5,'2019-04-04','кро');
/*!40000 ALTER TABLE `write-off_acts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `write-off_inventory`
--

DROP TABLE IF EXISTS `write-off_inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `write-off_inventory` (
  `Line_id` int(11) NOT NULL AUTO_INCREMENT,
  `Write-off_act_id` int(11) NOT NULL,
  `Inventory_id` int(11) NOT NULL,
  `Write-off_reason` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`Line_id`),
  KEY `Write-off_act_idx` (`Write-off_act_id`),
  KEY `Write-off_inventory_idx` (`Inventory_id`),
  CONSTRAINT `Write-off_act` FOREIGN KEY (`Write-off_act_id`) REFERENCES `write-off_acts` (`Line_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `Write-off_inventory` FOREIGN KEY (`Inventory_id`) REFERENCES `inventory` (`Line_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `write-off_inventory`
--

LOCK TABLES `write-off_inventory` WRITE;
/*!40000 ALTER TABLE `write-off_inventory` DISABLE KEYS */;
INSERT INTO `write-off_inventory` VALUES (1,4,6,'Смена президента пиндосов');
/*!40000 ALTER TABLE `write-off_inventory` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-05-26  1:07:38
